
CTD Entity exporter for 3ds max 5 ( also 5.1 )


14th august, 2005

info AT botorabi DOT de

http://yag2002.sourceforge.net

version:  1.1




release notes
-------------

this is an exporter for CTD entities. such entities are prefixed with $ in studio max model objects. the user-defined properties are used to specify entity parameters.


how to use
----------

every entity must be identified by its leading '$' character in its object name. then one of available entity names follows. the instance name is
given by appending ' : ' and an instance name. e.g.:

  to place a static mesh entity in level model a simple mesh ( e.g. a cube ) and give it the following name:

  $StaticMesh:barrel01


its parameters can be defined using mesh's user-defined properties. 

entity parameters must have the following format as user-defined peroperty:

 
  <Parameter name> [Type] = <Value>


  Parameter name: must be the exact name of any entity's parameter.

  Type must be one of parameter types:  Float, Integer, Vector3, String

  Value is the parameter value, for vectors use a space to separate the x, y, and z components.


legal macros for parameter values are:

  $POSITION      object's world position
  $ROTATION      object's world rotation as euler angles
  $DIMENSIONS    objec'ts bounding box dimensions
  
  
  
build notes
-----------

there are vc7.1 project files to build the package. further you need 3ds max's sdk and IGame library. 

set the include and lib paths of 3ds max sdk into vc7.1 studio's project settings ( menu Tools/Options.../Projects/VC++ Directories )
  
  
   
install notes
-------------

1. copy the file 'CTD-entityexporter5.dle' into folder <3dsmax install path>/plugins

2. copy the file 'IGame.dll' in lib directory into <3dsmax install path>


