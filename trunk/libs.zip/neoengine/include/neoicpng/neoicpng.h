/***************************************************************************
                          neoicpng.h  -  description
                             -------------------
    begin                : Fri Aug 23 2002
    copyright            : (C) 2002 by Mattias Jansson
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoICPNG, neoicpng.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOICPNG_H
#define __NEOICPNG_H


#include <neoengine/base.h>
#include <neoengine/texture.h>


namespace NeoPNG
{


/**
  * \brief Image loader codec for png files
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class ImageCodec : public NeoEngine::ImageCodec
{
	public:

		/**
		* Create new PNG loader codec object
		* \param rvstrExtensions        Extension string vector
		*/
		                                ImageCodec( const std::vector<std::string> &rvstrExtensions );

		/**
		*/
		virtual                        ~ImageCodec();

		/**
		* Check if file is a PNG file
		* \param pkFile                 File to check
		* \return                       true if PNG file, false if not recognized
		*/
		virtual bool                    IsType( NeoEngine::File *pkFile );

		/**
		* Loads data from file
		* \param pkFile                 File
		* \return                       Ptr to new ImageData object
		*/
		virtual NeoEngine::ImageData   *LoadImage( NeoEngine::File *pkFile );

		/**
		* Free image data
		* \param pkImageData            Image data
		*/
		virtual void                    FreeImage( NeoEngine::ImageData *pkImageData );

		/**
		* Write image data to file
		* \param pkImageData            Image to write
		* \param pkFile                 File to write image to
		*/
		virtual bool                    WriteImage( NeoEngine::ImageData *pkImageData, NeoEngine::File *pkFile );
};


}; // namespace NeoPNG


#endif
