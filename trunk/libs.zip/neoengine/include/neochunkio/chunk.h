/***************************************************************************
                         chunk.h  -  Chunk base class
                             -------------------
    begin                : Tue Feb 18 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, chunk.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef _NEOCHUNKIO_CHUNK_H_
#define _NEOCHUNKIO_CHUNK_H_


/**
  * \file neochunkio/chunk.h
  * Chunk base class
  */
  

#include "base.h"
#include "chunkio.h"
#include "chunktype.h"

#include <neoengine/hashstring.h>
#include <neoengine/file.h>

#include <assert.h>

#include <vector>


// External classes
namespace NeoEngine
{
	class FileManager;
	class File;
};


namespace NeoChunkIO
{


#ifdef WIN32
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif
#  ifndef __HAVE_VECTOR_NECHUNK
     ChunkIOUDTVectorEXPIMP( class Chunk* );
#    define __HAVE_VECTOR_NECHUNK
#  endif
#endif



/**
  * \brief Chunk base class
  * All chunks are derived from this base class. Derived implementations
  * should only overload the ReadData, ParseData, WriteData and GetSize methods.
  * Do not inherit from this base class directly, but from the PrimitiveChunk and
  * ComplexChunk classes.
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOCHUNKIO_API Chunk
{
	protected:
	
		/*! Chunk type */
		unsigned short                                m_usType;

		/*! Type as string */
		NeoEngine::HashString                         m_strType;
	
		/*! Chunk ID */
		NeoEngine::HashString                         m_strID;
		
		/*! Chunk type used in search */
		unsigned short                                m_usFindType;

		/*! Sub chunks */
		std::vector< Chunk* >                         m_vpkSubChunks;
						

		
		
	public:

		/*! Parse flag. If false, the chunk will not be parsed */
		bool                                          m_bParse;
		

		/**
		* Initialize chunk
		* \param usType                               Chunk type
		* \param rstrType                             Chunk type as string
		* \param rstrID                               Chunk ID string
		*/ 
		                                              Chunk( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID = "" ) : m_usType( usType ), m_strType( rstrType ), m_strID( rstrID ), m_usFindType( usType ), m_bParse( true ) {}

		/**
		* Deallocate data and subchunks
		*/
		virtual                                      ~Chunk();

		/**
		* Attach subchunk
		* \param pkChunk                              Chunk to attach
		* \param bReplace                             Replace and deallocate old chunk of same type and ID (default false)
		*/
		void                                          AttachChunk( Chunk *pkChunk, bool bReplace = false );

		/**
		* Locate chunk in hierarchy matching chunk properties
		* \param rstrID                               Chunk ID
		* \param usType                               Chunk type, ignored if zero
		* \param iRecurse                             Recurse on sub (1 - recurse infinite, 0 - only ourselves, -1 only child nodes - default)
		* \param bIgnoreID                            Ignore matching ID string
		* \return                                     Ptr to first chunk matching search criteria
		*/
		Chunk                                        *FindChunk( const NeoEngine::HashString &rstrID, unsigned short usType, int iRecurse = -1, bool bIgnoreID = false );

		/**
		* Find all subchunks matching query
		* \param rstrID                               Chunk ID
		* \param usType                               Chunk type, ignored if zero
		* \param pvpkResult                           Vector of chunk pointers receiving pointers to matching subchunks (if null, only count)
		* \param bRecurse                             Recurse on subchunks (default false, search only our subchunks)
		* \param bIgnoreID                            Ignore matching ID string
		* \return                                     Number of chunks found
		*/
		int                                           FindChunks( const NeoEngine::HashString &rstrID, unsigned short usType, std::vector< Chunk* > *pvpkResult, bool bRecurse = false, bool bIgnoreID = false );

		/**
		* \return                                     Subchunk vector
		*/
		inline const std::vector< Chunk* >           &GetSubChunks() const { return m_vpkSubChunks; }

		/**
		* \return                                     Chunk type
		*/
		inline unsigned short                         GetType() const { return m_usType; }

		/**
		* \return                                     Chunk type as string
		*/
		inline const NeoEngine::HashString           &GetTypeAsString() const { return m_strType; }

		/**
		* \return                                     Chunk ID
		*/
		inline const NeoEngine::HashString           &GetID() const { return m_strID; }
		
		/**
		* Get size of chunk in binary mode
		* \param bIncludeHeader                       If true, add header of chunk (type + ID) to size as well as subchunks and data
		* \return                                     Size of chunk data in bytes as if read/written from/to file
		*/
		virtual int                                   GetSize( bool bIncludeHeader = false ) const = 0;

		/**
		* \return                                     true if complex chunk, false if primitive
		*/
		virtual bool                                  IsComplex() const = 0;

		/**
		* Read chunk data from file
		* \param pkFile                               File
		* \param eMode                                Chunk mode (ChunkIO::ASCII or ChunkIO::BINARY)
		* \param uiEnd                                Bytes to end of chunk (in binary mode)
		* \return                                     <0 if error, number of bytes read if successful
		*/
		virtual int                                   ReadData( NeoEngine::File *pkFile, ChunkIO::CHUNKIOMODE eMode, unsigned int uiEnd ) { return 0; }

		/**
		* Parse chunk data
		* \param uiFlags                              Parse flags
		* \param pkFileManager                        File manager
		* \return                                     <0 if error, >0 if successful (0 reserved)
		*/
		virtual int                                   ParseData( unsigned int uiFlags, NeoEngine::FileManager *pkFileManager ) { return 0; }

		/**
		* Write chunk data to file
		* \param pkFile                               File
		* \param eMode                                Chunk mode (ChunkIO::ASCII or ChunkIO::BINARY)
		* \param uiLevel                              Recursion level for ascii format
		* \return                                     <0 if error, number of bytes written if successful
		*/
		virtual int                                   WriteData( NeoEngine::File *pkFile, ChunkIO::CHUNKIOMODE eMode, unsigned int uiLevel ) { return 0; }

		/**
		* Parse child chunks, then ourselves
		* \param uiFlags                              Parse flags
		* \param pkFileManager                        File manager object
		* \return                                     <0 if error, >0 if successful (0 reserved for future use)
		*/
		int                                           ParseRecursive( unsigned int uiFlags, NeoEngine::FileManager *pkFileManager );
};


};


#endif
