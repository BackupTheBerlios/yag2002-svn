/***************************************************************************
                   core_inl.h  -  Chunk I/O core object and services
                             -------------------
    begin                : Tue Jan 20 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, core_inl.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


NEOCHUNKIO_API NotifyCallback *Core::SetNotifyCallback( NotifyCallback *pkCallback )
{
	NotifyCallback *pkOld = m_pkNotifyCallback;
	m_pkNotifyCallback = pkCallback;
	return pkOld;
}


NEOCHUNKIO_API NotifyCallback *Core::GetNotifyCallback()
{
	return m_pkNotifyCallback;
}


NEOCHUNKIO_API Core *Core::Get()
{
	if( !s_pkSingleton )
		s_pkSingleton = new Core;
	return s_pkSingleton;
}

