/***************************************************************************
                   technique.h  -  Material technique chunk
                             -------------------
    begin                : Fri Jan 9 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, technique.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef _NECHUNKIO_TECHNIQUE_H_
#define _NECHUNKIO_TECHNIQUE_H_


/**
  * \file neochunkio/technique.h
  * Material technique chunk
  */


#include "base.h"
#include "complex.h"

#include <neoengine/material.h>
#include <neoengine/shader.h>


namespace NeoChunkIO
{


/**
  * \brief Material technique pass chunk
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOCHUNKIO_API TechniquePassChunk : public ComplexChunk
{
	public:

		/*! Material for this technique */
		NeoEngine::MaterialPass                      *m_pkPass;


		/**
		* Initialize chunk
		* \param usType                               Chunk type
		* \param rstrType                             Chunk type as string
		* \param rstrID                               Chunk ID string
		*/ 
		                                              TechniquePassChunk( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID = "" ) : ComplexChunk( usType, rstrType, rstrID ), m_pkPass( 0 ) {}
		
		/**
		* Setup chunk with default values
		* \param rstrID                               Chunk ID string, default empty
		*/
													  TechniquePassChunk( const NeoEngine::HashString &rstrID = "" ) : ComplexChunk( ChunkType::PASS, "pass", rstrID ), m_pkPass( 0 ) {}
		
		/**
		* Deallocate data and subchunks
		*/
		virtual                                      ~TechniquePassChunk();

		/**
		* Parse chunk data
		* \param uiFlags                              Parse flags
		* \param pkFileManager                        File manager
		* \return                                     <0 if error, >0 if successful (0 reserved)
		*/
		virtual int                                   ParseData( unsigned int uiFlags, NeoEngine::FileManager *pkFileManager );

		/**
		* Allocate new chunk
		* \param usType                               Type identifier
		* \param rstrType                             Type identifier as string
		* \param rstrID                               ID string
		* \return                                     New chunk
		*/
		static Chunk                                 *Allocator( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID ) { return new TechniquePassChunk( usType, rstrType, rstrID ); }
};


/**
  * \brief Material technique chunk
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOCHUNKIO_API TechniqueChunk : public TechniquePassChunk
{
	public:

		/*! Material for this technique */
		NeoEngine::MaterialPtr                        m_pkMaterial;

		/*! Flag indicating this technique is compatible with the hardware */
		bool                                          m_bIsCompatible;


		/**
		* Initialize chunk
		* \param usType                               Chunk type
		* \param rstrType                             Chunk type as string
		* \param rstrID                               Chunk ID string
		*/ 
		                                              TechniqueChunk( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID = "" ) : TechniquePassChunk( usType, rstrType, rstrID ), m_bIsCompatible( true ) {}
		
		/**
		* Setup chunk with default values
		* \param rstrID                               Chunk ID string, default empty
		*/
													  TechniqueChunk( const NeoEngine::HashString &rstrID = "" ) : TechniquePassChunk( ChunkType::TECHNIQUE, "technique", rstrID ), m_bIsCompatible( true ) {}
		
		/**
		* Deallocate data and subchunks
		*/
		virtual                                      ~TechniqueChunk();

		/**
		* Check that technique is compatible with device
		* \param pkFile                               File
		* \param eMode                                Chunk mode (ChunkIO::ASCII or ChunkIO::BINARY)
		* \param uiEnd                                Bytes to end of chunk (in binary mode)
		* \return                                     <0 if error, number of bytes read if successful
		*/
		virtual int                                   ReadData( NeoEngine::File *pkFile, ChunkIO::CHUNKIOMODE eMode, unsigned int uiEnd );

		/**
		* Parse chunk data
		* \param uiFlags                              Parse flags
		* \param pkFileManager                        File manager
		* \return                                     <0 if error, >0 if successful (0 reserved)
		*/
		virtual int                                   ParseData( unsigned int uiFlags, NeoEngine::FileManager *pkFileManager );

		/**
		* Allocate new chunk
		* \param usType                               Type identifier
		* \param rstrType                             Type identifier as string
		* \param rstrID                               ID string
		* \return                                     New chunk
		*/
		static Chunk                                 *Allocator( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID ) { return new TechniqueChunk( usType, rstrType, rstrID ); }
};


};


#endif

