/***************************************************************************
                     polygonbuffer.h  -  Polygonbuffer chunk
                             -------------------
    begin                : Wed Feb 26 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, polygonbuffer.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef _NECHUNKIO_POLYGONBUFFER_H_
#define _NECHUNKIO_POLYGONBUFFER_H_


/**
  * \file polygonbuffer.h
  * Polygonbuffer chunk
  */


#include "base.h"
#include "complex.h"

#include <neoengine/polygonbuffer.h>


namespace NeoChunkIO
{


/**
  * \class PolygonBufferChunk
  * \brief Polygon buffer chunk
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOCHUNKIO_API PolygonBufferChunk : public ComplexChunk
{
	public:

		/*! Polygon buffer */
		NeoEngine::PolygonBufferPtr                   m_pkBuffer;

		/**
		* Initialize chunk
		* \param usType                               Chunk type
		* \param rstrType                             Chunk type as string
		* \param rstrID                               Chunk ID string
		*/ 
		                                              PolygonBufferChunk( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID = "" ) : ComplexChunk( usType, rstrType, rstrID ) {}
		
		/**
		* Setup chunk with default values
		* \param pkBuffer                             Polygon buffer object
		* \param rstrID                               Chunk ID string, default empty
		* \param bCreateSubChunk                      Create subchunks from polygon buffer object data (num, type) if true
		*/
		                                              PolygonBufferChunk( const NeoEngine::PolygonBufferPtr &pkBuffer, const NeoEngine::HashString &rstrID = "", bool bCreateSubChunk = false ) : ComplexChunk( ChunkType::POLYGONBUFFER, "polygonbuf", rstrID ), m_pkBuffer( pkBuffer ) { if( bCreateSubChunk ) { SetTypeChunk( pkBuffer->GetType() ); SetNumChunk( pkBuffer->GetNumElements() ); } }
		
		/**
		* Deallocate data and subchunks
		*/
		virtual                                      ~PolygonBufferChunk() {}

		/**
		* Get size of chunk in binary mode
		* \param bIncludeHeader                       Add header of chunk (type + ID) to size as well as subchunks and data
		* \return                                     Size of chunk data in bytes as if read/written from/to file
		*/
		virtual int                                   GetSize( bool bIncludeHeader = false ) const;

		/**
		* Read chunk data from file
		* \param pkFile                               File
		* \param eMode                                Chunk mode (ChunkIO::ASCII or ChunkIO::BINARY)
		* \param uiEnd                                Bytes to end of chunk (in binary mode)
		* \return                                     <0 if error, number of bytes read if successful
		*/
		virtual int                                   ReadData( NeoEngine::File *pkFile, ChunkIO::CHUNKIOMODE eMode, unsigned int uiEnd );

		/**
		* Parse chunk data
		* \param uiFlags                              Parse flags
		* \param pkFileManager                        File manager
		* \return                                     <0 if error, >0 if successful (0 reserved)
		*/
		virtual int                                   ParseData( unsigned int uiFlags, NeoEngine::FileManager *pkFileManager );
		
		/**
		* Write chunk data to file
		* \param pkFile                               File
		* \param eMode                                Chunk mode (ChunkIO::ASCII or ChunkIO::BINARY)
		* \param uiLevel                              Recursion level for ascii format
		* \return                                     <0 if error, number of bytes written if successful
		*/
		virtual int                                   WriteData( NeoEngine::File *pkFile, ChunkIO::CHUNKIOMODE eMode, unsigned int uiLevel );

		/**
		* Set num subchunk
		* \param uiNumElements                        Number of elements
		*/
		void                                          SetNumChunk( unsigned int uiNumElements );

		/**
		* Set buffer type subchunk
		* \param uiType                               Buffer type
		*/
		void                                          SetTypeChunk( unsigned int uiType );

		/**
		* Allocate new chunk
		* \param usType                               Type identifier
		* \param rstrType                             Type identifier as string
		* \param rstrID                               ID string
		* \return                                     New chunk
		*/
		static Chunk                                 *Allocator( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID ) { return new PolygonBufferChunk( usType, rstrType, rstrID ); }
};


}; // namespace NeoChunkIO


#endif

