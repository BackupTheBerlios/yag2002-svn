/***************************************************************************
                         scene.h  -  Scene file loader
                             -------------------
    begin                : Thu Nov 1 2001
    copyright            : (C) 2001 by Mattias Jansson
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, scene.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOCHUNKIO_SCENE_H
#define __NEOCHUNKIO_SCENE_H


/**
  * \file scene.h
  * Scene file loader interface
  */


#include "base.h"

#include <neoengine/loadableentity.h>
#include <neoengine/scenenode.h>
#include <neoengine/mesh.h>


// External classes
namespace NeoEngine
{
	class FileManager;
	class Room;


#ifdef WIN32
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif
#  ifndef __HAVE_VECTOR_NEROOM
     ChunkIOUDTVectorEXPIMP( class Room* );
#    define __HAVE_VECTOR_NEROOM
#  endif
#endif


};


namespace NeoChunkIO
{


/**
  * \class Scene
  * \brief Scene file loader class
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOCHUNKIO_API Scene : public NeoEngine::LoadableEntity, public NeoEngine::SceneNode
{
	public:

		/**
		* \enum NESCENELOADERFLAG
		* \brief Flags passed to scene loader
		*/
		enum NESCENELOADERFLAG
		{	
		  /*! This flag prevents creation of mesh instances of blueprints */
		  NOINSTANCES                                 = 0x00000001,

		  /*! This flag forces stipification of all polygon buffers */
		  STRIPIFYALL                                 = 0x00000002
		};




	protected:

		/*! Meshes */
		std::vector< NeoEngine::MeshPtr >             m_vpkMeshes;

		/*! Loading flags */
		unsigned int                                  m_uiLoadFlags;

		
  
		/**
		* Load scene
		* \return                                     true if successful, false otherwise
		*/
		virtual bool                                  LoadNode( unsigned int uiFlags );




	public:

		/*! Rooms (this will probably change in the future) */
		std::vector< NeoEngine::Room* >               m_vpkRooms;

		

		/**
		* \param pkFileManager                        File manager, will use engine core file manager if null (default)
		*/
		                                              Scene( NeoEngine::FileManager *pkFileManager = 0 );

		/**
		* Deallocate memory and attached nodes
		*/
		virtual                                      ~Scene();

		/**
		* Locate mesh blueprint
		* \param rstrName                             Mesh name
		* \return                                     Ptr to mesh if found, null if not
		*/
		NeoEngine::MeshPtr                            GetMesh( const NeoEngine::HashString &rstrName );

		/**
		* \return                                     Vector of all mesh blueprints in scene
		*/
		const std::vector< NeoEngine::MeshPtr >      &GetMeshes() const { return m_vpkMeshes; }
};


}; // namespace NeoChunkIO



#endif
