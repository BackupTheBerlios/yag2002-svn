/***************************************************************************
                   texmatrixgen.h  -  Texture matrix gen chunk
                             -------------------
    begin                : Wed Feb 26 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, texmatrixgen.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef _NECHUNKIO_TEXMATRIXGEN_H_
#define _NECHUNKIO_TEXMATRIXGEN_H_


/**
  * \file neochunkio/texmatrixgen.h
  * Texture matrix gen chunk
  */


#include "base.h"
#include "complex.h"


// External classes
namespace NeoEngine
{
	class TextureMatrixGen;
};


namespace NeoChunkIO
{


/**
  * \brief Texture matrix gen chunk
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOCHUNKIO_API TextureMatrixGenChunk : public ComplexChunk
{
	public:

		/*! Texture matrix gen object */
		NeoEngine::TextureMatrixGen                  *m_pkGen;

		/**
		* Initialize chunk
		* \param usType                               Chunk type
		* \param rstrType                             Chunk type as string
		* \param rstrID                               Chunk ID string
		*/ 
		                                              TextureMatrixGenChunk( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID = "" ) : ComplexChunk( usType, rstrType, rstrID ), m_pkGen( 0 ) {}
		
		/**
		* Deallocate data and subchunks
		*/
		virtual                                      ~TextureMatrixGenChunk();

		/**
		* Parse chunk data
		* \param uiFlags                              Parse flags
		* \param pkFileManager                        File manager
		* \return                                     <0 if error, >0 if successful (0 reserved)
		*/
		virtual int                                   ParseData( unsigned int uiFlags, NeoEngine::FileManager *pkFileManager );

		/**
		* Allocate new chunk
		* \param usType                               Type identifier
		* \param rstrType                             Type identifier as string
		* \param rstrID                               ID string
		* \return                                     New chunk
		*/
		static Chunk                                 *Allocator( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID ) { return new TextureMatrixGenChunk( usType, rstrType, rstrID ); }
};


};


#endif

