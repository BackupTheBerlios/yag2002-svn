/***************************************************************************
                 chunktype.h  -  Builtin chunk type identifiers
                             -------------------
    begin                : Wed Feb 26 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, chunktype.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef _NEOCHUNKIO_CHUNKTYPE_H_
#define _NEOCHUNKIO_CHUNKTYPE_H_


/**
  * \file neochunkio/chunktype.h
  * Builtin chunk type identifiers
  */
  
  
#include "base.h"


namespace NeoChunkIO
{


/**
  * \brief Chunk type identifier class with builtin chunk type identifiers
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOCHUNKIO_API ChunkType
{
	public:

		/**
		* \brief Builtin chunk type identifiers and string identifiers. External chunk types must not have identifiers within range [FIRSTBUILTINTYPE,LASTBUILTINTYPE]
		*/
		enum CHUNKTYPE
		{
		  UNKNOWN                     = 0xFFFF,

		  FIRSTBUILTINCHUNKTYPE       = 0x0000,

		  //Primitive types
		  PRIMITIVE                   = 0x1000,
		  STRING                      = 0x1001, // "str"
		  INTEGER                     = 0x1002, // "int"
		  FLOAT                       = 0x1003, // "flt"
		  SHORT                       = 0x1004, // "sht"
		  BOOL                        = 0x1006, // "bool"
		  VECTOR                      = 0x1010, // "vec"
		  QUATERNION                  = 0x1011, // "quat"
		  MATRIX                      = 0x1012, // "mat"
		  COLOR                       = 0x1020, // "col"
			

		  //Complex types
		  COMPLEX                     = 0x2000,

		  SCENENODE                   = 0x2001, // "node", ALSO USED FOR SEARCH TYPE FOR ALL NODE CHUNK TYPES
		  ANIMATEDNODE                = 0x2002, // "animnode"
		  PHYSICSNODE                 = 0x2003, // "physnode"
		  MASSPARTICLENODE            = 0x2004, // "massnode"
		  RIGIDBODYNODE               = 0x2005, // "rigidnode"

		  BONE                        = 0x2010, // "bone"
		  SKELETON                    = 0x2011, // "skeleton"

		  NODEKEYFRAME                = 0x2020, // "nodekey"
		  SUBMESHKEYFRAME             = 0x2021, // "submeshkey"

		  NODEANIMATION               = 0x2030, // "nodeanim"
		  SUBMESHANIMATION            = 0x2031, // "submeshanim"
		  SKELETONANIMATION           = 0x2032, // "skeletonanim"

		  MATERIAL                    = 0x2040, // "material"
		  TEXTURELAYER                = 0x2041, // "texlayer"
		  TEXMATRIXGEN                = 0x2042, // "texmatrixgen"
		  TECHNIQUE                   = 0x2043, // "technique"
		  SHADER                      = 0x2044, // "shader"
		  PASS                        = 0x2045, // "pass"

		  VERTEXBUFFER                = 0x2050, // "vertexbuf"
		  POLYGONBUFFER               = 0x2051, // "polygonbuf"
		  POLYGONSTRIPBUFFER          = 0x2052, // "stripbuf"
		  SKINVERTEXBUFFER            = 0x2053, // "skinvertexbuf"

		  BOUNDINGVOLUME              = 0x2060, // NOT USED IN FILES, only for accessing specific volumes through one chunk type
		  AABB                        = 0x2061, // "aabb"
		  OBB                         = 0x2062, // "obb"
		  SPHERE                      = 0x2063, // "sphere"

		  SKIN                        = 0x2070, // "skin"

		  SUBMESH                     = 0x2080, // "submesh", ALSO USED FOR SEARCH TYPE FOR ALL SUBMESH CHUNK TYPES
		  ANIMATEDSUBMESH             = 0x2081, // "animatedsubmesh"
		  PATCHSUBMESH                = 0x2082, // "patchsubmesh"
		  SKELETALSUBMESH             = 0x2083, // "skeletalsubmesh"

		  MESH                        = 0x2090, // "mesh"        (old name "meshblp")
		  MESHENTITY                  = 0x2091, // "meshentity"  (old name "meshinstance")

		  ROOM                        = 0x20a0, // NOT USED IN FILES, only for accessing specific rooms through one chunk type
		  //OCTATREEROOM                = 0x20a1, // "octatree" DEPRECATED - not supported anymore
		  BSPROOM                     = 0x20a2, // "bsp"
		  ABTROOM                     = 0x20a3, // "abt"

		  BSPNODE                     = 0x20b0, // "bspnode"
		  BSPLEAF                     = 0x20b1, // "bspleaf"
		  BSPVISCLUSTER               = 0x20b2, // "bspviscluster"

		  SKYDOME                     = 0x20c0, // "skydome"
		  SKYBOX                      = 0x20c1, // "skybox"

		  LIGHT                       = 0x20d0, // "light"

		  SCENEENTITY                 = 0x2100, // "sceneentity", USED FOR ALL SCENE ENTITIES

		  NOTIFY                      = 0x2200, // "notify"

		  /*! CHUNK ID 0x3A00 TO 0x3FFF RESERVED BY NEOWTK EXTENSION */

		  LASTBUILTINCHUNKTYPE        = 0x3FFF,

		  INVALID                     = 0xFFFF
		};
};


};


#endif
