/***************************************************************************
                     integer.h  -  Integer primitive chunk
                             -------------------
    begin                : Tue Feb 25 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, integer.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef _NEOCHUNKIO_INTEGER_H_
#define _NEOCHUNKIO_INTEGER_H_


/**
  * \file integer.h
  * Integer primitive chunk
  */
  

#include "base.h"
#include "primitive.h"


namespace NeoChunkIO
{


/**
  * \brief Integer primitive chunk
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOCHUNKIO_API IntChunk : public PrimitiveChunk
{
	public:

		/*! Data */
		int                                           m_iData;
		
	
		/**
		* Initialize chunk
		* \param usType                               Chunk type
		* \param rstrType                             Chunk type as string
		* \param rstrID                               Chunk ID string
		*/ 
		                                              IntChunk( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID = "" ) : PrimitiveChunk( usType, rstrType, rstrID ) {}
		
		/**
		* Setup chunk with default values
		* \param iData                                Data value
		* \param rstrID                               Chunk ID string, default empty
		*/
		                                              IntChunk( int iData, const NeoEngine::HashString &rstrID = "" ) : PrimitiveChunk( ChunkType::INTEGER, "int", rstrID ), m_iData( iData ) {}
		
		/**
		* Deallocate data and subchunks
		*/
		virtual                                      ~IntChunk() {}

		/**
		* Get size of chunk in binary mode
		* \param bIncludeHeader                       Add header of chunk (type + ID) to size as well as subchunks and data
		* \return                                     Size of chunk data in bytes as if read/written from/to file
		*/
		virtual int                                   GetSize( bool bIncludeHeader = false ) const { return( PrimitiveChunk::GetSize( bIncludeHeader ) + 4 ); }

		/**
		* Read chunk data from file
		* \param pkFile                               File
		* \param eMode                                Chunk mode (ChunkIO::ASCII or ChunkIO::BINARY)
		* \param uiEnd                                Bytes to end of chunk (in binary mode)
		* \return                                     <0 if error, number of bytes read if successful
		*/
		virtual int                                   ReadData( NeoEngine::File *pkFile, ChunkIO::CHUNKIOMODE eMode, unsigned int uiEnd );

		/**
		* Write chunk data to file
		* \param pkFile                               File
		* \param eMode                                Chunk mode (ChunkIO::ASCII or ChunkIO::BINARY)
		* \param uiLevel                              Recursion level for ascii format
		* \return                                     <0 if error, number of bytes written if successful
		*/
		virtual int                                   WriteData( NeoEngine::File *pkFile, ChunkIO::CHUNKIOMODE eMode, unsigned int uiLevel );

		/**
		* Allocate new chunk
		* \param usType                               Type identifier
		* \param rstrType                             Type identifier as string
		* \param rstrID                               ID string
		* \return                                     New chunk
		*/
		static Chunk                                 *Allocator( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID ) { return new IntChunk( usType, rstrType, rstrID ); }
};


}; // namespace NeoChunkIO


#endif
