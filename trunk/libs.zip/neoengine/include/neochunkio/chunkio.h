/***************************************************************************
                     chunkio.h  -  I/O routines for chunk files
                             -------------------
    begin                : Tue Feb 25 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, chunkio.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef _NEOCHUNKIO_CHUNKIO_H_
#define _NEOCHUNKIO_CHUNKIO_H_


/**
  * \file chunkio.h
  * I/O routines for chunk files
  */


#include "base.h"


// External classes
namespace NeoEngine
{
	class File;
	class FileManager;
};


namespace NeoChunkIO
{


// External classes
class Chunk;


/**
  * \brief Reads/writes chunks from/to file
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOCHUNKIO_API ChunkIO
{
	public:

		/**
		* \enum CHUNKIOMODE
		* \brief File mode defines (binary or ascii)
		*/
		enum CHUNKIOMODE
		{
		  /*! Binary file */
		  BINARY                                      = 0,

		  /*! Text file */
		  ASCII                                       = 1
		};

		
		/**
		* \enum CHUNKIOPARSEFLAG
		* \brief Builtin parse flag identifiers
		*/
		enum CHUNKIOPARSEFLAG
		{
		  /*! First reserved flag */
		  FIRSTBUILTINFLAG                            = 0x00000000,
		  
		  /*! No flags */
		  NONE                                        = 0x00000000,
		  
		  /*! Stripify all polygon buffers */
		  STRIPIFYALL                                 = 0x00000001,

		  /*! Last reserved flag */
		  LASTBUILTINFLAG                             = 0x0000FFFF
		};


		/**
		* \enum CHUNKIOVERSIONREQ
		* \brief Minimum required version of chunk format
		*/
		enum CHUNKIOVERSIONREQ
		{
		  /*! Major version required */
		  MAJORVERSIONREQUIRED                        = 0,

		  /*! Minor version required */
		  MINORVERSIONREQUIRED                        = 30
		};

		

	public:	

		/*! File I/O mode */
		CHUNKIOMODE                                   m_eMode;

		/*! Chunk format major version */
		int                                           m_iMajorVersion;

		/*! Chunk format minor version */
		int                                           m_iMinorVersion;



		/**
		* Default to text mode
		*/
		                                              ChunkIO( CHUNKIOMODE eMode = ASCII ) : m_eMode( eMode ), m_iMajorVersion( MAJORVERSIONREQUIRED ), m_iMinorVersion( MINORVERSIONREQUIRED ) {}

		/**
		* Read chunk from file
		* \param pkFile                               File
		* \return                                     Chunk object read, 0 if invalid file or EOF
		*/
		Chunk                                        *ReadChunk( NeoEngine::File *pkFile );

		/**
		* Parse chunk
		* \param pkChunk                              Chunk to parse
		* \param uiFlags                              Parse flags
		* \param pkFileManager                        File manager
		* \return                                     <0 if error, >=0 if successful
		*/
		int                                           ParseChunk( Chunk *pkChunk, unsigned int uiFlags, NeoEngine::FileManager *pkFileManager );

		/**
		* Write chunk to file
		* \param pkChunk                              Chunk to write
		* \param pkFile                               File
		* \param uiLevel                              Current recursion level (used for ascii files)
		*/
		void                                          WriteChunk( Chunk *pkChunk, NeoEngine::File *pkFile, unsigned int uiLevel = 0 );
};


}; // namespace NeoChunkIO


#endif
