/***************************************************************************
                     vertexbuffer.h  -  Vertexbuffer chunk
                             -------------------
    begin                : Wed Feb 26 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, vertexbuffer.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef _NECHUNKIO_VERTEXBUFFER_H_
#define _NECHUNKIO_VERTEXBUFFER_H_


/**
  * \file neochunkio/vertexbuffer.h
  * Vertexbuffer chunk
  */


#include "base.h"
#include "complex.h"

#include <neoengine/vertexbuffer.h>


namespace NeoChunkIO
{


/**
  * \brief Vertex buffer chunk
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOCHUNKIO_API VertexBufferChunk : public ComplexChunk
{
	public:

		/*! Vertex buffer object */
		NeoEngine::VertexBufferPtr                    m_pkBuffer;

		/**
		* Initialize chunk
		* \param usType                               Chunk type
		* \param rstrType                             Chunk type as string
		* \param rstrID                               Chunk ID string
		*/ 
		                                              VertexBufferChunk( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID = "" ) : ComplexChunk( usType, rstrType, rstrID, 2 ) {}
		
		/**
		* Setup chunk with default values
		* \param pkBuffer                             Vertex buffer object
		* \param rstrID                               Chunk ID string, default empty
		* \param bCreateSubChunks                     Create subchunks from vertex buffer object data (num, declaration, type) if true
		*/
		                                              VertexBufferChunk( const NeoEngine::VertexBufferPtr &pkBuffer, const NeoEngine::HashString &rstrID = "", bool bCreateSubChunks = false ) : ComplexChunk( ChunkType::VERTEXBUFFER, "vertexbuf", rstrID, 2 ), m_pkBuffer( pkBuffer ) { if( bCreateSubChunks ) { SetNumChunk( pkBuffer->GetNumElements() ); SetTypeChunk( pkBuffer->GetType() ); SetFormatChunk( pkBuffer->GetVertexFormat() ); } }
		
		/**
		* Deallocate data and subchunks
		*/
		virtual                                      ~VertexBufferChunk() {}

		/**
		* Get size of chunk in binary mode
		* \param bIncludeHeader                       Add header of chunk (type + ID) to size as well as subchunks and data
		* \return                                     Size of chunk data in bytes as if read/written from/to file
		*/
		virtual int                                   GetSize( bool bIncludeHeader = false ) const;

		/**
		* Read chunk data from file
		* \param pkFile                               File
		* \param eMode                                Chunk mode (ChunkIO::ASCII or ChunkIO::BINARY)
		* \param uiEnd                                Bytes to end of chunk (in binary mode)
		* \return                                     <0 if error, number of bytes read if successful
		*/
		virtual int                                   ReadData( NeoEngine::File *pkFile, ChunkIO::CHUNKIOMODE eMode, unsigned int uiEnd );

		/**
		* Write chunk data to file
		* \param pkFile                               File
		* \param eMode                                Chunk mode (ChunkIO::ASCII or ChunkIO::BINARY)
		* \param uiLevel                              Recursion level for ascii format
		* \return                                     <0 if error, number of bytes written if successful
		*/
		virtual int                                   WriteData( NeoEngine::File *pkFile, ChunkIO::CHUNKIOMODE eMode, unsigned int uiLevel );

		/**
		* Set num subchunk
		* \param uiNumVertices                        Number of vertices
		*/
		void                                          SetNumChunk( unsigned int uiNumVertices );

		/**
		* Set buffer type subchunk
		* \param uiType                               Buffer type
		*/
		void                                          SetTypeChunk( unsigned int uiType );

		/**
		* Set vertex declaration subchunk
		* \param pkFormat                             Vertex declaration format
		*/
		void                                          SetFormatChunk( const NeoEngine::VertexDeclaration *pkFormat );

		/**
		* Allocate new chunk
		* \param usType                               Type identifier
		* \param rstrType                             Type identifier as string
		* \param rstrID                               ID string
		* \return                                     New chunk
		*/
		static Chunk                                 *Allocator( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID ) { return new VertexBufferChunk( usType, rstrType, rstrID ); }
};


};


#endif

