/***************************************************************************
                        factory.h  -  Chunk factory
                             -------------------
    begin                : Tue Feb 25 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, factory.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef _NEOCHUNKIO_FACTORY_H_
#define _NEOCHUNKIO_FACTORY_H_


/**
  * \file factory.h
  * Chunk factory
  */


#include "base.h"

#include <neoengine/hashstring.h>
#include <neoengine/hashtable.h>

#include <vector>


namespace NeoChunkIO
{


// External classes
class Chunk;


/*! Chunk allocation callback interface */
typedef Chunk* ( *CreateChunkCallback  )( unsigned short, const NeoEngine::HashString&, const NeoEngine::HashString& );


/**
  * \brief Data for a registered chunk type
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOCHUNKIO_API ChunkFactoryCallback
{
	public:
		
		/*! Chunk type */
		unsigned short                                      m_usType;

		/*! Chunk type string */
		NeoEngine::HashString                               m_strType;
	
		/*! Allocator callback */
		CreateChunkCallback                                 m_pfAllocator;
};


/*! Export vector specialization in DLL */
ChunkIOUDTVectorEXPIMP( ChunkFactoryCallback* );

/**
  * \brief Chunk allocator, factory pattern
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOCHUNKIO_API ChunkFactory
{
	friend class Core;

	protected:


		/*! Hash table mapping chunk type strings to chunk allocation callbacks */
		static NeoEngine::HashTable< ChunkFactoryCallback >    *s_pkStringTypeCallbacks;

		/*! Vector mapping chunk type shorts to chunk allocation callbacks */
		static std::vector< ChunkFactoryCallback* >            *s_pvpkShortTypeCallbacks;

		/*! Flag indicating we have registered default types */
		static bool                                             s_bHaveDefaultTypes;


		/**
		* Register default chunk types
		*/
		static void                                             RegisterDefaultTypes();

		/**
		* Deregister all types
		*/
		static void                                             DeregisterAllTypes();



	public:

		/**
		* Create chunk of specified type
		* \param usType                                         Chunk type identifier
		* \param rstrID                                         Chunk ID
		* \return                                               Ptr to new chunk object
		*/
		static Chunk                                           *CreateChunk( unsigned short usType, const NeoEngine::HashString &rstrID = "" );  

		/**
		* Create chunk of specified type
		* \param rstrType                                       Chunk type identifier as string
		* \param rstrID                                         Chunk ID
		* \return                                               Ptr to new chunk object
		*/
		static Chunk                                           *CreateChunk( const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID = "" );

		/**
		* Register a new chunk type. Will replace any previously registered allocator for this type
		* \param usType                                         Type identifier
		* \param rstrType                                       Type identifier as string
		* \param pfAllocator                                    Chunk allocation callback method
		*/
		static void                                             RegisterChunkType( unsigned short usType, const NeoEngine::HashString &rstrType, CreateChunkCallback pfAllocator );
};


};


#endif
