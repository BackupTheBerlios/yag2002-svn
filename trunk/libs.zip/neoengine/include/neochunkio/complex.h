/***************************************************************************
                        complex.h  -  Complex chunks
                             -------------------
    begin                : Tue Feb 18 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, complex.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef _NECHUNKIO_COMPLEX_H_
#define _NECHUNKIO_COMPLEX_H_


/**
  * \file complex.h
  * Complex chunks
  */  


#include "base.h"
#include "chunk.h"


namespace NeoChunkIO
{


/**
  * \brief Base class for complex chunks
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOCHUNKIO_API ComplexChunk : public Chunk
{
	public:

		/*! Chunk version */
		unsigned short                                m_usVersion;


		/**
		* Initialize chunk
		* \param usType                               Chunk type
		* \param rstrType                             Chunk type as string
		* \param rstrID                               Chunk ID string
		* \param usVersion                            Chunk version
		*/ 
		                                              ComplexChunk( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID = "", unsigned short usVersion = 1 ) : Chunk( usType, rstrType, rstrID ), m_usVersion( usVersion ) {}
		
		/**
		* Deallocate data and subchunks
		*/
		virtual                                      ~ComplexChunk() {}

		/**
		* Get size of chunk in binary mode
		* \param bIncludeHeader                       Add header of chunk (type + ID) to size as well as subchunks and data
		* \return                                     Size of chunk data in bytes as if read/written from/to file
		*/
		virtual int                                   GetSize( bool bIncludeHeader = false ) const;

		/**
		* \return                                     true (we are a complex chunk)
		*/
		virtual bool                                  IsComplex() const { return true; }
};


}; // namespace NeoChunkIO


#endif

