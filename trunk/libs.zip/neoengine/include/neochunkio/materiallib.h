/***************************************************************************
                  materiallib.h  -  Material library file loader
                             -------------------
    begin                : Thu Feb 27 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, materiallib.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef _NECHUNKIO_MATERIALLIB_H_
#define _NECHUNKIO_MATERIALLIB_H_


/**
  * \file materiallib.h
  * Material library file loader
  */  


#include "base.h"

#include <neoengine/core.h>
#include <neoengine/material.h>
#include <neoengine/loadableentity.h>


namespace NeoChunkIO
{


/**
  * \brief Material library
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOCHUNKIO_API MaterialLibrary : public NeoEngine::LoadableEntity
{
	protected:

		/**
		* Load material library file. Called by LoadableEntity to load object if file was opened successfully
		* \param uiFlags                              Flags passed by caller to Load() method
		* \return                                     true if load was successful, false otherwise
		*/
		virtual bool                                  LoadNode( unsigned int uiFlags = 0 );


	public:

		/*! Material table object to add materials to */
		NeoEngine::MaterialTable                     *m_pkMaterialTable;

		/*! Loaded materials */
		std::vector< NeoEngine::MaterialPtr >         m_vpkMaterials;

		/**
		* Initialize library for loading
		* \param pkMaterialTable                      Material table to load into, if null will use engine core material manager (default)
		* \param pkFileManager                        File manager, if null will use engine core file manager (default)
		*/
		                                              MaterialLibrary( NeoEngine::MaterialTable *pkMaterialTable = 0, NeoEngine::FileManager *pkFileManager = 0 ) : NeoEngine::LoadableEntity( pkFileManager ), m_pkMaterialTable( pkMaterialTable ? pkMaterialTable : NeoEngine::Core::Get()->GetMaterialManager() ) {}
		
		/**
		*/
		virtual                                      ~MaterialLibrary() {}
};


};


#endif

