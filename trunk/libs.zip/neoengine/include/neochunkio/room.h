/***************************************************************************
                            room.h  -  Room chunk
                             -------------------
    begin                : Thu Feb 27 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, room.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef _NECHUNKIO_ROOM_H_
#define _NECHUNKIO_ROOM_H_


/**
  * \file neochunkio/room.h
  * Room chunk
  */


#include "base.h"
#include "complex.h"


// External classes
namespace NeoEngine
{
	class Room;
};


namespace NeoChunkIO
{


/**
  * \brief Room chunk
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOCHUNKIO_API RoomChunk : public ComplexChunk
{
	public:

		/*! Room object */
		NeoEngine::Room                              *m_pkRoom;

		/**
		* Initialize chunk
		* \param usType                               Chunk type
		* \param rstrType                             Chunk type as string
		* \param rstrID                               Chunk ID string
		*/ 
		                                              RoomChunk( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID = "" ) : ComplexChunk( usType, rstrType, rstrID ), m_pkRoom( 0 ) {}
		
		/**
		* Deallocate data and subchunks
		*/
		virtual                                      ~RoomChunk();

		/**
		* Parse chunk data
		* \param uiFlags                              Parse flags
		* \param pkFileManager                        File manager
		* \return                                     <0 if error, >0 if successful (0 reserved)
		*/
		virtual int                                   ParseData( unsigned int uiFlags, NeoEngine::FileManager *pkFileManager );
};


};


#endif

