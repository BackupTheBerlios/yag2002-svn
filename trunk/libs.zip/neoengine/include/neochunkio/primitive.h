/***************************************************************************
                       primitive.h  -  Primitive chunks
                             -------------------
    begin                : Tue Feb 18 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, primitive.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef _NECHUNKIO_PRIMITIVE_H_
#define _NECHUNKIO_PRIMITIVE_H_


/**
  * \file primitive.h
  * Primitive chunks
  */


#include "base.h"
#include "chunk.h"


namespace NeoChunkIO
{


/**
  * \class PrimitiveChunk
  * \brief Base class for primitive chunks
  * A primitive chunk cannot have any subchunks
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOCHUNKIO_API PrimitiveChunk : public Chunk
{
	public:

		/**
		* Initialize chunk
		* \param usType                               Chunk type
		* \param rstrType                             Chunk type as string
		* \param rstrID                               Chunk ID string
		*/ 
		                                              PrimitiveChunk( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID = "" ) : Chunk( usType, rstrType, rstrID ) {}
		
		/**
		* Deallocate data and subchunks
		*/
		virtual                                      ~PrimitiveChunk() {}

		/**
		* Get size of chunk in binary mode. A primitive chunk must be able to return chunk size without target object and prior ReadData call
		* \param bIncludeHeader                       Add header of chunk (type + ID) to size as well as subchunks and data
		* \return                                     Size of chunk data in bytes as if read/written from/to file
		*/
		virtual int                                   GetSize( bool bIncludeHeader = false ) const;

		/**
		* \return                                     false (we are a primitive chunk)
		*/
		virtual bool                                  IsComplex() const { return false; }
};


}; // namespace NeoChunkIO


#endif

