/***************************************************************************
                  animlib.h  -  Animation library file loader
                             -------------------
    begin                : Mon May 5 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoChunkIO, animlib.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef _NECHUNKIO_ANIMLIB_H_
#define _NECHUNKIO_ANIMLIB_H_


/**
  * \file animlib.h
  * Animation library file loader
  */
  

#include "base.h"

#include <neoengine/loadableentity.h>
#include <neoengine/skeletonanimator.h>
#include <neoengine/nodeanimator.h>
#include <neoengine/submeshanimator.h>

#include <vector>


namespace NeoChunkIO
{


/**
  * \class AnimationLibrary
  * \brief Animation library
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOCHUNKIO_API AnimationLibrary : public NeoEngine::LoadableEntity
{
	protected:

		/**
		* Load animation library file. Called by LoadableEntity to load object if file was opened successfully
		* \param uiFlags                              Flags passed by caller to Load() method
		* \return                                     true if load was successful, false otherwise
		*/
		virtual bool                                  LoadNode( unsigned int uiFlags = 0 );


	public:

		/*! Skeletal animations */
		std::vector< NeoEngine::SkeletonAnimation* >  m_vpkSkeletonAnimations;

		/*! Submesh animations */
		std::vector< NeoEngine::SubMeshAnimation* >   m_vpkSubMeshAnimations;

		/*! Node animations */
		std::vector< NeoEngine::NodeAnimation* >      m_vpkNodeAnimations;

		/**
		* Initialize library for loading
		* \param pkFileManager                        File manager, will use core file manager if null (default)
		*/
		                                              AnimationLibrary( NeoEngine::FileManager *pkFileManager = 0 ) : NeoEngine::LoadableEntity( pkFileManager ) {}

		/**
		* Deallocate data
		*/
		virtual                                      ~AnimationLibrary();
};


}; // namespace NeoChunkIO


#endif

