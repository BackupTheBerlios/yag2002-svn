/***************************************************************************
               link.h  -  Automatic entry point for static lib
                             -------------------
    begin                : Thu Jun 03 2004
    copyright            : (C) 2004 by emedia-solutions wolf
    email                : markus@emedia-soltions-wolf.de
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoFCZip, neofczip.h

 The Initial Developer of the Original Code is Markus Wolf.
 Portions created by Markus Wolf are Copyright (C) 2004
 emedia-solutions wolf. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOFCZIP_H
#define __NEOFCZIP_H


#include <neoengine/base.h>
#include <neoengine/filecodec.h>


namespace NeoZIP
{


/**
  * \brief File loader codec for zip compressed files
  * This codec uses the free zlib library from Jean-loup Gailly and Mark Adler. Please read
  * the LICENSE file in the zip subdirectory for license information.
  * \author Markus Wolf (markus@emedia-solutions-wolf.de)
  */
class FileCodec : public NeoEngine::FileCodec
{
	public:

		/**
		* Create new zip loader codec object
		*/
		                                FileCodec();

		/**
		* Check if file is a zip file
		* \param pkFile                 File to check
		* \return                       true if zip file, false if not recognized
		*/
		bool                            IsType( NeoEngine::File *pkFile );

		/**
		* Loads data from file
		* \param pkFile                 File
		* \param iSrcSize               Size of source data
		* \param pDest                  Pointer to destination buffer
		* \param piSize                 Pointer to integer holding size of uncompressed data
		* \return                       Error code, 0 if success
		*/
		int                             LoadFileData( NeoEngine::File *pkFile, int iSrcSize, void *pDest, int *piSize );
};


}; // namespace NeoZIP


#endif

