/***************************************************************************
                     bsp.h  -  Room specification, BSP tree
                             -------------------
    begin                : Fri Dec 7 2001
    copyright            : (C) 2001 by Mattias Jansson
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoBSP, bsp.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NEOBSP_BSP_H
#define __NEOBSP_BSP_H


/**
  * \file bsp.h
  * BSP scheme
  */


#include "base.h"

#include <neoengine/room.h>
#include <neoengine/vertex.h>
#include <neoengine/polygon.h>


//external classes
namespace NeoEngine
{
	class Plane;
	class AABB;
	class RenderPrimitive;
};


namespace NeoBSP
{


/**
  * \brief Node in BSP tree
  * This is a basic class holding data for a BSP node.
  * \author Mattias Jansson (mattias@realityrift.com)
  * \todo Profile and see if split into different classes with same base for node and leaf is better
  */
class NEOBSP_API BSPNode
{
	public:

		/**
		* \enum BSPNODETYPE
		* \brief BSP node type identifier
		*/
		enum BSPNODETYPE
		{
		  INVALID                                     = -1,
		  NODE                                        = 0,
		  LEAF                                        = 1
		};

	

	public:

		/*! Type */
		int                                           m_iType;

		/*! Paritioning plane */
		NeoEngine::Plane                             *m_pkPartition;

		/*! Front child node */
		BSPNode                                      *m_pkFront;

		/*! Back child node */
		BSPNode                                      *m_pkBack;

		/*! Bounding box */
		NeoEngine::AABB                              *m_pkAABB;

		/* Visibility cluster */
		int                                           m_iVisCluster;

		/*! Node ID */
		int                                           m_iID;

		/*! Polygons */
		std::vector< NeoEngine::PolygonBufferPtr >    m_vpkPolygons;

		/*! Scene nodes */
		std::vector< NeoEngine::SceneNode* >          m_vpkSceneNodes;


		/**
		*/
		                                              BSPNode();

		/**
		* Deallocate memory
		*/
		virtual                                      ~BSPNode();

		/**
		* Add scene node object to node
		* \param pkNode                               Node to attach
		* \return                                     undefined
		*/
		virtual int                                   AttachNode( NeoEngine::SceneNode *pkNode );

		/**
		* Detach scene node from node
		* \param pkNode                               Node to detach
		* \return                                     undefined
		*/
		virtual int                                   DetachNode( NeoEngine::SceneNode *pkNode );

		/**
		* Update scene node
		* \param pkNode                               Node to update
		* \return                                     undefined
		*/
		virtual int                                   UpdateNode( NeoEngine::SceneNode *pkNode );

		/**
		* Render node
		* \param pkPrimitive                          Preallocated render primitive object to use
		* \param pkFrustum                            Frustum
		*/
		virtual void                                  Render( NeoEngine::RenderPrimitive *pkPrimitive, NeoEngine::Frustum *pkFrustum = 0 );

		/**
		* Get front or back child node based on split plane, or return this if leaf
		* \param rkPoint                              Point to search for
		* \return                                     Leaf containing the node
		*/
		BSPNode                                      *GetNextNode( const NeoEngine::Vector3d &rkPoint );

		/**
		* Intersect ray with static geometry and scene nodes
		* \param rkRay                                Ray
		* \param pkContactSet                         Contact data set object receiving cpllision contact data
		* \return                                     true if intersection found, false if not
		*/
		virtual bool                                  Intersection( const NeoEngine::Ray &rkRay, NeoEngine::ContactSet *pkContactSet );

		/**
		* Intersect volume with static geometry and scene nodes
		* \param pkVolume                             Bounding volume
		* \param pkContactSet                         Contact data set object receiving collision contact data
		*/
		virtual bool                                  Intersection( NeoEngine::BoundingVolume *pkVolume, NeoEngine::ContactSet *pkContactSet );
};


/**
  * \class BSPVisCluster
  * \brief Visibility data for BSP nodes
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOBSP_API BSPVisCluster
{
	public:

		/*! Cluster count */
		int                                           m_iClusterCount;

		/*! Row length */
		int                                           m_iRowLength;

		/*! Data */
		unsigned char                                *m_pucData;

		/**
		*/
		                                              BSPVisCluster() : m_iClusterCount(0), m_iRowLength(0), m_pucData(0) {}

		/**
		* Deallocate data buffer
		*/
		                                             ~BSPVisCluster();
};


#ifdef WIN32
#  ifndef __HAVE_VECTOR_NEBSPNODE
     BSPUDTVectorEXPIMP( class BSPNode* );
#    define __HAVE_VECTOR_NEBSPNODE
#  endif
#endif


/**
  * \class BSPRoom
  * \brief Room with specific space partition scheme
  * A room with BSP
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOBSP_API BSPRoom : public NeoEngine::Room
{
	public:
		
		DefineVisitable();

	protected:

		/*! Render primitive object, to avoid reallocation each node */
		NeoEngine::RenderPrimitive                   *m_pkRenderPrimitive;



	public:

		/*! Visibility cluster */
		BSPVisCluster                                *m_pkVisCluster;

		/*! Root BSP node */
		BSPNode                                      *m_pkRootNode;

		/*! All leaves (if we use vis cluster) */
		std::vector< BSPNode* >                       m_vpkLeaves;

		/*! All vertex buffers */
		std::vector< NeoEngine::VertexBufferPtr >     m_vpkVertexBuffers;



		/**
		* Create named room with BSP scheme
		* \param rstrName                             room name
		*/
		                                              BSPRoom( const std::string &rstrName = "" );

		/**
		*/
		virtual                                      ~BSPRoom();

		/**
		* Render
		* \param pkFrustum                            Frustum
		* \param bForce                               Ignored
		* \return                                     true
		*/
		virtual bool                                  Render( NeoEngine::Frustum *pkFrustum = 0, bool bForce = false );

		/**
		* Attach scene node
		* \param pkNode                               Node to attach
		* \param bKeepWorldSRT                        If true, node will keep world SRT data
		* \return                                     Space partition scheme specific value
		*/
		virtual int                                   AttachNode( NeoEngine::SceneNode *pkNode, bool bKeepWorldSRT = true );

		/**
		* Detach scene node
		* \param pkNode                               Node to detach
		* \return                                     Space partition scheme specific value
		*/
		virtual int                                   DetachNode( NeoEngine::SceneNode *pkNode );

		/**
		* Intersect ray with static geometry and scene nodes
		* \param rkRay                                Ray
		* \param pkCollSet                            Collision data set object receiving contact data
		* \return                                     true if intersection found, false if not
		*/
		virtual bool                                  Intersection( const NeoEngine::Ray &rkRay, NeoEngine::ContactSet *pkContactSet );

		/**
		* Intersect volume with static geometry and scene nodes
		* \param pkVolume                             Bounding volume
		* \param pkCollSet                            Collision data set object receiving contact data
		* \return                                     true if intersection found, false if not
		*/
		virtual bool                                  Intersection( NeoEngine::BoundingVolume *pkVolume, NeoEngine::ContactSet *pkContactSet );
};


};


#endif
