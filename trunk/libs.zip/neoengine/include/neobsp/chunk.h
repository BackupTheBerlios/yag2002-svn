/***************************************************************************
                          bsp.h  -  BSP room chunk
                             -------------------
    begin                : Thu Feb 27 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoBSP, chunk.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOBSP_CHUNK_H
#define __NEOBSP_CHUNK_H


/**
  * \file neobsp/chunk.h
  * BSP room chunk
  */
  

#include "base.h"


#ifdef HAVE_NEOCHUNKIO


#include <neochunkio/room.h>


namespace NeoBSP
{


/**
  * \brief Chunk type identifier class with builtin chunk type identifiers
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOBSP_API BSPChunkType
{
	public:

		/**
		* \enum CHUNKTYPE
		* \brief Builtin chunk type identifiers and string identifiers
		*/
		enum CHUNKTYPE
		{
		  BSPROOM                     = 0x20a2, // "bsp"
		  BSPNODE                     = 0x20b0, // "bspnode"
		  BSPLEAF                     = 0x20b1, // "bspleaf"
		  BSPVISCLUSTER               = 0x20b2  // "bspviscluster"
		};
};


/**
  * \brief BSP node and leaf chunks
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOBSP_API BSPNodeChunk : public NeoChunkIO::ComplexChunk
{
	public:

		/*! BSP node */
		BSPNode                                      *m_pkNode;

		/*! Vertex buffer indices */
		int                                          *m_piVertexBuffers;

		/*! Load flag to flush out unused nodes/leaves */
		int                                           m_iLoadFlag;


		/**
		* Initialize chunk
		* \param usType                               Chunk type
		* \param rstrType                             Chunk type as string
		* \param rstrID                               Chunk ID string
		*/ 
		                                              BSPNodeChunk( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID = "" ) : NeoChunkIO::ComplexChunk( usType, rstrType, rstrID ), m_pkNode( 0 ), m_piVertexBuffers( 0 ), m_iLoadFlag( 0 ) {}
		
		/**
		* Deallocate data and subchunks
		*/
		virtual                                      ~BSPNodeChunk();

		/**
		* Parse chunk data
		* \param uiFlags                              Parse flags
		* \param pkFileManager                        File manager
		* \return                                     <0 if error, >0 if successful (0 reserved)
		*/
		virtual int                                   ParseData( unsigned int uiFlags, NeoEngine::FileManager *pkFileManager );

		/**
		* Allocate new chunk
		* \param usType                               Type identifier
		* \param rstrType                             Type identifier as string
		* \param rstrID                               ID string
		* \return                                     New chunk
		*/
		static NeoChunkIO::Chunk                     *Allocator( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID ) { return new BSPNodeChunk( usType, rstrType, rstrID ); }
};


/**
  * \brief BSP visibility cluster chunk
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOBSP_API BSPVisClusterChunk : public NeoChunkIO::ComplexChunk
{
	public:

		/*! Visibility cluster object */
		BSPVisCluster                                *m_pkCluster;

		/**
		* Initialize chunk
		* \param usType                               Chunk type
		* \param rstrType                             Chunk type as string
		* \param rstrID                               Chunk ID string
		*/ 
		                                              BSPVisClusterChunk( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID = "" ) : NeoChunkIO::ComplexChunk( usType, rstrType, rstrID ), m_pkCluster( 0 ) {}
		
		/**
		* Setup chunk with default values
		* \param pkCluster                            Pointer to cluster data
		* \param rstrID                               Chunk ID string, default empty
		*/
		                                              BSPVisClusterChunk( BSPVisCluster *pkCluster, const NeoEngine::HashString &rstrID = "" ) : NeoChunkIO::ComplexChunk( BSPChunkType::BSPVISCLUSTER, "bspviscluster", rstrID ), m_pkCluster( pkCluster ) {}
		
		/**
		* Deallocate data and subchunks
		*/
		virtual                                      ~BSPVisClusterChunk();

		/**
		* Get size of chunk in binary mode
		* \param bIncludeHeader                       Add header of chunk (type + ID) to size as well as subchunks and data
		* \return                                     Size of chunk data in bytes as if read/written from/to file
		*/
		virtual int                                   GetSize( bool bIncludeHeader = false ) const;

		/**
		* Read chunk data from file
		* \param pkFile                               File
		* \param eMode                                Chunk mode (ChunkIO::ASCII or ChunkIO::BINARY)
		* \param uiEnd                                Bytes to end of chunk (in binary mode)
		* \return                                     <0 if error, number of bytes read if successful
		*/
		virtual int                                   ReadData( NeoEngine::File *pkFile, NeoChunkIO::ChunkIO::CHUNKIOMODE eMode, unsigned int uiEnd );

		/**
		* Write chunk data to file
		* \param pkFile                               File
		* \param eMode                                Chunk mode (ChunkIO::ASCII or ChunkIO::BINARY)
		* \param uiLevel                              Recursion level for ascii format
		* \return                                     <0 if error, number of bytes written if successful
		*/
		virtual int                                   WriteData( NeoEngine::File *pkFile, NeoChunkIO::ChunkIO::CHUNKIOMODE eMode, unsigned int uiLevel );

		/**
		* Allocate new chunk
		* \param usType                               Type identifier
		* \param rstrType                             Type identifier as string
		* \param rstrID                               ID string
		* \return                                     New chunk
		*/
		static NeoChunkIO::Chunk                     *Allocator( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID ) { return new BSPVisClusterChunk( usType, rstrType, rstrID ); }
};


/**
  * \brief Room chunk
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOBSP_API BSPRoomChunk : public NeoChunkIO::RoomChunk
{
	public:

		/**
		* Initialize chunk
		* \param usType                               Chunk type
		* \param rstrType                             Chunk type as string
		* \param rstrID                               Chunk ID string
		*/ 
		                                              BSPRoomChunk( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID = "" ) : NeoChunkIO::RoomChunk( usType, rstrType, rstrID ) {}
		
		/**
		* Setup chunk with default values
		* \param rstrID                               Chunk ID string, default empty
		*/
													  BSPRoomChunk( const NeoEngine::HashString &rstrID = "" ) : NeoChunkIO::RoomChunk( BSPChunkType::BSPROOM, "bsp", rstrID ) {}
		
		/**
		* Deallocate data and subchunks
		*/
		virtual                                      ~BSPRoomChunk() {}

		/**
		* Parse chunk data
		* \param uiFlags                              Parse flags
		* \param pkFileManager                        File manager
		* \return                                     <0 if error, >0 if successful (0 reserved)
		*/
		virtual int                                   ParseData( unsigned int uiFlags, NeoEngine::FileManager *pkFileManager );

		/**
		* Allocate new chunk
		* \param usType                               Type identifier
		* \param rstrType                             Type identifier as string
		* \param rstrID                               ID string
		* \return                                     New chunk
		*/
		static NeoChunkIO::Chunk                     *Allocator( unsigned short usType, const NeoEngine::HashString &rstrType, const NeoEngine::HashString &rstrID ) { return new BSPRoomChunk( usType, rstrType, rstrID ); }
};


};


#endif


#endif

