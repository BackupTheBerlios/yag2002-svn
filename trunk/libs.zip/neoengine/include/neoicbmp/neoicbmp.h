/***************************************************************************
                          neoicbmp.h  -  description
                             -------------------
    begin                : Wed Aug 17 2002
    copyright            : (C) 2002 by Matthew Holmes
    email                : kerion@vengeanceagenda.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoICBMP, neoicbmp.h

 The Initial Developer of the Original Code is Matthew Holmes.
 Portions created by Matthew Holmes are Copyright (C) 2003
 Matthew Holmes. All Rights Reserved.

 ***************************************************************************/

#ifndef NEOICBMP_H_
#define NEOICBMP_H_


#include <neoengine/base.h>
#include <neoengine/texture.h>


#ifdef WIN32
	#pragma pack(push, 1)
#endif


namespace NeoBMP
{

class Header
{
public:
	char m_acMagic[2];
	unsigned int m_uiSize;
	unsigned short m_usReserved1;
	unsigned short m_usReserved2;
	unsigned int m_uiOffBits;
};

class InfoUpper
{
public:
	unsigned short m_usPlanes;
	unsigned short m_usBitCount;
};

class InfoLower
{
public:
	unsigned int m_uiCompression;
	unsigned int m_uiSizeImage;
	int m_iXPixelsPerMeter;
	int m_iYPixelsPerMeter;
	unsigned int m_uiClrUsed;
	unsigned int m_uiClrImportant;
};
#ifdef WIN32
	#pragma pack(pop)
#endif

#ifndef BI_RGB
#define BI_RGB			0
#define BI_RLE8			1
#define BI_RLE4			2
#define BI_BITFIELDS	3
#endif

class ImageCodec : public NeoEngine::ImageCodec
{
public:
	/**
	* Create new TGA loader codec object
	*/
	                                ImageCodec( const std::vector<std::string> &rvstrExtensions );

	/**
	* Check if file is a TGA file
	* \param pkFile                 File to check
	* \return                       true if TGA file, false if not recognized
	*/
	virtual bool                    IsType( NeoEngine::File *pkFile);

	/**
	* Loads data from file
	* \param pkFile                 File
	* \return                       Ptr to new ImageData object
	*/
	virtual NeoEngine::ImageData   *LoadImage( NeoEngine::File *pkFile);

	/**
	* Free image data
	* \param pkImageData            Image data
	*/
	virtual void                    FreeImage( NeoEngine::ImageData *pkImageData);

	/**
	* Write image to file
	* \param pkImage                Image to write
	* \param pkFile                 File to write into
	*/
	virtual bool                    WriteImage( NeoEngine::ImageData *pkImage, NeoEngine::File *pkFile );
};


}; // namespace NeoBMP


#endif
