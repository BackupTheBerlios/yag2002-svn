/***************************************************************************
              pixelbuffertarget.h  -  Pixel buffer render target
                             -------------------
    begin                : Fri May 23 2003
    copyright            : (C) 2003 by Keaton Mullis
    email                : kmullis@zianet.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevD3D9, pixelbuffertarget.h

 The Initial Developer of the Original Code is Keaton Mullis.
 Portions created by Keaton Mullis are Copyright (C) 2003
 Keaton Mullis. All Rights Reserved.

 ***************************************************************************/

#ifndef __NED3DPIXELBUFFERTARGET_H
#define __NED3DPIXELBUFFERTARGET_H


/**
  * \file pixelbuffertarget.h
  * Pixel buffer render target
  */


#include "device.h"
#include "rendertarget.h"


namespace NeoD3D9
{


// External classes
class PixelBuffer;


/**
  * \brief Pixel buffer render target
  * \author Keaton Mullis (kmullis@zianet.com)
  */
class PixelBufferRenderTarget : public RenderTarget
{
	public:

		/*! Pixel buffer */
		PixelBuffer                                  *m_pkCurBuffer;

		/**
		* Initialize data
		* \param pkDevice                             Device
		*/
		                                              PixelBufferRenderTarget( Device *pkDevice );

		/**
		* Deallocate memory
		*/
		virtual                                      ~PixelBufferRenderTarget();

		/**
		* \return                                     Render target identifier
		*/
		virtual unsigned int                          GetID() { return NeoEngine::RenderDevice::PIXELBUFFER; }

		/**
		* Activate
		*/
		inline virtual void                           Activate();

		/**
		* Deactivate
		*/
		inline virtual void                           Deactivate();

		/**
		* Set active pixel buffer
		* \param uiPixelBuffer                        Pixel buffer ID
		* \return                                     true if successful, false if error
		*/
		bool                                          SetPixelBuffer( unsigned int uiPixelBuffer );
};


}; // namespace NeoD3D9


#endif

