/***************************************************************************
                  texture.h  -  Direct3D texture implementation
                             -------------------
    begin                : Sat Mar 15 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevD3D9, texture.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NED3D9TEXTURE_H
#define __NED3D9TEXTURE_H


/**
  * \file texture.h
  * Direct3D texture implementation
  */

#include "device.h"

#include <neoengine/texture.h>
#include <neoengine/loadableentity.h>


namespace NeoD3D9
{


/**
  * \brief Direct3D texture implementation
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class Texture : public NeoEngine::Texture, public NeoEngine::LoadableEntity
{
	protected:

		/*! ID counter */
		static int                                    s_iIDCount;

		/*! Device */
		Device                                       *m_pkDevice;


		/**
		* Load texture file
		* \param uiFlags                              Load flags
		* \return                                     true if successful, false if not
		*/
		bool                                          LoadNode( unsigned int uiFlags );

		/**
		* Format conversion
		* \param uiSrcFormat                          Source engine format
		* \param eDestFormat                          Destination D3D9 format
		* \param pucSrc                               Source buffer
		* \param iWidth                               Width of source buffer
		* \param iHeight                              Height of source buffer
		* \param pucDest                              Destination buffer
		* \param uiDestPitch                          Pitch of destination buffer
		* \return                                     true if conversion successful, false if error
		*/
		bool                                          ConvertFormat( NeoEngine::Texture::TEXTUREFORMAT eSrcFormat, D3DFORMAT eDestFormat, unsigned char *pucSrc, int iWidth, int iHeight, unsigned char *pucDest, unsigned int uiDestPitch );

                
	public:

		/*! Direct3D texture object */
		IDirect3DBaseTexture9                        *m_pkD3DTexture;

		/*! Cubemap face identifier mapping */
		static const D3DCUBEMAP_FACES                 s_aeD3DCubeFaces[6];


		/**
		* Create an empty texture object
		* \param pkDevice                             Device
		* \param rstrName                             Texture name
		* \param eTextureType                         Texture type (2D, cubemap, ...)
		* \param eTextureFormat                       Texture format
		* \param uiFiltering                          Texture filtering
		* \param uiMaxAnisotropy                      Max anisotropy
		* \param pkTexturePool                        Parent texture pool object
		* \param pkResourceManager                    Resource manager object
		*/
		                                              Texture( Device *pkDevice, const std::string &rstrName, TEXTURETYPE eTextureType, TEXTUREFORMAT eTextureFormat, unsigned int uiFiltering, unsigned int uiMaxAnisotropy, NeoEngine::TexturePool *pkTexturePool, NeoEngine::FileManager *pkFileManager );

		/**
		* Delete texture object, deallocate associated memory
		*/
		virtual                                      ~Texture();

		/**
		* Upload image data
		* \param pkImageData                          Image data
		* \param eTextureType                         Texture type (2D, cubemap, ...)
		* \param eFormat                              Requested format
		* \param uiFlags                              Texture load flags
		* \param uiFiltering                          Texture filtering
		* \param uiMaxAnisotropy                      Texture max anisotropy
		* \return                                     true if successful, false otherwise
		*/
		virtual bool                                  UploadImage( NeoEngine::ImageData *pkImageData, TEXTURETYPE eTextureType, TEXTUREFORMAT eTextureFormat, unsigned int uiFlags, unsigned int uiFiltering, unsigned int uiMaxAnisotropy );
};


typedef NeoEngine::Pointer< NeoD3D9::Texture > TexturePtr;


}; // namespace NeoD3D9


#endif
