/***************************************************************************
                 rendertarget.h  -  Base class for render targets
                             -------------------
    begin                : Fri Apr 25 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevD3D9, rendertarget.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NED3D9RENDERTARGET_H
#define __NED3D9RENDERTARGET_H


/**
  * \file rendertarget.h
  * Base class for render target
  */


#include <neoengine/activator.h>


namespace NeoEngine
{
	class RenderPrimitive;
};


namespace NeoD3D9
{


// External classes
class Device;
class RenderQueue;



/**
  * \brief Base class for render target
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class RenderTarget : virtual public NeoEngine::Activator
{
	protected:

		/*! Device */
		Device                                       *m_pkDevice;

		/*! Normal render queue */
		RenderQueue                                  *m_pkNormalQueue;

		/*! No translation render queue */
		RenderQueue                                  *m_pkNoTransQueue;


	public:

		/*! Frame flags */
		unsigned int                                  m_uiFrameFlags;


		/**
		* Initialize data
		* \param pkDevice                             Device
		*/
		                                              RenderTarget( Device *pkDevice );

		/**
		* Deallocate memory
		*/
		virtual                                      ~RenderTarget();

		/**
		* Queue render primitive
		* \param rkData                               Render primitive data
		* \param uiFlags                              Flags
		*/
		virtual void                                  Queue( const NeoEngine::RenderPrimitive &rkData, unsigned int uiFlags );

		/**
		* Flush pipeline
		*/
		virtual void                                  Flush();

		/**
		* Flip buffers
		*/
		virtual void                                  Flip();

		/**
		* \return                                     Render target identifier
		*/
		virtual unsigned int                          GetID() = 0;
};


}; // namespace NeoD3D9


#endif

