/***************************************************************************
                       avltree.h  -  Balanced binary tree
                             -------------------
    begin                : Thu May 15 2003
    copym_pkRight            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevD3D9, avltree.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NED3D9AVLTREE_H
#define __NED3D9AVLTREE_H



namespace NeoD3D9
{


/**
  * \class AVLTreeNode
  * \brief Balanced binary tree node
  * \author Mattias Jansson (mattias@realityrift.com)
  */
template <class AVLTreeDataType> class AVLTreeNode
{
	public:

		/**
		* \enum AVLTREEBALANCE
		* \brief Balance identifiers for a node
		*/
		enum AVLTREEBALANCE
		{
		  /*! Left-heavy */
		  LEFTHEAVY,

		  /*! Balanced */
		  BALANCED,

		  /*! Right-heavy */
		  RIGHTHEAVY
		};



		/*! Left subtree */
		AVLTreeNode< AVLTreeDataType >           *m_pkLeft;

		/*! Right subtree */
		AVLTreeNode< AVLTreeDataType >           *m_pkRight;

		/*! Tree balance factor */
		AVLTREEBALANCE                              m_eBalance;

		/*! Data in node */
		AVLTreeDataType                            *m_pkData;



		/**
		*/
		                                              AVLTreeNode( AVLTreeDataType *pkData ) : m_pkLeft( 0 ), m_pkRight( 0 ), m_eBalance( BALANCED ), m_pkData( pkData ) {}
};




/**
  * \class AVLTree
  * \brief Balanced binary tree that allows nodes with identical values
  * \author Mattias Jansson (mattias@realityrift.com)
  */
template <class AVLTreeDataType> class AVLTree
{
	public:

		typedef AVLTreeNode< AVLTreeDataType >    AVLTreeNodeType;


		/**
		* \enum AVLTREERESULT
		* \brief Result of tree operation
		*/
		enum AVLTREERESULT
		{
		  /*! None of the subtrees has grown in height entire tree is still balanced */
		  OK,

		  /*! One of the branches has grown in height, tree might need rebalancing */
		  BALANCE,

		  /*! Error */
		  INVALID
		};


	protected:

		/**
		* Rotate tree left
		* \param ppkCurNode
		*/
		inline void                                   RotateLeft( AVLTreeNodeType **ppkCurNode )
		{
            AVLTreeNodeType *pkTmp = *ppkCurNode;
    
            *ppkCurNode             = (*ppkCurNode)->m_pkRight;
            pkTmp->m_pkRight        = (*ppkCurNode)->m_pkLeft;
            (*ppkCurNode)->m_pkLeft = pkTmp;
		}

		/**
		* Rotate tree right
		* \param ppkCurNode
		*/
		inline void                                   RotateRight( AVLTreeNodeType **ppkCurNode )
		{
            AVLTreeNodeType *pkTmp = *ppkCurNode;
    
            *ppkCurNode              = (*ppkCurNode)->m_pkLeft;
            pkTmp->m_pkLeft          = (*ppkCurNode)->m_pkRight;
            (*ppkCurNode)->m_pkRight = pkTmp;
		}

		/**
		* Rebalance tree after left side has grown
		* \param ppkCurNode                           Current node
		* \return                                     OK if tree is balanced (entire tree is valid), BALANCE if local tree is balanced but has grown in height (entire tree not guaranteed to be valid)
		*/
		inline AVLTREERESULT                          LeftGrown( AVLTreeNodeType **ppkCurNode )
		{
			switch( (*ppkCurNode)->m_eBalance )
			{
				case AVLTreeNodeType::LEFTHEAVY:
				{
					if( (*ppkCurNode)->m_pkLeft->m_eBalance == AVLTreeNodeType::LEFTHEAVY )
					{
						(*ppkCurNode)->m_eBalance = (*ppkCurNode)->m_pkLeft->m_eBalance = AVLTreeNodeType::BALANCED;
						RotateRight( ppkCurNode );
					}
					else
					{
						switch( (*ppkCurNode)->m_pkLeft->m_pkRight->m_eBalance )
						{
							case AVLTreeNodeType::LEFTHEAVY:
							{
								(*ppkCurNode)->m_eBalance           = AVLTreeNodeType::RIGHTHEAVY;
								(*ppkCurNode)->m_pkLeft->m_eBalance = AVLTreeNodeType::BALANCED;
								break;
							}

							case AVLTreeNodeType::RIGHTHEAVY:
							{
								(*ppkCurNode)->m_eBalance           = AVLTreeNodeType::BALANCED;
								(*ppkCurNode)->m_pkLeft->m_eBalance = AVLTreeNodeType::LEFTHEAVY;
								break;
							}

							default:
							{
								(*ppkCurNode)->m_eBalance           = AVLTreeNodeType::BALANCED;
								(*ppkCurNode)->m_pkLeft->m_eBalance = AVLTreeNodeType::BALANCED;
								break;
							}
						}

						(*ppkCurNode)->m_pkLeft->m_pkRight->m_eBalance = AVLTreeNodeType::BALANCED;
						
						RotateLeft( &(*ppkCurNode)->m_pkLeft );
						RotateRight( ppkCurNode );
					}

                    return OK;
				}
    
				case AVLTreeNodeType::RIGHTHEAVY:
				{
					(*ppkCurNode)->m_eBalance = AVLTreeNodeType::BALANCED;
					return OK;
				}
            
				default:
				{
					(*ppkCurNode)->m_eBalance = AVLTreeNodeType::LEFTHEAVY;
					return BALANCE;
				}
			}

			assert( !"Unreachable code" );

			return OK;
		}


		/**
		* Rebalance tree after right side has grown
		* \param ppkCurNode                           Current node
		* \return                                     OK if tree is balanced (entire tree is valid), BALANCE if local tree is balanced but has grown in height (entire tree not guaranteed to be valid)
		*/
		inline AVLTREERESULT                          RightGrown( AVLTreeNodeType **ppkCurNode )
		{
			switch( (*ppkCurNode)->m_eBalance )
			{
				case AVLTreeNodeType::LEFTHEAVY:
				{
					(*ppkCurNode)->m_eBalance = AVLTreeNodeType::BALANCED;
					return OK;
				}
    
				case AVLTreeNodeType::RIGHTHEAVY:
				{
					if( (*ppkCurNode)->m_pkRight->m_eBalance == AVLTreeNodeType::RIGHTHEAVY )
					{
						(*ppkCurNode)->m_eBalance = (*ppkCurNode)->m_pkRight->m_eBalance = AVLTreeNodeType::BALANCED;
						RotateLeft( ppkCurNode );
					}
					else
					{
						switch( (*ppkCurNode)->m_pkRight->m_pkLeft->m_eBalance )
						{
							case AVLTreeNodeType::RIGHTHEAVY:
							{
								(*ppkCurNode)->m_eBalance            = AVLTreeNodeType::LEFTHEAVY;
								(*ppkCurNode)->m_pkRight->m_eBalance = AVLTreeNodeType::BALANCED;
								break;
							}
                            
                            case AVLTreeNodeType::LEFTHEAVY:
							{
								(*ppkCurNode)->m_eBalance            = AVLTreeNodeType::BALANCED;
								(*ppkCurNode)->m_pkRight->m_eBalance = AVLTreeNodeType::RIGHTHEAVY;
								break;
							}

                            default:
							{
								(*ppkCurNode)->m_eBalance            = AVLTreeNodeType::BALANCED;
								(*ppkCurNode)->m_pkRight->m_eBalance = AVLTreeNodeType::BALANCED;
								break;
                            }
						}
                            
						(*ppkCurNode)->m_pkRight->m_pkLeft->m_eBalance = AVLTreeNodeType::BALANCED;
                        
						RotateRight( &(*ppkCurNode)->m_pkRight );
                        RotateLeft( ppkCurNode );
					}

					return OK;
				}
    
				default:
				{
					(*ppkCurNode)->m_eBalance = AVLTreeNodeType::RIGHTHEAVY;
					return BALANCE;
				}
			}

			assert( !"Unreachable code" );

			return OK;
		}

		/**
		* Rebalance tree after left side has shrunk
		* \param ppkCurNode                           Current node
		* \return                                     OK if tree is balanced (entire tree is valid), BALANCE if local tree is balanced but has grown in height (entire tree not guaranteed to be valid)
		*/
		inline AVLTREERESULT                          LeftShrunk( AVLTreeNodeType **ppkCurNode )
		{
			switch( (*ppkCurNode)->m_eBalance )
			{
				case AVLTreeNodeType::LEFTHEAVY:
				{
					(*ppkCurNode)->m_eBalance = AVLTreeNodeType::BALANCED;
					return BALANCE;
				}
    
				case AVLTreeNodeType::RIGHTHEAVY:
				{
					switch( (*ppkCurNode)->m_pkRight->m_eBalance )
					{
						case AVLTreeNodeType::RIGHTHEAVY:
						{
							(*ppkCurNode)->m_eBalance = (*ppkCurNode)->m_pkRight->m_eBalance = AVLTreeNodeType::BALANCED;
							RotateLeft( ppkCurNode );
							return BALANCE;
						}

						case AVLTreeNodeType::BALANCED:
						{
							(*ppkCurNode)->m_eBalance            = AVLTreeNodeType::RIGHTHEAVY;
							(*ppkCurNode)->m_pkRight->m_eBalance = AVLTreeNodeType::LEFTHEAVY;
                            RotateLeft( ppkCurNode );
                            return OK;
						}

						default:
						{
							switch( (*ppkCurNode)->m_pkRight->m_pkLeft->m_eBalance )
							{
								case AVLTreeNodeType::LEFTHEAVY:
								{
									(*ppkCurNode)->m_eBalance            = AVLTreeNodeType::BALANCED;
									(*ppkCurNode)->m_pkRight->m_eBalance = AVLTreeNodeType::RIGHTHEAVY;
									break;
								}
    
								case AVLTreeNodeType::RIGHTHEAVY:
								{
									(*ppkCurNode)->m_eBalance            = AVLTreeNodeType::LEFTHEAVY;
									(*ppkCurNode)->m_pkRight->m_eBalance = AVLTreeNodeType::BALANCED;
									break;
								}
    
								default:
								{
									(*ppkCurNode)->m_eBalance            = AVLTreeNodeType::BALANCED;
									(*ppkCurNode)->m_pkRight->m_eBalance = AVLTreeNodeType::BALANCED;
									break;
								}
							}

							(*ppkCurNode)->m_pkRight->m_pkLeft->m_eBalance = AVLTreeNodeType::BALANCED;
                            
							RotateRight( &(*ppkCurNode)->m_pkRight );
							RotateLeft( ppkCurNode );

							return BALANCE;
						}
					}

					break;
				}
    
				default:
				{
					(*ppkCurNode)->m_eBalance = AVLTreeNodeType::RIGHTHEAVY;
					return OK;
				}
			}

			assert( !"Unreachable code" );

			return OK;
		}
    

		/**
		* Rebalance tree after right side has shrunk
		* \param ppkCurNode                           Current node
		* \return                                     OK if tree is balanced (entire tree is valid), BALANCE if local tree is balanced but has grown in height (entire tree not guaranteed to be valid)
		*/
		inline AVLTREERESULT                          RightShrunk( AVLTreeNodeType **ppkCurNode )
		{
			switch( (*ppkCurNode)->m_eBalance )
			{
				case AVLTreeNodeType::RIGHTHEAVY:
				{
					(*ppkCurNode)->m_eBalance = AVLTreeNodeType::BALANCED;
					return BALANCE;
				}
    
				case AVLTreeNodeType::LEFTHEAVY:
				{
					switch( (*ppkCurNode)->m_pkLeft->m_eBalance )
					{
						case AVLTreeNodeType::LEFTHEAVY:
						{
							(*ppkCurNode)->m_eBalance = (*ppkCurNode)->m_pkLeft->m_eBalance = AVLTreeNodeType::BALANCED;
							RotateRight( ppkCurNode );
							return BALANCE;
						}

						case AVLTreeNodeType::BALANCED:
						{
							(*ppkCurNode)->m_eBalance           = AVLTreeNodeType::LEFTHEAVY;
							(*ppkCurNode)->m_pkLeft->m_eBalance = AVLTreeNodeType::RIGHTHEAVY;
							RotateRight( ppkCurNode );
							return OK;
						}

						default:
						{
							switch( (*ppkCurNode)->m_pkLeft->m_pkRight->m_eBalance )
							{
								case AVLTreeNodeType::LEFTHEAVY:
								{
									(*ppkCurNode)->m_eBalance           = AVLTreeNodeType::RIGHTHEAVY;
									(*ppkCurNode)->m_pkLeft->m_eBalance = AVLTreeNodeType::BALANCED;
									break;
								}
    
								case AVLTreeNodeType::RIGHTHEAVY:
								{
									(*ppkCurNode)->m_eBalance           = AVLTreeNodeType::BALANCED;
									(*ppkCurNode)->m_pkLeft->m_eBalance = AVLTreeNodeType::LEFTHEAVY;
									break;
								}
                            
								default:
								{
									(*ppkCurNode)->m_eBalance           = AVLTreeNodeType::BALANCED;
									(*ppkCurNode)->m_pkLeft->m_eBalance = AVLTreeNodeType::BALANCED;
									break;
								}
							}

							(*ppkCurNode)->m_pkLeft->m_pkRight->m_eBalance = AVLTreeNodeType::BALANCED;
                        
							RotateLeft( &(*ppkCurNode)->m_pkLeft );
							RotateRight( ppkCurNode );
							
							return BALANCE;
						}
					}

					break;
				}
    
				default:
				{
					(*ppkCurNode)->m_eBalance = AVLTreeNodeType::LEFTHEAVY;
					return OK;
				}
			}

			assert( !"Unreachable code" );

			return OK;
		}

		/**
		* Replace a node with the highest-ranking item in subtree
		* \param pkNode                               Node to be replaced
		* \param ppkSubTree                           Subtree to search
		* \param peResult                             Pointer to result variable to tell caller if further checks are needed
		* \return                                     true if node found, false if not
		*/
		inline bool                                   FindHighest( AVLTreeNodeType *pkTarget, AVLTreeNodeType **ppkSubTree, AVLTREERESULT *peResult )
		{
			AVLTreeNodeType *pkTmp;
    
			*peResult = BALANCE;

			if( !*ppkSubTree )
				return false;

			if( (*ppkSubTree)->m_pkRight )
			{
				if( !FindHighest( pkTarget, &(*ppkSubTree)->m_pkRight, peResult ) )
					return false;

				if( *peResult == BALANCE )
					*peResult = RightShrunk( ppkSubTree );

				return true;
			}

			pkTarget->m_pkData = (*ppkSubTree)->m_pkData;

			pkTmp       = *ppkSubTree;
			*ppkSubTree = (*ppkSubTree)->m_pkLeft;

			delete pkTmp;

			return true;
		}
    
		/**
		* Replace a node with the lowest-ranking item in subtree
		* \param pkNode                               Node to be replaced
		* \param ppkSubTree                           Subtree to search
		* \param peResult                             Pointer to result variable to tell caller if further checks are needed
		* \return                                     true if node found, false if not
		*/
		inline bool                                   FindLowest( AVLTreeNodeType *pkTarget, AVLTreeNodeType **ppkSubTree, AVLTREERESULT *peResult )
		{
			AVLTreeNodeType *pkTmp;
    
			*peResult = BALANCE;

			if( !*ppkSubTree )
				return false;

			if( (*ppkSubTree)->m_pkLeft )
			{
				if( !FindLowest( pkTarget, &(*ppkSubTree)->m_pkLeft, peResult ) )
					return false;

				if( *peResult == BALANCE )
					*peResult = LeftShrunk( ppkSubTree );

				return true;
			}

			pkTarget->m_pkData = (*ppkSubTree)->m_pkData;

			pkTmp       = *ppkSubTree;
			*ppkSubTree = (*ppkSubTree)->m_pkRight;

			delete pkTmp;

			return true;
		}

		/**
		* Insert data in tree and rebalance
		* \param ppkCurNode                           Pointer to current node pointer
		* \param pkData                               Data to insert
		* \return                                     Result of insert (OK if subtree is balanced, BALANCE if three is heavy on either side)
		*/
		AVLTREERESULT                                 Insert( AVLTreeNodeType **ppkCurNode, AVLTreeDataType *pkData )
		{
			AVLTREERESULT eResult = OK;
    
			if( !*ppkCurNode )
			{
				*ppkCurNode = new AVLTreeNodeType( pkData );
				return BALANCE;
			}

			if( *pkData < *(*ppkCurNode)->m_pkData )
			{
				if( ( eResult = Insert( &(*ppkCurNode)->m_pkLeft, pkData ) ) == BALANCE )
					eResult = LeftGrown( ppkCurNode );
			}
			else //if( *pkData >= *(*ppkCurNode)->m_pkData )
			{
				if( ( eResult = Insert( &(*ppkCurNode)->m_pkRight, pkData ) ) == BALANCE )
					eResult = RightGrown( ppkCurNode );
			}

			return eResult;
		}

		/**
		* Delete data from tree and rebalance
		* \param ppkCurNode                           Pointer to current node pointer
		* \param pkData                               Data to delete
		* \return                                     Result of deletion (OK if subtree is balanced, BALANCE if three is heavy on either side)
		*/
		AVLTREERESULT                                 Delete( AVLTreeNodeType **ppkCurNode, AVLTreeDataType *pkData )
		{
			if( !*ppkCurNode )
				return INVALID;

			AVLTREERESULT eResult = OK;

			if( pkData != (*ppkCurNode)->m_pkData )
			{
				//Since rotations in balance algorithm can make identical values end up in left subtree
				//we must search there as well if value of search data equals this node data
				if( ( *pkData <= *(*ppkCurNode)->m_pkData ) && (*ppkCurNode)->m_pkLeft )
				{
					if( ( eResult = Delete( &(*ppkCurNode)->m_pkLeft, pkData ) ) == BALANCE )
						return LeftShrunk( ppkCurNode );

					if( eResult != INVALID )
						return eResult;
				}
				
				if( ( *pkData >= *(*ppkCurNode)->m_pkData ) && (*ppkCurNode)->m_pkRight )
				{
					if( ( eResult = Delete( &(*ppkCurNode)->m_pkRight, pkData ) ) == BALANCE )
						return RightShrunk( ppkCurNode );

					if( eResult != INVALID )
						return eResult;
				}

				//Node not found
				return INVALID;
			}

			if( (*ppkCurNode)->m_pkLeft )
			{
				if( FindHighest( *ppkCurNode, &(*ppkCurNode)->m_pkLeft, &eResult ) )
				{
					if( eResult == BALANCE )
						eResult = LeftShrunk( ppkCurNode );
					return eResult;
				}
			}

			if( (*ppkCurNode)->m_pkRight )
			{
				if( FindLowest( *ppkCurNode, &(*ppkCurNode)->m_pkRight, &eResult ) )
				{
					if( eResult == BALANCE )
						eResult = RightShrunk( ppkCurNode );
					return eResult;
				}
			}
            
			delete *ppkCurNode;

			*ppkCurNode = 0;

			return BALANCE;
		}

		/**
		* Search for node with best fit to key
		* \param pkNode                               Current node
		* \param uiKey                                Search key
		* \return                                     Node
		*/
		AVLTreeNodeType                            *SearchBestFit( AVLTreeNodeType *pkNode, unsigned int uiKey )
		{
			if( !pkNode )
				return 0;

			if( *pkNode->m_pkData < uiKey )
				return SearchBestFit( pkNode->m_pkRight, uiKey );
			else if( *pkNode->m_pkData > uiKey )
			{
				AVLTreeNodeType *pkFoundNode = SearchBestFit( pkNode->m_pkLeft, uiKey );

				if( pkFoundNode )
					return pkFoundNode;
			}

			//We are either best or exact fit
			return pkNode;
		}

		/**
		* Delete nodes
		* \param pkNode                               Node to delete
		*/
		void                                          DeleteNode( AVLTreeNodeType *pkNode )
		{
			if( !pkNode )
				return;

			DeleteNode( pkNode->m_pkLeft );
			DeleteNode( pkNode->m_pkRight );

			delete pkNode;
		}

		/**
		* Get all node data
		* \param pvpkData                             Pointer to vector recieving data
		*/
		void                                          GetAllData( AVLTreeNodeType *pkNode, std::vector< AVLTreeDataType* > *pvpkData )
		{
			if( !pkNode )
				return;

			pvpkData->push_back( pkNode->m_pkData );

			GetAllData( pkNode->m_pkLeft, pvpkData );
			GetAllData( pkNode->m_pkRight, pvpkData );
		}



	public:

		/*! Root node */
		AVLTreeNodeType                            *m_pkRoot;


		/**
		*/
		                                              AVLTree() : m_pkRoot( 0 ) {}

		/**
		*/
		virtual                                      ~AVLTree() { DeleteNode( m_pkRoot ); }

		/**
		* Insert data
		* \param pkData                               Data object to insert
		*/
		inline void                                   Insert( AVLTreeDataType *pkData ) { Insert( &m_pkRoot, pkData ); }

		/**
		* Delete data
		* \param pkData                               Data object to delete
		*/
		inline void                                   Delete( AVLTreeDataType *pkData ) { Delete( &m_pkRoot, pkData ); }

		/**
		* Find data best matching required search criteria
		* \param uiKey                                Search key, matching node will be node best matching == compare, while still being larger
		* \return                                     Found data, or null if no match
		*/
		inline AVLTreeDataType                     *BestFit( unsigned int uiKey ) { AVLTreeNodeType *pkNode = SearchBestFit( m_pkRoot, uiKey ); return( pkNode ? pkNode->m_pkData : 0 ); }

		/**
		* Get all node data
		* \param pvpkData                             Pointer to vector recieving data
		*/
		inline void                                   GetAllData( std::vector< AVLTreeDataType* > *pvpkData ) { GetAllData( m_pkRoot, pvpkData ); }

		/**
		* Check tree
		* \param pkNode                               Subtree root
		*/
		inline void                                   CheckTreeIntegrity( AVLTreeNodeType *pkNode = 0 )
		{
			if( !pkNode )
			{
				if( m_pkRoot )
					CheckTreeIntegrity( m_pkRoot );

				return;
			}

			if( pkNode->m_pkLeft )
			{
				assert( *pkNode->m_pkData >= *pkNode->m_pkLeft->m_pkData );
				CheckTreeIntegrity( pkNode->m_pkLeft );
			}

			if( pkNode->m_pkRight )
			{
				assert( *pkNode->m_pkData <= *pkNode->m_pkRight->m_pkData );
				CheckTreeIntegrity( pkNode->m_pkRight );
			}
		}
};


}; // namespace NeoD3D9


#endif
