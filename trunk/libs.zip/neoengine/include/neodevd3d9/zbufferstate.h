/***************************************************************************
                   zbufferstate.h  -  Z buffer state management
                             -------------------
    begin                : Mon Mar 17 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevD3D9, zbufferstate.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NED3D9ZBUFFERSTATE_H
#define __NED3D9ZBUFFERSTATE_H



/**
  * \file zbufferstate.h
  * Z buffer state management
  */

#include "device.h"


namespace NeoD3D9
{


// External classes
class Device;


/**
  * \brief Z buffer state management
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class ZBufferState
{
	protected:

		/*! Device */
		Device                                       *m_pkDevice;

		/*! Write mode */
		unsigned int                                  m_uiWriteMode;

		/*! Current test mode */
		unsigned int                                  m_uiTestMode;

		/*! Translate table between engine mode enums and D3D9 enums */
		static D3DCMPFUNC                             s_aeTestModeTranslator[];

                
	public:

		/**
		* \param pkDevice                             Device
		*/
		                                              ZBufferState( Device *pkDevice );

		/**
		*/
		virtual                                      ~ZBufferState();

		/**
		* Set z buffer state
		* \param uiTest                               Test mode
		* \param uiWrite                              Write mode
		*/
		inline void                                   SetMode( unsigned int uiTest, unsigned int uiWrite ) { if( m_uiTestMode != uiTest ) m_pkDevice->m_pkDevice->SetRenderState( D3DRS_ZFUNC, s_aeTestModeTranslator[ ( m_uiTestMode = uiTest ) ] ); if( m_uiWriteMode != uiWrite ) m_pkDevice->m_pkDevice->SetRenderState( D3DRS_ZWRITEENABLE, ( ( m_uiWriteMode = uiWrite ) == NeoEngine::ZBufferMode::ENABLED ) ? TRUE : FALSE ); }
};


}; // namespace NeoD3D9


#endif
