/***************************************************************************
          polygonstripbuffer.h  -  Polygon strip buffer implementation
                             -------------------
    begin                : Sat Mar 15 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevD3D9, polygonstripbuffer.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NED3D9POLYGONSTRIPBUFFER_H
#define __NED3D9POLYGONSTRIPBUFFER_H


/**
  * \file polygonstripbuffer.h
  * Polygon strip buffer implementation
  */


#include "device.h"

#include <neoengine/polygon.h>


namespace NeoD3D9
{


// External classes
class BufferManager;
class BufferRegion;


/**
  * \brief Polygon strip storage for Direct3D 9
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class PolygonStripBufferD3D : public NeoEngine::PolygonStripBuffer
{
	protected:

		/*! Device */
		Device                                       *m_pkDevice;

		/*! Buffer manager */
		BufferManager                                *m_pkManager;


		/**
		* Called by Lock to acquire device dependant cached data
		*/
		virtual bool                                  AcquireLock();

		/**
		* Called by Unlock when no more active locks. Upload to D3D buffer area
		*/
		virtual void                                  ReleaseLock();



	public:

		/*! Direct3D buffer object */
		IDirect3DIndexBuffer9                        *m_pkD3DBuffer;

		/*! Buffer region */
		BufferRegion                                 *m_pkRegion;

#ifdef NED3DPOLYGONBUFFER_USEMINMAXINDEX
		/*! Minimum vertex index */
		unsigned int                                  m_uiMinIndex;

		/*! Maximum vertex index */
		unsigned int                                  m_uiMaxIndex;
#endif



		/**
		* \param pkDevice                             Device
		* \param uiType                               Buffer type
		* \param uiNumPolygons                        Polygon count
		* \param pusData                              Optional pointer to data to copy
		*/
		                                              PolygonStripBufferD3D( Device *pkDevice, BufferManager *pkBufferManager, unsigned int uiType = NORMAL, unsigned int uiNumPolygons = 0, const unsigned short *pkData = 0 );

		/**
		* Deallocate memory
		*/
		virtual                                      ~PolygonStripBufferD3D();

		/**
		* Resize buffer
		* \param uiNumPolygons                        New polygon count
		* \param pusData                              Optional pointer to data to copy
		*/
		virtual void                                  AllocateStrip( unsigned int uiNumPolygons, const unsigned short *pusData = 0 );
};


}; // namespace NeoD3D9


#endif

