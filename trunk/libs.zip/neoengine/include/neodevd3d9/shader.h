/***************************************************************************
                       shader.h  -  Pipeline shaders
                             -------------------
    begin       : Mon May 05 2003
    copyright   : (C) 2003 by Reality Rift Studios
    email       : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevD3D9, shader.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 Contributors: Keaton Mullis (kmullis@zianet.com)

 ***************************************************************************/

#ifndef __NED3D9SHADER_H
#define __NED3D9SHADER_H

#include "device.h"

#include <neoengine/shader.h>

namespace NeoD3D9
{


typedef NeoEngine::HashTable< class D3DShader > ShaderTable;


//typedef HRESULT ( __stdcall IDirect3DDevice9::* SetShaderConstantF )( unsigned int, const float*, unsigned int );


/**
  * \brief Direct3D9 implementation of pipeline shaders
  * \author Keaton Mullis (kmullis@zianet.com)
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class D3D9Shader : public NeoEngine::Shader
{
	friend class Device;

	protected:

		/*! Vertex shader table */
		static ShaderTable                            s_kVSTable;

		/*! Fragment shader table */
		static ShaderTable                            s_kFSTable;


		/*! Render device */
		Device                                       *m_pkDevice;

		/*! Shader type enum (vertexshader or fragment shader) */
		NeoEngine::Shader::SHADERTYPE                 m_eType;

		/*! Shader compiled? */
		bool                                          m_bCompiled;

		/*! Vertex shader object */
		IDirect3DVertexShader9                       *m_pkVertexShader;

		/*! Pixel shader object */
		IDirect3DPixelShader9                        *m_pkPixelShader;


		/**
		* Bind parameter for vertex shader
		* \param pkParam                              Parameter
		* \param pkPrimitive                          Current primitive
		* \param rkView                               Current view matrix
		*/
		inline void                                   BindParameterVS( NeoEngine::ShaderParam *pkParam, NeoEngine::RenderPrimitive *pkPrimitive, const NeoEngine::Matrix &rkView );

		/**
		* Bind parameter for pixel shader
		* \param pkParam                              Parameter
		* \param pkPrimitive                          Current primitive
		* \param rkView                               Current view matrix
		*/
		inline void                                   BindParameterPS( NeoEngine::ShaderParam *pkParam, NeoEngine::RenderPrimitive *pkPrimitive, const NeoEngine::Matrix &rkView );


	public:

		/**
		* Create an Direct3D pipeline shader
		* \param pkDevice                             Render device
		* \param eType                                Shader type
		* \param pkFileManager                        File manager
		*/
		                                              D3D9Shader( Device *pkDevice, SHADERTYPE eType, NeoEngine::FileManager *pkFileManager );

		/**
		* Destruct this instance of the Direct3D vertex shader instance
		*/
		virtual                                      ~D3D9Shader();

		/**
		* Set name of shader
		* \param rstrName                             New name
		*/
		virtual void                                  SetName( const NeoEngine::HashString &rstrName );

		/**
		* Compile the pipeline shader
		* \param pstrSource                           Source string, null if use already loaded source
		* \return                                     True if compiled, or false
		*/
		virtual bool                                  Compile( const std::string *pstrSource );

		/**
		* Bind this pipeline shader, performing Direct3D specific operations
		* \param pkPrimitive                          Current render primitive
		* \param rkView                               Current view matrix (engine format)
		* \return                                     True if bound, or false if error
		*/
		bool                                          Bind( NeoEngine::RenderPrimitive *pkPrimitive, const NeoEngine::Matrix &rkView );

		/**
		* Bind light parameters
		* \param pkPrimitive                          Primitive currently processing
		* \return                                     True if bound, or false if error
		*/
		bool                                          BindLightParams( NeoEngine::RenderPrimitive *pkPrimitive );

		/**
		* Disable shader
		* \return                                     true if successful, false if error
		*/
		bool                                          Unbind();
};


};


#endif
