/***************************************************************************
                 buffermanager.h  -  Buffer allocation manager
                             -------------------
    begin                : Fri Mar 27 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevD3D9, buffermanager.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NED3DBUFFERMANAGER_H
#define __NED3DBUFFERMANAGER_H


/**
  * \file buffermanager.h
  * Buffer allocation manager
  */


#include "avltree.h"

#include <vector>


namespace NeoD3D9
{


//External classes
class BufferRegion;



/**
  * Manages buffer allocations from backing store
  * \author Mattias Jansson (mattias@realityrift.com)
  */    
class BufferManager
{
	protected:

		/*! Size of allocated memory */
		unsigned int                                        m_uiSize;

		/*! Root region */
		BufferRegion                                       *m_pkRootRegion;

		/*! Tail region */
		BufferRegion                                       *m_pkTailRegion;

		/*! Free regions */
		AVLTree< BufferRegion >                             m_kFreeRegions;


	public:

		/**
		* \param uiSize                                     Initial size
		*/
		                                                    BufferManager( unsigned int uiSize );

		/**
		* Free memory
		*/
		virtual                                            ~BufferManager();

		/**
		* Get pointer to free region of memory
		* \param uiSize                                     Requested size
		* \param uiRequiredAlign                            Alignment of start of region, 0 if not required
		* \return                                           Pointer to buffer region object or null if failed
		*/
		virtual BufferRegion                               *Alloc( unsigned int uiSize, unsigned int uiRequiredAlign = 0 );

		/**
		* Free region of memory
		* \param pkRegion                                   Buffer region to free
		*/
		virtual void                                        Free( BufferRegion *pkRegion );

		/**
		* Set size of buffer
		* \param uiSize                                     New size
		*/
		virtual void                                        SetSize( unsigned int uiSize );

		/**
		* \return                                           Buffer size
		*/
		inline unsigned int                                 GetSize() const { return m_uiSize; }

		/**
		* Verify buffer region integrity
		*/
		void                                                CheckMemoryIntegrity();

		/**
		* Dump data about allocations to debug output
		*/
		void                                                DumpAllocationData();
};


}; // namespace NeoD3D9


#endif
