/***************************************************************************
                       renderqueue.h  -  Render queue 
                             -------------------
    begin                : Thu May 22 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevD3D9, renderqueue.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NED3D9RENDERQUEUE_H
#define __NED3D9RENDERQUEUE_H


/**
  * \file renderqueue.h
  * Render queue
  */


#include <neoengine/base.h>
#include <neoengine/radix.h>


namespace NeoD3D9
{


// External classes
class Device;
class OpArray;



/**
  * \brief A render queue caches, sorts and executes render primitives
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class RenderQueue
{
	public:

		/*! Device */
		Device                                       *m_pkDevice;
	
		/*! All operations for this frame */
		OpArray                                     **m_ppkOpArray;

		/*! Sort key values for allocated op arrays */
		uint64_t                                     *m_puiOpSort;

		/*! Max number of arrays pointers allocated */
		int                                           m_iNumOpArrayPointers;

		/*! Number of arrays allocated */
		int                                           m_iNumOpArrays;
		
		/*! Number of active op pointers in render op arrays */
		int                                           m_iNumOps;

		/*! Number of active op pointers in last frame */
		int                                           m_iLastNumOps;

		/*! Maximum number of ops (this is simply m_iNumOpArrays * ARRAYSIZE ) */
		int                                           m_iMaxOps;

		/*! Sky flag */
		bool                                          m_bIsSky;

		/*! Op sorter */
		NeoEngine::RadixSort                          m_kSorter;


		/**
		* Initialize data
		* \param pkDevice                             Device
		* \param iArrayPointers                       Number of initial array pointers
		* \param iArrays                              Number of initial arrays
		* \param bSky                                 Sky flag
		*/
		                                              RenderQueue( Device *pkDevice, int iArrayPointers, int iArrays, bool bSky );

		/**
		* Deallocate memory
		*/
		virtual                                      ~RenderQueue();

		/**
		* Allocate new array
		*/
		void                                          AllocArray();

		/**
		* Clean unused ops
		*/
		void                                          CleanOps();

		/**
		* Sort ops
		*/
		void                                          SortOps();

		/**
		* Execute ops
		*/
		void                                          ExecuteOps();
};


}; // namespace NeoD3D9


#endif

