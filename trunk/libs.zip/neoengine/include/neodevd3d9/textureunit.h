/***************************************************************************
                   textureunit.h  -  Texture unit management
                             -------------------
    begin                : Sun Mar 16 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevD3D9, textureunit.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NED3D9TEXTUREUNIT_H
#define __NED3D9TEXTUREUNIT_H


/**
  * \file textureunit.h
  * Texture unit management
  */

#include "device.h"
#include "texture.h"

#include <neoengine/material.h>


namespace NeoD3D9
{


/**
  * \brief Texture unit management
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class TextureUnit
{
	protected:

		/*! Filter mode translator table */
		static unsigned int                           s_auiFilterMode[4];

		/*! Device */
		Device                                       *m_pkDevice;

		/*! Unit number */
		unsigned int                                  m_uiID;

		/*! Current texture */
		IDirect3DBaseTexture9                        *m_pkCurTexture;

		/*! Current UV layer */
		unsigned int                                  m_uiUV;

		/*! Transform state ID */
		D3DTRANSFORMSTATETYPE                         m_eTransformState;

		/*! Flag indicating we got texture transform matrix */
		bool                                          m_bGotTransform;

		/*! Current flitering modes */
		unsigned char                                 m_aucFilter[3];

		/*! Current UV addressing mode */
		unsigned int                                  m_uiUVAddress;

		/*! Current max anisotropy */
		unsigned int                                  m_uiMaxAnisotropy;

	public:

		/**
		* \param pkDevice                             Device
		* \param uiID                                 Unit number
		*/
		                                              TextureUnit( Device *pkDevice, unsigned int uiID );

		/**
		*/
		virtual                                      ~TextureUnit();

		/**
		* Set texture
		* \param pkTexture                            Texture
		* \param uiFiltering                          Filtering
		*/
		inline void                                   SetTexture( IDirect3DBaseTexture9 *pkTexture )
		{
			if( m_pkCurTexture != pkTexture )
				m_pkDevice->m_pkDevice->SetTexture( m_uiID, ( m_pkCurTexture = pkTexture ) );
		}

		/**
		* Set UV layer to use
		* \param uiLayer                              Layer number
		*/
		inline void                                   SetUVLayer( unsigned int uiLayer )
		{ 
			if( m_uiUV != uiLayer )
				m_pkDevice->m_pkDevice->SetTextureStageState( m_uiID, D3DTSS_TEXCOORDINDEX, ( m_uiUV = uiLayer ) );
		}

		/**
		* Set blend mode
		* \param uiSrcMode                            Source mode
		* \param uiDstMode                            Destination mode
		* \param fFactor                              Constant factor
		* \return                                     true if compatible mode, false if incompatible
		*/
		bool                                          SetBlendMode( unsigned int uiSrcMode, unsigned int uiDstMode, float fFactor );

		/**
		* Set new texture transform matrix
		* \param pkMatrix                             New transform matrix, or 0 for identity
		* \param uiDim                                Dimension of texture coords
		*/
		void                                          SetTransform( NeoEngine::Matrix *pkMatrix, unsigned int uiDim );

		/**
		* Set filtering mode
		* \param uiFilter                             Filtering mode
		*/
		inline void                                   SetFiltering( unsigned int uiFilter )
		{
			static unsigned char aucFilter[3];

			aucFilter[0] =   uiFilter         & 0xFF;
			aucFilter[1] = ( uiFilter >> 8  ) & 0xFF;
			aucFilter[2] = ( uiFilter >> 16 ) & 0xFF;

			if( m_aucFilter[0] != aucFilter[0] )
				m_pkDevice->m_pkDevice->SetSamplerState( m_uiID, D3DSAMP_MINFILTER, s_auiFilterMode[ ( m_aucFilter[0] = aucFilter[0] ) ] );
			if( m_aucFilter[1] != aucFilter[1] )
				m_pkDevice->m_pkDevice->SetSamplerState( m_uiID, D3DSAMP_MAGFILTER, s_auiFilterMode[ ( m_aucFilter[1] = aucFilter[1] ) ] );
			if( m_aucFilter[2] != aucFilter[2] )
				m_pkDevice->m_pkDevice->SetSamplerState( m_uiID, D3DSAMP_MIPFILTER, s_auiFilterMode[ ( m_aucFilter[2] = aucFilter[2] ) ] );
		}

		/**
		* Set max anisotropy
		* \param uiMaxAnisotropy                      Max anisotropy
		*/
		inline void                                   SetMaxAnisotropy( unsigned int uiMaxAnisotropy )
		{
			if( m_uiMaxAnisotropy != uiMaxAnisotropy )
				m_pkDevice->m_pkDevice->SetSamplerState( m_uiID, D3DSAMP_MAXANISOTROPY, ( m_uiMaxAnisotropy = uiMaxAnisotropy ) );
		}

		/**
		* Set UV addressing mode
		* \param uiUVAddress                          New UV addressing mode
		*/
		inline void                                   SetAddressingMode( unsigned int uiUVAddress )
		{
			if( uiUVAddress != m_uiUVAddress )
			{
				m_pkDevice->m_pkDevice->SetSamplerState( m_uiID, D3DSAMP_ADDRESSU, ( ( uiUVAddress & 0x000F ) == NeoEngine::TextureLayer::CLAMP_U ) ? D3DTADDRESS_CLAMP : D3DTADDRESS_WRAP );
				m_pkDevice->m_pkDevice->SetSamplerState( m_uiID, D3DSAMP_ADDRESSV, ( ( uiUVAddress & 0x00F0 ) == NeoEngine::TextureLayer::CLAMP_V ) ? D3DTADDRESS_CLAMP : D3DTADDRESS_WRAP );
				//m_pkDevice->m_pkDevice->SetSamplerState( m_uiID, D3DSAMP_ADDRESSW, ( ( uiUVAddress & 0x0F00 ) == NeoEngine::TextureLayer::CLAMP_U ) ? D3DTADDRESS_CLAMP : D3DTADDRESS_WRAP );

				m_uiUVAddress = uiUVAddress;
			}
		}

		/**
		* Disable unit and all following units
		*/
		void                                          Disable();
};


}; // namespace NeoD3D9


#endif
