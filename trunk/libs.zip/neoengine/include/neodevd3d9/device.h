/***************************************************************************
                     device.h  -  Direct3D9 render device
                             -------------------
    begin                : Sun Mar 9 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevD3D9, device.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NED3D9DEVICE_H
#define __NED3D9DEVICE_H


/**
  * \file device.h
  * Direct3D9 render device
  */

#ifndef WIN32_LEAN_AND_MEAN
#  define WIN32_LEAN_AND_MEAN
#endif

#define NEEDGDI

#include <neoengine/render.h>

#include <windows.h>
#include <d3d9.h>

#include <string>

#undef ERROR

#ifndef NED3DPOLYGONBUFFER_USEMINMAXINDEX
//uncomment to use min and max index calculation
#  define NED3DPOLYGONBUFFER_USEMINMAXINDEX
#endif


namespace NeoEngine
{

// External classes
class Texture;

};


namespace NeoD3D9
{


//External classes
class TextureUnit;
class ZBufferState;
class BufferManager;
class D3D9Shader;
class RenderTarget;
class FrameBufferRenderTarget;
class PixelBufferRenderTarget;
class PixelBuffer;


/**
  * \brief Direct3D9 implementation of render device
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class Device : public NeoEngine::RenderDevice
{
	friend class Texture;
	friend class PixelBuffer;

	public:

		/*! Flag indicating if window class has been registered */
		static bool                                   s_bWindowClassRegistered;

		/*! Direct3D object */
		IDirect3D9                                   *m_pkD3D;

		/*! Direct3D device */
		IDirect3DDevice9                             *m_pkDevice;

		/*! Texture units */
		TextureUnit                                 **m_ppkTMU;

		/*! Number of texture units */
		unsigned int                                  m_uiNumTMUs;

		/*! Z buffer state manager */
		ZBufferState                                 *m_pkZBufferState;

		/*! Vertex buffer manager */
		BufferManager                                *m_pkVertexBufferManager;

		/*! Vertex buffer */
		IDirect3DVertexBuffer9                       *m_pkVertexBufferStore;

		/*! Polygon buffer manager */
		BufferManager                                *m_pkPolygonBufferManager;

		/*! Polygon buffer */
		IDirect3DIndexBuffer9                        *m_pkPolygonBufferStore;

		/*! Back buffer format */
		D3DFORMAT                                     m_eFormat;

		/*! Current vertex shader */
		D3D9Shader                                   *m_pkVertexShader;

		/*! Current fragment shader */
		D3D9Shader                                   *m_pkFragmentShader;

		/*! Frame callbacks */
		std::vector< NeoEngine::FrameCallback* >      m_avpkFrameCallbacks[ NeoEngine::FrameCallback::NUMCALLBACKS ];

		/*! Current active render target */
		RenderTarget                                 *m_pkCurTarget;
		
		/*! Frame buffer render target */
		FrameBufferRenderTarget                      *m_pkFrameBufferTarget;
		
		/*! Frame buffer render target */
		PixelBufferRenderTarget                      *m_pkPixelBufferTarget;

		/*! Pixel buffers */
		std::vector< PixelBuffer* >                   m_vpkPixelBuffers;

		/*! Default material */
		NeoEngine::MaterialPtr                        m_pkDefaultMaterial;

		/*! Flag to force use of default material */
		bool                                          m_bForceDefaultMaterial;

		/*! Ignore sending kill event on window close */
		bool                                          m_bIgnoreKill;

		/*! Current clamp modes for all texture coord layers */
		unsigned int                                  m_uiClamp[16];

		/*! Show mouse cursor? */
		bool                                          m_bShowCursor;

		/*! Draw outlines? */
		bool                                          m_bDrawOutlines;

		/*! Draw polygons? */
		bool                                          m_bDrawPolygons;

		/*! Draw normals? */
		bool                                          m_bDrawNormals;

		/*! Draw tangents? */
		bool                                          m_bDrawTangents;

		/*! Active lights */
		NeoEngine::Light                            **m_ppkLights;

		/*! Allocated number of light pointers */
		unsigned int                                  m_uiAllocatedLights;

		/*! Maximum number of lights in vertex lighting path */
		unsigned int                                  m_uiMaxLights;

		/*! Number of active lights */
		unsigned int                                  m_uiNumLights;

		/*! Current light offset */
		unsigned int                                  m_uiCurLight;

		/*! Total sum of ambient lights */
		NeoEngine::Color                              m_kAmbientLight;

		/*! Total sum of ambient light from all lights, including directional and point lights */
		NeoEngine::Color                              m_kTotalAmbientLight;


	public:

		/*! Pending events */
		std::vector< NeoEngine::InputEvent* >         m_vpkEvents;



		/**
		* \param pkFileManager                        File manager
		* \param pkInputManager                       Input manager to attach to for reporting events
		*/
		                                              Device( NeoEngine::FileManager *pkFileManager, NeoEngine::InputManager *pkInputManager );

		/**
		* Cleanup
		*/
		virtual                                      ~Device();

		/**
		* Open device
		* \param rkWndData                            Window data
		* \return                                     true if successful, false if not
		*/
		virtual bool                                  Open( const NeoEngine::RenderWindow &rkWndData );

		/**
		* Close device, restore settings
		*/
		virtual void                                  Close();

		/**
		* Initialize Direct3D
		* \param rkCaps                               Requested render caps
		* \return                                     true if successful, false if not
		*/
		bool                                          Initialize( const NeoEngine::RenderCaps &rkCaps );

		/**
		* Terminate Direct3D
		*/
		void                                          Shutdown();

		/**
		* Begin new frame. Call this before any calls to Render
		* \param rkViewMatrix                         View matrix for this batch of render operations
		*/
		virtual void                                  Begin( const NeoEngine::Matrix &rkViewMatrix, unsigned int uiFlags );

		/**
		* End frame
		*/
		virtual void                                  End();

		/**
		* Render primitive batch
		* \param rkData                               Render batch data
		* \param iFlags                               Batch flags
		*/
		virtual void                                  Render( const NeoEngine::RenderPrimitive &rkData, unsigned int uiFlags );

		/**
		* Set current render target
		* \param uiTarget                             Render target identifier
		* \param pkBuffer                             For offscreen rendering, pixel buffer object
		* \return                                     Previous render target identifier (you should restore this if other than INVALIDBUFFER)
		*/
		virtual unsigned int                          SetRenderTarget( unsigned int uiTarget );

		/**
		* Set culling mode. Must be called outside Begin()-End() block
		* \param eCullMode                            Culling mode identifier
		* \return                                     Last culling mode
		*/
		virtual CULLMODE                              SetCullMode( CULLMODE eCullMode );

		/**
		* Set stencil op (only when render target is STENCILBUFFER)
		* \param eZFail                               Operation when z buffer test fails
		* \param eZPass                               Operation when z buffer test passes
		*/
		virtual void                                  SetStencilOp( STENCILOP eStencilFail, STENCILOP eZFail, STENCILOP eZPass );

		/**
		* Set stencil function, reference value and test mask
		* \param eFunc                                Stencil test func
		* \param uiRefValue                           Reference value
		* \param uiTestMask                           A mask that is ANDed with both the reference value and the stored stencil value when the test is done
		*/
		virtual void                                  SetStencilFunc( STENCILFUNC eFunc, unsigned int uiRefValue, unsigned int uiTestMask );

		/**
		* Set stencil write mask
		* \param uiMask                               Write mask
		*/
		virtual void                                  SetStencilMask( unsigned int uiWriteMask );

		/**
		* Set render target write mask
		* \param bWrite                               Write flag, if false will disable writing to render target buffer, if true enable writing to render target buffer
		*/
		virtual void                                  SetTargetMask( bool bWrite );

		/**
		* Set buffer backing storage size. You must call this method prior to an Open() call, or
		* default sizes will be used.
		* \param uiVertexStorageSize                  Size in bytes of vertex buffer storage (default 3Mb)
		* \param uiPolygonStorageSize                 Size in bytes of polygon buffer storage (default 1Mb)
		* \return                                     true if successful, false if error (called after Open(), unable to allocate memory)
		*/
		virtual bool                                  SetStorageSize( unsigned int uiVertexStorageSize, unsigned int uiPolygonStorageSize );

		/**
		* Set projection matrix
		* \param rkMatrix                             Projection matrix
		*/
		virtual void                                  SetProjection( const NeoEngine::Matrix &rkMatrix );

		/**
		* Set rendering viewport (must be outside Begin()-End() block)
		* \param iX                                   Starting x coordinate
		* \param iY                                   Starting y coordinate
		* \param iWidth                               Width
		* \param iHeight                              Height
		*/
		virtual void                                  SetViewport( int iX, int iY, int iWidth, int iHeight );

		/**
		* Clear the current viewport (must be outside Begin()-End() block) for framebuffer, 
		* or for other clear targets clear the whole buffer
		* \param uiTargets                            Target bitfield (combination of CLEAR_xxx enums )
		* \param rkColor                              Color to clear color buffer with
		* \param fZValue                              Value to clear z buffer with
		* \param uiStencilValue                       Value to clear stencil buffer with
		*/
		virtual void                                  Clear( unsigned int uiTargets, const NeoEngine::Color &rkColor, float fZValue, unsigned int uiStencilValue );

		/**
		* Flip buffers, flush pipeline (must be outside Begin()-End() block)
		*/
		virtual void                                  Flip();

		/**
		* Add light to rendering pipeline for this Begin()-End() block. This is implementation/hardware specific and is not guaranteed to work in the fixed-function pipeline (max number of lights)
		* \param pkLight                              Light to add
		* \return                                     < 0 if failed
		*/
		virtual int                                   AddLight( NeoEngine::Light *pkLight );

		/**
		* Load a texture file. Implement in derived class
		* \param rstrFilename                         File name
		* \param eTextureType                         Texture type (2D, cubemap, ...)
		* \param eTextureFormat                       Requested texture format (Texture::DEFAULT if not needed)
		* \param uiFlags                              Load flags (default Texture::NONE)
		* \param uiFiltering                          Texture filtering modes (0 as default, using default set device filtering mode)
		* \param uiMaxAnisotropy                      Max anisotropy
		* \return                                     Ptr to texture
		*/
		virtual NeoEngine::TexturePtr                 LoadTexture( const std::string &rstrFilename, NeoEngine::Texture::TEXTURETYPE eTextureType, NeoEngine::Texture::TEXTUREFORMAT eTextureFormat, unsigned int uiFlags, unsigned int uiFiltering, unsigned int uiMaxAnisotropy );

		/**
		* Create new texture object
		* \param rstrName                             Texture name
		* \param eTextureType                         Texture type (2D, cubemap, ...)
		* \param eTextureFormat                       Requested texture format (Texture::DEFAULT if not needed)
		* \return                                     Ptr to texture
		*/
		virtual NeoEngine::TexturePtr                 CreateTexture( const std::string &rstrName, NeoEngine::Texture::TEXTURETYPE eTextureType, NeoEngine::Texture::TEXTUREFORMAT eTextureFormat );

		/**
		* Find texture by name
		* \param rstrName                             Texture name
		* \return                                     Ptr to texture
		*/
		virtual NeoEngine::TexturePtr                 GetTexture( const std::string &rstrName );

		/**
		* Allocate a vertex buffer
		* \param uiType                               Buffer type
		* \param uiNumVertices                        Number of vertices
		* \param uiVertexFormat                       Flexible vertex format specifier
		* \param pData                                Optional pointer to data to load buffer with
		* \return                                     Ptr to new vertex buffer
		*/
		virtual NeoEngine::VertexBufferPtr            CreateVertexBuffer( unsigned int uiType, unsigned int uiNumVertices, const NeoEngine::VertexDeclaration *pkFormat, const void *pData );

		/**
		* Allocate a polygon buffer
		* \param uiType                               Buffer type
		* \param uiNumPolygons                        Number of polygons
		* \param pkData                               Optional pointer to data to load buffer with
		* \param bStripify                            Stripify buffer if true
		* \return                                     Ptr to new polygon buffer
		*/
		virtual NeoEngine::PolygonBufferPtr           CreatePolygonBuffer( unsigned int uiType, unsigned int uiNumPolygons, const NeoEngine::Polygon *pkData, bool bStripify );

		/**
		* Allocate a polygon strip buffer
		* \param uiType                               Buffer type
		* \param uiNumPolygons                        Number of polygons
		* \param pusData                              Optional pointer to data to load buffer with
		* \return                                     Ptr to new polygon strip buffer
		*/
		virtual NeoEngine::PolygonStripBufferPtr      CreatePolygonStripBuffer( unsigned int uiType, unsigned int uiNumPolygons, const unsigned short *pusData );

		/**
		* Create a pixel buffer for offscreen rendering
		* \param uiWidth                              Width of buffer
		* \param uiHeight                             Height of buffer
		* \param uiBPP                                Suggested bit depth (might be ignored if not found or incompatible in windowed mode)
		* \param eTextureType                         Target texture type (2D, cubemap, ... )
		* \return                                     New pixel buffer object, or null if error/unsupported
		*/
		virtual NeoEngine::PixelBuffer               *CreatePixelBuffer( unsigned int uiWidth, unsigned int uiHeight, unsigned int uiBPP, NeoEngine::Texture::TEXTURETYPE eTextureType );

		/**
		* Create a new shader object, which can then be loaded and compiled
		* \param eType                                Shader type (vertex or fragment)
		* \return                                     Pointer to the new shader object
		*/
		virtual NeoEngine::ShaderPtr                  CreateShader( NeoEngine::Shader::SHADERTYPE eType );

		/**
		* Find shader by name and type (only successfully compiled shaders are searched)
		* \param eType                                Shader type
		* \param rstrName                             Shader name
		* \return                                     Ptr to Shader
		*/
		virtual NeoEngine::ShaderPtr                  GetShader( NeoEngine::Shader::SHADERTYPE eType, const std::string &rstrName );

		/**
		* Read pixels from currently bound buffer (framebuffer, pixelbuffer, stencilbuffer)
		* \return                                     Image data containing pixels
		*/
		virtual NeoEngine::ImageData                 *ReadPixels();

		/**
		* \return                                     String with statistics for last frame
		*/
		virtual std::string                           GetStatistics();

		/**
		* Set mouse position relative window client area top-left corner.
		* \param iX                                   X coordinate in pixels
		* \param iX                                   Y coordinate in pixels
		*/
		virtual void                                  SetMousePos( int iX, int iY );

		/**
		* Capture or release mouse from window
		* \param bCapture                             If true, capture mouse in window. If false, release mouse
		*/
		virtual void                                  CaptureMouse( bool bCapture );

		/**
		* Show or hide mouse cursor
		* \param bShow                                If true, show cursor. If false, hide cursor
		*/
		virtual void                                  ShowCursor( bool bShow );

		/**
		* Process OS messages
		* \param pkEvent                              Ptr to event to fill with data of first event in queue
		* \return                                     true if event was collected, false if not (no event in queue)
		*/
		bool                                          Collect( NeoEngine::InputEvent *pkEvent );

		/**
		* Configuration change callback
		* \param rstrKey                              Key that has changed
		*/
		void                                          ConfigValueChange( const NeoEngine::HashString &rstrKey );

		/**
		* \return                                     Vertex buffer store
		*/
		IDirect3DVertexBuffer9                       *GetVertexBufferStore() { return m_pkVertexBufferStore; }

		/**
		* \return                                     Polygon buffer store
		*/
		IDirect3DIndexBuffer9                        *GetPolygonBufferStore() { return m_pkPolygonBufferStore; }

		/**
		* Register/deregister frame callback
		* \param eType                                Callback type
		* \param pkCallback                           Callback object
		* \param bRegister                            If true, register new callback. If false, deregister callback
		*/
		virtual void                                  RegisterFrameCallback( NeoEngine::FrameCallback::FRAMECALLBACKTYPE eType, NeoEngine::FrameCallback *pkCallback, bool bRegister );

		/**
		* Query device for available adapters
		* \param pvkAdapters                          Pointer to vector receiving available adapters
		*/
		virtual void                                  QueryAdapters( std::vector< NeoEngine::RenderAdapter > *pvkAdapters );

		/**
		* Query device for available fullscreen resolutions, sorted by total area, bits per pixel, refresh rate
		* \param pvkResolutions                       Pointer to vector receiving available resolutions
		* \param uiAdapter                            Adapter identifier, 0 for default (primary) adapter
		*/
		virtual void                                  QueryResolutions( std::vector< NeoEngine::RenderResolution > *pvkResolutions, unsigned int uiAdapter );
};


}; // namespace NeoD3D9


#endif
