/***************************************************************************
        bufferregion.h  -  Abstract representation of memory region
                             -------------------
    begin                : Fri Mar 27 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevD3D9, bufferregion.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NED3DBUFFERREGION_H
#define __NED3DBUFFERREGION_H


/**
  * \file bufferregion.h
  * Memory region abstraction
  */

namespace NeoD3D9
{


/**
  * \brief Memory region
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class BufferRegion
{
	public:

		/**
		* \brief State identifiers
		*/
		enum BUFFERREGIONSTATE
		{
		  /*! Allocated */
		  ALLOCATED,

		  /*! Free */
		  FREE
		};


		/*! Size of aligned region */
		unsigned int                                  m_uiRegionSize;

		/*! Aligned offset from start of buffer */
		unsigned int                                  m_uiRegionOffset;

		/*! Real size */
		unsigned int                                  m_uiRealSize;

		/*! Real offset */
		unsigned int                                  m_uiRealOffset;

		/*! Border region */
		BufferRegion                                 *m_pkPreRegion;

		/*! Border region */
		BufferRegion                                 *m_pkPostRegion;

		/*! Region state */
		BUFFERREGIONSTATE                             m_eState;


		/**
		*/
		                                              BufferRegion() : m_uiRegionSize( 0 ), m_uiRegionOffset( 0 ), m_uiRealOffset( 0 ), m_uiRealSize( 0 ), m_pkPreRegion( 0 ), m_pkPostRegion( 0 ), m_eState( ALLOCATED ) {}

		/**
		* Align buffer offset
		* \param uiAlignment                          Alignment requirement
		* \param uiSize                               Size
		*/
		inline void                                   Align( unsigned int uiAlignment, unsigned int uiSize )
		{
			unsigned int uiPadding = uiAlignment ? ( m_uiRealOffset % uiAlignment ) : 0;

			if( uiPadding )
				uiPadding = uiAlignment - uiPadding;

			m_uiRegionOffset = m_uiRealOffset + uiPadding;
			m_uiRegionSize   = uiSize;
		}

		/**
		* Compare region sizes
		* \param rkRegion                             Reference region object to compare with
		* \return                                     true if region size is smaller than reference region
		*/
		inline bool                                   operator < ( const BufferRegion &rkRegion ) const { return( m_uiRealSize < rkRegion.m_uiRealSize ); }

		/**
		* Compare region sizes
		* \param rkRegion                             Reference region object to compare with
		* \return                                     true if region size is equal or smaller than reference region
		*/
		inline bool                                   operator <= ( const BufferRegion &rkRegion ) const { return( m_uiRealSize <= rkRegion.m_uiRealSize ); }

		/**
		* Compare region sizes
		* \param rkRegion                             Reference region object to compare with
		* \return                                     true if region size is larger than reference region
		*/
		inline bool                                   operator > ( const BufferRegion &rkRegion ) const { return( m_uiRealSize > rkRegion.m_uiRealSize ); }

		/**
		* Compare region sizes
		* \param rkRegion                             Reference region object to compare with
		* \return                                     true if region size is equal or larger than reference region
		*/
		inline bool                                   operator >= ( const BufferRegion &rkRegion ) const { return( m_uiRealSize >= rkRegion.m_uiRealSize ); }

		/**
		* Compare region size
		* \param uiSize                               Size to compare with
		* \return                                     true if region size is smaller than reference value
		*/
		inline bool                                   operator < ( unsigned int uiSize ) const { return( m_uiRealSize < uiSize ); }

		/**
		* Compare region size
		* \param uiSize                               Size to compare with
		* \return                                     true if region size is equal or smaller than reference value
		*/
		inline bool                                   operator <= ( unsigned int uiSize ) const { return( m_uiRealSize <= uiSize ); }

		/**
		* Compare region size
		* \param rkRegion                             Size to compare with
		* \return                                     true if region size is larger than reference value
		*/
		inline bool                                   operator > ( unsigned int uiSize ) const { return( m_uiRealSize > uiSize ); }

		/**
		* Compare region sizes
		* \param rkRegion                             Size to compare with
		* \return                                     true if region size is equal or larger than reference value
		*/
		inline bool                                   operator >= ( unsigned int uiSize ) const { return( m_uiRealSize >= uiSize ); }
};


}; // namespace NeoD3D9


#endif
