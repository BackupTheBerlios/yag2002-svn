/***************************************************************************
                 vertexbuffer.h  -  Vertex buffer implementation
                             -------------------
    begin                : Mon Mar 10 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevD3D9, vertexbuffer.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NED3D9VERTEXBUFFER_H
#define __NED3D9VERTEXBUFFER_H


/**
  * \file vertexbuffer.h
  * Vertex buffer implementation
  */


#include <neoengine/vertexbuffer.h>
#include <neoengine/vertexdecl.h>


namespace NeoD3D9
{


// External classes
class Device;
class BufferManager;
class BufferRegion;


/**
  * \brief Vertex storage for D3D9
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class VertexBufferD3D : public NeoEngine::VertexBuffer
{
	protected:

		/*! Device */
		Device                                       *m_pkDevice;

		/*! Buffer manager */
		BufferManager                                *m_pkManager;

		/**
		* Called by Lock to acquire device dependant cached data
		*/
		virtual bool                                  AcquireLock();

		/**
		* Called by Unlock when no more active locks. Upload to D3D buffer area
		*/
		virtual void                                  ReleaseLock();



	public:

		/*! Direct3D FVF identifier */
		unsigned int                                  m_uiD3DFVF;

		/*! Direct3D buffer object */
		IDirect3DVertexBuffer9                       *m_pkD3DBuffer;

		/*! Buffer region */
		BufferRegion                                 *m_pkRegion;

		/*! Vertex declaration */
		IDirect3DVertexDeclaration9                  *m_pkVertexDeclaration;

		/*! Texture layer dimensions */
		unsigned int                                  m_auiTexLayerDims[16];


		/**
		* \param pkDevice                             Device
		* \param pkBufferManager                      Buffer manager
		* \param uiType                               Buffer type
		* \param uiNumVertices                        New vertex count
		* \param pkFormat                             Vertex format
		* \param pData                                Optional pointer to data to copy
		*/
		                                              VertexBufferD3D( Device *pkDevice, BufferManager *pkBufferManager, unsigned int uiType, unsigned int uiNumVertices, const NeoEngine::VertexDeclaration *pkFormat, const void *pData = 0 );

		/**
		* Deallocate memory
		*/
		virtual                                      ~VertexBufferD3D();

		/**
		* Resize buffer
		* \param uiNumVertices                        New vertex count
		* \param pkFormat                             Vertex format
		* \param pData                                Optional pointer to data to copy
		*/
		virtual void                                  AllocateVertices( unsigned int uiNumVertices, const NeoEngine::VertexDeclaration *pkFormat, const void *pData = 0 );
};


}; // namespace NeoD3D9


#endif

