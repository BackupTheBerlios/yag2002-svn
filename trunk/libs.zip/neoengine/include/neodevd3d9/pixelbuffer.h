/***************************************************************************
           pixelbuffer.h  -  Direct3D pixel buffer implementation
                             -------------------
    begin                : Fri May 23 2003
    copyright            : (C) 2003 by Keaton Mullis
    email                : kmullis@zianet.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevD3D9, pixelbuffer.h

 The Initial Developer of the Original Code is Keaton Mullis.
 Portions created by Keaton Mullis are Copyright (C) 2003
 Keaton Mullis. All Rights Reserved.

 Contributors: Mattias Jansson (mattias@realityrift.com)

 ***************************************************************************/

#ifndef __NED3DPIXELBUFFER_H
#define __NED3DPIXELBUFFER_H

#include "device.h"
#include "texture.h"

#include <neoengine/activator.h>
#include <neoengine/pixelbuffer.h>



/**
  * \file pixelbuffer.h
  * Classes for Direct3D pixel buffer
  */


namespace NeoD3D9
{


/**
  * \brief Direct3D pixel buffer implementation
  * \author Keaton Mullis (kmullis@zianet.com)
  */
class PixelBuffer : public NeoEngine::PixelBuffer, virtual public NeoEngine::Activator
{
    public:

		                                              PixelBuffer( Device *pkDevice );

		virtual                                      ~PixelBuffer();

		bool                                          Open( unsigned int uiWidth, unsigned int uiHeight, unsigned int uiBPP, Texture::TEXTURETYPE eTextureType );

		void                                          Close();

		virtual void                                  Activate();

		virtual void                                  Deactivate();

		/**
		* Set active target cubemap face. Ignored for non-cubemap target texture types
		* \param eCubeMapFace                         Which cubemap face to render to
		*/
		virtual void                                  SetCubeMapFace( Texture::TEXTURECUBEMAPFACE eCubeMapFace );

		/**
		* Get texture object from this pixel buffer
		* \return                                     Texture
		*/
		virtual const NeoEngine::TexturePtr          &GetTexture() { return m_pkTexture; }

	protected:

		Device                                       *m_pkDevice;

		IDirect3DSurface9                            *m_pkSurface;

		IDirect3DSurface9                            *m_pkBackBuffer;

		NeoEngine::TexturePtr                         m_pkTexture;

		Texture::TEXTURECUBEMAPFACE                   m_eCurCubemapFace;

		NeoEngine::Viewport                           m_kViewport;
};


}; // namespace NeoD3D9


#endif


