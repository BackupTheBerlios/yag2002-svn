/***************************************************************************
               core.h  -  Lua scripting core object and services
                             -------------------
    begin                : Fri Jan 16 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoLua, core.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOLUA_CORE_H
#define __NEOLUA_CORE_H

#include "base.h"

#include <vector>


namespace NeoLua
{


// External classes
class Script;
class BindingCallback;


#ifdef WIN32
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif
#  ifndef __HAVE_VECTOR_NEOLUABINDINGCALLBACK
     NeoLuaUDTVectorEXPIMP( class BindingCallback* );
#    define __HAVE_VECTOR_NEOLUABINDINGCALLBACK
#  endif
#endif


class NEOLUA_API Core
{
	protected:

		/*! Singleton object */
		static Core                                  *s_pkSingleton;



		/*! Binding callback objects */
		std::vector< BindingCallback* >               m_vpkBinders;


		/**
		* Prevent new objects to be created
		*/
		                                              Core();


	public:

		/**
		*/
		                                             ~Core();


		/**
		* Initialize Lua scripting core
		* \return                                     true if successful, false if not
		*/
		bool                                          Initialize();

		/**
		* Terminate Lua scripting core, deallocate core object
		*/
		void                                          Shutdown();

		/**
		* Create a new Lua script
		* \return                                     new Lua script
		*/
		Script                                       *CreateScript();

		/**
		* Add a callback for intializing and binding a new Lua script
		* \param pkBinder                             Binding callback object, will be deleted when scripting services terminate
		*/
		void                                          AddBindingCallback( BindingCallback *pkBinder );

		/**
		* Get singleton object
		* \return                                     Chunk I/O core object
		*/
		inline static Core                           *Get() { if( !s_pkSingleton ) s_pkSingleton = new Core; return s_pkSingleton; }
};


};


#endif
