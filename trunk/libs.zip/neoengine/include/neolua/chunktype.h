/***************************************************************************
                 chunktype.h  -  Builtin chunk type identifiers
                             -------------------
    begin                : Fri Jan 16 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoLua, chunktype.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOLUA_CHUNKTYPE_H_
#define __NEOLUA_CHUNKTYPE_H_


/**
  * \file neolua/chunktype.h
  * Builtin chunk type identifiers
  */

  
#include "base.h"


#ifdef HAVE_NEOCHUNKIO


namespace NeoLua
{


/**
  * \brief Chunk type identifier class with builtin chunk type identifiers
  * \author Mattias Jansson (mattias@realityrift.com)
  **/
class NEOLUA_API ChunkType
{
	public:

		/**
		* \enum CHUNKTYPE
		* \brief Builtin chunk type identifiers and string identifiers
		*/
		enum CHUNKTYPE
		{
		  /*! First reserved chunk type ID */
		  FIRSTBUILTINCHUNKTYPE                             = 0x3C00,

		  /*! WTK hook method */
		  WTKMSGHOOK                                        = 0x3C00,  // "luawtkmsghook"

		  /*! Last reserved chunk type ID */
		  LASTBUILTINCHUNKTYPE                              = 0x3CFF
		};
};


};


#endif


#endif

