/***************************************************************************
                    console.h  -  Lua scriptable console
                             -------------------
    begin                : Sun Jan 18 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoLua, console.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NEOLUA_CONSOLE_H
#define __NEOLUA_CONSOLE_H


/**
  * \file console.h
  * Lua scriptable console
  */


#include "base.h"

#include <neoengine/console.h>


namespace NeoLua
{


// External classes
class Script;


/**
  * \brief Lua scriptable extended console
  * Adds Lua scripting capabilities to the engine console
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOLUA_API LuaConsole : public NeoEngine::Console
{
	protected:

		/*! Script */
		Script                                       *m_pkScript;

		/**
		* Process command entered in console
		* \param rstrCmd                              Command string
		* \return                                     true if command was processed, false if not
		*/
		virtual bool                                  ProcessCmd( const std::string &rstrCmd );


	public:

		/**
		* \param uiHistory                            Number of lines in history
		*/
		                                              LuaConsole( unsigned int uiHistory = DEFAULTHISTORY );

		/**
		* Deallocate memory
		*/
		virtual                                      ~LuaConsole();

		/**
		* \return                                     Lua script object
		*/
		inline virtual Script                        *GetScript() { return m_pkScript; }
};


};


#endif
