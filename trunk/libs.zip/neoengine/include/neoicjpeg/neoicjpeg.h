/***************************************************************************
                         neoicjpeg.h  -  description
                             -------------------
    begin                : Wed Apr 18 2002
    copyright            : (C) 2002 by Mattias Jansson
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoICJPEG, neoicjpeg.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOICJPEG_H
#define __NEOICJPEG_H


#include <neoengine/base.h>
#include <neoengine/texture.h>


namespace NeoJPEG
{


/**
  * \brief Image loader codec for jpeg files
  * This codec uses the free libjpeg library from The Independant JPEG Group. Please read
  * the README file in the jpeg-6b subdirectory for license information.
  * \author Mattias Jansson (mattias@realityrift.com)
  */	
class ImageCodec : public NeoEngine::ImageCodec
{
	public:

		/**
		* Create new JPEG loader codec object
		* \param rvstrExtensions        Extension string vector
		*/
		                                ImageCodec( const std::vector<std::string> &rvstrExtensions );

		/**
		* Check if file is a JPEG file
		* \param pkFile                 File to check
		* \return                       true if JPEG file, false if not recognized
		*/
		bool                            IsType( NeoEngine::File *pkFile );

		/**
		* Loads data from file
		* \param pkFile                 File
		* \return                       Ptr to new ImageData object
		*/
		NeoEngine::ImageData           *LoadImage( NeoEngine::File *pkFile );

		/**
		* Free image data
		* \param pkImageData            Image data
		*/
		void                            FreeImage( NeoEngine::ImageData *pkImageData );

		/**
		* Write image to file
		* \param pkImage                Image to write
		* \param pkFile                 File to write image into
		*/
		virtual bool                    WriteImage( NeoEngine::ImageData *pkImage, NeoEngine::File *pkFile );
};


}; // namespace NeoJPEG


#endif
