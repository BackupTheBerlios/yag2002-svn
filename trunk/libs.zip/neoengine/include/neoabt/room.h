/***************************************************************************
                       room.h  -  Main ABT room class
                             -------------------
    begin                : Tue Jul 8 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoABT, room.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEABT_ROOM_H
#define __NEABT_ROOM_H


/**
  * \file neoabt/room.h
  * Main ABT room class
  */


#include "base.h"

#include <neoengine/room.h>
#include <neoengine/renderprimitive.h>


/**
  * \brief Namespace for ABT room implementation classes
  */
namespace NeoABT
{


// External classes
class Node;


/**
  * \brief Adaptive binary tree room
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOABT_API ABTRoom : public NeoEngine::Room
{
	protected:

		/*! Root node */
		Node                                         *m_pkRoot;


	public:

		/*! Render primitive used in render loop */
		static NeoEngine::RenderPrimitive             s_kRenderPrimitive;


		/**
		* \param rstrName                             Room name
		*/
		                                              ABTRoom( const NeoEngine::HashString &rstrName = "" );

		/**
		*/
		virtual                                      ~ABTRoom();

		/**
		* Attach node. Set node room pointer
		* \param pkNode                               Node to attach
		* \param bKeepWorldSRT                        If true, recalculate node relative position to maintain world SRT
		* \return                                     undefined (reserved for future use or derived classes)
		*/
		virtual int                                   AttachNode( NeoEngine::SceneNode *pkNode, bool bKeepWorldSRT = false );

		/**
		* Detach node. Reset node room pointer
		* \param pkNode                               Node to detach
		* \return                                     undefined (reserved for future use or derived classes)
		*/
		virtual int                                   DetachNode( NeoEngine::SceneNode *pkNode );

		/**
		* Render room
		* \param pkFrustum                            Current view frustum (if any)
		* \param bForce                               Render even if rendered previously this frame or deactivated
		* \return                                     true if we were rendered, false if not (already rendered)
		*/
		virtual bool                                  Render( NeoEngine::Frustum *pkFrustum = 0, bool bForce = false );

		/**
		* Update object
		* \param fDeltaTime                           Time passed since last update
		*/
		virtual void                                  Update( float fDeltaTime );

		/**
		* Add and partition geometry
		* \param pkPolygonBuffer                      Polygon buffer
		* \param pkVertexBuffer                       Vertex buffer
		* \param pkMaterial                           Material
		*/
		virtual void                                  AddGeometry( const NeoEngine::PolygonBufferPtr &pkPolygonBuffer, const NeoEngine::VertexBufferPtr &pkVertexBuffer, const NeoEngine::MaterialPtr &pkMaterial );

		/**
		* Slice geometry with triangle
		* \param rkV0                                 First vertex
		* \param rkV1                                 Second vertex
		* \param rkV2                                 Third vertex
		* \param pvkPoints                            Pointer to vector receiving line segments
		*/
		virtual void                                  SliceGeometry( const NeoEngine::Vector3d &rkV0, const NeoEngine::Vector3d &rkV1, const NeoEngine::Vector3d &rkV2, std::vector< NeoEngine::Vector3d > *pvkPoints );

		/**
		* Intersection test with unknown object type
		* \param pkObj                                Bounding volume object to test for intersection with
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \return                                     true if volumes intersect, false if not
		*/
		virtual bool                                  Intersection( NeoEngine::BoundingVolume *pkObj, NeoEngine::ContactSet *pkContactSet = 0 );

		/**
		* Intersection test with ray
		* \param rkRay                                Ray
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \return                                     true if volumes intersect, false if not
		*/
		virtual bool                                  Intersection( const NeoEngine::Ray &rkRay, NeoEngine::ContactSet *pkContactSet = 0 );

		/**
		* Search hierarchy for named node, including this node. Will return first node found
		* along selected search mode.
		* \param rstrName                             Node name to search for
		* \param eMode                                Search mode (see enum descriptions for details)
		* \param bInitSearch                          Internal flag
		* \return                                     Ptr to node or null if not found
		*/
 	        virtual NeoEngine::SceneNode                 *GetByName( const NeoEngine::HashString &rstrName, NODESEARCHMODE eMode = BREADTH_FIRST, bool bInitSearch = true );

		/**
		* Traverse the hierarchy applying the visitor to the nodes.
		* \param rkVisitor                            Visitor to apply to each node.
		* \param eMode                                Search mode (see enum descriptions for details)
		* \param iDirection                           Direction of traversal (for DEPTH_FIRST, > 0 means top-down, < 0 means bottom up)
		* \param bInitSearch                          Internal flag
		*/
		virtual void                                  Traverse( NeoEngine::BaseVisitor &rkVisitor, NODESEARCHMODE eMode = DEPTH_FIRST, int iDirection = 1, bool bInitSearch = true );
};


};


#endif
