/***************************************************************************
                           node.h  -  Node in ABT
                             -------------------
    begin                : Tue Jul 8 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoABT, node.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEABT_NODE_H
#define __NEABT_NODE_H

/**
  * \file neoabt/node.h
  * Node in ABT
  */


#include "base.h"
#include "geometry.h"

#include <neoengine/scenenode.h>
#include <neoengine/aabb.h>
#include <neoengine/updateentity.h>

#include <vector>


namespace NeoABT
{


/**
  * \brief Adaptive binary tree node
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOABT_API Node : public NeoEngine::SceneNodeCallback, public NeoEngine::RenderEntity, public NeoEngine::UpdateEntity
{
	public:

		/**
		* \brief Node type identifiers
		*/
		enum NODETYPE
		{
		  /*! Node */
		  NODE,

		  /*! Leaf */
		  LEAF
		};
		
		/**
		* \brief Node defines
		*/
		enum NODEDEFS
		{
		  /*! Maximum number of scenenodes. This must be an uneven value! */
		  MAXNODES                                    = 5
		};


	protected:

		/*! Node type */
		NODETYPE                                      m_eType;

		/*! Root */
		Node                                         *m_pkRoot;

		/*! Parent */
		Node                                         *m_pkParent;

		/*! Child node */
		Node                                         *m_pkLeft;

		/*! Child node */
		Node                                         *m_pkRight;
		
		/*! Scene nodes */
		NeoEngine::SceneNode                         *m_apkNodes[MAXNODES+1];
		
		/*! Number of active nodes */
		unsigned int                                  m_uiNumNodes;

		/*! Reference size of bounding box */
		float                                         m_fRefSize;

		
		/*! Recalculate the bounding volume */
		void                                          RecalcVolume();

		/*! One of the child leaves are empty, merge child nodes/leaves */
		void                                          MergeChildren();

		/*! Get and remove all scene nodes */
		void                                          CollectNodes( std::vector< NeoEngine::SceneNode* > *pvpkNodes );



	public:
	
		/*! Bounding box */
		NeoEngine::AABB                               m_kAABB;

		/**
		* \param pkParent                             Parent node
		* \param pkRoot                               Root
		*/
		                                              Node( Node *pkParent, Node *pkRoot );
		/**
		*/
		virtual                                      ~Node();

		/**
		* Render object
		* \param pkFrustum                            Current view frustum (if any)
		* \param bForce                               Render even if rendered previously this frame or deactivated (default false)
		* \return                                     true if we were rendered, false if not (already rendered, not forced)
		*/
		virtual bool                                  Render( NeoEngine::Frustum *pkFrustum = 0, bool bForce = false );

		/**
		* Update object
		* \param fDeltaTime                           Time passed since last update
		*/
		virtual void                                  Update( float fDeltaTime );

		/**
		* Add a node
		* \param pkNode                               Node
		*/
		void                                          AddNode( NeoEngine::SceneNode *pkNode );
		
		/**
		* Remove a node
		* \param pkNode                               Node
		* \return                                     >0 if node not found, 0 if found and removed, <0 if found and removed and node empty/merged
		*/
		int                                           RemoveNode( NeoEngine::SceneNode *pkNode );

		/**
		* Called by node when SRT data changed
		* \param pkNode                               Node
		*/
		virtual void                                  NodeChanged( NeoEngine::SceneNode *pkNode );

		/**
		* Called by node when deleted
		* \param pkNode                               Node
		*/
		virtual void                                  NodeDeleted( NeoEngine::SceneNode *pkNode );

		/**
		* Called by node when bounding volume data changed
		* \param pkNode                               Node
		*/
		void                                          NodeChanged( Node *pkNode );

		/**
		* Intersection test with unknown object type
		* \param pkObj                                Bounding volume object to test for intersection with
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \return                                     true if volumes intersect, false if not
		*/
		bool                                          Intersection( NeoEngine::BoundingVolume *pkObj, NeoEngine::ContactSet *pkContactSet );

		/**
		* Intersection test with ray
		* \param rkRay                                Ray
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \return                                     true if volumes intersect, false if not
		*/
		bool                                          Intersection( const NeoEngine::Ray &rkRay, NeoEngine::ContactSet *pkContactSet );

		/**
		* Search hierarchy for named node, including this node. Will return first node found
		* along selected search mode.
		* \param rstrName                             Node name to search for
		* \param eMode                                Search mode (see enum descriptions for details)
		* \param bInitSearch                          Internal flag
		* \return                                     Ptr to node or null if not found
		*/
 	        virtual NeoEngine::SceneNode                 *GetByName( const NeoEngine::HashString &rstrName, NeoEngine::SceneNode::NODESEARCHMODE eMode = NeoEngine::SceneNode::BREADTH_FIRST );

		/**
		* Traverse the hierarchy applying the visitor to the nodes.
		* \param rkVisitor                            Visitor to apply to each node.
		* \param eMode                                Search mode (see enum descriptions for details)
		* \param iDirection                           Direction of traversal (for DEPTH_FIRST, > 0 means top-down, < 0 means bottom up)
		* \param bInitSearch                          Internal flag
		*/
		virtual void                                  Traverse( NeoEngine::BaseVisitor &rkVisitor, NeoEngine::SceneNode::NODESEARCHMODE eMode = NeoEngine::SceneNode::DEPTH_FIRST, int iDirection = 1 );
};


};


#endif

