/***************************************************************************
                          neoictga.h  -  description
                             -------------------
    begin                : Wed Apr 17 2002
    copyright            : (C) 2002 by Mattias Jansson
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoICTGA, neoictga.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOICTGA_H
#define __NEOICTGA_H


#include <neoengine/base.h>
#include <neoengine/texture.h>


namespace NeoTGA
{


/**
  * \brief Data for a TGA file header
  * \author Mattias Jansson (mattias@realityrift.com)
  */
#ifdef WIN32
	#pragma pack( push, 1 )
#endif
class Header
{
	public:

		enum TGAFORMATS
		{
		  TGAFMT_NO_DATA               = 0,
		  TGAFMT_COLMAP_UNCOMP         = 1,
		  TGAFMT_UNMAP_UNCOMP          = 2,
		  TGAFMT_BW_UNCOMP             = 3,
		  TGAFMT_COLMAP_COMP           = 9,
		  TGAFMT_UNMAP_COMP            = 10,
		  TGAFMT_BW_COMP               = 11
		};


		enum TGAORIGIN
		{
		  TGAORG_MASK                  = 0x30,
		  TGAORG_TOPLEFT               = 0x20,
		  TGAORG_BOTTOMLEFT            = 0x00,
		  TGAORG_BOTTOMRIGHT           = 0x10,
		  TGAORG_TOPRIGHT              = 0x30
		};


		/*! Length of ID field */
		unsigned char                  m_ucIDLength;

		/*! Color map type */
		unsigned char                  m_ucColorMapType;
		
		/*! Data type */
		unsigned char                  m_ucDataType;
	
		/*! Color map origin */
		unsigned short                 m_usColorMapOrigin;

		/*! Color map type */
		unsigned short                 m_usColorMapLength;
		
		/*! Color map entry size */
		unsigned char                  m_ucColorMapEntrySize;
		
		/*! Image X origin */
		unsigned short                 m_usImageXOrigin;
		
		/*! Image Y origin */
		unsigned short                 m_usImageYOrigin;
		
		/*! Image width */
		unsigned short                 m_usImageWidth;
		
		/*! Image height */
		unsigned short                 m_usImageHeight;
				
		/*! Image bits per pixel */
		unsigned char                  m_ucImageBPP;
				
		/*! Image descriptor */
		unsigned char                  m_ucImageDescriptor;
};


class NEOENGINE_ATTRIBUTE_PACKED Footer
{
	public:

		/*! Extension area offset */
		unsigned int                   m_uiExtensionOffset;

		/*! Developer directory offset */
		unsigned int                   m_uiDeveloperDirOffset;

		/*! Signature (TRUEVISION-XFILE) */
		unsigned char                  m_aucSignature[16];

		/*! ASCII period '.' */
		unsigned char                  m_ucReserved;

		/*! Null character */
		unsigned char                  m_ucNull;
};


class NEOENGINE_ATTRIBUTE_PACKED Extension
{
	public:

		enum TGAEXTDEFS
		{
		  TGA_EXT_LEN                  = 495
		};


		/*! Size of area, should be TGA_EXT_LEN */
		unsigned short                 m_usSize;

		/*! Image author name */
		unsigned char                  m_aucAuthorName[41];

		/*! Author comments */
		unsigned char                  m_aucAuthorComments[324];

		/*! Timestamp */
		unsigned short                 m_usMonth, m_usDay, m_usYear, m_usHour, m_usMinute, m_usSecond;

		/*! Job description */
		unsigned char                  m_aucJobID[41];

		/*! Job time */
		unsigned short                 m_usJobHour, m_usJobMin, m_usJobSecs;

		/*! Software that created image */
		unsigned char                  m_aucSoftwareID[41];

		/*! Software version unmber * 100 */
		unsigned short                 m_usSoftwareVersion;

		/*! Software version letter */
		unsigned char                  m_ucSoftwareVersionLetter;

		/*! Transparent color */
		unsigned int                   m_uiKeyColor;
};

#ifdef WIN32
	#pragma pack( pop )
#endif




/**
  * \brief Image loader codec for tga files
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class ImageCodec : public NeoEngine::ImageCodec
{
	protected:

		/**
		* Read color map image
		* \param pkFile                 File
		* \param rkHeader               Header
		* \return                       Image data object, null if error
		*/
		NeoEngine::ImageData           *ReadColMap( NeoEngine::File *pkFile, Header &rkHeader );

		/**
		* Read unmap image
		* \param pkFile                 File
		* \param rkHeader               Header
		* \return                       Image data object, null if error
		*/
		NeoEngine::ImageData           *ReadUnmap( NeoEngine::File *pkFile, Header &rkHeader );

		/**
		* Read BW image
		* \param pkFile                 File
		* \param rkHeader               Header
		* \return                       Image data object, null if error
		*/
		NeoEngine::ImageData           *ReadBW( NeoEngine::File *pkFile, Header &rkHeader );

		/**
		* Uncompress data
		* \param pkFile                 File
		* \param pucDest                Destination buffer, allocated by caller prior to call
		* \param uiWidth                Width of image
		* \param uiHeight               Height of image
		* \param uiBytesPerPixel        Bytes per pixel
		* \return                       true if success, false if error
		*/
		bool                            UncompressStream( NeoEngine::File *pkFile, unsigned char *pucDest, unsigned int uiWidth, unsigned int uiHeight, unsigned int uiBytesPerPixel );


	public:

		/**
		* Create new TGA loader codec object
		* \param rvstrExtensions        Extension string vector
		*/
		                                ImageCodec( const std::vector<std::string> &rvstrExtensions );

		/**
		* Check if file is a TGA file
		* \param pkFile                 File to check
		* \return                       true if TGA file, false if not recognized
		*/
		bool 							IsType( NeoEngine::File *pkFile );

		/**
		* Loads data from file
		* \param pkFile                 File
		* \return                       Ptr to new ImageData object
		*/
		NeoEngine::ImageData           *LoadImage( NeoEngine::File *pkFile );

		/**
		* Free image data
		* \param pkImageData            Image data
		*/
		void                            FreeImage( NeoEngine::ImageData *pkImageData );

		/**
		* Write image to file
		* \param pkImage                Image to write
		* \param pkFile                 File to write image to
		*/
		virtual bool                    WriteImage( NeoEngine::ImageData *pkImage, NeoEngine::File *pkFile );
};


}; // namespace NeoTGA


#endif
