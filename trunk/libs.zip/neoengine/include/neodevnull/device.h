/***************************************************************************
                     device.h  -  Null render device
                             -------------------
    begin                : Tue Jul 13 2004
    copyright            : (C) 2003 by emedia-solutions wolf
    email                : markus@emedia-solutions-wolf.de
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevNull, device.h

 The Initial Developer of the Original Code is Markus Wolf.
 Portions created by Markus Wolf are Copyright (C) 2004
 emedia-solutions wolf. All Rights Reserved.

 ***************************************************************************/

#ifndef __NENULLDEVICE_H
#define __NENULLDEVICE_H


/**
  * \file device.h
  * Null render device
  */
#ifdef WIN32
#  ifndef WIN32_LEAN_AND_MEAN
#    define WIN32_LEAN_AND_MEAN
#  endif

#  define NEEDGDI
#endif

#include <neoengine/render.h>

#include <string>

#undef ERROR


namespace NeoEngine
{

// External classes
class Texture;

};


namespace NeoNull
{


/**
  * \brief Nulldevice implementation of render device
  * \author Markus Wolf (markus@emedia-solutions-wolf.de)
  */
class Device : public NeoEngine::RenderDevice
{
	public:

		/*! Frame callbacks */
		std::vector< NeoEngine::FrameCallback* >      m_avpkFrameCallbacks[ NeoEngine::FrameCallback::NUMCALLBACKS ];

	public:

		/*! Pending events */
		std::vector< NeoEngine::InputEvent* >         m_vpkEvents;



		/**
		* \param pkFileManager                        File manager
		* \param pkInputManager                       Input manager to attach to for reporting events
		*/
		                                              Device( NeoEngine::FileManager *pkFileManager, NeoEngine::InputManager *pkInputManager );

		/**
		* Cleanup
		*/
		virtual                                      ~Device() { Close(); }

		/**
		* Open device
		* \param rkWndData                            Window data
		* \return                                     true if successful, false if not
		*/
		virtual bool                                  Open( const NeoEngine::RenderWindow &rkWndData ) { return true; }

		/**
		* Close device, restore settings
		*/
		virtual void                                  Close() {}

		/**
		* Begin new frame. Call this before any calls to Render
		* \param rkViewMatrix                         View matrix for this batch of render operations
		*/
		virtual void                                  Begin( const NeoEngine::Matrix &rkViewMatrix, unsigned int uiFlags ) {}

		/**
		* End frame
		*/
		virtual void                                  End() {}

		/**
		* Render primitive batch
		* \param rkData                               Render batch data
		* \param iFlags                               Batch flags
		*/
		virtual void                                  Render( const NeoEngine::RenderPrimitive &rkData, unsigned int uiFlags ) {}

		/**
		* Set current render target
		* \param uiTarget                             Render target identifier
		* \param pkBuffer                             For offscreen rendering, pixel buffer object
		* \return                                     Previous render target identifier (you should restore this if other than INVALIDBUFFER)
		*/
		virtual unsigned int                          SetRenderTarget( unsigned int uiTarget ) { return INVALIDBUFFER; }

		/**
		* Set culling mode. Must be called outside Begin()-End() block
		* \param eCullMode                            Culling mode identifier
		* \return                                     Last culling mode
		*/
		virtual CULLMODE                              SetCullMode( CULLMODE eCullMode ) { return RenderDevice::CULLNONE; }

		/**
		* Set stencil op (only when render target is STENCILBUFFER)
		* \param eZFail                               Operation when z buffer test fails
		* \param eZPass                               Operation when z buffer test passes
		*/
		virtual void                                  SetStencilOp( STENCILOP eStencilFail, STENCILOP eZFail, STENCILOP eZPass ) {}

		/**
		* Set stencil function, reference value and test mask
		* \param eFunc                                Stencil test func
		* \param uiRefValue                           Reference value
		* \param uiTestMask                           A mask that is ANDed with both the reference value and the stored stencil value when the test is done
		*/
		virtual void                                  SetStencilFunc( STENCILFUNC eFunc, unsigned int uiRefValue, unsigned int uiTestMask ) {}

		/**
		* Set stencil write mask
		* \param uiMask                               Write mask
		*/
		virtual void                                  SetStencilMask( unsigned int uiWriteMask ) {}

		/**
		* Set render target write mask
		* \param bWrite                               Write flag, if false will disable writing to render target buffer, if true enable writing to render target buffer
		*/
		virtual void                                  SetTargetMask( bool bWrite ) {}

		/**
		* Set buffer backing storage size. You must call this method prior to an Open() call, or
		* default sizes will be used.
		* \param uiVertexStorageSize                  Size in bytes of vertex buffer storage (default 3Mb)
		* \param uiPolygonStorageSize                 Size in bytes of polygon buffer storage (default 1Mb)
		* \return                                     true if successful, false if error (called after Open(), unable to allocate memory)
		*/
		virtual bool                                  SetStorageSize( unsigned int uiVertexStorageSize, unsigned int uiPolygonStorageSize ) { return true; }

		/**
		* Set projection matrix
		* \param rkMatrix                             Projection matrix
		*/
		virtual void                                  SetProjection( const NeoEngine::Matrix &rkMatrix ) {}

		/**
		* Set rendering viewport (must be outside Begin()-End() block)
		* \param iX                                   Starting x coordinate
		* \param iY                                   Starting y coordinate
		* \param iWidth                               Width
		* \param iHeight                              Height
		*/
		virtual void                                  SetViewport( int iX, int iY, int iWidth, int iHeight ) {}

		/**
		* Clear the current viewport (must be outside Begin()-End() block) for framebuffer, 
		* or for other clear targets clear the whole buffer
		* \param uiTargets                            Target bitfield (combination of CLEAR_xxx enums )
		* \param rkColor                              Color to clear color buffer with
		* \param fZValue                              Value to clear z buffer with
		* \param uiStencilValue                       Value to clear stencil buffer with
		*/
		virtual void                                  Clear( unsigned int uiTargets, const NeoEngine::Color &rkColor, float fZValue, unsigned int uiStencilValue ) {}

		/**
		* Flip buffers, flush pipeline (must be outside Begin()-End() block)
		*/
		virtual void                                  Flip() {}

		/**
		* Add light to rendering pipeline for this Begin()-End() block. This is implementation/hardware specific and is not guaranteed to work in the fixed-function pipeline (max number of lights)
		* \param pkLight                              Light to add
		* \return                                     < 0 if failed
		*/
		virtual int                                   AddLight( NeoEngine::Light *pkLight ) { return -1; }

		/**
		* Load a texture file. Implement in derived class
		* \param rstrFilename                         File name
		* \param eTextureType                         Texture type (2D, cubemap, ...)
		* \param eTextureFormat                       Requested texture format (Texture::DEFAULT if not needed)
		* \param uiFlags                              Load flags (default Texture::NONE)
		* \param uiFiltering                          Texture filtering modes (0 as default, using default set device filtering mode)
		* \param uiMaxAnisotropy                      Max anisotropy
		* \return                                     Ptr to texture
		*/
		virtual NeoEngine::TexturePtr                 LoadTexture( const std::string &rstrFilename, NeoEngine::Texture::TEXTURETYPE eTextureType, NeoEngine::Texture::TEXTUREFORMAT eTextureFormat, unsigned int uiFlags, unsigned int uiFiltering, unsigned int uiMaxAnisotropy );

		/**
		* Create new texture object
		* \param rstrName                             Texture name
		* \param eTextureType                         Texture type (2D, cubemap, ...)
		* \param eTextureFormat                       Requested texture format (Texture::DEFAULT if not needed)
		* \return                                     Ptr to texture
		*/
		virtual NeoEngine::TexturePtr                 CreateTexture( const std::string &rstrName, NeoEngine::Texture::TEXTURETYPE eTextureType, NeoEngine::Texture::TEXTUREFORMAT eTextureFormat );

		/**
		* Find texture by name
		* \param rstrName                             Texture name
		* \return                                     Ptr to texture
		*/
		virtual NeoEngine::TexturePtr                 GetTexture( const std::string &rstrName );

		/**
		* Allocate a vertex buffer
		* \param uiType                               Buffer type
		* \param uiNumVertices                        Number of vertices
		* \param uiVertexFormat                       Flexible vertex format specifier
		* \param pData                                Optional pointer to data to load buffer with
		* \return                                     Ptr to new vertex buffer
		*/
		virtual NeoEngine::VertexBufferPtr            CreateVertexBuffer( unsigned int uiType, unsigned int uiNumVertices, const NeoEngine::VertexDeclaration *pkFormat, const void *pData );

		/**
		* Allocate a polygon buffer
		* \param uiType                               Buffer type
		* \param uiNumPolygons                        Number of polygons
		* \param pkData                               Optional pointer to data to load buffer with
		* \param bStripify                            Stripify buffer if true
		* \return                                     Ptr to new polygon buffer
		*/
		virtual NeoEngine::PolygonBufferPtr           CreatePolygonBuffer( unsigned int uiType, unsigned int uiNumPolygons, const NeoEngine::Polygon *pkData, bool bStripify );

		/**
		* Allocate a polygon strip buffer
		* \param uiType                               Buffer type
		* \param uiNumPolygons                        Number of polygons
		* \param pusData                              Optional pointer to data to load buffer with
		* \return                                     Ptr to new polygon strip buffer
		*/
		virtual NeoEngine::PolygonStripBufferPtr      CreatePolygonStripBuffer( unsigned int uiType, unsigned int uiNumPolygons, const unsigned short *pusData );

		/**
		* Create a pixel buffer for offscreen rendering
		* \param uiWidth                              Width of buffer
		* \param uiHeight                             Height of buffer
		* \param uiBPP                                Suggested bit depth (might be ignored if not found or incompatible in windowed mode)
		* \param eTextureType                         Target texture type (2D, cubemap, ... )
		* \return                                     New pixel buffer object, or null if error/unsupported
		*/
		virtual NeoEngine::PixelBuffer               *CreatePixelBuffer( unsigned int uiWidth, unsigned int uiHeight, unsigned int uiBPP, NeoEngine::Texture::TEXTURETYPE eTextureType );

		/**
		* Create a new shader object, which can then be loaded and compiled
		* \param eType                                Shader type (vertex or fragment)
		* \return                                     Pointer to the new shader object
		*/
		virtual NeoEngine::ShaderPtr                  CreateShader( NeoEngine::Shader::SHADERTYPE eType );

		/**
		* Find shader by name and type (only successfully compiled shaders are searched)
		* \param eType                                Shader type
		* \param rstrName                             Shader name
		* \return                                     Ptr to Shader
		*/
		virtual NeoEngine::ShaderPtr                  GetShader( NeoEngine::Shader::SHADERTYPE eType, const std::string &rstrName );

		/**
		* Read pixels from currently bound buffer (framebuffer, pixelbuffer, stencilbuffer)
		* \return                                     Image data containing pixels
		*/
		virtual NeoEngine::ImageData                 *ReadPixels();

		/**
		* \return                                     String with statistics for last frame
		*/
		virtual std::string                           GetStatistics();

		/**
		* Set mouse position relative window client area top-left corner.
		* \param iX                                   X coordinate in pixels
		* \param iX                                   Y coordinate in pixels
		*/
		virtual void                                  SetMousePos( int iX, int iY ) {}

		/**
		* Capture or release mouse from window
		* \param bCapture                             If true, capture mouse in window. If false, release mouse
		*/
		virtual void                                  CaptureMouse( bool bCapture ) {}

		/**
		* Show or hide mouse cursor
		* \param bShow                                If true, show cursor. If false, hide cursor
		*/
		virtual void                                  ShowCursor( bool bShow ) {}

		/**
		* Register/deregister frame callback
		* \param eType                                Callback type
		* \param pkCallback                           Callback object
		* \param bRegister                            If true, register new callback. If false, deregister callback
		*/
		virtual void                                  RegisterFrameCallback( NeoEngine::FrameCallback::FRAMECALLBACKTYPE eType, NeoEngine::FrameCallback *pkCallback, bool bRegister );

		/**
		* Query device for available adapters
		* \param pvkAdapters                          Pointer to vector receiving available adapters
		*/
		virtual void                                  QueryAdapters( std::vector< NeoEngine::RenderAdapter > *pvkAdapters ) {}

		/**
		* Query device for available fullscreen resolutions, sorted by total area, bits per pixel, refresh rate
		* \param pvkResolutions                       Pointer to vector receiving available resolutions
		* \param uiAdapter                            Adapter identifier, 0 for default (primary) adapter
		*/
		virtual void                                  QueryResolutions( std::vector< NeoEngine::RenderResolution > *pvkResolutions, unsigned int uiAdapter ) {}

		/**
		* Collect input events
		* \param pkEvent                              Event object to fill with data
		* \return                                     true if events was collected, false if not
		*/
		virtual bool                                  Collect( NeoEngine::InputEvent *pkEvent ) { return false; }

		/**
		* Called when a value change in configuration repository
		* \param rstrKey                              Key name
		*/
		virtual void                                  ConfigValueChange( const NeoEngine::HashString &rstrKey );
};


}; // namespace NeoNull


#endif
