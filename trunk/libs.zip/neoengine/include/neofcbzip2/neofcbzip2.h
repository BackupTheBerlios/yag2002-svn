/***************************************************************************
                        neofcbzip2.h  -  description
                             -------------------
    begin                : Mon Apr 29 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoFCBZip2, neofcbzip2.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOFCBZIP2_H
#define __NEOFCBZIP2_H


#include <neoengine/base.h>
#include <neoengine/filecodec.h>


namespace NeoBZIP2
{


/**
  * \brief File loader codec for bzip2 compressed files
  * This codec uses the free libbzip2 library from Julian R Seward. Please read
  * the LICENSE file in the bzip2 subdirectory for license information.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class FileCodec : public NeoEngine::FileCodec
{
	public:

		/**
		* Create new bzip2 loader codec object
		*/
		                                FileCodec();

		/**
		* Check if file is a bzip2 file
		* \param pkFile                 File to check
		* \return                       true if bzip2 file, false if not recognized
		*/
		bool                            IsType( NeoEngine::File *pkFile );

		/**
		* Loads data from file
		* \param pkFile                 File
		* \param iSrcSize               Size of source data
		* \param pDest                  Pointer to destination buffer
		* \param piSize                 Pointer to integer holding size of uncompressed data
		* \return                       Error code, 0 if success
		*/
		int                             LoadFileData( NeoEngine::File *pkFile, int iSrcSize, void *pDest, int *piSize );
};


}; // namespace NeoBZIP2


#endif

