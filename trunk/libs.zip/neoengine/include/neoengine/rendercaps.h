/***************************************************************************
                rendercaps.h  -  Render device capability bitfield
                             -------------------
    begin                : Thu Mar 27 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, rendercaps.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NERENDERCAPS_H
#define __NERENDERCAPS_H


/**
  * \file rendercaps.h
  * Render device capabilities bitfield
  */


#include "base.h"
#include "util.h"


namespace NeoEngine
{



/**
  * \brief Describe capabilities for a render device
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API RenderCaps
{
	public:

		/**
		* \brief Render capabilities bitfields (256 groups of 24 caps each)
		*/
		enum RENDERCAPS
		{
		  /*! Group for caps related to buffers (frame, stencil, z, pixel) */
		  BUFFER_GROUP                                = 0x00000000,

		  /*! Stencil buffer present */
		  STENCILBUFFER                               = 0x00000001,

		  /*! Advanced pixel format enumeration */
		  PIXELFORMAT                                 = 0x00000100,

		  /*! Device can create pixel buffers */
		  PIXELBUFFER                                 = 0x00000200,

		  /*! Device can render to texture (i.e use pixel buffer as texture) */
		  RENDERTEXTURE                               = 0x00000400,


		  /*! Group for caps related to programmable pipeline */
		  SHADER_GROUP                                = 0x01000000,

		  /*! Vertex shaders supported */
		  VERTEXSHADER                                = 0x01000001,

		  /*! Fragment shaders supported */
		  FRAGMENTSHADER                              = 0x01000002,


		  /*! Group for caps related to multitexturing */
		  MULTITEXTURE_GROUP                          = 0x02000000,

		  /*! Device can multitexture */
		  MULTITEXTURE                                = 0x02000001,

		  /*! Device can use cubemaps */
		  CUBEMAP                                     = 0x02000010,

		  /*! Device can use factor blend mode */
		  BLENDMODE_FACTOR                            = 0x02000100,

		  /*! Device can use LERP blend modes */
		  BLENDMODE_INTERPOLATE                       = 0x02000200,

		  /*! Mask for number of texture units */
		  MULTITEXTURE_UNITS_MASK                     = 0x00FF0000,

		  /*! Shift bitcount for number of texture units */
		  MULTITEXTURE_UNITS_SHIFT                    = 0x00000010,


		  /*! Group for misc caps */
		  MISC_GROUP                                  = 0x04000000,

		  /*! Normalize vertex normals in vertex lighting path */
		  NORMALIZATION                               = 0x04000001,

		  /*! Fog coordinate */
		  FOGCOORD                                    = 0x04000002,

		  /*! Point sprites */
		  POINTSPRITES                                = 0x04000004,


		  /*! Group for caps related to the rendering window */
		  WINDOW_GROUP                                = 0x0F000000,

		  /*! Frame buffer is double buffered */
		  DOUBLEBUFFER                                = 0x0F000001,

		  /*! Open render device in fullscreen mode */
		  FULLSCREEN                                  = 0x0F000002,


		  /*! Group for caps related to the acceleration state of the driver */
		  ACCELERATION_GROUP                          = 0xF0000000,

		  /*! Rendering path is hardware accelerated */
		  HARDWAREACCELERATED                         = 0xF0000100
		};




	protected:

		/*! Caps */
		unsigned int                                  m_auiCaps[256];


	public:

		/**
		*/
		                                              RenderCaps() { memset( m_auiCaps, 0, sizeof( unsigned int ) * 256 ); }

		/**
		*/
		                                             ~RenderCaps() {}

		/**
		* Query if cap is set
		* \param uiCaps                               Caps bits to query for
		* \return                                     true if capability flag is set, false if not
		*/
		inline bool                                   IsSet( unsigned int uiCaps ) const { return( ( m_auiCaps[ ( uiCaps >> 24 ) & 0xFF ] & ( uiCaps & 0x00FFFFFF ) ) != 0 ); }

		/**
		* Set caps (don't combine flags from different groups)
		* \param uiCaps                               Capability bits to set
		*/
		inline void                                   Set( unsigned int uiCaps ) { m_auiCaps[ ( uiCaps >> 24 ) & 0xFF ] |= ( uiCaps & 0x00FFFFFF ); }

		/**
		* Reset caps
		* \param uiCaps                               Capability bits to reset
		*/
		inline void                                   Reset( unsigned int uiCaps ) { m_auiCaps[ ( uiCaps >> 24 ) & 0xFF ] &= ( ~uiCaps & 0x00FFFFFF ); }

		/**
		* Reset all caps
		*/
		inline void                                   ResetAll() { memset( m_auiCaps, 0, sizeof( unsigned int ) * 256 ); }

		/**
		* \param uiGroup                              Group identifier (0x00000000, 0x01000000, 0x02000000, ...)
		* \return                                     Flags bitfield for a group
		*/
		inline unsigned int                           GetGroupFlags( unsigned int uiGroup ) const { return m_auiCaps[ ( uiGroup >> 24 ) & 0xFF ]; }

		/**
		* Assign from reference object
		* \param rkCaps                               Reference caps object to copy data from
		*/
		inline RenderCaps                            &operator = ( const RenderCaps &rkCaps ) { fmemcpy( m_auiCaps, rkCaps.m_auiCaps, sizeof( unsigned int ) * 256 ); return( *this ); }
};

}; // namespace NeoEngine


#endif
