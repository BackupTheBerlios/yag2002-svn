/***************************************************************************
                pointer.h  -  Reference counting and smart pointers
                             -------------------
    begin                : Tue Oct 30 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, pointer.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEPOINTER_H
#define __NEPOINTER_H


/**
* \file pointer.h
* Reference counted objects and smart pointers
*/


#include "base.h"

#include <assert.h>

#ifdef WIN32
#  include <vector>
#endif


namespace NeoEngine
{


/**
  * \brief Base reference counter
  * Used by all objects that are managed through smart pointers
  * Once reference count reaches zero, deletes itself.
  * <b>You must NEVER delete a reference counted object directly!
  * All access to a reference counted object MUST be done through
  * the smart pointer interface as offered by the Pointer template class</b>
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API RefCounter
{
	private:

		/*! Reference count */
		int                                           m_iRefCount;


	public:

		/**
		* Set reference count to 0
		*/
		inline                                        RefCounter();

		/**
		* Dummy method for virtual destructor chain
		*/
		inline virtual                               ~RefCounter();

		/**
		* Increase reference count
		*/
		inline void                                   IncRef();

		/**
		* Decrease reference count and garbage collect if 0
		*/
		inline void                                   DecRef();

		/**
		* \return                                     Current reference count
		*/
		inline int                                    GetRefCount() const;
};


/**
  * \brief Smart pointer template for reference counted classes
  * <b>Reference counted objects MUST be accessed through smart pointers
  * at all times to make sure reference counting scheme operates correctly.
  * Failure to do so will result in strange and unpredictable behaviour and crashes.</b>
  * The smart pointer class takes care of reference counting management at
  * creation, destruction and assignement of pointers, and lets the reference counting
  * scheme correctly free objects that are no longer referenced.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
template < class T > class Pointer
{
	private:

		/*! Pointer to object */
		T                                            *m_pkObject;

	public:

		/**
		* Assign pointer and increase reference for object if not null
		* \param pkObject               Pointer to object
		*/
		inline                                        Pointer( T *pkObject = 0 );

		/**
		* Assign pointer and increment reference for object if not null
		* \param rkPointer                            Pointer object ref
		*/
		inline                                        Pointer( const Pointer< T > &rkPointer );

		/**
		* Decrease reference for object if not null
		*/
		inline                                       ~Pointer();

		/**
		* \return                                     true if pointer is valid, false if null
		*/
		inline                                        operator const bool () const;

		/**
		* \return                                     Typecast to pointer to class
		*/
		inline                                        operator T* ();

		/**
		* \return                                     Typecast to pointer to class
		*/
		inline                                        operator const T* () const;

		/**
		* \return                                     Typecast to pointer to class and dereference
		*/
		inline T                                     &operator * ();

		/**
		* \return                                     Typecast to pointer to class and dereference
		*/
		inline const T                               &operator * () const;

		/**
		* \return                                     Typecast to pointer to class and dereference
		*/
		inline T                                     *operator -> ();

		/**
		* \return                                     Typecast to pointer to class and dereference
		*/
		inline const T                               *operator -> () const;

		/**
		* \return                                     True if invalid pointer (null), false if valid
		*/
		inline bool                                   operator !() const;

		/**
		* Assignment of pointer, decrease reference count for old object and increase for current object
		* \param rkPointer                            Smart pointer to copy from
		* \return                                     Pointer ref (this)
		*/
		inline Pointer< T >                          &operator = ( const Pointer< T > &rkPointer );

		/**
		* Assignment of pointer, decrease reference count for old object and increase for current object
		* \param pkObject                             Pointer to object
		* \return                                     Pointer ref (this)
		*/
		inline Pointer< T >                          &operator = ( T *pkObject );

		/**
		* \param rkPointer                            Reference smart pointer object
		* \return                                     True if pointers are equal, false if not
		*/
		inline bool                                   operator == ( const Pointer< T > &rkPointer ) const;

		/**
		* \param pkObject                             Pointer to reference object
		* \return                                     True if pointers are equal, false if not
		*/
		inline bool                                   operator == ( const T *pkObject ) const;

		/**
		* \param rkPointer                            Reference smart pointer object
		* \return                                     True if pointers are not equal, false if equal
		*/
		inline bool                                   operator != ( const Pointer< T > &rkPointer ) const;

		/**
		* \param pkObject                             Pointer to reference object
		* \return                                     True if pointers are not equal, false if equal
		*/
		inline bool                                   operator != ( const T *pkObject ) const;

		/**
		* \param rkPointer                            Reference smart pointer object
		* \return                                     True if pointer address is less that reference , false if equal
		*/
		inline bool                                   operator < ( const Pointer< T > &rkPointer ) const;

		/**
		* \param pkObject                             Pointer to reference object
		* \return                                     True if pointer address is less that reference, false if equal
		*/
		inline bool                                   operator < ( const T *pkObject ) const;
};


#include "pointer_inl.h"


//Macros for easy typing

#ifdef WIN32
#  ifdef _MSC_VER
#    pragma warning( disable : 4786 )
#  endif
#  if ( _MSC_VER >= 1300 )
#    define SmartPointer( classname ) \
       class classname; \
       typedef Pointer< classname > classname##Ptr; \
       EXPIMP_TEMPLATE template class NEOENGINE_API Pointer< classname >; \
	   EXPIMP_TEMPLATE template class NEOENGINE_API std::allocator< Pointer< classname > >; \
       EXPIMP_TEMPLATE template class NEOENGINE_API std::vector< Pointer< classname > >
#  elif defined( _MSC_VER )
#    define SmartPointer( classname ) \
       class classname; \
       typedef Pointer< classname > classname##Ptr; \
       EXPIMP_TEMPLATE template class NEOENGINE_API Pointer< classname >; \
       EXPIMP_TEMPLATE template class NEOENGINE_API std::vector< Pointer< classname > >
#  else
#    define SmartPointer(classname) typedef Pointer< classname > classname##Ptr
#  endif
#else
#  define SmartPointer(classname) typedef Pointer< classname > classname##Ptr
#endif


};


#endif
