/***************************************************************************
                 joint.h  -  Joint emulation between rigid bodies
                             -------------------
    begin                : Mon Jan 26 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, joint.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEJOINT_H
#define __NEJOINT_H


/**
  * \file joint.h
  * Joint emulation between rigid bodies
  */


#include "base.h"
#include "rigidbody.h"
#include "physics.h"

namespace NeoEngine
{


/**
  * \brief Joint between two rigidbody nodes
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Joint
{
	public:

		/*! Rigidbody nodes */
		RigidBody                                    *m_apkBody[2];

		/*! Joint offset in <b>local</b> space of each node */
		Vector3d                                      m_akOffset[2];

		/*! Constraint rotation around x axis */
		float                                         m_afConstraint[2];


		/**
		* \param pkBody0                              First rigidbody
		* \param pkBody1                              Second rigidbody
		* \param rkOffset0                            Offset to first node in <b>local</b> space for first rigidbody
		* \param rkOffset1                            Offset to second node in <b>local</b> space for second rigidbody
		*/
		                                              Joint( RigidBody *pkBody0, RigidBody *pkBody1, const Vector3d &rkOffset0, const Vector3d &rkOffset1 );

		/**
		*/
		virtual                                      ~Joint();

		/**
		* Solve the joint constraints
		* \param eMode                                Contact processing mode
		* \return                                     true if joint imposed constraints, false if no action taken
		*/
		bool                                          Solve( ContactNode::CONTACTMODE eMode );
};


};


#endif
