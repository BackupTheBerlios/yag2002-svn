/***************************************************************************
       loadableentity.h  -  Base class for object which can be loaded
                             -------------------
    begin                : Mon Sep 11 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, loadableentity.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NELOADABLEENTITY_H
#define __NELOADABLEENTITY_H


/**
  * \file loadableentity.h
  * Base class for object which can be loaded
  */


#include "base.h"

#include <string>


namespace NeoEngine
{


//External classes
class FileManager;
class File;


/**
  * \brief Interface for object which can be loaded
  * A loadable entity can load its data from a file.
  * Derived classes only needs to implement the LoadNode
  * method, file locating/opening/closing is handled
  * automatically by the this base class Load methods.
  *
  * If the derived class needs to keep the file open,
  * it should set the m_bKeepFile flag to true before
  * returning from the LoadNode method.
  *
  * This base class also keeps track of redundant multiple
  * calls to load and object that has already been loaded.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API LoadableEntity
{
	protected:

		/*! File */
		File                                         *m_pkFile;

		/*! Flag indicating node is loaded */
		bool                                          m_bLoaded;

		/*! Flag to block file deletion on load completion */
		bool                                          m_bKeepFile;

		/*! File manager */
		FileManager                                  *m_pkFileManager;


		/**
		* Main loader method. Called by LoadableEntity to load object if file was opened successfully
		* \param uiFlags                              Flags passed by caller to Load() method
		* \return                                     true if load was successful, false otherwise
		*/
		virtual bool                                  LoadNode( unsigned int uiFlags = 0 ) = 0;


	public:

		/**
		* \param pkFileManager                        Ptr to file manager, will use core file manager if null (default)
		*/
		                                              LoadableEntity( FileManager *pkFileManager = 0 );

		/**
		*/
		virtual                                      ~LoadableEntity();

		/**
		* Set new file manager object
		* \param pkManager                            Ptr to file manager object
		*/
		void                                          SetFileManager( FileManager *pkManager );

		/**
		* Load resource
		* \param rstrFilename                         Filename
		* \param uiFlags                              Flags to pass to loader
		* \param bForceReload                         Force reload if already loaded (default false)
		* \param bSearchFileSystem                    Look in normal file system for file if not found in file manager (default false)
		* \return                                     true if successful (or already loaded and not force flag set), false otherwise (load/reload failed)
		*/
		bool                                          Load( const std::string &rstrFilename, unsigned int uiFlags = 0, bool bForceReload = false, bool bSearchFileSystem = false );

		/**
		* Load resource
		* \param pkFile                               File object
		* \param uiFlags                              Flags to pass to loader
		* \param bForceReload                         Force reload if already loaded
		* \return                                     true if successful (or already loaded and not force flag set), false otherwise (load/reload failed)
		*/
		bool                                          Load( File *pkFile, unsigned int uiFlags = 0, bool bForceReload = false );
};


}; // namespace NeoEngine


#endif
