/***************************************************************************
                    config.h  -  Configuration repository
                             -------------------
    begin                : Wed Jul 03 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, config.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NECONFIG_H
#define __NECONFIG_H


/**
  * \file config.h
  * Configuration repository
  */


#include "base.h"
#include "hashtable.h"
#include "callback.h"
#include "loadableentity.h"


namespace NeoEngine
{


// External classes
class ConfigCallback;
class Console;


/**
  * \brief Configuration data for a single key
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ConfigValue
{
	public:

		/*! String value */
		HashString                                    m_strValue;

		/*! Integer value */
		int                                           m_iValue;

		/*! Float value */
		float                                         m_fValue;

		/*! Boolean value */
		bool                                          m_bValue;

		
		/**
		* Initialize values to default ( string: "[NA]", int: 0, float: 0.0f, boolean: false )
		*/
		                                              ConfigValue() : m_strValue( "[NA]" ), m_iValue( 0 ), m_fValue( 0.0f ), m_bValue( false ) {}
};


HashTableExport( ConfigValue );


#ifdef WIN32
#  ifndef __HAVE_VECTOR_CONFIGCALLBACK
     UDTVectorEXPIMP( class ConfigCallback* );
#    define __HAVE_VECTOR_CONFIGCALLBACK
#  endif
#endif


/**
  * \brief Configuration data repository
  * Configuration can be loaded from a file through the loadable entity interface.
  * The configuration repository will by default listen to the "set" and "showconfig"
  * console commands, and the core config repository object will automatically
  * register the commands with the core console object when the core is initialized.
  *
  * For an example on how to use config change callbacks, look at the documentation
  * for the ConfigCallback class.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Config : public LoadableEntity, public ConsoleCmdCallback
{
	private:

		/*! Hash table of keys */
		HashTable< ConfigValue >                     *m_pkHashTable;

		/*! Callback objects */
		std::vector< ConfigCallback* >                m_vpkCallbacks;

		/**
		* Main loader method. Called by LoadableEntity to load object if file was opened successfully
		* \param uiFlags                              Loader flags (currently ignored for config)
		* \return                                     true if load was successful, false otherwise
		*/
		virtual bool                                  LoadNode( unsigned int uiFlags );

	public:

		/**
		* Initialize configuration repository, register console commands on specified
		* console object
		* \param pkConsole                            Console object, will use core console if null
		*/
		                                              Config( Console *pkConsole = 0 );

		/**
		*/
		virtual                                      ~Config();

		/**
		* Set string value for key
		* \param rstrKey                              Key to set
		* \param rstrValue                            String value
		*/
		void                                          SetValue( const HashString &rstrKey, const HashString &rstrValue );

		/**
		* Set float value for key
		* \param rstrKey                              Key to set
		* \param fValue                               Float value
		*/
		void                                          SetValue( const HashString &rstrKey, float fValue );

		/**
		* Set int value for key
		* \param rstrKey                              Key to set
		* \param iValue                               Integer value
		*/
		void                                          SetValue( const HashString &rstrKey, int iValue );

		/**
		* Set int value for key
		* \param rstrKey                              Key to set
		* \param bValue                               Boolean value
		*/
		void                                          SetValue( const HashString &rstrKey, bool bValue );

		/**
		* Get string value for key
		* \param rstrKey                              Key to get
		* \param pstrValue                            String recieving value
		* \return                                     0 if invalid value (not a string), >0 if success
		*/
		int                                           GetValue( const HashString &rstrKey, std::string *pstrValue );

		/**
		* Get float value for key
		* \param rstrKey                              Key to get
		* \param pfValue                              Float recieving value
		* \return                                     0 if invalid value (not a float), >0 if success
		*/
		int                                           GetValue( const HashString &rstrKey, float *pfValue );

		/**
		* Get int value for key
		* \param rstrKey                              Key to get
		* \param piValue                              Integer recieving value
		* \return                                     0 if invalid value (not a int), >0 if success
		*/
		int                                           GetValue( const HashString &rstrKey, int *piValue );

		/**
		* Get boolean value for key
		* \param rstrKey                              Key to get
		* \param pbValue                              Boolean recieving value
		* \return                                     0 if invalid value (not a int), >0 if success
		*/
		int                                           GetValue( const HashString &rstrKey, bool *pbValue );

		/**
		* Print out configuration repository data to core logger at DEBUG level
		*/
		void                                          Print();
		
		/**
		* Register a callback method for listening to change events
		* \param pkCallback                           Callback object
		*/
		void                                          RegisterCallback( ConfigCallback *pkCallback );

		/**
		* Unregister a callback method
		* \param pkCallback                           Callback object
		*/
		void                                          UnregisterCallback( ConfigCallback *pkCallback );

		/**
		* Process console command
		* \param rstrCmd                              Command
		* \param rstrArgs                             Argument string
		*/
		virtual void                                  ConsoleCmd( const HashString &rstrCmd, const HashString &rstrArgs );
};


};



#endif
