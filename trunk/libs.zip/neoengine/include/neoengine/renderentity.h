/***************************************************************************
              renderentity.h  -  Base class for renderable entities
                             -------------------
    begin                : Thu Sep 11 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, renderentity.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NERENDERENTITY_H
#define __NERENDERENTITY_H


/**
  * \file renderentity.h
  * Base class for renderable entities
  */


#include "base.h"
#include "activator.h"


namespace NeoEngine
{


//External classes
class Frustum;


/**
  * \brief Interface for renderable objects
  * A renderable object overloads and implements the Render method,
  * optionally using the base Render method to use the automatic
  * check for redundant multiple render calls per frame. This base
  * class keeps track of the last frame the object was rendered, and
  * if already rendered the current frame, the base Render method
  * will return false (otherwise true).
  *
  * Render objects are derived from Activator for easy on/off
  * management. The base Render method returns false if the object
  * is not active.
  * \author Mattias Jansson (mattias@realityrift.com)
  * \todo What happens with frame tracker in a multithreaded app with multiple render devices?
  */
class NEOENGINE_API RenderEntity : public virtual Activator
{
	public:

		/*! Frame counter (at 500 frames per second, can be active ~100 days continously before loop, and then it will just skip one frame -> safe enough) */
		static unsigned int                           s_uiFrameCount;

		/*! Last frame count we were rendered */
		unsigned int                                  m_uiLastFrame;

		/**
		*/
		                                              RenderEntity() : m_uiLastFrame( 0 ) {}

		/**
		*/
		virtual                                      ~RenderEntity() {}

		/**
		* Render object
		* \param pkFrustum                            Current view frustum (if any)
		* \param bForce                               Render even if rendered previously this frame or deactivated (default false)
		* \return                                     true if we were rendered, false if not (already rendered, not forced)
		*/
		inline virtual bool                           Render( Frustum *pkFrustum = 0, bool bForce = false ) { if( bForce ) { m_uiLastFrame = s_uiFrameCount; return true; } if( !m_bActive || ( m_uiLastFrame >= s_uiFrameCount ) ) return false; m_uiLastFrame = s_uiFrameCount; return true; }
};


}; // namespace NeoEngine


#endif
