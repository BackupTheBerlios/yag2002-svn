/***************************************************************************
                          line.h  -  3D line primitive
                             -------------------
    begin                : Wed Sep 18 2002
    copyright            : (C) 2002 by Reality Rift studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, line.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NELINE_H
#define __NELINE_H


#include "base.h"
#include "nemath.h"



/**
  * \file line.h
  * 3D line objects
  */


namespace NeoEngine
{



/**
  * \class Line
  * \brief Data defining a 3D line
  * Class defining a line in 3D
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Line
{
	public:

		/*! Point of origin */
		Vector3d                  m_kOrigin;

		/*! Direction */
		Vector3d                  m_kDirection;


		/**
		* \param rkOrigin         Origin
		* \param rkDir            Direction
		*/
		                          Line( const Vector3d &rkOrigin, const Vector3d &rkDir ) : m_kOrigin( rkOrigin ), m_kDirection( rkDir ) {}

		/**
		*/
		virtual                  ~Line() {}
};



/**
  * \class Ray
  * \brief Data defining a 3D ray
  * Class defining a ray in 3D
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Ray
{
	public:

		/*! Point of origin */
		Vector3d                  m_kOrigin;

		/*! Direction */
		Vector3d                  m_kDirection;


		/**
		* \param rkOrigin         Origin
		* \param rkDir            Direction
		*/
		                          Ray( const Vector3d &rkOrigin, const Vector3d &rkDir ) : m_kOrigin( rkOrigin ), m_kDirection( rkDir ) {}

		/**
		*/
		virtual                  ~Ray() {}
};


}; // namespace NeoEngine


#endif // __NELINE_H
