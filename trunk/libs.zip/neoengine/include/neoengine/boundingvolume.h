/***************************************************************************
              boundingvolume.h  -  Base interface for bounding volumes
                             -------------------
    begin                : Sat Jan 26 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, boundingvolume.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEBOUNDINGVOLUME_H
#define __NEBOUNDINGVOLUME_H


#include "base.h"
#include "collision.h"
#include "node.h"
#include "pointer.h"
#include "color.h"


/**
  * \file neoengine/boundingvolume.h
  * Base interface for bounding volumes
  */

namespace NeoEngine
{


// External classes
class AABB;
class OBB;
class Sphere;
class VertexBuffer;

typedef Pointer< VertexBuffer > VertexBufferPtr;


/**
  * \brief Base class for bounding volumes
  * All bounding objects (AABB, OBB, Sphere, Capsule) inherit
  * from this base class, and implement specific collision and intersection tests
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API BoundingVolume : public SRTNode
{
	public:

		/**
		* \brief Bounding volume type identifiers
		*/
		enum BOUNDINGVOLUMETYPE
		{
		  /*! Axis-aligned bounding box */
		  BV_AABB,
		
		  /*! Oriented bounding box */
		  BV_OBB,

		  /*! Sphere */
		  BV_SPHERE,

		  /*! Capsule */
		  BV_CAPSULE
		};


	public:

		/**
		*/
		                                              BoundingVolume() : SRTNode() {}

		/**
		* Create from reference object
		* \param rkVolume                             Reference volume object
		*/
		                                              BoundingVolume( const BoundingVolume &rkVolume ) : SRTNode( rkVolume ) {}

		/**
		* Intersection with AABB
		* \param pkAABB                               AABB
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \param bInvertNormal                        If false, collision normal will point from passed object to this. If true, normal will point in other direction
		* \return                                     true if the AABB intersects with this object, false if not
		*/
		virtual bool                                  Intersection( AABB *pkAABB, ContactSet *pkContactSet = 0, bool bInvertNormal = false ) = 0;

		/**
		* Intersection with OBB
		* \param pkOBB                                OBB
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \param bInvertNormal                        If false, collision normal will point from passed object to this. If true, normal will point in other direction
		* \return                                     true if OBB intersects with this object, false if not
		*/
		virtual bool                                  Intersection( OBB *pkOBB, ContactSet *pkContactSet = 0, bool bInvertNormal = false ) = 0;

		/**
		* Intersection with sphere
		* \param pkSphere                             Sphere
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \param bInvertNormal                        If false, collision normal will point from passed object to this. If true, normal will point in other direction
		* \return                                     true if sphere intersects with this object, false if not
		*/
		virtual bool                                  Intersection( Sphere *pkSphere, ContactSet *pkContactSet = 0, bool bInvertNormal = false ) = 0;

		/**
		* Intersection with capsule
		* \param pkCapsule                            Capsule
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \param bInvertNormal                        If false, collision normal will point from passed object to this. If true, normal will point in other direction
		* \return                                     true if capsule intersects with this object, false if not
		*/
		virtual bool                                  Intersection( Capsule *pkCapsule, ContactSet *pkContactSet = 0, bool bInvertNormal = false ) = 0;

		/**
		* Intersection with frustum
		* \param pkFrustum                            Frustum
		* \return                                     true if frustum intersects with this object, false if not
		*/
		virtual bool                                  Intersection( Frustum *pkFrustum ) = 0;

		/**
		* Intersection with polygon
		* \param rkV0                                 First corner
		* \param rkV1                                 Second corner
		* \param rkV2                                 Third corner
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \param bForceTriNormal                      If true force use of triangle normal as separating plane when calculating contact points and depths
		* \param rkNormal                             Optional precalculated normal
		* \return                                     true if polygon intersects with this object, false if not
		*/
		virtual bool                                  Intersection( const Vector3d &rkV0, const Vector3d &rkV1, const Vector3d &rkV2, ContactSet *pkContactSet = 0, bool bForceTriNormal = true, const Vector3d &rkNormal = Vector3d::ZERO ) = 0;

		/**
		* Intersection test with unknown object type
		* \param pkObj                                Bounding volume object to test for intersection with
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \param bInvertNormal                        If false, collision normal will point from passed object to this. If true, normal will point in other direction
		* \return                                     true if volumes intersect, false if not
		*/
		virtual bool                                  Intersection( BoundingVolume *pkObj, ContactSet *pkContactSet = 0, bool bInvertNormal = false ) = 0;

		/**
		* Intersection with point
		* \param rkPoint                              Point
		* \return                                     true if point intersects with this object, false if not
		*/
		virtual bool                                  Intersection( const Vector3d &rkPoint ) = 0;

		/**
		* Intersection with ray
		* \param rkRay                                Ray
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \return                                     true if ray intersects with this object, false if not
		*/
		virtual bool                                  Intersection( const Ray &rkRay, ContactSet *pkContactSet = 0 ) = 0;

		/**
		* Intersection with line
		* \param rkLine                               Line
		* \return                                     true if line intersects with this object, false if not
		*/
		virtual bool                                  Intersection( const Line &rkLine ) = 0;

		/**
		* Intersection with plane
		* \param rkPlane                              Plane
		* \return                                     true if plane intersects with this object, false if not
		*/
		virtual bool                                  Intersection( const Plane &rkPlane ) = 0;

		/**
		* Generate from AABB
		* \param pkAABB                               Source AABB object
		*/
		virtual void                                  Generate( AABB *pkAABB ) = 0;

		/**
		* Generate from OBB
		* \param pkOBB                                Source OBB object
		*/
		virtual void                                  Generate( OBB *pkOBB ) = 0;

		/**
		* Generate from sphere
		* \param pkSphere                             Source sphere object
		*/
		virtual void                                  Generate( Sphere *pkSphere ) = 0;

		/**
		* Generate from capsule
		* \param pkCapsule                            Source capsule object
		*/
		virtual void                                  Generate( Capsule *pkCapsule ) = 0;

		/**
		* Generate from unknown object
		* \param pkObj                                Source object
		*/
		inline void                                   Generate( BoundingVolume *pkObj )
		{
			BOUNDINGVOLUMETYPE eType = pkObj->GetType();

			if( eType == BV_AABB )
				Generate( (AABB*)pkObj );
			else if( eType == BV_OBB )
				Generate( (OBB*)pkObj );
			else if( eType == BV_SPHERE )
				Generate( (Sphere*)pkObj );
			else // BV_CAPSULE
				Generate( (Capsule*)pkObj );
		}

		/**
		* Generate from vertex soup
		* \param pkVertexBuffer                       Vertex buffer
		*/
		virtual void                                  Generate( VertexBufferPtr &pkVertexBuffer ) = 0;

		/**
		* Merge with AABB
		* \param pkAABB                               Source AABB object
		*/
		virtual void                                  Merge( AABB *pkAABB ) = 0;

		/**
		* Merge with OBB
		* \param pkOBB                                Source OBB object
		*/
		virtual void                                  Merge( OBB *pkOBB ) = 0;

		/**
		* Merge with sphere
		* \param pkSphere                             Source sphere object
		*/
		virtual void                                  Merge( Sphere *pkSphere ) = 0;

		/**
		* Merge with capsule
		* \param pkCapsule                            Source capsule object
		*/
		virtual void                                  Merge( Capsule *pkCapsule ) = 0;

		/**
		* Merge with unknown object
		* \param pkObj                                Source object
		*/
		inline void                                   Merge( BoundingVolume *pkObj )
		{
			BOUNDINGVOLUMETYPE eType = pkObj->GetType();

			if( eType == BV_AABB )
				Merge( (AABB*)pkObj );
			else if( eType == BV_OBB )
				Merge( (OBB*)pkObj );
			else if( eType == BV_SPHERE )
				Merge( (Sphere*)pkObj );
			else // BV_CAPSULE
				Merge( (Capsule*)pkObj );
		}

		/**
		* \return                                     Bounding volume type identifier
		*/
		virtual BOUNDINGVOLUMETYPE                    GetType() = 0;

		/**
		* Duplicate volume
		* \return                                     New volume object that is exact copy of this
		*/
		virtual BoundingVolume                       *Duplicate() const = 0;

		/**
		* Render volume outlines
		* \param rkColor                              Color of outlines
		*/
		virtual void                                  RenderOutlines( const Color &rkColor = Color::GREEN ) const = 0;
};


};


#endif

