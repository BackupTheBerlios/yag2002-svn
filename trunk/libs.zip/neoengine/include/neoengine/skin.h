/***************************************************************************
                    skin.h  -  Skeletal controlled submeshes
                             -------------------
    begin                : Wed Sep 18 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, skin.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NESKIN_H
#define __NESKIN_H


/**
  * \file neoengine/skin.h
  * Skinned submeshes
  */


#include "base.h"
#include "submesh.h"
#include "nemath.h"


namespace NeoEngine
{


// External classes
class Skeleton;


/**
  * \brief Data for bone influences for a weighted vertex
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API BoneInfluence
{
	public:

		/*! Bone ID */
		int                                           m_iBoneID;

		/*! Weight */
		float                                         m_fWeight;

		/*! Offset from bone */
		Vector3d                                    m_kOffset;
};


/**
  * \brief Influences for a weighted vertex in a skin
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SkinVertex
{
	public:

		/*! Number of influences */
		int                                           m_iNumInfluences;

		/*! Influences */
		BoneInfluence                                *m_pkInfluences;

		/**
		*/
		                                              SkinVertex() : m_iNumInfluences(0), m_pkInfluences(0) {}
		
		/**
		*/
		                                             ~SkinVertex();
};


/**
  * \brief An array of bone weights defining a skin
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Skin : public RefCounter
{
	public:

		/*! Number of skin vertices */
		int                                           m_iNumVertices;

		/*! Skin vertex array */
		SkinVertex                                 *m_pkSkinVertices;

		/*! Vertex data */
		VertexBufferPtr                             m_pkVertices;


		/**
		*/
		                                              Skin( int iNumVertices = 0, SkinVertex *pkSkinVertices = 0, VertexBufferPtr pkVertices = 0 ) : m_iNumVertices( iNumVertices ), m_pkSkinVertices( pkSkinVertices ), m_pkVertices( pkVertices ) {}

		/**
		* Deallocate memory
		*/
		virtual                                      ~Skin();
};


//Define smart pointer interface
SmartPointer( Skin );


/**
  * \brief Derived shard with bone weighted vertices for skeletal animation
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SkeletalSubMesh : public SubMesh
{
	protected:

		/**
		* Update data
		*/
		virtual void                                  UpdateData() { WeightVertices(); }


	public:

		/*! Skeleton */
		Skeleton                                     *m_pkSkeleton;
	
		/*! Vertex weight data */
		SkinPtr                                       m_pkSkin;


		/**
		*/
		                                              SkeletalSubMesh();

		/**
		* \param rkSubMesh                            Reference submesh to copy data from
		*/
		                                              SkeletalSubMesh( const SkeletalSubMesh &rkSubMesh );

		/**
		*/
		virtual                                      ~SkeletalSubMesh();

		/**
		* \return                                     Weighted vertices
		*/
		inline virtual VertexBufferPtr               &GetVertexBuffer() { if( m_bNeedUpdate ) { WeightVertices(); m_bNeedUpdate = false; } return m_pkVertices; }

		/**
		* Weight vertices
		*/
		void                                          WeightVertices();

		/**
		* Update submesh (only trigger flag to weight vertices)
		* \param fDeltaTime                           Delta time passed
		*/
		virtual void                                  Update( float fDeltaTime ) { m_bNeedUpdate = true; }

		/**
		* \return                                     new submesh that is duplicate of this
		*/
		virtual SubMesh                              *Duplicate() const;

		/**
		* \return                                     Sub mesh type
		*/
		virtual unsigned int                          GetType() const { return SKELETALSUBMESH; }
};


};


#endif
