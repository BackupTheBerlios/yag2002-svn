/***************************************************************************
                       buffer.h  -  Buffer base class
                             -------------------
    begin                : Tue Oct 30 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, buffer.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEBUFFER_H
#define __NEBUFFER_H


/**
  * \file buffer.h
  * Base class for buffers
  */


#include "base.h"
#include "pointer.h"
#include "core.h"
#include "logstream.h"

#include <string>
#include <assert.h>


namespace NeoEngine
{


/**
  * \class Buffer
  * \brief Reference counted buffers
  *
  * Buffers can be stored in system RAM or in video RAM. A buffer of type DYNAMIC have
  * a system RAM backing storage and are when used in a render primitive uploaded to
  * video RAM if needed. A buffer of type STATIC have no system RAM storage, it is
  * always stored in video RAM if present.
  *
  * This allows sharing of video RAM among buffers with a total storage larger than the
  * allocated video RAM segment, and buffers are "swapped out" on a least-recent-used
  * scheme.
  * 
  * When a DYNAMIC buffer is used for rendering, first the dirty flag is checked (a
  * WRITE lock to the buffer will cause the dirty flag to be set) and if set the buffer
  * will update it's video RAM segment. This will also happen if the segment was
  * invalidated (swapped out). If no segment present (or invalid) a new segment will
  * be requested from the backend (which might cause other segments to be invalidated
  * to make enough free space). The data is then uploaded to the video RAM segment.
  *
  * The buffer upload policy determines when a buffer will be uploaded to the video RAM
  * segment. Possible values are ONUNLOCK for uploading directly after a WRITE lock is
  * released, ONRENDER for uploading when used in a Render() call to the device, or
  * ONFLUSH for uploading during render pipeline flush.
  *
  * Buffers are by default (the default policy) set to uploaded on render if the buffer is
  * dirty (a WRITE lock was held during the frame). If the policy is to upload on unlock,
  * but the flag NOUPLOAD was given to the lock method for a WRITE lock it will
  * cause the dirty flag to be set and upload-on-render being used. The flag FORCEUPLOAD
  * will force the upload to be made on unlock, regardless of the policy.
  *
  * A buffer of type STATIC that has a READPRIORITIZED and/or WRITEPRIORITIZED type set
  * might also get a system RAM backing store. The same argument for upload-on-render
  * and upload-on-unlock as above applies, with the exception that the video RAM
  * segment of a STATIC buffer will never be invalidated.
  *
  * A buffer with type NOREADWRITE set can be optimized by the backend by not allowing
  * the buffer to be locked for read or write access. This means you must pass a data
  * pointer to the buffer creation call.
  *
  * Finally, a buffer of type NORENDER can be optimized by the backend to never use any
  * video RAM resources. This buffer type must NEVER be sent for rendering.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Buffer : public RefCounter
{
	public:

		/**
		* \enum BUFFERTYPE
		* \brief Buffer type identifiers. Any combination of the flags is valid.
		*/
		enum BUFFERTYPE
		{
		  /*! Dynamic buffer with system RAM backing store */
		  DYNAMIC                                     = 0x00000000,

		  /*! AGP or VRAM storage if possible */
		  STATIC                                      = 0x00000001,

		  /*! Prioritize read access */
		  READPRIORITIZED                             = 0x00000002,

		  /*! Prioritize write accesss */
		  WRITEPRIORITIZED                            = 0x00000004,

		  /*! Buffer that can never be read from or written to, must pass data pointer to ctor */
		  NOREADWRITE                                 = 0x00000008,

		  /*! Buffer that must never be sent for rendering, guaranteed to not use video RAM resources */
		  NORENDER                                    = 0x00000010,

		  /*! Default type */
		  NORMAL                                      = ( DYNAMIC | READPRIORITIZED | WRITEPRIORITIZED )
		};

		/**
		* \enum BUFFERUPLOADPOLICY
		* \brief Upload policy identifiers
		*/
		enum BUFFERUPLOADPOLICY
		{
		  /*! Upload after WRITE lock released */
		  ONUNLOCK,

		  /*! Upload when used in render primitive queued for render */
		  ONRENDER,

		  /*! Upload when used in render pipeline flush */
		  ONFLUSH
		};


		/**
		* \enum BUFFERLOCK
		* \brief Lock type identifiers
		*/
		enum BUFFERLOCK
		{
		  /*! Read access */
		  READ                                        = 1,

		  /*! Write access (implies read access) */
		  WRITE                                       = 2,

		  /*! No upload on unlock, will cause upload-on-render */
		  NOUPLOAD                                    = 4,

		  /*! Force upload on unlock */
		  FORCEUPLOAD                                 = 8
		};


	protected:

		/*! Buffer type */
		unsigned int                                  m_uiType;

		/*! Current lock type held */
		unsigned int                                  m_uiLock;

		/*! Dirty flag */
		bool                                          m_bDirty;

		/*! Number of allocated elements */
		unsigned int                                  m_uiNumAllocated;

		/*! Number of currently used elements */
		unsigned int                                  m_uiNumCurrent;

		/**
		* Called by Lock. Lock type member m_uiLock has been set at this point
		* \return                                     true if lock successful, false if not
		*/
		virtual bool                                  AcquireLock() = 0;

		/**
		* Called by Unlock when a lock should be released. Lock type member m_uiLock is still holding lock type at this point.
		*/
		virtual void                                  ReleaseLock() = 0;


	public:

		/*! Buffer upload policy */
		static BUFFERUPLOADPOLICY                     s_eUploadPolicy;


		/**
		*/
		                                              Buffer( unsigned int uiType ) : RefCounter(), m_uiType( uiType ), m_uiLock( 0 ), m_bDirty( false ), m_uiNumAllocated( 0 ), m_uiNumCurrent( 0 ) {}

		/**
		*/
		virtual                                      ~Buffer()
		{
			if( m_uiLock )
			{
				neolog << LogLevel( WARNING ) << "*** Active lock present when destroying buffer" << std::endl;
				assert( false );
			}
		}

		/**
		* Lock buffer for read/write operation
		* \param uiLockType                           Lock type
		* \return                                     true if lock acquired, false if failed (already locked)
		*/
		inline bool                                   Lock( unsigned int uiLockType )
		{
#ifdef _DEBUG
			if( m_uiLock )
			{
				neolog << LogLevel( WARNING ) << "*** Unable to lock buffer: active lock present" << std::endl;
				return false;
			}

			if( m_uiType & Buffer::NOREADWRITE )
			{
				neolog << LogLevel( ERROR ) << "*** Unable to lock buffer: NOREADWRITE buffer" << std::endl;
				return false;
			}
#endif
			
			m_uiLock  = uiLockType;
			m_bDirty |= ( ( m_uiLock & WRITE ) != 0 );
				
			if( !AcquireLock() )
			{
				m_uiLock = 0;
				return false;
			}
			
			return true;
		}

		/**
		* Unlock buffer
		*/
		inline void                                   Unlock()
		{
			if( m_uiLock )
			{
				bool bUpload = ( m_bDirty && ( ( s_eUploadPolicy == ONUNLOCK ) || ( m_uiLock & FORCEUPLOAD ) ) && !( m_uiLock & NOUPLOAD ) );

				ReleaseLock();
		
				if( bUpload )
					Upload();

				m_uiLock = 0;
			}
		}

		/**
		* Upload data to backing store, reset dirty flag
		*/
		virtual void                                  Upload() { m_bDirty = false; }

		/**
		* \return                                     true if buffer is locked, false if not
		*/
		inline bool                                   IsLocked() const { return( m_uiLock != 0 ); }

		/**
		* \return                                     true if buffer is dirty, false if not
		*/
		inline bool                                   IsDirty() const { return m_bDirty; }

		/**
		* \return                                     Buffer type
		*/
		inline unsigned int                           GetType() const { return m_uiType; }

		/**
		* \return                                     Number of allocated elements
		*/
		inline unsigned int                           GetNumAllocated() const { return m_uiNumAllocated; }

		/**
		* \return                                     Number of currently used elements
		*/
		inline unsigned int                           GetNumElements() const { return m_uiNumCurrent; }

		/**
		* Set new count of currently used elements
		* \param uiNumElements                        Number of elements currently used, will be clamped to [0,numallocated] range
		*/
		inline void                                   SetNumElements( unsigned int uiNumElements ) { m_uiNumCurrent = ( ( uiNumElements > m_uiNumAllocated ) ? m_uiNumAllocated : uiNumElements ); }

		/**
		* Get buffer type as string
		* \param uiType                               Type identifier
		* \return                                     Type as string
		*/
		static std::string                            GetTypeAsString( unsigned int uiType );

		/**
		* Get buffer type from string
		* \param strType                              String type identifier
		* \return                                     Type id
		*/
		static unsigned int                           GetTypeFromString( std::string const &strType );
};


};


#endif


