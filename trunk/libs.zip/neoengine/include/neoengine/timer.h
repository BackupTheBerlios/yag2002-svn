/***************************************************************************
                             timer.h  -  Timer
                             -------------------
    begin                : Tue Nov 6 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, timer.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NETIMER_H
#define __NETIMER_H

#include "base.h"


/**
  * \file timer.h
  * Timer abstraction
  */


namespace NeoEngine
{


/**
  * \brief Timer class
  * Used to get delta time between two moments. The timer class abstracts away OS specific implementations
  * and gives you a single interface for timing across all supported platforms. The timer is reset
  * when you first create it, an successive calls to GetDeltaTime() will return the deltatime passed
  * between the calls. If you do not wish to reset the timer when querying for the deltatime, you pass
  * false as argument to GetDeltaTime<br><br>
  * The timer also has a static heartbeat counter that can be used to synchronize unrelated objects in
  * the game. The heartbeat is reset on application startup and increases as it executes. Use the heartbeat
  * divisor to get the factor of increase.
  * \author Mattias Jansson (mattias@realityrift.com)
  * \todo Look into RTC implementation for Linux targets
  */
class NEOENGINE_API Timer
{
	friend class Core;

	protected:

		/*! Old clock */
		uint64_t                        m_uliOldClock;
		
		/*! Old heartbeat clock */
		static uint64_t                 s_uliOldHeartbeatClock;

		/*! Heartbeat is updated periodically and is used to maintain sync between different sections of the engine	*/
		static uint64_t                 s_uliHeartbeat;

		/*! The divisor is the factor by which you convert heartbeats to seconds. Multiply heartbeat with divisor */
		static uint64_t                 s_uliDivisor;

		
	public:

		/**
		*/
		                                Timer();

		/**
		* \param bReset                 Reset timer if true
		* \return                       Time passed in seconds since last call to Reset() or GetDeltaTime(true)
		*/
		float                           GetDeltaTime( bool bReset = true );

		/**
		* Reset timer
		*/
		void                            Reset();

		/**
		* \return                       Heartbeat
		*/
		static uint64_t                 GetHeartbeat();
		
		/**
		* \return                       Heartbeat divisor
		*/
		static uint64_t                 GetHeartbeatDivisor();
};


}; // namespace NeoEngine


#endif // __NETIMER_H
