/***************************************************************************
            physicsnode.h  -  Base node class for physics simulation
                             -------------------
    begin                : Sat Jan 3 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, physicsnode.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEPHYSICSNODE_H
#define __NEPHYSICSNODE_H


/**
  * \file physicsnode.h
  * Base node class for physics simulation
  */


#include "base.h"
#include "scenenode.h"

#include <vector>


namespace NeoEngine
{


/**
  * \brief State date for a physics node
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API PhysicsNodeState
{
	public:

		/*! Velocity */
		Vector3d                                      m_kVelocity;

		/*! Translation */
		Vector3d                                      m_kTranslation;

		/*! Rotation */
		Quaternion                                    m_kRotation;

		/**
		*/
		                                              PhysicsNodeState() {}

		/**
		* \param rkVelocity                           Velocity
		* \param rkTranslation                        Translation
		* \param rkRotation                           Rotation
		*/
		                                              PhysicsNodeState( const Vector3d &rkVelocity, const Vector3d &rkTranslation, const Quaternion &rkRotation ) : m_kVelocity( rkVelocity ), m_kTranslation( rkTranslation ), m_kRotation( rkRotation ) {}

		/**
		* \param rkState                              Reference state to copy
		*/
		                                              PhysicsNodeState( const PhysicsNodeState &rkState ) : m_kVelocity( rkState.m_kVelocity ), m_kTranslation( rkState.m_kTranslation ), m_kRotation( rkState.m_kRotation ) {}

		/**
		* Needed for STL exports of UDTs under Win32
		* \param rkState                              State data to compare with
		* \return                                     false
		*/
		bool                                          operator < ( const PhysicsNodeState &rkState ) const { return( false ); }

		/**
		* Query if states are equal
		* \param rkState                              State data to compare with
		* \return                                     true if all elements are equal, false if not
		*/
		bool                                          operator == ( const PhysicsNodeState &rkState ) const { return( ( m_kVelocity == rkState.m_kVelocity ) && ( m_kTranslation == rkState.m_kTranslation ) && ( m_kRotation == rkState.m_kRotation ) ); }
};


#ifdef WIN32
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif
#  ifndef __HAVE_VECTOR_NEPHYSICSNODESTATEOBJ
     UDTVectorEXPIMP( PhysicsNodeState );
#    define __HAVE_VECTOR_NEPHYSICSNODESTATEOBJ
#  endif
#endif


/**
  * \brief Base class for all physics nodes
  * Base class with methods for physic simulation objects
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API PhysicsNode : public SceneNode
{
	public:

		DefineVisitable();
	

	private:

		/*! State stack */
		std::vector< PhysicsNodeState >               m_vkStateStack;


	protected:

		/*! Velocity */
		Vector3d                                      m_kVelocity;



	public:

		/**
		*/
		                                              PhysicsNode();

		/**
		*/
		virtual                                      ~PhysicsNode();

		/**
		* Set velocity
		* \param rkVelocity                           Velocity
		*/
		inline void                                   SetVelocity( const Vector3d &rkVelocity ) { m_kVelocity = rkVelocity; }

		/**
		* \return                                     current velocity
		*/
		inline const Vector3d                        &GetVelocity() const { return m_kVelocity; }

		/**
		* Duplicate node
		* \return                                     New node that is exact copy of this node
		*/
		virtual SceneNode                            *Duplicate();

		/**
		* Update state by integrating equations for laws of motion
		* \param fDeltaTime                           Delta time passed since last update
		*/
		virtual void                                  Update( float fDeltaTime );

		/**
		* Push current state to stack
		*/
		virtual void                                  PushState();

		/**
		* Restore state from stack
		* \param bSet                                 If true, restore node to state popped off stack, otherwise ignore popped state
		*/
		virtual void                                  PopState( bool bSet = true );

		/**
		* Clear state stack
		*/
		virtual void                                  ClearState();

};


};


#endif
