/***************************************************************************
               socket.h  -  Virtual base class for network sockets
                             -------------------
    begin                : Thu Oct 10 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, socket.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NESOCKET_H
#define __NESOCKET_H


/**
* \file socket.h
* Network socket objects
*/


#include <string>
#include "base.h"

namespace NeoEngine
{


//Forward declarations
class SocketCallback;




/**
  * \class Socket
  * \brief Abstract interface for network sockets
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Socket
{
	public:

		/**
		* \enum SOCKETEVENT
		* \brief Socket event identifiers (bitfield)
		*/
		enum SOCKETEVENT
		{
		  /*! No event */
		  NONE           = 0x0000000,

		  /*! Connection received */
		  CONNECTION     = 0x0000001,

		  /*! Data to be read */
		  DATAIN         = 0x0000002,

		  /*! Error */
		  ERR            = 0x0000004,

		  /*! Hung up */
		  HUP            = 0x0000008,

		  /*! Invalid socket */
		  NVAL           = 0x0000010,

		  /*! Timeout */
		  TIMEOUT        = 0x0000020,

		  /*! Connected */
		  CONNECTED      = 0x0000040,

		  INVALID        = 0xFFFFFFF    //Invalid event, error in syscall or invalid arguments
		};


	public:

		/*! Callback object receiving events */
		SocketCallback                      *m_pkCallback;



		/**
		* \param pkCallback                    Socket callback object receiving events
		*/
		                                       Socket( SocketCallback *pkCallback = 0 ) : m_pkCallback( pkCallback ) {}

		/**
		*/
		virtual                               ~Socket() {}

		/**
		* \return                              Socket FD
		*/
		virtual int                            GetFD() = 0;

		/**
		* Set blocking/nonblocking mode
		* \param bBlock                        Blocking flag
		*/
		virtual void                           SetBlocking( bool bBlock = false ) = 0;

		/**
		* Poll socket
		* \param iTimeout                      Timeout in milliseconds
		* \return                              Events bitfield
		*/
		virtual unsigned int                   Poll( int iTimeout ) = 0;

		/**
		* Sets a new SocketCallback
		* \param pkCallback                    New callback method
		*/
		virtual void                           SetCallback( SocketCallback *pkCallback = 0 ) { m_pkCallback = pkCallback; }
};




/**
  * \class SocketCallback
  * \brief Callback method for socket events
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SocketCallback
{
	public:

		/**
		* Process socket event
		* \param pkSocket                      Socket
		* \param eEvent                        Event
		* \param pData                         Data
		*/
		virtual void                           SocketEventCallback( class Socket *pkSocket, Socket::SOCKETEVENT eEvent, void *pData ) = 0;
};


}; // namespace NeoEngine





#endif
