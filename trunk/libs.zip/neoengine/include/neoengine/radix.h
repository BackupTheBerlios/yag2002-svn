/***************************************************************************
                          radix.h  -  Radix sorter
                             -------------------
    begin                : Mon May 13 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, radix.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NERADIX_H
#define __NERADIX_H


#include "base.h"


/**
  * \file radix.h
  * Class for radix sort algorithm
  */


namespace NeoEngine
{


/**
  * \brief Radix sorter (original implementation by Pierre Terdiman, http://www.codecorner.com)
  * Radix sorter that can sort signed/unsigned 32-bit integers, signed/unsigned 64-bit integers and floats.
  * To use the sorted, pass the desired data type to the constructor and then Sort(), passing the
  * pointer to your data (of the same type as you passed to the ctor) and number of elements in the
  * array to sort. To access the sorted indices you use GetIndices() which will return a pointer
  * to an index array for the sorted elements. This means the radix sorter does not modify your original
  * data array, but gives you and index array allowing you to access the objects in sorted order.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API RadixSort
{
	public:

		/**
		* \enum RADIXSORTTYPE
		* \brief Supported input data types for radix sorter
		*/
		enum RADIXSORTTYPE
		{
		  /*! Signed 32bit */
		  INT32                                       = 0x00000000,

		  /*! Unsigned 32bit */
		  UINT32                                      = 0x00000001,

		  /*! Signed 64bit */
		  INT64                                       = 0x00000002,

		  /*! Unsigned 64bit */
		  UINT64                                      = 0x00000003,

		  /*! Float 32bit */
		  FLOAT32                                     = 0x00000004
		};


	protected:

		/*! Data type */
		RADIXSORTTYPE                                 m_eType;

		/*! Current size of the indices list */
		unsigned int                                  m_uiCurrentSize;

		/*! Size involved in previous call */
		unsigned int                                  m_uiPreviousSize;

		/*! Lists swapped each pass, first list */
		unsigned int                                 *m_puiIndices;

		/*! Lists swapped each pass, second list */
		unsigned int                                 *m_puiIndices2;

		/*! Statistics, total sort calls */
		unsigned int                                  m_uiTotalCalls;

		/*! Statistics, premature exits due to temporal coherence */
		unsigned int                                  m_uiHits;

		/*! Histogram array */
		unsigned int                                 *m_puiHistogram;

		/*! Offset array */
		unsigned int                                 *m_puiOffset;

		/**
		* Resize inner lists
		* \param uiNB                                 Number of indices
		*/
		bool                                          Resize( unsigned int uiNB );

		/**
		* Reset the inner indices
		*/
		void                                          ResetIndices();

		/**
		* Create histograms and check for temporal coherence
		* \param pInput                               Input data to be sorted
		* \param uiNB                                 Number of elements to be sorted
		* \return                                     true if already sorted, false if needs sorting
		*/
		bool                                          CreateHistograms( const void *pInput, unsigned int uiNB );

		/**
		* Sort float data
		* \param pfInput                              Array of data to sort
		* \param uiNB                                 Number of elements to sort
		* \return                                     self-reference
		*/
		RadixSort                                    &Sort( const float *pfInput, unsigned int uiNB );



	public:

		/**
		* \param eType                                Data type to sort
		*/
		                                              RadixSort( RADIXSORTTYPE eType = INT32 );

		/**
		* Free used memory
		*/
		                                             ~RadixSort();
													 
		/**
		* Set data type
		* \param eType                                Data type to sort
		*/
		void                                          SetType( RADIXSORTTYPE eType );

		/**
		* Sort data based on type of sorter as passed to constructor
		* \param pInput                               Array of data to sort
		* \param uiNB                                 Number of elements to sort
		* \return                                     self-reference
		*/
		RadixSort                                    &Sort( const void *pInput, unsigned int uiNB );

		/**
		* Access to results, a list of indices in sorted order
		* \return                                     Pointer to index array with sorted indices into data array sent to sort method
		*/
		inline unsigned int                          *GetIndices() { return m_puiIndices; }

		/**
		* \return                                     Memory used by this sort object
		*/
		unsigned int                                  GetUsedMemory() const;

		/**
		* \return                                     Total number of calls to the radix sorter
		*/
		inline unsigned int                           GetTotalCalls() const { return m_uiTotalCalls; }

		/**
		* \return                                     Number of premature exits due to temporal coherence
		*/
		inline unsigned int                           GetHits() const { return m_uiHits; }
};


};


#endif
