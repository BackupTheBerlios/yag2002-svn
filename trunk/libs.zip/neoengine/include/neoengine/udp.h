/***************************************************************************
                            udp.h  -  UDP sockets
                             -------------------
    begin                : Sun Jun 1 2003
    copyright            : (C) 2003 by Keaton Mullis
    email                : kmullis@zianet.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, udp.h

 The Initial Developer of the Original Code is Keaton Mullis.
 Portions created by Keaton Mullis are Copyright (C) 2003
 Keaton Mullis. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEUDP_H
#define __NEUDP_H



#include "base.h"
#include "socket.h"

#include <string>


/**
  * \file udp.h
  * UDP socket wrapper
  */

namespace NeoEngine
{


//External classes
class Thread;




/**
  * \class UDPSocket
  * \brief UDP implementation of socket interface
  * \author Keaton Mullis (kmullis@zianet.com)
  */
class NEOENGINE_API UDPSocket : public Socket
{
	public:

		/*! Socket descriptor */
		int                                    m_iSocket;

		/**
		* \param pkCallback                    Socket callback object receiving events
		*/
		                                       UDPSocket( SocketCallback *pkCallback = 0 );

		/**
		* \param iSocket                       Socket descriptor
		* \param pkCallback                    Socket callback object receiving events
		*/
		                                       UDPSocket( int iSocket, SocketCallback *pkCallback = 0 );

		/**
		*/
		virtual                               ~UDPSocket();

		/**
		* Listen for incoming connections
		* \param iPort                         Port to listen to
		* \param pkCallback                    Callback recieving connection events (will replace current callback object if not null)
		* \return                              true if socket successfuly setup, false otherwise
		*/
		virtual bool                           Listen( int iPort, SocketCallback *pkCallback );

		/**
		* Read data from socket
		* \param pDst                          Destination buffer
		* \param iBytes                        Bytes to read
		* \param rstrFromAddr                  Address of sender
		* \param riFromPort                    Port of sender
		* \return                              Actual number of bytes read
		* \todo Current method for returning from address/port is UGLY, clean it up
		*/
		int                                    Read( void *pDst, int iBytes, std::string &rstrFromAddr, int &riFromPort );

		/**
		* Write data to socket
		* \param pSrc                          Source buffer
		* \param iBytes                        Bytes to write
		* \param rstrFromAddr                  Address of recipient
		* \param riFromPort                    Port of recipient
		* \return                              Actual number of bytes written
		*/
		int                                    Write( const void *pSrc, int iBytes, std::string strToAddr, int iToPort );

		/**
		* \return                              Socket FD
		*/
		virtual int                            GetFD() { return m_iSocket; }

		/**
		* Set blocking/nonblocking mode
		* \param bBlock                        Blocking flag
		*/
		virtual void                           SetBlocking( bool bBlock = false );

		/**
		* Poll socket
		* \param iTimeout                      Timeout in milliseconds
		* \return                              Events bitfield
		*/
		virtual unsigned int                   Poll( int iTimeout );
};


}; // namespace NeoEngine



#endif
