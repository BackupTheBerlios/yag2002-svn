/***************************************************************************
                   polygon.h  -  Polygon and edge primitives
                             -------------------
    begin                : Fri Nov 2 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, polygon.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEPOLYGON_H
#define __NEPOLYGON_H

#include "base.h"
#include "util.h"


/**
  * \file polygon.h
  * Polygon representation as three indices into a vertex buffer. Edges.
  */


namespace NeoEngine
{


/**
  * \brief Polygon abstraction class (triangles only)
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Polygon
{
	public:

		/*! Indices */
		unsigned short                                v[3];

		/**
		*/
		                                              Polygon() {}

		/**
		* \param v0                                   First index
		* \param v1                                   Second index
		* \param v2                                   Third index
		*/
		                                              Polygon( unsigned short v0, unsigned short v1, unsigned short v2 ) { v[0] = v0; v[1] = v1; v[2] = v2; }

		/**
		* \param pusIndices                           Indices pointer
		*/
		                                              Polygon( unsigned short *pusIndices ) { fmemcpy( v, pusIndices, sizeof( unsigned short ) * 3 ); }
		                               
		/**
		* \param rkPoly                               Polygon reference object
		*/
		                                              Polygon( const Polygon &rkPoly ) { fmemcpy( v, rkPoly.v, sizeof( unsigned short ) * 3 ); }
		                               
		/**
		* Array access (no range check)
		* \param iIndex                               Component to access
		*/
		inline unsigned short                        &operator []( int iIndex ) { return v[iIndex]; }

		/**
		* \param rkPoly                               Polygon reference object
		* \return                                     ref to this
		*/
		inline Polygon                               &operator = ( const Polygon &rkPoly ) { v[0] = rkPoly.v[0]; v[1] = rkPoly.v[1]; v[2] = rkPoly.v[2]; return( *this ); }

		/**
		* Useful operator, compare two polygons
		* \param rkPoly                               Polygon to compare with
		* \return                                     true if indices are equal, false if not
		*/
		inline bool                                   operator == ( const Polygon &rkPoly ) const { return( ( v[0] == rkPoly.v[0] ) && ( v[1] == rkPoly.v[1] ) && ( v[2] == rkPoly.v[2] ) ); }

		/**
		* Dummy method for Win32 compatibility (template instantiation)
		* \param rkPoly                               Polygon to compare with
		* \return                                     false
		*/
		inline bool                                   operator < ( const Polygon &rkPoly ) const { return false; }
};


/**
  * \brief Primitive class for edges
  * An edge is simply two connected vertices. Object of this class will be used in meshes to precaclulate
  * edges and their dependencies for use in shadow volume generation. This class only holds two indices
  * into some vertex array the owner will have to implement (probably indices into a VertexBuffer), a
  * polygon (index into a polygon array) and some internal flags. An edge is shared by two polygons, we
  * do not allow non-manifold meshes.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Edge
{
	public:

		/*! Vertices defining this edge */
		unsigned short                                m_usVertices[2];

		/*! Polygon this edge belongs to */
		unsigned int                                  m_uiPolygon;

		/*! Edge sharing vertices with this edge (m_pkNeighbour->m_iPolygon is neighbour polygon) */
		Edge                                         *m_pkNeighbour;

		/*! Visible flag (-1 invisible, 0 not calculated, 1 visible). Used internally during rendering of shadow volumes */
		int                                           m_iVisible;

		/**
		* Reset flags and data
		*/
		                                              Edge() { m_usVertices[0] = m_usVertices[1] = 0; m_uiPolygon = 0; m_pkNeighbour = 0; m_iVisible = 0; }
};


};


#endif
