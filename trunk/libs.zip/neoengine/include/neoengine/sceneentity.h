/***************************************************************************
               sceneentity.h  -  Base class for scene entities
                             -------------------
    begin                : Sat Jan 25 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, sceneentity.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NESCENEENTITY_H
#define __NESCENEENTITY_H


/**
  * \file neoengine/sceneentity.h
  * Base class for entities in scene graph
  */


#include "base.h"
#include "updateentity.h"
#include "renderentity.h"
#include "visitor.h"


namespace NeoEngine
{


//External classes
class SceneNode;
class BoundingVolume;
class ContactSet;
class Ray;


/**
  * \brief Base class for entities in a scene graph
  * A scene entity is an object in the scene graph, contained
  * by scene nodes. The entity itself does not hold SRT data,
  * that is stored in the parent scene node object. A scene entity
  * can be anything that can be described as an object in a scene
  * graph, such as meshes, lights, skyboxes. A scene entity has base
  * methods for updating and rendering, as well as a collision
  * detection interface.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SceneEntity : public virtual UpdateEntity, public RenderEntity, public BaseVisitable
{
	friend class SceneNode;

	public:

		DefineVisitable();


	protected:

		/*! Parent scene node object */
		SceneNode                                    *m_pkNode;

		/*! Bounding volume for this entity */
		BoundingVolume                               *m_pkBoundingVolume;

		/**
		* Called by scene node when entity has been set to a node
		*/
		virtual void                                  SetNode() {}


	public:

		/**
		*/
		                                              SceneEntity() : m_pkNode( 0 ), m_pkBoundingVolume( 0 ) {}

		/**
		*/
		virtual                                      ~SceneEntity();

		/**
		* \return                                     parent scene node
		*/
		inline SceneNode                             *GetSceneNode() { return m_pkNode; }

		/**
		* \return                                     Bounding volume
		*/
		inline BoundingVolume                        *GetBoundingVolume() { return m_pkBoundingVolume; }

		/**
		* Set new bounding volume object. Old bounding volume object will be deleted.
		* The new bounding volume SRT data should be in <b>LOCAL</b> space, the world
		* space SRT data will be calculated internally
		* \param pkBoundingVolume                     New bounding volume object
		*/
		void                                          SetBoundingVolume( BoundingVolume *pkBoundingVolume );

		/**
		* Duplicate entity
		* \return                                     New entity that is exact copy of entity, or null if not supported by entity type
		*/
		virtual SceneEntity                          *Duplicate() { return 0; }

		/**
		* Intersection test with unknown object type
		* \param pkObj                                Bounding volume object to test for intersection with
		* \param pkContactSet                         Collision set object receiving collision contact data, 0 if not needed
		* \param bInvertNormal                        If false, collision normal will point from passed object to this. If true, normal will point in other direction
		* \return                                     true if volumes intersect, false if not
		*/
		virtual bool                                  Intersection( BoundingVolume *pkObj, ContactSet *pkContactSet = 0, bool bInvertNormal = false ) { return false; }

		/**
		* Intersection test with ray
		* \param rkRay                                Ray
		* \param pkContactSet                            Collision set object receiving collision contact data, 0 if not needed
		* \return                                     true if volumes intersect, false if not
		*/
		virtual bool                                  Intersection( const Ray &rkRay, ContactSet *pkContactSet = 0 ) { return false; }
};


};


#endif
