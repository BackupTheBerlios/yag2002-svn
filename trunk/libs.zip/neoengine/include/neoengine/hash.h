/***************************************************************************
                          hash.h  -  Hash methods
                             -------------------
    begin                : Wed Feb 12 2003
    copyright            : (C) 2003 by Mattias Jansson
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, hash.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEHASH_H
#define __NEHASH_H

#include "base.h"

#include <string>

 
 /**
  * \file hash.h
  * Hash methods
  */


namespace NeoEngine
{


/**
* Calculate hash value of string. All engine objects using hashes use
* this method for calculating the hash value. If you need to manually
* calculate an hash, you should use this method.
* \param pszString        String
* \param uiLength         Length to hash (0 for entire string, default)
* \return                 Hash value
*/
inline unsigned int Hash( const char *pszString, unsigned int uiLength = 0 )
{
	if( !pszString )
		return 0;

	if( !uiLength )
		uiLength = (unsigned int)strlen( pszString );

	unsigned int         uiRet  = 0;
	unsigned int         uiTmp;
	const unsigned char *pszStr = (const unsigned char*)pszString;

	for( unsigned int i = 0; i < uiLength; ++i, ++pszStr )
	{
		uiRet = ( uiRet << 4 ) + *pszStr;

		if( ( uiTmp = uiRet & 0xF0000000 ) )
			uiRet ^= ( uiTmp >> 24 );

		uiRet &= ~uiTmp;
	}

	return uiRet;
}


/**
* Calculate hash value of string. All engine objects using hashes use
* this method for calculating the hash value. If you need to manually
* calculate an hash, you should use this method.
* \param rstrString       String
* \param uiLength         Length to hash (0 for entire string, default)
* \return                 Hash value
*/
inline unsigned int Hash( const std::string &rstrString, unsigned int uiLength = 0 )
{
	return Hash( rstrString.c_str(), uiLength ? uiLength : rstrString.length() );
}


};


#endif

