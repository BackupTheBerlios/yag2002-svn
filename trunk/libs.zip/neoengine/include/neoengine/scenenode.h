/***************************************************************************
        scenenode.h  -  Base class for hierarchies in a scene graph
                             -------------------
    begin                : Sat Jan 25 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, scenenode.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NESCENENODE_H
#define __NESCENENODE_H


/**
  * \file neoengine/scenenode.h
  * Base class for hierarchies in a scene graph
  */


#include "base.h"
#include "hierarchynode.h"
#include "updateentity.h"
#include "renderentity.h"
#include "boundingvolume.h"

#include <vector>
#include <string>


namespace NeoEngine
{


// External classes
class SceneEntity;
class Room;
class SceneNodeCallback;

#ifdef WIN32

#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif

#  ifndef __HAVE_VECTOR_NESCENENODE
     UDTVectorEXPIMP( class SceneNode* );
#    define __HAVE_VECTOR_NESCENENODE
#  endif
#  ifndef __HAVE_VECTOR_NESCENENODECALLBACK
     UDTVectorEXPIMP( class SceneNodeCallback* );
#    define __HAVE_VECTOR_NESCENENODECALLBACK
#  endif

#  ifdef _MSC_VER
#    ifndef __HAVE_NEHIERARCHYNODE_NESCENENODE
       EXPIMP_TEMPLATE template class NEOENGINE_API HierarchyNode< class SceneNode >;
#      define __HAVE_NEHIERARCHYNODE_NESCENENODE
#    endif
#  endif

#endif


/**
  * \brief Base class for hierarchies in a scene graph
  * A scene node is the building block of a scene graph. Derived
  * from the SRT node for basic capabilities, extended with hierarchy
  * data (one parent, mutliple children). World data is cached and
  * updated when needed by overloading SRT node methods and flagging
  * for invalid caches. A scene node can contain an entity, which
  * can be anything from a mesh, a light or a sprite to a forcefield
  * or other modifier. With this container-entity relationship we can
  * allow for derived scene node objects (such as a physics-controlled
  * particle or rigid-body) to hold all kinds of entities. A scene
  * node is derived from Activator and can thus be activated/deactivated.
  * A deactivated node will turn off calls to Update and Render for
  * the entire subtree with that node as root.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SceneNode : public virtual UpdateEntity, public virtual RenderEntity, public HierarchyNode<SceneNode>
{
	public:

		DefineVisitable();

	
	protected:

		/*! Scene entity contained in this node */
		SceneEntity                                  *m_pkEntity;

		/*! Bounding volume for subtree rooted at this node */
		BoundingVolume                               *m_pkBoundingVolume;

		/*! Flag indicating bounding volume needs remerging */
		bool                                          m_bNeedVolumeUpdate;

		/*! Internal flag for indicating we should ignore requests for volume update */
		bool                                          m_bIgnoreVolumeUpdate;

		/*! Update callbacks */
		std::vector< SceneNodeCallback* >             m_vpkCallbacks;


		/**
		* Updates world SRT data cache
		* \return                                     true if world cache data was updated, false if not
		*/
		virtual bool                                  UpdateWorld();

		/**
		* Updates bounding volume for subtree rooted at this node
		* \return                                     true if any bounding volume was updated, false if not
		*/
		virtual bool                                  UpdateVolume();

		/**
		* Used to get this as correct type
		* \return                                     This node
		*/
		inline virtual SceneNode                     *Get();


	public:

		/*! Room we are attached to */
		Room                                         *m_pkRoom;

		/*! Flag indicating parent node should ignore this node when calculating bounding volume */
		bool                                          m_bIgnoreVolume;


		/**
		* Create named, attached node. Will initially have same world position as parent
		* (i.e zero relative rotation and translation, no scaling)
		* \param rstrName                             Node name
		* \param pkParent                             Parent node
		* \param eVolume                              Desired bounding volume type (default axis-aligned box)
		*/
		                                              SceneNode( const HashString &rstrName = "", SceneNode *pkParent = 0, BoundingVolume::BOUNDINGVOLUMETYPE eVolume = BoundingVolume::BV_AABB );

		/**
		* Create node from reference object
		* \param rkNode                               Reference node object to copy
		* \param bDuplicateChildren                   Duplicate child nodes if true
		*/
		                                              SceneNode( SceneNode &rkNode, bool bDuplicateChildren = true );

		/**
		* Deallocates child nodes and detaches from parent
		*/
		virtual                                      ~SceneNode();

		/**
		* Set world udpate flag. If flag is set, a call to any of the
		* GetWorldScaling, GetWorldRotation, GetWorldTranslation will
		* cause world cache data to be updated. Optionally recurses on
		* all child nodes (default).
		* \param bRecurse                             Recurse on children
		*/
		inline virtual void                           NotifyUpdate( bool bRecurse = true );

		/**
		* Set bounding volume udpate flag. If flag is set, a call to any of the
		* GetBoundingVolume will cause volume to be remerged from child nodes and entity.
		* Optionally recurses on parent (default).
		* \param bRecurse                             Recurse on parent
		*/
		inline virtual void                           NotifyVolumeUpdate( bool bRecurse = true );

		/**
		* If node is active, update node and any child nodes. Also calls
		* Update on the entity object, if any.
		* \param fDeltaTime                           Delta time passed
		*/
		virtual void                                  Update( float fDeltaTime );

		/**
		* If node is active, render entity (if any) and any child nodes.
		* \param pkFrustum                            Current view frustum
		* \param bForce                               Force rendering even if rendered already this frame (default false)
		* \return                                     true if we were rendered, false if not (already rendered and not forced)
		*/
		virtual bool                                  Render( Frustum *pkFrustum = 0, bool bForce = false );

		/**
		* Get bounding volume
		* \return                                     Bounding volume for entire subtree rooted at this node
		*/
		inline BoundingVolume                        *GetBoundingVolume();

		/**
		* Set bounding volume object. Bounding volume transformation should be in world coordinate system
		* \param pkVolume                             Bounding volume
		*/
		void                                          SetBoundingVolume( BoundingVolume *pkVolume );

		/**
		* Get scene entity attached to this node	
		* \return                                     Scene entity object pointer
		*/
		inline SceneEntity                           *GetEntity();

		/**
		* Attach new scene entity to this node. If flag set, Will delete
		* previous entity (if any)
		* \param pkEntity                             New scene entity object
		* \param bDeleteOld                           if true, delete old entity object
		*/
		void                                          SetEntity( SceneEntity *pkEntity, bool bDeleteOld = true );

		/**
		* Debug output. Print hierarchy of nodes
		* \param uiLevel                              Current recursion level
		*/
		void                                          PrintHierarchy( unsigned int uiLevel = 0 );

		/**
		* Duplicate node, child nodes and optionally entities
		* \return                                     New node that is exact duplicate of this node
		*/
		virtual SceneNode                            *Duplicate();

		/**
		* Also traverse the entitiy
		* \param rkVisitor                            Visitor to apply to each node
		*/
		virtual void                                  TraverseNode( BaseVisitor &rkVisitor );

		/**
		* Intersection test with unknown object type
		* \param pkObj                                Bounding volume object to test for intersection with
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \return                                     true if volumes intersect, false if not
		*/
		virtual bool                                  Intersection( BoundingVolume *pkObj, ContactSet *pkContactSet = 0 );

		/**
		* Intersection test with ray
		* \param rkRay                                Ray
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \return                                     true if volumes intersect, false if not
		*/
		virtual bool                                  Intersection( const Ray &rkRay, ContactSet *pkContactSet = 0 );

		/**
		* Add callback
		* \param pkCallback                           Callback object
		*/
		void                                          AddCallback( SceneNodeCallback *pkCallback );

		/**
		* Remove callback
		* \param pkCallback                           Callback object
		*/
		void                                          RemoveCallback( SceneNodeCallback *pkCallback );
};


/**
  * \brief Node update callback
  * Called by nodes when SRT data changes
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SceneNodeCallback
{
	public:
	
		/**
		* Called by node when SRT data changed
		* \param pkNode                               Node
		*/
		virtual void                                  NodeChanged( SceneNode *pkNode ) = 0;

		/**
		* Called by node when deleted
		* \param pkNode                               Node
		*/
		virtual void                                  NodeDeleted( SceneNode *pkNode ) = 0;
};


#include "scenenode_inl.h"


};


#endif
