/***************************************************************************
                     pool_inl.h  -  Multi-node hash table
                             -------------------
    begin                : Wed Feb 12 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, pool_inl.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/



template < class PoolDataType > inline PoolNode< PoolDataType >::PoolNode( const HashString &rstrKey, PoolDataType *pkData ) :
	m_strKey( rstrKey ),
	m_vpkData( 1, pkData )
{
}




template < class PoolDataType > inline PoolNode< PoolDataType > *Pool< PoolDataType >::LookupNode( const HashString &rstrKey, int iIndex )
{
	unsigned int i = ( iIndex ? iIndex : rstrKey.GetHash() ) % m_iSize;
	
	if( !m_pvkTable[i].size() )
		return 0;

	typename PoolNodeVec::iterator pkNode = m_pvkTable[i].begin();
	typename PoolNodeVec::iterator pkEnd  = m_pvkTable[i].end();

	for( ; pkNode != pkEnd; ++pkNode )
	{
		if( pkNode->m_strKey == rstrKey )
			return &(*pkNode);
	}

	return 0;
}


template < class PoolDataType > Pool< PoolDataType >::Pool( int iSize ) :
	m_pvkTable( new PoolNodeVec[ iSize ] ),
	m_iSize( iSize )
{
}


template < class PoolDataType > Pool< PoolDataType >::~Pool()
{
	delete [] m_pvkTable;
}


template < class PoolDataType > void Pool< PoolDataType >::Insert( const HashString &rstrKey, PoolDataType *pkData )
{
	assert( m_pvkTable );

	unsigned int i = rstrKey.GetHash() % m_iSize;

	PoolNodeType *pkNode = LookupNode( rstrKey, i );

	if( pkNode )
	{
		typename PoolDataVec::iterator ppkData = pkNode->m_vpkData.begin();
		typename PoolDataVec::iterator ppkEnd  = pkNode->m_vpkData.end();

		for( ; ppkData != ppkEnd; ++ppkData )
			if( *ppkData == pkData )
				return;

		pkNode->m_vpkData.push_back( pkData );
	}
	else
		m_pvkTable[i].push_back( PoolNodeType( rstrKey, pkData ) );
}


template < class PoolDataType > const typename Pool< PoolDataType >::PoolDataVec *Pool< PoolDataType >::Find( const HashString &rstrKey )
{
	assert( m_pvkTable );

	PoolNodeType *pkNode = LookupNode( rstrKey );

	return( pkNode ? &pkNode->m_vpkData : 0 );
}


template < class PoolDataType > void Pool< PoolDataType >::Delete( const HashString &rstrKey, PoolDataType *pkData )
{
	assert( m_pvkTable );

	unsigned int i = rstrKey.GetHash() % m_iSize;

	typename PoolNodeVec::iterator pkNode = m_pvkTable[i].begin();
	typename PoolNodeVec::iterator pkEnd  = m_pvkTable[i].end();

	for( ; pkNode != pkEnd; ++pkNode )
	{
		if( pkNode->m_strKey == rstrKey )
		{
			typename PoolDataVec::iterator ppkData = pkNode->m_vpkData.begin();
			typename PoolDataVec::iterator ppkEnd  = pkNode->m_vpkData.end();

			for( ; ppkData != ppkEnd; ++ppkData )
			{
				if( *ppkData == pkData )
				{
					pkNode->m_vpkData.erase( ppkData );

					break;
				}
			}

			if( !pkNode->m_vpkData.size() )
				m_pvkTable[i].erase( pkNode );

			break;
		}
	}
}


template < class PoolDataType > void Pool< PoolDataType >::GetAllNodes( PoolNodePtrVec *pvpkVector )
{
	for( int i = 0; i < m_iSize; ++i )
	{
		typename PoolNodeVec::iterator pkNode = m_pvkTable[i].begin();
		typename PoolNodeVec::iterator pkEnd  = m_pvkTable[i].end();

		for( ; pkNode != pkEnd; ++pkNode )
			pvpkVector->push_back( &(*pkNode) );
	}
}


template < class PoolDataType > void Pool< PoolDataType >::GetAllNodeData( PoolDataVec *pvpkVector )
{
	for( int i = 0; i < m_iSize; ++i )
	{
		typename PoolNodeVec::iterator pkNode = m_pvkTable[i].begin();
		typename PoolNodeVec::iterator pkEnd  = m_pvkTable[i].end();

		for( ; pkNode != pkEnd; ++pkNode )
		{
			typename PoolDataVec::iterator ppkData    = pkNode->m_vpkData.begin();
			typename PoolDataVec::iterator ppkDataEnd = pkNode->m_vpkData.end();

			for( ; ppkData != ppkDataEnd; ++ppkData )
				pvpkVector->push_back( *ppkData );
		}
	}
}


