/***************************************************************************
                     sound.h  -  Sound classes and codecs
                             -------------------
    begin                : Wed Mar 17 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, sound.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NESOUND_H
#define __NESOUND_H

#include "base.h"
#include "module.h"
#include "filetype.h"

#include <string>
#include <vector>


/** 
  * \file sound.h
  * Sound classes and codecs
  */


namespace NeoEngine
{


class Sound;
class SoundStream;
class SoundCodec;


/**
  * \brief Sound (2D stereo sound)
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Sound
{
	protected:

		/*! Name */
		std::string                                        m_strName;

		/*! The sound stream object */
		SoundStream                                       *m_pkStream;

		/*! Loop flag */
		bool                                               m_bLoop;

		/*! Sound is playing */
		bool                                               m_bIsPlaying;

	
	public:

		/**
		* \param rstrName                                  Name
		* \param pkStream                                  Sound stream
		*/
		                                                   Sound( const std::string &rstrName, SoundStream *pkStream );

		/**
		*/
		virtual                                           ~Sound();

		/**
		* Play the sound
		* \param bLoop                                     Loop sound if true
		*/
		virtual void                                       Play( bool bLoop = false ) = 0;

		/**
		* Pause the sound. Next Play call will resume sound from paused position
		*/
		virtual void                                       Pause() = 0;
		
		/**
		* Stop playing the sound. Next Play call will start sound from beginning
		*/
		virtual void                                       Stop() = 0;

		/**
		* \return                                          true if the sound is playing, false if not
		*/
		inline bool                                        IsPlaying() const { return m_bIsPlaying; }

		/**
		* \return                                          Sound name
		*/
		inline const std::string                          &GetName() const { return m_strName; }
};


/**
  * \brief Sound stream data
  * Sounds stream data is produced by the sound codecs and consumed by the sound object
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SoundStream
{
	protected:

		/*! The sound file */
		File                                              *m_pkFile;

		/*! Total size in bytes of sound data in stream */
		unsigned int                                       m_uiSize;

		/*! Current offset */
		unsigned int                                       m_uiCurPos;

		/*! Number of channels */
		unsigned int                                       m_uiNumChannels;

		/*! Samples per second */
		unsigned int                                       m_uiSamplesPerSecond;

		/*! Buts per sample */
		unsigned int                                       m_uiBitsPerSample;


	public:

		/**
		* \param pkFile                                    Sound file
		*/
		                                                   SoundStream( File *pkFile );

		/**
		*/
		virtual                                           ~SoundStream();

		/**
		* Reset the stream to start
		*/
		virtual void                                       Reset();

		/**
		* Decode a chunk of data
		* \param pucBuffer                                 Target buffer
		* \param uiBytes                                   Maximum number of bytes to decode (maximum size of buffer)
		* \return                                          Number of bytes decoded
		*/
		virtual unsigned int                               Decode( unsigned char *pucBuffer, unsigned int uiBytes ) = 0;

		/**
		* \return                                          total size in bytes of sound data
		*/
		inline unsigned int                                GetSize() const { return m_uiSize; }

		/**
		* \return                                          current offset in stream
		*/
		inline unsigned int                                GetPosition() const { return m_uiCurPos; }

		/**
		* \return                                          Number of channels
		*/
		inline unsigned int                                GetNumChannels() const { return m_uiNumChannels; }

		/**
		* \return                                          Number of samples per second
		*/
		inline unsigned int                                GetSamplesPerSecond() const { return m_uiSamplesPerSecond; }

		/**
		* \return                                          Number of bits per sample
		*/
		inline unsigned int                                GetBitsPerSample() const { return m_uiBitsPerSample; }
};


/**
  * \brief Base class for sound codecs
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SoundCodec : public FiletypeIdentifier
{
	friend class AudioDevice;

	protected:

		/*! The codec module */
		ModulePtr                                          m_pkModule;


	public:

		/**
		* \param rstrFiletypeName                          File type name
		* \param rvstrExtensions                           File type extensions
		*/
		                                                   SoundCodec( const std::string &rstrFiletypeName, const std::vector<std::string> &rvstrExtensions );

		/**
		*/
		virtual                                           ~SoundCodec();

		/**
		* Create a sound stream
		* \param pkFile                                    File
		* \return                                          Ptr to new SoundStream object
		*/
		virtual SoundStream                               *GetStream( File *pkFile ) = 0;
};


};


#endif

