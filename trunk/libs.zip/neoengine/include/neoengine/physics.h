/***************************************************************************
                    physics.h  -  Physics simulation classes
                             -------------------
    begin                : Tue Nov 6 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, physics.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEPHYSICS_H
#define __NEPHYSICS_H


/**
  * \file physics.h
  * Classes for physics simulations
  */


#include "base.h"
#include "nemath.h"
#include "room.h"
#include "updateentity.h"
#include "rigidbody.h"
#include "contact.h"

#include <vector>


namespace NeoEngine
{


#ifdef WIN32
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif
#  ifndef __HAVE_VECTOR_NERIGIDBODY
     UDTVectorEXPIMP( RigidBody* );
#    define __HAVE_VECTOR_NERIGIDBODY
#  endif
#  ifndef __HAVE_VECTOR_NECONTACTSET
     UDTVectorEXPIMP( ContactSet* );
#    define __HAVE_VECTOR_NECONTACTSET
#  endif
#  ifndef __HAVE_VECTOR_NECONTACTNODE
     UDTVectorEXPIMP( class ContactNode* );
#    define __HAVE_VECTOR_NECONTACTNODE
#  endif
#  ifndef __HAVE_VECTOR_NEMATRIX
     UDTVectorEXPIMP( Matrix* );
#    define __HAVE_VECTOR_NEMATRIX
#  endif
#  ifndef __HAVE_VECTOR_NEJOINT
     UDTVectorEXPIMP( class Joint* );
#    define __HAVE_VECTOR_NEJOINT
#  endif
#endif


/**
  * \brief Node in contact directed acyclic graph
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ContactNode
{
	public:

		/**
		* Contact resolution mode
		*/
		enum CONTACTMODE
		{
		  /*! Collisions */
		  COLLISION                                   = 0,

		  /*! Contacts */
		  CONTACT                                     = 1,

		  /*! Shock propagation */
		  SHOCKPROPAGATION                            = 2
		};


		/*! Rigid body */
		RigidBody                                    *m_pkBody;

		/*! Parent nodes for each contact */
		std::vector< ContactNode* >                   m_vpkParents;

		/*! Contact sets for each parent contact */
		std::vector< ContactSet* >                    m_vpkContactSets;

		/*! Children */
		std::vector< ContactNode* >                   m_vpkChildren;

		/*! Visited flag */
		bool                                          m_bVisited;

		/*! Free (no parent node contact) */
		bool                                          m_bFree;

		/*! Generic ID data */
		unsigned int                                  m_uiID;

		/*! Total number of contact points */
		unsigned int                                  m_uiTotalPoints;

		/*! Used during graph partitioning */
		unsigned int                                  m_uiPartitionPass;


		/**
		* \param pkBody                               Rigidbody object
		*/
		                                              ContactNode( RigidBody *pkBody );

		/**
		*/
		virtual                                      ~ContactNode();

		/**
		* Sweep the contact DAG and solve contacts
		* \param eMode                                Contact mode
		* \param uiPass                               Current pass
		* \param uiNumPasses                          Number of passes
		*/
		bool                                          Solve( CONTACTMODE eMode, unsigned int uiPass, unsigned int uiNumPasses );

		/**
		* Reset visited flag
		*/
		void                                          ResetVisited();

		/**
		* Add a contact
		* \param pkParent                             Parent DAG node
		* \param pkSet                                Contact set
		*/
		void                                          AddContact( ContactNode *pkParent, ContactSet *pkSet );

		/**
		* Clear all data
		*/
		void                                          Clear();
};


/**
  * \brief Manager of rigidbody nodes in a scene
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API PhysicsManager : public virtual UpdateEntity
{
	public:

		/**
		* Defines and default values for physics manager
		*/
		enum PHYSICSMANAGERDEFS
		{
		  /*! Default number of collision passes */
		  DEFAULTCOLLISIONPASSES                      = 5,

		  /*! Default number of contact passes */
		  DEFAULTCONTACTPASSES                        = 10
		};


	protected:

		/*! Number of collision passes */
		unsigned int                                  m_uiCollisionPasses;

		/*! Number of contact passes */
		unsigned int                                  m_uiContactPasses;

		/*! Room */
		Room                                         *m_pkRoom;

		/*! Gravity */
		Vector3d                                      m_kGravity;

		/*! Managed rigidbodies */
		std::vector< RigidBody* >                     m_vpkBodies;

		/*! Contact DAG nodes for each managed rigidbody */
		std::vector< ContactNode* >                   m_vpkBodyNodes;

		/*! Joints */
		std::vector< Joint* >                         m_vpkJoints;

		/*! Contact set */
		ContactSet                                   *m_pkContactSet;
	
		/*! Flag store of active state */
		bool                                         *m_pbIsActive;

		/*! Contact graph nodes */
		ContactNode                                 **m_ppkContacts;

		/*! Contact graph nodes */
		ContactNode                                 **m_ppkResting;

		/*! Contact graph partition table */
		unsigned int                                 *m_puiNodePartition;

		/*! Size of arrays */
		unsigned int                                  m_uiStoreSize;


	public:


		/**
		* \param pkRoom                               Room this manager resides in
		* \param uiCollisionPasses                    Number of passes in collision resolving phase
		* \param uiContactPasses                      Number of passes in contact resolving phase
		*/
		                                              PhysicsManager( Room *pkRoom, unsigned int uiCollisionPasses = DEFAULTCOLLISIONPASSES, unsigned int uiContactPasses = DEFAULTCONTACTPASSES );

		/**
		*/
		virtual                                      ~PhysicsManager();

		/**
		* Set gravity
		* \param rkGravity                            Gravity acceleration vector
		*/
		void                                          SetGravity( const Vector3d &rkGravity );

		/**
		* Update the physics simulation
		* \param fDeltaTime                           Delta time passed since last update
		*/
		virtual void                                  Update( float fDeltaTime );

		/**
		* Add a rigidbody to the physics simulation
		* \param pkBody                               Rigidbody object
		*/
		virtual void                                  AddRigidBody( RigidBody *pkBody );

		/**
		* Remove a rigidbody from the physics simulation
		* \param pkBody                               Rigidbody object
		*/
		virtual void                                  RemoveRigidBody( RigidBody *pkBody );

		/**
		* Get all rigidbodies managed by system
		* \return                                     Vector with pointers to all managed rigidbody objects
		*/
		const std::vector< RigidBody* >              &GetRigidBodies() { return m_vpkBodies; }

		/**
		* Add a joint
		* \param pkJoint                              Joint
		*/
		virtual void                                  AddJoint( Joint *pkJoint );

		/**
		* Remove a joint
		* \param pkJoint                              Joint
		*/
		virtual void                                  RemoveJoint( Joint *pkJoint );

		void RenderDebug( ContactNode::CONTACTMODE eMode, unsigned int uiPass );
};


};


#endif
