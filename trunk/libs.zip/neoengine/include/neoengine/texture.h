/***************************************************************************
                      texture.h  -  Texture abstraction
                             -------------------
    begin                : Tue Oct 30 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, texture.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NETEXTURE_H
#define __NETEXTURE_H



/**
  * \file texture.h
  * Texture abstract class, device-dependant features in derived class in device module
  */


#ifndef __NEED_VECTOR_STRING
#  define __NEED_VECTOR_STRING
#endif

#include "base.h"
#include "pointer.h"
#include "filetype.h"
#include "pool.h"
#include "hashstring.h"
#include "module.h"
#include "logstream.h"

#include <string>


namespace NeoEngine
{


// External classes
class RenderDevice;
class FileManager;

// Forward declarations
class ImageData;
class Texture;


PoolExport( Texture );

typedef Pool< Texture > TexturePool;



/**
  * \brief Texture class
  *
  * Texture abstraction class. Device-independant texture, device-dependant
  * operations/data in derived classes
  *
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Texture : public RefCounter
{
	public:

		/**
		* \brief Texture class defines
		*/
		enum TEXTUREDEF
		{
		  INVALIDID                                   = -1,
		  FILEVERSION                                 =  1
		};

		/**
		* \brief Internal texture format identifiers
		*/
		enum TEXTUREINTERNALFORMAT
		{
		  INTERNALFORMAT_RGB888                       = 0,
		  INTERNALFORMAT_RGBA8888                     = 1,
		  INTERNALFORMAT_RGBx8888                     = 2,
		  INTERNALFORMAT_RGBA4444                     = 3,
		  INTERNALFORMAT_RGBx4444                     = 4,
		  INTERNALFORMAT_RGBA5551                     = 5,
		  INTERNALFORMAT_RGBx5551                     = 6,
		  INTERNALFORMAT_RGB565                       = 7,
		  INTERNALFORMAT_ALPHA8                       = 8,
		  INTERNALFORMAT_GRAY8                        = 9,
		  INTERNALFORMAT_GRAYALPHA88                  = 10
		};

		/**
		* \brief Texture format specifiers during loading
		*/
		enum TEXTUREFORMAT
		{
		  /*! Use file format */
		  DEFAULT                                     = -1,
		  RGB                                         = 0,
		  RGBA                                        = 1,
		  ALPHA                                       = 2,
		  GRAY                                        = 3,
		  GRAYALPHA                                   = 4
		};

		/**
		* \brief Type of texture (normal, cubemap, spheremap)
		*/
		enum TEXTURETYPE
		{
		  /*! 2D texture */
		  TEX2D                                       = 0,

		  /*! Cubemap (of six 2D textures, UploadImage expects image data object that is six images aligned in vertical order, i.e height = width * 6) */
		  CUBEMAP                                     = 1
		};

		/**
		* \brief Texture loading flags
		*/
		enum TEXTURELOADFLAG
		{
		  /*! No explicit flags set */
		  NOFLAGS                                     = 0,

		  /*! Prevent generating mipmaps */
		  NOMIPMAPS                                   = 1
		};

		/**
		* \brief Cube map face identifiers
		*/
		enum TEXTURECUBEMAPFACE
		{
		  /*! Right face (+X) */
		  CUBEFACE_RIGHT                              = 0,

		  /*! Left face (-X) */
		  CUBEFACE_LEFT                               = 1,

		  /*! Up face (+Y) */
		  CUBEFACE_UP                                 = 2,

		  /*! Down face (-Y) */
		  CUBEFACE_DOWN                               = 3,

		  /*! Back face (-Z) */
		  CUBEFACE_BACK                               = 4,

		  /*! Front face (+Z) */
		  CUBEFACE_FRONT                              = 5
		};

		/**
		* \brief Texture filtering modes, primitive and combined
		*/
		enum TEXTUREFILTERMODE
		{
		  /*! Nearest */
		  NEAREST                                     = 1,

		  /*! Linear */
		  LINEAR                                      = 2,

		  /*! No filtering (min:nearest, max:nearest, mip:nearest) */
		  NOFILTERING                                 = ( NEAREST | ( NEAREST << 8 ) | ( NEAREST << 16 ) ),

		  /*! Bilinear filtering (min:linear, max:linear, mip:nearest) */
		  BILINEAR                                    = ( LINEAR  | ( LINEAR  << 8 ) | ( NEAREST << 16 ) ),

		  /*! Trilinear filtering (min:linear, max:linear, mip:linear) */
		  TRILINEAR                                   = ( LINEAR  | ( LINEAR  << 8 ) | ( LINEAR  << 16 ) ),
		};


	protected:

		/*! Name */
		HashString                                    m_strName;

		/*! ID */
		int                                           m_iID;

		/*! Dimensions of texture as integers */
		int                                           m_iWidth, m_iHeight;

		/*! Dimensions of texture as floats */
		float                                         m_fWidth, m_fHeight, m_fOriginalWidth, m_fOriginalHeight;

		/*! Ratio */
		float                                         m_fRatio;

		/*! Texture type */
		TEXTURETYPE                                   m_eType;

		/*! Texture format */
		TEXTUREFORMAT                                 m_eFormat;

		/*! Internal texture format */
		int                                           m_iInternalFormat;

		/*! Texture pool */
		TexturePool                                  *m_pkPool;

		/*! Filtering modes */
		unsigned int                                  m_uiFiltering;

        /*! Max anisotropy */
		unsigned int                                  m_uiMaxAnisotropy;

	public:

		/**
		* Create an empty texture object
		*/
		                                              Texture( const std::string &rstrName, TexturePool *pkTexturePool );

		/**
		* Delete texture object, deallocate associated memory
		*/
		virtual                                      ~Texture();

		/**
		* \return                                     Texture ID
		*/
		inline int                                    GetID() const { return m_iID; }

		/**
		* \return                                     Texture type
		*/
		inline TEXTURETYPE                            GetType() const { return m_eType; }

		/**
		* Query if texture is valid
		* \return                                     true if valid, false if not
		*/
		inline bool                                   IsValid() const { return( m_iID != INVALIDID ); }

		/**
		* Check if texture has alpha channel
		* \return                                     true if texture has alpha channel, false if not
		*/
		inline bool                                   HasAlpha() const { return( ( m_eFormat == RGBA ) || ( m_eFormat == ALPHA ) ); }

		/**
		* \return                                     Width of texture (float)
		*/
		inline float                                  GetWidth() const { return( IsValid() ? m_fWidth : 0.0f ); }

		/**
		* \return                                     Height of texture (float)
		*/
		inline float                                  GetHeight() const { return( IsValid() ? m_fHeight : 0.0f ); }

		/**
		* \return                                     Original width of texture (float)
		*/
		inline float                                  GetOriginalWidth() const { return( IsValid() ? m_fOriginalWidth : 0.0f ); }

		/**
		* \return                                     Original height of texture (float)
		*/
		inline float                                  GetOriginalHeight() const { return( IsValid() ? m_fOriginalHeight : 0.0f ); }


		/**
		* \param rstrName                             New texture name
		*/
		void                                          SetName( const std::string &rstrName );

		/**
		* \return                                     Texture name
		*/
		inline const HashString                      &GetName() const { return m_strName; }

		/**
		* \return                                     Texture format
		*/
		inline TEXTUREFORMAT                          GetFormat() const { return m_eFormat; }

		/**
		* \return                                     Filtering mode
		*/
		inline unsigned int                           GetFiltering() const { return m_uiFiltering; }

		/**
		* \return                                     Max anisotropy
		*/
		inline unsigned int                           GetMaxAnisotropy() const { return m_uiMaxAnisotropy; }

		/**
		* Upload image data
		* \param pkImageData                          Image data
		* \param eType                                Texture type (2D, cubemap, ...)
		* \param eFormat                              Requested format, -1 for default
		* \param uiFlags                              Texture load flags
		* \param uiFiltering                          Filtering modes, 0 for default
		* \param uiMaxAnisotropy                      Max anisotropy
		* \return                                     true if successful, false otherwise
		*/
		virtual bool                                  UploadImage( ImageData *pkImageData, TEXTURETYPE eType = TEX2D, TEXTUREFORMAT eFormat = DEFAULT, unsigned int uiFlags = 0, unsigned int uiFiltering = 0, unsigned int uiMaxAnisotropy = 1 ) = 0;

		/**
		* Generate a normalization cubemap
		* \param iSize                                Side length in cube (texture resolution)
		* \return                                     true if successful, false otherwise
		*/
		bool                                          GenerateNormalizationCubeMap( int iSize = 256 );

		/**
		* Generate a exponent lookup map. The texture gives the value of u ^ ( ( iMax - iMin ) * v + iMin ), useful for specular caluclations (n dot h)^k
		* \param iWidth                               Width of texture (resolution of "n dot h" lookup)
		* \param iHeight                              Height of texture (resolution of k lookup)
		* \param iMin                                 Minimum exponent
		* \param iMax                                 Maximum exponent
		* \return                                     true if successful, false otherwise
		*/
		bool                                          GenerateNHKMap( int iWidth = 256, int iHeight = 32, int iMin = 0, int iMax = 32 );

		/**
		* Generate a 1D falloff map (linear if k == 1). The texture gives the value of ( 1 - u )^k
		* \param iSize                                Length of texture (resultion of lookup)
		* \param fExp                                 Exponent (1 for linear falloff)
		* \return                                     true if successful, false otherwise
		*/
		bool                                          GenerateFalloffMap( int iSize = 256, float fExp = 1.0f );

		/**
		* Build filtering mode from primitives
		* \param eMinFilter                           Minification filter mode
		* \param eMagFilter                           Magnification filter mode
		* \param eMipFilter                           Mipmap filter mode
		*/
		static inline unsigned int                    BuildFilter( TEXTUREFILTERMODE eMinFilter, TEXTUREFILTERMODE eMagFilter, TEXTUREFILTERMODE eMipFilter ) { return( eMinFilter | ( eMagFilter << 8 ) | ( eMipFilter << 16 ) ); }

		/**
		* Set max anisotropy when anisotropic filtering is enabled
		* \param uiMaxAnisotropy                      Max anisotropy
		*/
		inline void                                   SetMaxAnisotropy( unsigned int uiMaxAnisotropy ) { m_uiMaxAnisotropy = uiMaxAnisotropy; }

		/**
		* Compare texture IDs
		* \param rkTexture                            Texture to compare with
		* \return                                     true if our id is less than pkTexture
		*/
		inline bool                                   operator < ( const Texture &rkTexture ) const { return( m_iID < rkTexture.GetID() ); }

		/**
		* Compare two textures
		* \param rkTexture                            Texture
		* \return                                     true if equal (name and format), false if not
		*/
		inline bool                                   operator == ( const Texture &rkTexture ) const { return( ( m_eType == rkTexture.GetType() ) && ( m_eFormat == rkTexture.GetFormat() ) && ( m_strName == rkTexture.GetName() ) ); }
};


//Make a smart pointer typedef
SmartPointer(Texture);


#ifdef WIN32
#  ifndef __HAVE_VECTOR_NETEXTURE
     UDTVectorEXPIMP( class Texture* );
#    define __HAVE_VECTOR_NETEXTURE
#  endif
#endif


/**
  * \brief Raw image data with optional mipmaps
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ImageData
{
	public:

		/*! Width of image */
		int                                           m_iWidth;

		/*! Height of image */
		int                                           m_iHeight;

		/*! Format of data */
		Texture::TEXTUREFORMAT                        m_eFormat;

		/*! Color channels */
		int                                           m_iChannels;

		/*! Bits per pixel */
		int                                           m_iBPP;

		/*! Ptr to data */
		unsigned char                                *m_pucData;

		/*! Image codec that created the image */
		class ImageCodec                             *m_pkCodec;

		/*! Number of mipmaps */
		int                                           m_iMipMaps;
		
		/*! Mipmaps */
		ImageData                                    *m_pkMipMaps;
		
		
		/**
		* Clear data
		*/
		                                              ImageData() : m_iWidth(0), m_iHeight(0), m_eFormat( Texture::RGB ), m_pucData(0), m_pkCodec(0), m_iMipMaps(0), m_pkMipMaps(0) {}

		/**
		* Deallocate memory
		*/
		virtual                                      ~ImageData();

		/**
		* Create mipmaps
		*/
		virtual void                                  CreateMipMaps();

		/**
		* Scale image
		* \param iComp                                Components per pixel
		* \param iInWidth                             Current width
		* \param iInHeight                            Current height
		* \param pucInData                            Image to scale
		* \param iOutWidth                            Requested width
		* \param iOutHeight                           Requested height
		* \param pucOutData                           Pointer to memory for new scaled image
		*/
		static bool                                   ScaleImage( int iComp, int iInWidth, int iInHeight, const unsigned char *pucInData, int iOutWidth, int iOutHeight, unsigned char *pucOutData );
};


/**
  * \brief Loads image file data
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ImageCodec : public FiletypeIdentifier
{
	friend class TextureLoader;

	protected:

		/*! Library module */
		ModulePtr                                     m_pkModule;

    
	public:
		
		/**
		* \param rstrFiletypeName                     File type name
		* \param rvstrExtensions                      File type extensions
		*/
		                                              ImageCodec( const std::string &rstrFiletypeName, const std::vector<std::string> &rvstrExtensions );

		/**
		*/
		virtual                                      ~ImageCodec();

		/**
		* Loads data from file
		* \param pkFile                               File
		* \return                                     Ptr to new ImageData object
		*/
		virtual ImageData                            *LoadImage( File *pkFile ) = 0;

		/**
		* Free image data
		* \param pkImageData                          Image data object to free (obj returned by previous call to LoadImage())
		*/
		virtual void                                  FreeImage( ImageData *pkImageData ) = 0;

		/**
		* Writes image data to a file
		* \param pkImage                              Image data to write
		* \param pkFile                               File to to write image to
		*/
		virtual bool                                  WriteImage( ImageData *pkImageData, File *pkFile ) = 0;
};


#ifdef WIN32
#  ifndef __HAVE_VECTOR_NEIMAGECODEC
     UDTVectorEXPIMP( class ImageCodec* );
#    define __HAVE_VECTOR_NEIMAGECODEC
#  endif
#endif


/**
  * \class TextureLoader
  * \brief Base loader for textures
  * Loads texture files and returns raw data for device to process
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API TextureLoader
{
	protected:

		/*! Loaders */
		std::vector< ImageCodec* >                    m_vpkCodecs;

		/*! File manager */
		FileManager                                  *m_pkFileManager;


	public:

		/**
		* \param pkFileManager                        File manager, will use core global object if null (default)
		*/
		                                              TextureLoader( FileManager *pkFileManager = 0 );

		/**
		*/
		virtual                                      ~TextureLoader();

		/**
		* Register new image file type loader (codec)
		* \param rstrName                             Codec name
		* \return                                     true if successful, false otherwise
		*/
		bool                                          LoadImageCodec( const std::string &rstrName );
		
		/**
		* Load texture raw data
		* \param pkFile                               File to load
		* \return                                     Ptr to new ImageData object for device to process
		*/
		ImageData                                    *LoadImageData( File *pkFile );

		/**
		* Load image data
		* \param rstrFilename                         Filename of image to load
		* \return                                     Pointer to new ImageData object
		*/
		ImageData                                    *LoadImageData( const std::string &rstrFilename );
		
		/**
		* Free texture raw data
		* \param pkImageData                          Image data to free, must be ptr returned by LoadImageData
		*/
		void                                          FreeImageData( ImageData *pkImageData );
};


};


#endif // __NETEXTURE_H

