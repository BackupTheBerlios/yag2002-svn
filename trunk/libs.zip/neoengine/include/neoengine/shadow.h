/***************************************************************************
                      shadow.h  -  Shadow generator base
                             -------------------
    begin                : Wed Apr 30 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, shadow.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NESHADOW_H
#define __NESHADOW_H


/**
  * \file shadow.h
  * Shadow generator base
  */



#include "base.h"
#include "renderprimitive.h"
#include "vertex.h"
#include "polygon.h"
#include "callback.h"
#include "shader.h"
#include "nemath.h"
#include "activator.h"

#include <vector>

namespace NeoEngine
{


/*! External classes */
class BoundingVolume;





/**
  * \class ShadowGenerator
  * \brief Shadow generator
  * A shadow generator processes input geometry and generates
  * a shadow. Implementations can range from simple projected blobs to 
  * render-to-texture projected shadow textures and stencil buffer shadows.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ShadowGenerator : public virtual Activator
{
	public:

		/**
		*/
		                                              ShadowGenerator() : Activator() {}

		/**
		*/
		virtual                                      ~ShadowGenerator() {}

		/**
		* Generate shadow
		* \param pkVertexBuffer                       Vertex buffer for input geometry
		* \param pkPolygonBuffer                      Polygon buffer for input geometry
		* \param pkBoundingVolume                     Bounding volume for input geometry
		* \param rkTransform                          Transformation matrix
		* \param rkInvTransform                       Inverse transformation matrix
		*/
		virtual void                                  GenerateShadow( VertexBufferPtr &pkVertexBuffer, PolygonBufferPtr &pkPolygonBuffer, BoundingVolume *pkBoundingVolume, const Matrix &rkTransform, const Matrix &rkInvTransform ) = 0;
};





/**
  * \class ShadowOp
  * \brief Shadow primitive operation
  * Storage object for shadow primitive operations, used by render callback
  * for each active light object in the scene.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ShadowOp
{
	public:

		/*! Vertex buffer */
		VertexBufferPtr                             m_pkVertexBuffer;

		/*! Polygon buffer */
		PolygonBufferPtr                            m_pkPolygonBuffer;

		/*! Bounding volume */
		BoundingVolume                             *m_pkBoundingVolume;

		/*! Transformation matrix */
		Matrix                                      m_kTransform;

		/*! Inverse transformation matrix */
		Matrix                                      m_kInvTransform;

		/* Final render op */
		RenderPrimitive                             m_kPrimitive;
};



#ifdef WIN32

#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif

#  ifndef __HAVE_VECTOR_NESHADOWOP
     UDTVectorEXPIMP( class ShadowOp* );
#    define __HAVE_VECTOR_NESHADOWOP
#  endif

#endif




/**
  * \class StencilShadowGenerator
  * \brief Shadow generator using stencil buffer
  * Generates self-shadowing dynamic shadows using the stencil buffer
  * (support for stencil buffer must be present in render device)
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API StencilShadowGenerator : public ShadowGenerator, public FrameCallback
{
	protected:

		/*! Shadow primitive ops */
		std::vector< ShadowOp* >                      m_vpkOps;

		/*! Number of used ops */
		unsigned int                                  m_uiNumUsedOps;

		/*! Shadow length */
		float                                         m_fShadowLength;

		/*! Temporary buffer for vertices */
		Vertex                                       *m_pkVertices;

		/*! Temporary buffer for polygons */
		Polygon                                      *m_pkPolygons;

		/*! Number of maximum vertices in temporary buffer */
		unsigned int                                  m_uiMaxVertices;

		/*! Number of maximum polygons in temporary buffer */
		unsigned int                                  m_uiMaxPolygons;

		/*! Material during stencil buffer rendering */
		MaterialPtr                                   m_pkStencilMat;

		/*! Material during frame buffer rendering */
		MaterialPtr                                   m_pkFrameBufferMat;


	public:

		/**
		* Check that device supports stencil shadows, if so register as frame listener
		* \param fShadowLength                        Length of shadow volume
		*/
		                                              StencilShadowGenerator( float fShadowLength = 100.0f );

		/**
		* Deregister as frame listener
		*/
		virtual                                      ~StencilShadowGenerator();

		/**
		* Generate shadow
		* \param pkVertexBuffer                       Vertex buffer for input geometry
		* \param pkPolygonBuffer                      Polygon buffer for input geometry
		* \param pkBoundingVolume                     Bounding volume for input geometry
		* \param rkTransform                          Transformation matrix
		* \param rkInvTransform                       Inverse transformation matrix
		*/
		virtual void                                  GenerateShadow( VertexBufferPtr &pkVertexBuffer, PolygonBufferPtr &pkPolygonBuffer, BoundingVolume *pkBoundingVolume, const Matrix &rkTransform, const Matrix &rkInvTransform );

		/**
		* Frame callback, render shadow volume
		* \param eType                                Callback type
		* \param pData                                Data pointer (type specific)
		*/
		virtual void                                  FrameEvent( FrameCallback::FRAMECALLBACKTYPE eType, void *pData );
};



//Disabled
#if 0


/**
  * \brief Shadow generator using stencil buffer and programmable pipeline
  * Generates self-shadowing dynamic shadows using the stencil buffer
  * (support for stencil buffer must be present in render device)
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API VertexShaderStencilShadowGenerator : public ShadowGenerator, public FrameCallback
{
	protected:

		/*! Shadow primitive ops */
		std::vector< ShadowOp* >                      m_vpkOps;

		/*! Number of used ops */
		unsigned int                                  m_uiNumUsedOps;

		/*! Shadow length */
		float                                         m_fShadowLength;

		/*! Material during stencil buffer rendering */
		MaterialPtr                                   m_pkStencilMat;

		/*! Material during frame buffer rendering */
		MaterialPtr                                   m_pkFrameBufferMat;

		/*! Vertex shader for positional lights */
		Shader                                        *m_pkVertexShaderPos;

		/*! Light position parameter */
		ShaderParam                                   *m_pkLightParamPos;

		/*! Extrude length parameter */
		ShaderParam                                   *m_pkExtrudeParamPos;

		/*! Modelviewprojection matrix parameter */
		ShaderParam                                   *m_pkTransformParamPos;

		/*! Inverse model matrix parameter */
		ShaderParam                                   *m_pkInvTransformParamPos;

		/*! Vertex shader for directional lights */
		Shader                                        *m_pkVertexShaderDir;

		/*! Light position parameter */
		ShaderParam                                   *m_pkLightParamDir;

		/*! Extrude length parameter */
		ShaderParam                                   *m_pkExtrudeParamDir;

		/*! Modelviewprojection matrix parameter */
		ShaderParam                                   *m_pkTransformParamDir;

		/*! Inverse model matrix parameter */
		ShaderParam                                   *m_pkInvTransformParamDir;


	public:

		/**
		* Check that device supports stencil shadows, if so register as frame listener
		* \param fShadowLength                        Length of shadow volume
		* \param fOffset                              Offset of volume from mesh
		*/
		                                              VertexShaderStencilShadowGenerator( float fShadowLength = 100.0f, float fOffset = 0.0f );

		/**
		* Deregister as frame listener
		*/
		virtual                                      ~VertexShaderStencilShadowGenerator();

		/**
		* Generate shadow
		* \param pkVertexBuffer                       Vertex buffer for input geometry
		* \param pkPolygonBuffer                      Polygon buffer for input geometry
		* \param pkBoundingVolume                     Bounding volume for input geometry
		* \param rkTransform                          Transformation matrix
		* \param rkInvTransform                       Inverse transformation matrix
		*/
		virtual void                                  GenerateShadow( VertexBufferPtr &pkVertexBuffer, PolygonBufferPtr &pkPolygonBuffer, BoundingVolume *pkBoundingVolume, const Matrix &rkTransform, const Matrix &rkInvTransform );

		/**
		* Frame callback, render shadow volume
		* \param eType                                Callback type
		* \param pData                                Data pointer (type specific)
		*/
		virtual void                                  FrameEvent( FrameCallback::FRAMECALLBACKTYPE eType, void *pData );
};

#endif


};


#endif
