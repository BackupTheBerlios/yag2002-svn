/***************************************************************************
                 contact.h  -  Collision detection contact data
                             -------------------
    begin                : Wed Feb 26 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, colldata.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NECONTACT_H
#define __NECONTACT_H

#include "base.h"
#include "nemath.h"
#include "material.h"
#include "scenenode.h"

#include <vector>


/**
  * \file contact.h
  * Collision detection contact data
  */


namespace NeoEngine
{


#ifdef WIN32
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif
#  ifndef __HAVE_VECTOR_NECONTACTDATA
     UDTVectorEXPIMP( class Contact* );
#    define __HAVE_VECTOR_NECONTACTDATA
#  endif
#endif


/**
  * \brief Collision detection contact data
  * Used for returning collision detection contact results
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Contact
{
	public:

		/*! Contact points, sorted in descending depth (deepest first) */
		Vector3d                                      m_pkPoints[8];

		/*! Penetration depths for each point */
		float                                         m_pfDepths[8];

		/*! Number of points */
		unsigned int                                  m_uiNumPoints;

		/*! Normal of colliding area/line/point */
		Vector3d                                      m_kNormal;

		/*! Materials of the contacting surfaces. If either is null, no material associated with that colliding primitive */
		MaterialPtr                                   m_apkMaterials[2];

		/*! Scene node collided with. This is invalid for static geometry! */
		SceneNode                                    *m_pkSceneNode;

		/**
		* Reset data
		*/
		inline                                        Contact() : m_uiNumPoints( 0 ), m_pkSceneNode( 0 ) {}

		/**
		* Sort points according to depth, deepest first
		*/
		inline void                                   Sort()
		{
			if( m_uiNumPoints <= 1 )
				return;

			Vector3d kTemp;
			float fTemp;

			//Simple bubblesorter for now
			for( unsigned int uiPass = 0; uiPass < ( m_uiNumPoints - 1 ); ++uiPass )
			{
				for( unsigned int uiPoint = 0; uiPoint < ( m_uiNumPoints - ( uiPass + 1 ) ); ++uiPoint )
				{
					if( m_pfDepths[uiPoint+1] > m_pfDepths[uiPoint] )
					{
						//Swap
						kTemp = m_pkPoints[uiPoint];
						fTemp = m_pfDepths[uiPoint];

						m_pkPoints[uiPoint]   = m_pkPoints[uiPoint+1];
						m_pfDepths[uiPoint]   = m_pfDepths[uiPoint+1];
						m_pkPoints[uiPoint+1] = kTemp;
						m_pfDepths[uiPoint+1] = fTemp;
					}
				}
			}
		}
};


/**
  * \brief Data defining a set of collision detection contact data
  * Used for collision detection
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ContactSet
{
	public:

		/*! Contacts, sorted in descending depth of deepest contact point for each contact */
		std::vector< Contact* >                       m_vpkContacts;



		/**
		*/
		                                              ContactSet() {}

		/**
		* Clear any contact data stored
		*/
		virtual                                      ~ContactSet();

		/**
		* Add new contact data
		* \param pkData                               Contact data
		*/
		void                                          Add( Contact *pkData );

		/**
		* Clear all collision data
		*/
		void                                          Clear();
};


};


#endif
