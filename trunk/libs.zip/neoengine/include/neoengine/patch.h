/***************************************************************************
                          patch.h  -  Patch surfaces
                             -------------------
    begin                : Thu May 2 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, patch.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEPATCH_H
#define __NEPATCH_H



/**
  * \file patch.h
  * Bezier patches
  */


#include "base.h"
#include "nemath.h"
#include "submesh.h"
#include "vertex.h"
#include "polygon.h"

#include <string>


namespace NeoEngine
{


//Forward declarations
class PatchSurfaceTesselator;







/**
  * \class PatchSurfaceData
  * \brief Data defining a patch object (for example a bezier patch)
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API PatchSurfaceData
{
	public:

		/**
		* \enum PATCHSURFACETYPE
		* \brief Supported patch surface types
		*/
		enum PATCHSURFACETYPE
		{
		  BEZIER                              = 0x00000001
		};

		/**
		* \enum PATCHSURFACEVISIBLE
		* \brief Visibility flags (back, front or both)
		*/
		enum PATCHSURFACEVISIBLE
		{
		  VISIBLE_FRONT                       = 0x00000001,
		  VISIBLE_BACK                        = 0x00000002,
		  VISIBLE_BOTH                        = 0x00000003
		};


	public:

		/*! Patch type. Must be PATCHSURFACETYPE_BEZIER */
		PATCHSURFACETYPE                    m_ePatchType;

		/*! Which side is visible */
		PATCHSURFACEVISIBLE                 m_eVisibleSide;

		/*! Control points */
		VertexBufferPtr                     m_pkControlPoints;

		/*! Control point width */
		int                                 m_iControlWidth;

		/*! Control point height */
		int                                 m_iControlHeight;

		/*! Subdivision level in u direction */
		int                                 m_iULevel;

		/*! Subdivision level in v direction */
		int                                 m_iVLevel;

		/*! Tesselated width (number of vertices in u direction) */
		int                                 m_iTessWidth;

		/*! Tesselated height (number of vertices in v direction) */
		int                                 m_iTessHeight;



		/**
		* Initialize data
		*/
		                                    PatchSurfaceData();

		/**
		* Deallocate memory
		*/
		virtual                            ~PatchSurfaceData();

		/**
		* Copy values from patch surface object
		* \param rkPatchData                Patch data source object
		* \return                           const ref patch data object (this)
		*/
		const PatchSurfaceData             &operator =( const PatchSurfaceData &rkPatchData );
};





/**
  * \class PatchSurfaceSubMesh
  * \brief Derived shard created from a patch surface
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API PatchSurfaceSubMesh : public SubMesh
{
    friend class PatchSurfaceTesselator;
    friend class QuadraticBezierPatchTesselator;
	
	protected:

		/*! Patch control data */
		PatchSurfaceData                  m_kPatchData;

		/*! Tesselator object */
		PatchSurfaceTesselator           *m_pkTesselator;

		/**
		* Update data
		*/
		virtual void                        UpdateData();



	public:

		/**
		* \param rkPatchData                Patch surface data
		*/
		                                    PatchSurfaceSubMesh( const PatchSurfaceData &rkPatchData );

		/**
		* \param rkSubMesh                  Patch surface submesh reference object to copy data from
		*/
		                                    PatchSurfaceSubMesh( const PatchSurfaceSubMesh &rkSubMesh );

		/**
		*/
		virtual                            ~PatchSurfaceSubMesh();

		/**
		* \return                           Ptr to vertex buffer with control lattice points
		*/
		virtual VertexBufferPtr             GetControlVertexBuffer() { return m_kPatchData.m_pkControlPoints; }

		/**
		* \return                           Data object
		*/
		const virtual PatchSurfaceData     &GetPatchData() const { return m_kPatchData; }

		/**
		* Ignored for patch surface submeshes
		* \param pkVertices                 New vertex buffer
		*/
		virtual void                        SetVertexBuffer( VertexBufferPtr pkVertices ) {}

		/**
		* Ignored for patch surface submeshes
		* \param pkPolygons                 New polygon buffer
		*/
		virtual void                        SetPolygonBuffer( PolygonBufferPtr pkPolygons ) {}

		/**
		* \return                           new submesh that is duplicate of this
		*/
		virtual SubMesh                    *Duplicate() const;

		/**
		* \return                           Sub mesh type
		*/
		virtual unsigned int                GetType() const { return PATCHSURFACE; }
};




/**
  * \class PatchSurfaceTesselator
  * \brief Tesselator for patch surfaces
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API PatchSurfaceTesselator
{
	public:

		/**
		*/
		                                    PatchSurfaceTesselator();

		/**
		*/
		virtual                            ~PatchSurfaceTesselator();

		/**
		* Set subdivision level for patch data
		* \param pkPatchData                Patch data
		* \param iULevel                    Force U level subdivision
		* \param iVLevel                    Force V level subdivision
		*/
		void                                SetSubdivisionLevel( PatchSurfaceData *pkPatchData, int iULevel = -1, int iVLevel = -1 );

		/**
		* Tesselate patch
		* \param pkPatchData                Patch data
		* \param pkShard                    Shard recieving data
		*/
		virtual void                        Tesselate( PatchSurfaceData *pkPatchData, PatchSurfaceSubMesh *pkShard );

		/**
		* Helper method during tesselation for vertices
		* \param pkPatchData                Patch data
		* \param pkVertexBuffer             Vertex buffer recieving data
		*/
		virtual void                        InterpolateVertices( PatchSurfaceData *pkPatchData, VertexBufferPtr pkVertexBuffer );
};





/**
  * \class QuadraticBezierPatchTesselator
  * \brief Specialized tesselator for quadratic bezier patch surfaces
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API QuadraticBezierPatchTesselator : public PatchSurfaceTesselator
{
	public:

		/**
		*/
		                                    QuadraticBezierPatchTesselator();

		/**
		*/
		virtual                            ~QuadraticBezierPatchTesselator();

		/**
		* Helper method during tesselation for vertices
		* \param pkPatchData                Patch data
		* \param pkVertexBuffer             Vertex buffer recieving data
		*/
		virtual void                        InterpolateVertices( PatchSurfaceData *pkPatchData, VertexBufferPtr pkVertexBuffer );
};


}; // namespace NeoEngine



#endif // __NEPATCH_H
