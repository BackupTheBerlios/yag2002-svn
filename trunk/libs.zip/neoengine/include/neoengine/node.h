/***************************************************************************
                   node.h  -  Base node class with SRT data
                             -------------------
    begin                : Tue Oct 30 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, node.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NENODE_H
#define __NENODE_H


/**
  * \file neoengine/node.h
  * Base node class local SRT data
  */



#include "base.h"
#include "nemath.h"

#include <vector>


namespace NeoEngine
{

#ifdef WIN32
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif
#  ifndef __HAVE_VECTOR_NESRTNODE
     UDTVectorEXPIMP( class SRTNode* );
#    define __HAVE_VECTOR_NESRTNODE
#  endif
#endif


/**
  * \brief Base class for hierarchy objects
  * A SRT node contains data for scaling, rotation and translation, and
  * core methods for modification and queries. Derived classes
  * can implement hierarchies by overloading the SetScaling, SetRotation
  * and SetTranslation methods and calculate world cache data.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SRTNode
{
	protected:

		/*! Uniform scaling factor (must be >0, default 1) */
		float                                         m_fScaling;

		/*! Rotation */
		Quaternion                                    m_kRotation;

		/*! Translation */
		Vector3d                                      m_kTranslation;


	public:


		/**
		*/
		                                              SRTNode() : m_fScaling( 1.0f ) {}

		/**
		* \param fScaling                             Scaling
		* \param rkRotation                           Rotation
		* \param rkTranslation                        Translation
		*/
		                                              SRTNode( float fScaling, const Quaternion &rkRotation, const Vector3d &rkTranslation ) : m_fScaling( 1.0f ), m_kRotation( rkRotation ), m_kTranslation( rkTranslation ) {}

		/**
		* \param rkNode                               Reference node objec to copy data from
		*/
		                                              SRTNode( const SRTNode &rkNode ) : m_fScaling( rkNode.m_fScaling ), m_kRotation( rkNode.m_kRotation ), m_kTranslation( rkNode.m_kTranslation ) {}

		/**
		* \return                                     Translation of this node
		*/
		inline const Vector3d                        &GetTranslation() const { return m_kTranslation; }

		/**
		* \return                                     Rotation of this node
		*/
		inline const Quaternion                      &GetRotation() const { return m_kRotation; }

		/**
		* \return                                     Uniform scaling factor
		*/
		inline float                                  GetScaling() const { return m_fScaling; }

		/**
		* Translate node from current position, in <b>local</b> (along current rotated axes) coordinate system.
		* Will call SetTranslation() for setting new translation of node, derived classes do not need to overload 
		* this method directly. Not affected by current scaling.
		* \param rkTranslation                        Translation offset vector
		* \param bNotifyUpdate                        Used by derived classes to indicate if to set update flag to child tree (true default, use false with caution)
		*/
		inline void                                   Translate( const Vector3d &rkTranslation, bool bNotifyUpdate = true ) { SetTranslation( m_kTranslation + ( m_kRotation * rkTranslation ), bNotifyUpdate ); }

		/**
 		* Translate node from current position, in <b>world</b> (along unrotated axes) coordinate system.
		* Will call SetTranslation() for setting new translation of node, derived classes do not need to overload 
		* this method directly. Not affected by current scaling.
		* \param rkTranslation                        Translation offset vector
		* \param bNotifyUpdate                        Used by derived classes to indicate if to set update flag to child tree (true default, use false with caution)
		*/
		inline void                                   TranslateWorld( const Vector3d &rkTranslation, bool bNotifyUpdate = true ) { SetTranslation( rkTranslation + m_kTranslation, bNotifyUpdate ); }

		/**
		* Rotate node in <b>local</b> (current rotation) coordinate system. Will call SetRotation()
		* for setting new rotation of node, derived classes do not need to overload this method
		* directly. Not affected by current scaling.
		* \param rkRotation                           Rotation quaternion
		* \param bNotifyUpdate                        Used by derived classes to indicate if to set update flag to child tree (true default, use false with caution)
		*/
		inline void                                   Rotate( const Quaternion &rkRotation, bool bNotifyUpdate = true ) { SetRotation( m_kRotation * rkRotation, bNotifyUpdate ); }

		/**
		* Rotate node in <b>world</b> (unrotated) coordinate system. Will call SetRotation()
		* for setting new rotation of node, derived classes do not need to overload this method
		* directly. Not affected by current scaling.
		* \param rkRotation                           Rotation quaternion
		* \param bNotifyUpdate                        Used by derived classes to indicate if to set update flag to child tree (true default, use false with caution)
		*/
		inline void                                   RotateWorld( const Quaternion &rkRotation, bool bNotifyUpdate = true ) { SetRotation( rkRotation * m_kRotation, bNotifyUpdate ); }

		/**
		* Scale node by uniform factor. Will use SetScaling for setting new scaling of node,
		* derived classes do not need to overload this method directly. Must be >0, where a
		* value of 1.0f indicates no scaling
		* \param fScaling                             Uniform scaling factor
		* \param bNotifyUpdate                        Used by derived classes to indicate if to set update flag to child tree (true default, use false with caution)
		*/
		inline void                                   Scale( float fScaling, bool bNotifyUpdate = true ) { SetScaling( m_fScaling * fScaling, bNotifyUpdate ); }

		/**
		* Set translation for node. Derived classes used in hierarchy trees
		* can overload this method and implement caching of world data, or
		* use flag to indicate update needed later.
		* \param rkTranslation                        New translation for node
		* \param bNotifyUpdate                        Used by derived classes to indicate if to set update flag to child tree
		*/
		inline virtual void                           SetTranslation( const Vector3d &rkTranslation, bool bNotifyUpdate = true ) { m_kTranslation = rkTranslation; }

		/**
		* Set rotation for node. Derived classes used in hierarchy trees
		* can overload this method and implement caching of world data, or
		* use flag to indicate update needed later.
		* \param rkRotation                           New rotation for node
		* \param bNotifyUpdate                        Used by derived classes to indicate if to set update flag to child tree (true default, use false with caution)
		*/
		inline virtual void                           SetRotation( const Quaternion &rkRotation, bool bNotifyUpdate = true ) { m_kRotation = rkRotation; }

		/**
		* Set uniform scaling for node. Derived classes used in hierarchy trees
		* can overload this method and implement caching of world data, or
		* use flag to indicate update needed later. A value of 1.0f indicates no scaling.
		* \param fScaling                             New uniform scaling factor
		* \param bNotifyUpdate                        Used by derived classes to indicate if to set update flag to child tree (true default, use false with caution)
		*/
		inline virtual void                           SetScaling( float fScaling, bool bNotifyUpdate = true ) { m_fScaling = fScaling; }
};


};


#endif
