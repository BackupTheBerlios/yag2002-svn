/***************************************************************************
           module.h  -  Wrapper for loading dynamic library modules
                             -------------------
    begin                : Mon Oct 14 2002
    copyright            : (C) 2002 by Cody Russell
    email                : cody [at] jhu.edu
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, module.h

 The Initial Developer of the Original Code is Cody Russell.
 Portions created by Cody Russell are Copyright (C) 2002
 Cody Russell. All Rights Reserved.

 Contributors: Mattias Jansson (mattias@realityrift.com)

 ***************************************************************************/

#ifndef __NEMODULE_H
#define __NEMODULE_H

#ifndef __NEED_VECTOR_STRING
#  define __NEED_VECTOR_STRING
#endif

#include "base.h"
#include "hashtable.h"
#include "pointer.h"

#include <string>
#include <vector>



/**
  * \file module.h
  * Loadable module interface
  */

namespace NeoEngine
{


#if defined( WIN32 )

typedef void *ModLib;
typedef void *ModSymbol;

#elif defined( __APPLE__ )

typedef void* ModLib;
typedef void* ModSymbol;

#elif defined( POSIX )

typedef void* ModLib;
typedef void* ModSymbol;

#else
#  error "Feature Module unimplemented on this platform"
#endif


HashTableExport( Module );


//Forward declarations
class ModuleManager;


/**
  * \brief Loadable module object
  * A module is an abstraction of a loadable library
  * Abstracts all platform-specific issues and allows easy query for symbols
  * available in the loaded module.
  * \author Cody Russell (cody [at] jhu.edu)
  */
class NEOENGINE_API Module : public RefCounter
{
	friend class ModuleManager;

	protected:

		/*! Module manager */
		ModuleManager                                 *m_pkManager;

		/*! Module name */
		HashString                                     m_strName;


	public:

		/**
		* Initialize module
		* \param rstrName                              Library name
		* \param pkManager                             Module manager object
		*/
		                                               Module( const HashString &rstrName, ModuleManager *pkManager );

		/**
		*/
		virtual                                       ~Module();

		/**
		* \return                                      true if module is loaded successfully, false if not (not existing or missing symbols)
		*/
		virtual bool                                   IsValid() const = 0;

		/**
		* \return                                      true if module is statically loaded, false if dynamic
		*/
		virtual bool                                   IsStatic() const = 0;

		/**
		* Query library for symbol
		* \param rstrSymbol                            Symbol name
		* \return                                      Symbol
		*/
		virtual ModSymbol                              LookupSymbol( const HashString &rstrSymbol ) = 0;

		/**
		* \return                                      Module name
		*/
		const HashString                              &GetName() const { return m_strName; }
};


#ifndef __HAVE_SMARTPOINTER_MODULE
SmartPointer( Module );
#  define __HAVE_SMARTPOINTER_MODULE
#endif


/**
  * \brief Module abstraction layer for dynamically linked modules
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ModuleDynamic : public Module
{
	private:

		/*! Full path */
		HashString                                     m_strPathName;

		/*! Lib instance */
		ModLib                                         m_Lib;

#ifdef __APPLE__

		/*! Used on Macintosh only; is this lib part of the core NeoEngine bundle? */
		bool                                           m_bIsMacBundleLib;

#endif

	public:

		/**
		* Load library
		* \param rstrName                              Library name
		* \param rstrFullPath                          Full path name
		* \param pkManager                             Module manager object
		* \param bMacBundleLib                         This is only used on Macintosh platform.  It indicates that the library is inside the NeoEngine bundle.
		*/
		                                               ModuleDynamic( const HashString &rstrName, const HashString &rstrFullPath, ModuleManager *pkManager, bool bMacBundleLib = false );

		/**
		* Free library, deregister from module manager
		*/
		virtual                                       ~ModuleDynamic();

		/**
		* \return                                      true if module is loaded successfully, false if not (not existing or missing symbols)
		*/
		virtual bool                                   IsValid() const { return( m_Lib != 0 ); }

		/**
		* \return                                      true if module is statically loaded, false if dynamic
		*/
		virtual bool                                   IsStatic() const { return false; }

		/**
		* Query library for symbol
		* \param rstrSymbol                            Symbol name
		* \return                                      Symbol
		*/
		virtual ModSymbol                              LookupSymbol( const HashString &rstrSymbol );
};


/**
  * \brief Module abstraction layer for statically linked modules
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ModuleStatic : public Module
{
	public:

		/*! Available symbols */
		HashTable< ModSymbol >                         m_Symbols;



		/**
		* Initialize library layer
		* \param rstrName                              Library name
		*/
		                                               ModuleStatic( const HashString &rstrName );

		/**
		*/
		virtual                                       ~ModuleStatic();

		/**
		* \return                                      true if module is loaded successfully, false if not (not existing or missing symbols)
		*/
		virtual bool                                   IsValid() const { return true; }

		/**
		* \return                                      true if module is statically loaded, false if dynamic
		*/
		virtual bool                                   IsStatic() const { return true; }

		/**
		* Query library for symbol
		* \param rstrSymbol                            Symbol name
		* \return                                      Symbol
		*/
		virtual ModSymbol                              LookupSymbol( const HashString &rstrSymbol );
};


#ifdef WIN32
#  ifndef __HAVE_VECTOR_HASHSTRING_NOPOINTER
     UDTVectorEXPIMP( class HashString );
#    define __HAVE_VECTOR_HASHSTRING_NOPOINTER
#  endif
#endif


/**
  * \brief Manages loadable modules
  * The module manager keeps track of search paths for modules
  * and the loaded modules for quick access. An object wanting
  * to load a module should do so through a ModuleManager interface,
  * preferrably the module manager in the core object.
  * \author Cody Russell (cody [at] jhu.edu)
  */
class NEOENGINE_API ModuleManager
{
	friend class Module;

	protected:

		/*! List of search paths */
		std::vector< HashString >                     m_vstrSearchPaths;

		/*! Hash table of loaded modules */
		HashTable< Module >                           m_hashModules;

		/**
		* Check to see if the given path exists.
		* \param rstrPath                             The path to check.
		*/
		bool                                          PathExists( const HashString &rstrPath );


	public:

		/**
		* Startup the module manager
		*/
		                                              ModuleManager();

		/**
		* Shutdown the module manager, free existing modules
		*/
		virtual                                      ~ModuleManager ();

		/**
		* Adds a search path for modules
		* \param rstrPath                             Directory path to add
		* \param bForce                               Force adding of the path, even if it doesn't exist?
		* \return                                     Whether the path existed.  If bForce is false and the return value is false, the path was not added.
		*/
		bool                                          AddSearchPath( const HashString &rstrPath, bool bForce = false );

		/**
		* Removes a search path from the manager
		* \param rstrPath                             Directory path to remove
		*/
		void                                          RemoveSearchPath( const HashString &rstrPath );

		/**
		* Gets an Module reference for the named module.  If the module has already been loaded, get a reference to it, otherwise try to load it first.
		* \param rstrName                             Name of the module requested.
		* \return                                     A reference to the requested module, if it could be obtained.
		*/
		virtual ModulePtr                             LoadModule( const HashString &rstrName );

		/**
		* Manually insert a (statically) linked module
		* \param pkModule                             Module object
		*/
		virtual void                                  InsertModule( Module *pkModule );

		/**
		* Unregister a module
		* \param pkModule                             Module object
		* \param bDeleted                             true if module already deleted, or in dtor chain
		*/
		virtual void                                  RemoveModule( Module *pkModule, bool bDeleted = false );
};


};


#endif
