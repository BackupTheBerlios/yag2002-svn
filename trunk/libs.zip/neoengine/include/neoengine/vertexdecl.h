/***************************************************************************
               vertexdecl.h  -  Flexible vertex format declaration
                             -------------------
    begin                : Thu Jul 31 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, vertexdecl.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEVERTEXDECL_H
#define __NEVERTEXDECL_H

#include "base.h"
#include "nemath.h"


/**
  * \file vertexdecl.h
  * Flexible vertex format declaration
  */

namespace NeoEngine
{


/**
  * \class VertexElement
  * \brief Data describing a single element in a vertex declaration
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API VertexElement
{
	public:

		/**
		* \enum VERTEXDATATYPE
		* \brief Data types supported for vertex data
		*/
		enum VERTEXDATATYPE
		{
		  /*! Single float value */
		  FLOAT                                       = 0,

		  /*! Two-dimension float vector */
		  FLOAT2                                      = 1,

		  /*! Three-dimension float vector */
		  FLOAT3                                      = 2,

		  /*! Four-dimension float vector */
		  FLOAT4                                      = 3,

		  /*! Four-byte color value (in device order, access with Color32 object) */
		  COLOR32                                     = 4,

		  /*! Identifier for matching any type during search */
		  UNKNOWNTYPE                                 = 255
		};


		/**
		* \enum VERTEXDATAUSAGE
		* \brief Usage types for vertex data element
		*/
		enum VERTEXDATAUSAGE
		{
		  /*! Position */
		  POSITION                                    = 0,

		  /*! Normal */
		  NORMAL                                      = 1,

		  /*! Texture coordinate */
		  TEXCOORD                                    = 2,

		  /*! Diffuse color */
		  DIFFUSECOLOR                                = 3,

		  /*! Tangent */
		  TANGENT                                     = 4,

		  /*! Binormal */
		  BINORMAL                                    = 5,

		  /*! Fog */
		  FOG                                         = 6,

		  /*! Unknown */
		  UNKNOWNUSAGE                                = 255
		};


		/*! Data type */
		unsigned int                                  m_uiType;

		/*! Usage type */
		unsigned int                                  m_uiUsage;

		/*! Usage index */
		unsigned int                                  m_uiIndex;

		/*! Offset */
		unsigned int                                  m_uiOffset;

		/**
		*/
		                                              VertexElement() : m_uiType( UNKNOWNTYPE ), m_uiUsage( UNKNOWNUSAGE ), m_uiIndex( 0 ), m_uiOffset( 0 ) {}

		/**
		* \param uiType                               Element type
		* \param uiUsage                              Usage type
		* \param uiIndex                              Usage index
		* \param uiOffset                             Offset
		*/
		                                              VertexElement( unsigned int uiType, unsigned int uiUsage, unsigned int uiIndex, unsigned int uiOffset ) : m_uiType( uiType ), m_uiUsage( uiUsage ), m_uiIndex( uiIndex ), m_uiOffset( uiOffset ) {}

		/**
		* \param rkElement                            Vertex element to compare with
		* \return                                     true if elements are equal, false if not
		*/
		inline bool                                   operator == ( const VertexElement &rkElement ) const { return( ( m_uiType == rkElement.m_uiType ) && ( m_uiUsage == rkElement.m_uiUsage ) && ( m_uiIndex == rkElement.m_uiIndex ) && ( m_uiOffset == rkElement.m_uiOffset ) ); }
};




/**
  * \class VertexDeclaration
  * \brief Complete declaration of a vertex
  * Complete declaration of a vertex format. All elements must be declared in offset order
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API VertexDeclaration
{
	public:

		/*! Vertex declarations */
		VertexElement                                *m_pkElements;

		/*! Number of elements */
		unsigned int                                  m_uiNumElements;


		/**
		* \param uiNumElements                        Number of elements in format declaration
		*/
		                                              VertexDeclaration( unsigned int uiNumElements );

		/**
		* \param rkDeclaration                        Reference declaration object to copy data from
		*/
		                                              VertexDeclaration( const VertexDeclaration &rkDeclaration );

		/**
		*/
		virtual                                      ~VertexDeclaration();

		/**
		* Get first matching element of specified type
		* \param uiType                               Element type
		* \param uiUsage                              Element usage, or UNKNOWN for matching any usage
		* \return                                     First matching element, or null if no match
		*/
		VertexElement                                *GetElement( unsigned int uiType = VertexElement::UNKNOWNTYPE, unsigned int uiUsage = VertexElement::UNKNOWNUSAGE );

		/**
		* Get first matching element of specified type
		* \param uiType                               Element type
		* \param uiUsage                              Element usage, or UNKNOWN for matching any usage
		* \return                                     First matching element, or null if no match
		*/
		const VertexElement                          *GetElement( unsigned int uiType = VertexElement::UNKNOWNTYPE, unsigned int uiUsage = VertexElement::UNKNOWNUSAGE ) const;

		/**
		* Get size of a vertex with this format declaration
		* \return                                     Size of a vertex
		*/
		unsigned int                                  GetVertexSize() const;

		/**
		* Duplicate vertex format declaration object
		* \return                                     New object that is copy of this object
		*/
		virtual VertexDeclaration                    *Duplicate() const;

		/**
		* \param rkDeclaration                        Reference declaration object to copy data from
		*/
		VertexDeclaration                            &operator = ( const VertexDeclaration &rkDeclaration );

		/**
		* \param rkDeclaration                        Reference declaration object to compare with
		* \return                                     true if declarations are equal
		*/
		bool                                          operator == ( const VertexDeclaration &rkDeclaration ) const;

		/**
		* Interpolate between two vertices of generic type
		* \param pucFrom                              Pointer to first source vertex
		* \param pucTo                                Pointer to second source vertex
		* \param pucDest                              Pointer to destination vertex receiving interpolated data
		* \param fFactor                              Interpolation factor
		*/
		inline void                                   Interpolate( unsigned char *pucFrom, unsigned char *pucTo, unsigned char *pucDest, float fFactor ) const
		{
			for( unsigned int uiElement = 0; uiElement < m_uiNumElements; ++uiElement )
			{
				const VertexElement &kElement = m_pkElements[ uiElement ];

				if( kElement.m_uiType < VertexElement::COLOR32 )
				{
					//Float interpolation
					float *pfLast = (float*)( pucFrom + kElement.m_uiOffset );
					float *pfNext = (float*)( pucTo   + kElement.m_uiOffset );
					float *pfDest = (float*)( pucDest + kElement.m_uiOffset );

					// ### FIXME: SIMD anyone? :)
					for( unsigned int uiFloat = 0; uiFloat < ( kElement.m_uiType + 1 ); ++uiFloat, ++pfLast, ++pfNext, ++pfDest )
						*pfDest = *pfLast + ( *pfNext - *pfLast ) * fFactor;

					// OUCH!
					if( kElement.m_uiUsage == VertexElement::NORMAL )
						((Vector3d*)( pucDest + kElement.m_uiOffset ))->Normalize();
				}
				else
				{
					//Color interpolation, each channel separately
					unsigned int uiSrcColorOne = *((unsigned int*)( pucFrom + kElement.m_uiOffset ) );
					unsigned int uiSrcColorTwo = *((unsigned int*)( pucTo   + kElement.m_uiOffset ) );

					// ### FIXME: SIMD anyone? :)
					float fCol[4][2] = { { float(   uiSrcColorOne         & 0xFF ), float(   uiSrcColorTwo         & 0xFF ) },
					                     { float( ( uiSrcColorOne >> 8  ) & 0xFF ), float( ( uiSrcColorTwo >> 8  ) & 0xFF ) },
					                     { float( ( uiSrcColorOne >> 16 ) & 0xFF ), float( ( uiSrcColorTwo >> 16 ) & 0xFF ) },
					                     { float( ( uiSrcColorOne >> 24 ) & 0xFF ), float( ( uiSrcColorTwo >> 24 ) & 0xFF ) } };

					int iFin[4]      = { int( fCol[0][0] + ( fCol[0][1] - fCol[0][0] ) * fFactor ),
					                     int( fCol[1][0] + ( fCol[1][1] - fCol[1][0] ) * fFactor ),
					                     int( fCol[2][0] + ( fCol[2][1] - fCol[2][0] ) * fFactor ),
					                     int( fCol[3][0] + ( fCol[3][1] - fCol[3][0] ) * fFactor ) };

					*((unsigned int*)( pucDest + kElement.m_uiOffset )) = ( iFin[0] & 0xFF ) | ( ( iFin[1] << 8 ) & 0xFF00 ) | ( ( iFin[2] << 16 ) & 0xFF0000 ) | ( ( iFin[3] << 24 ) & 0xFF000000 );
				}
			}
		}

		/**
		* Interpolate between two vertex buffers of generic type
		* \param pucFrom                              Pointer to first source vertex buffer
		* \param pucTo                                Pointer to second source vertex buffer
		* \param pucDest                              Pointer to destination vertex buffer receiving interpolated data
		* \param fFactor                              Interpolation factor
		* \param uiNumVertices                        Number of vertices to interpolate
		* \param pvbMask                              Optional pointer to mask array
		*/
		virtual void                                  InterpolateArray( unsigned char *pucFrom, unsigned char *pucTo, unsigned char *pucDest, float fFactor, unsigned int uiNumVertices, std::vector< bool > *pvbMask = 0 ) const;
};


};


#endif

