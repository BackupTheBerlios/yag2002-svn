/***************************************************************************
                         color.h  -  Color data classes
                             -------------------
    begin                : Mon Sep 16 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, color.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NECOLOR_H
#define __NECOLOR_H


#include "base.h"
#include "util.h"


/**
  * \file neoengine/color.h
  * Color abstraction
  */


namespace NeoEngine
{


/**
  * \brief Color abstraction
  * Color represented by 4 float (32 bit), RGBA order
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Color
{
	public:

		/*! Components */
		float                           r,g,b,a;


		/**
		* Reset to [0,0,0,1]
		*/
		                                Color() : r(0.0f), g(0.0f), b(0.0f), a(1.0f) {}

		/**
		* Set values from 32bit integer (one byte per channel) color
		* \param uiColor                color
		*/
		                                Color( unsigned int uiColor ) : r( float( uiColor & 0xFF ) * 0.0039215686f ), g( float( ( uiColor >> 8 ) & 0xFF ) * 0.0039215686f ), b( float( ( uiColor >> 16 ) & 0xFF ) * 0.0039215686f ), a( float( ( uiColor >> 24 ) & 0xFF ) * 0.0039215686f ) {}

		/**
		* Set values
		* \param fR                     Red
		* \param fG                     Green
		* \param fB                     Blue
		* \param fA                     Alpha
		*/
		                                Color( float fR, float fG, float fB, float fA = 1.0f ) : r(fR), g(fG), b(fB), a(fA) {}

		/**
		* Set values
		* \param fR                     Red
		* \param fG                     Green
		* \param fB                     Blue
		* \param fA                     Alpha (defaults to 1.0f)
		*/
		inline void                     Set( float fR, float fG, float fB, float fA = 1.0f ) { r = fR; g = fG; b = fB; a = fA; }

		/**
		* Set values
		* \param uiColor                color as 32bit integer
		*/
		inline void                     Set( unsigned int uiColor ) { r = float( uiColor & 0xFF ) * 0.0039215686f; g = float( ( uiColor >> 8 ) & 0xFF ) * 0.0039215686f; b = float( ( uiColor >> 16 ) & 0xFF ) * 0.0039215686f; a = float( ( uiColor >> 24 ) & 0xFF ) * 0.0039215686f; }

		/**
		* Set values
		* \param rkColor                Color reference
		*/
		inline void                     Set( const Color &rkColor ) { fmemcpy( &r, &rkColor.r, sizeof( float ) * 4 ); }

		/**
		* Conversion, to allow easy component access
		*/
		inline                          operator float* () { return &r; }

		/**
		* Conversion, to allow easy component access
		*/
		inline                          operator const float* () const { return &r; }

		/**
		* Array access to elements
		*/
		inline float                   &operator [] ( int iComponent ) { return ((float*)&r)[ iComponent ]; }

		/**
		* Array access to elements
		*/
		inline const float             &operator [] ( int iComponent ) const { return ((const float*)&r)[ iComponent ]; }

		/**
		* Copy
		* \param rkColor                Values to copy
		* \return                       ref to resulting color (this)
		*/
		inline Color                   &operator = ( const Color &rkColor ) { fmemcpy( &r, &rkColor.r, sizeof( float ) * 4 ); return( *this ); }

		/**
		* Compare
		* \param rkColor                Values to compare with
		* \return                       true if components equal (no EPSILON test!)
		*/
		inline bool                     operator == ( const Color &rkColor ) const { return( ( r == rkColor.r ) && ( g == rkColor.g ) && ( b == rkColor.b ) && ( a == rkColor.a ) ); }

		/**
		* Compare
		* \param rkColor                Values to compare with
		* \return                       true if components differ (no EPSILON test!)
		*/
		inline bool                     operator != ( const Color &rkColor ) const { return( !( *this == rkColor ) ); }

		/*! Predefined color, black */
		static const NE_STATIC Color    BLACK;

		/*! Predefined color, white */
		static const NE_STATIC Color    WHITE;

		/*! Predefined color, white */
		static const NE_STATIC Color    RED;

		/*! Predefined color, white */
		static const NE_STATIC Color    GREEN;

		/*! Predefined color, white */
		static const NE_STATIC Color    BLUE;
};


/**
  * \brief Color abstraction in device native format storage, accessible through RGBA order
  * Color represented by 32 bit unsigned int (8 bit unsigned char per element), RGBA (A high bit, R low bit) or BGRA (A high bit, B low bit) storage order.
  * Access to components are always made through RGBA order with red as component 0 and alpha as component 3
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Color32
{
	private:

		/**
		* \brief Union for easy access as unsigned int or unsigned char[]
		*/
		union Color32Union
		{
		  unsigned int                  m_uiValue;
		  unsigned char                 m_aucComponent[4];
		}                               m_uiColor;


	public:

		/*! Internal engine data */
		static unsigned int             s_uiShift[4];

		/*! Internal engine data */
		static unsigned int             s_uiComponent[4];


		/**
		* Reset to black [0,0,0,1]
		*/
		                                Color32() { m_uiColor.m_uiValue = 0xFF << s_uiShift[3]; }

		/**
		* Set values
		* \param ucR                    Red
		* \param ucG                    Green
		* \param ucB                    Blue
		* \param ucA                    Alpha
		*/
		                                Color32( unsigned char ucR, unsigned char ucG, unsigned char ucB, unsigned char ucA = 0xFF ) { m_uiColor.m_uiValue = ( ucR << s_uiShift[0] ) | ( ucG << s_uiShift[1] ) | ( ucB << s_uiShift[2] ) | ( ucA << s_uiShift[3] ); }

		/**
		* Set values from component array in RGBA order
		* \param pucComponents          Components in RGBA order
		*/
		                                Color32( unsigned char *pucComponents ) { m_uiColor.m_uiValue = ( pucComponents[0] << s_uiShift[0] ) | ( pucComponents[1] << s_uiShift[1] ) | ( pucComponents[2] << s_uiShift[2] ) | ( pucComponents[3] << s_uiShift[3] ); }

		/**
		* Set values from Color object
		* \param rkColor                Color
		*/
		                                Color32( const Color &rkColor ) { m_uiColor.m_uiValue = ( ( int( rkColor.r * 255.0f ) & 0xFF ) << s_uiShift[0] ) | ( ( int( rkColor.g * 255.0f ) & 0xFF ) << s_uiShift[1] ) | ( ( int( rkColor.b * 255.0f ) & 0xFF ) << s_uiShift[2] ) | ( ( int( rkColor.a * 255.0f ) & 0xFF ) << s_uiShift[3] ); }

		/**
		* Set values (components in range [0,1] )
		* \param pfComponents           Color channels array as floats in rgba order
		*/
		                                Color32( float *pfComponents ) { m_uiColor.m_uiValue = ( ( int( pfComponents[0] * 255.0f ) & 0xFF ) << s_uiShift[0] ) | ( ( int( pfComponents[1] * 255.0f ) & 0xFF ) << s_uiShift[1] ) | ( ( int( pfComponents[2] * 255.0f ) & 0xFF ) << s_uiShift[2] ) | ( ( int( pfComponents[3] * 255.0f ) & 0xFF ) << s_uiShift[3] ); }

		/**
		* Set values (components in range [0,1] )
		* \param fR                     Red
		* \param fG                     Green
		* \param fB                     Blue
		* \param fA                     Alpha
		*/
		                                Color32( float fR, float fG, float fB, float fA = 1.0f ) { m_uiColor.m_uiValue = ( ( int( fR * 255.0f ) & 0xFF ) << s_uiShift[0] ) | ( ( int( fG * 255.0f ) & 0xFF ) << s_uiShift[1] ) | ( ( int( fB * 255.0f ) & 0xFF ) << s_uiShift[2] ) | ( ( int( fA * 255.0f ) & 0xFF ) << s_uiShift[3] ); }

		/**
		* Set values
		* \param ucR                    Red
		* \param ucG                    Green
		* \param ucB                    Blue
		* \param ucA                    Alpha
		*/
		inline void                     Set( unsigned char ucR, unsigned char ucG, unsigned char ucB, unsigned char ucA = 0xFF ) { m_uiColor.m_uiValue = ( ucR << s_uiShift[0] ) | ( ucG << s_uiShift[1] ) | ( ucB << s_uiShift[2] ) | ( ucA << s_uiShift[3] ); }

		/**
		* Set values from component array
		* \param pucComponents          Components
		*/
		inline void                     Set( unsigned char *pucComponents ) { m_uiColor.m_uiValue = ( pucComponents[0] << s_uiShift[0] ) | ( pucComponents[1] << s_uiShift[1] ) | ( pucComponents[2] << s_uiShift[2] ) | ( pucComponents[3] << s_uiShift[3] ); }

		/**
		* Set values
		* \param rkColor                Color reference
		*/
		inline void                     Set( const Color &rkColor ) { m_uiColor.m_uiValue = ( ( int( rkColor.r * 255.0f ) & 0xFF ) | ( ( int( rkColor.g * 255.0f ) & 0xFF ) << 8 ) | ( ( int( rkColor.b * 255.0f ) & 0xFF ) << 16 ) | ( ( int( rkColor.a * 255.0f ) & 0xFF ) << 24 ) ); }

		/**
		* Set values (components in range [0,1] )
		* \param fR                     Red
		* \param fG                     Green
		* \param fB                     Blue
		* \param fA                     Alpha (defaults to 1.0f)
		*/
		inline void                     Set( float fR, float fG, float fB, float fA = 1.0f ) { m_uiColor.m_uiValue = ( ( int( fR * 255.0f ) & 0xFF ) << s_uiShift[0] ) | ( ( int( fG * 255.0f ) & 0xFF ) << s_uiShift[1] ) | ( ( int( fB * 255.0f ) & 0xFF ) << s_uiShift[2] ) | ( ( int( fA * 255.0f ) & 0xFF ) << s_uiShift[3] ); }

		/**
		* Conversion, FOR NATIVE USE ONLY!
		*/
		                                operator const unsigned int& () const { return m_uiColor.m_uiValue; }


		/**
		* Conversion, FOR NATIVE USE ONLY!
		*/
		                                operator unsigned char* () { return m_uiColor.m_aucComponent; }

		/**
		* Array access to elements in RGBA order, with r = 0, g = 1, b = 2 and a =3
		*/
		unsigned char                  &operator [] ( int iComponent ) { return m_uiColor.m_aucComponent[ s_uiComponent[ iComponent ] ]; }

		/**
		* Array access to elements
		*/
		const unsigned char            &operator [] ( int iComponent ) const { return m_uiColor.m_aucComponent[ s_uiComponent[ iComponent ] ]; }

		/**
		* Copy
		* \param rkColor                Values to copy
		* \return                       ref to resulting color (this)
		*/
		Color32                        &operator = ( const Color32 &rkColor ) { m_uiColor.m_uiValue = rkColor.m_uiColor.m_uiValue; return( *this ); }

		/**
		* Copy
		* \param rkColor                Values to copy
		* \return                       ref to resulting color (this)
		*/
		Color32                        &operator = ( const Color &rkColor ) { Set( rkColor.r, rkColor.g, rkColor.b, rkColor.a ); return( *this ); }

		/**
		* Set value from unigned int value in RGBA order
		* \param uiColor                Color
		* \return                       ref to resulting color (this)
		*/
		Color32                        &operator = ( unsigned int uiColor ) { Set( (unsigned char)( uiColor & 0xFF ), (unsigned char)( ( uiColor >> 8 ) & 0xFF ), (unsigned char)( ( uiColor >> 16 ) & 0xFF ), (unsigned char)( ( uiColor >> 24 ) & 0xFF ) ); return( *this ); }
};


};


#endif

