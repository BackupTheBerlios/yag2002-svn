/***************************************************************************
          zippackage.h  -  File management in virtual file system
                             -------------------
    begin                : Thu Jun 03 2004
    copyright            : (C) 2002 by emedia-solutions wolf
    email                : markus@emedia-solutions-wolf.de
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, zippackage.h

 The Initial Developer of the Original Code is Markus Wolf.
 Portions created by Markus Wolf are Copyright (C) 2004
 emedia-soltions wolf. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEZIPPACKAGE_H
#define __NEZIPPACKAGE_H


/**
  * \file package.h
  * File management in packages
  */


#include "base.h"
#include "package.h"

#include <string>

#ifdef GETSIG
#	undef GETSIG
#endif
#define GETSIG( addr ) ( unsigned int )( addr[ 0 ] << 24 ) + ( addr[ 1 ] << 16 ) + ( addr[ 2 ] << 8 ) + addr[ 3 ]

using namespace std;

namespace NeoEngine
{

// External classes
class FileManager;

#ifdef WIN32
#  pragma pack(push)
#  pragma pack(1)
#endif
struct ZipLFHeader
{
	unsigned long                                     iSignature;
	unsigned short                                    iVersionNeeded;
	unsigned short                                    iFlags;
	unsigned short                                    iCompressionMethod;
	unsigned short                                    iLastModFileTime;
	unsigned short                                    iLastModFileDate;
	unsigned long                                     iCRC32;
	unsigned long                                     iCompressedSize;
	unsigned long                                     iUncompressedSize;
	unsigned short                                    iFileNameLength;
	unsigned short                                    iExtraFieldLength;
	/*
	string                                            strFileName;
	string                                            strExtraField;
	*/
};
struct ZipCDFHeader
{
	unsigned long                                     iSignature;
	unsigned short                                    iMadyBy;
	unsigned short                                    iVersionNeeded;
	unsigned short                                    iFlags;
	unsigned short                                    iMethod;
	unsigned short                                    iLastModFileTime;
	unsigned short                                    iLastModFileDate;
	unsigned long                                     iCRC32;
	unsigned long                                     iCompressedSize;
	unsigned long                                     iUncompressedSize;
	unsigned short                                    iFileNameLength;
	unsigned short                                    iExtraFieldLength;
	unsigned short                                    iFileCommentLength;
	unsigned short                                    iDiskNumberStart;
	unsigned short                                    iInternalAttributes;
	unsigned long                                     iExternalAttributes;
	unsigned long                                     iDataOffset;
	/*
	string                                            strFileName;
	string                                            strExtraField;
	string                                            strFileComment;
	*/
};
#ifdef WIN32
#  pragma pack(pop)
#endif

/**
  * \brief File management in packages
  * A package can both contain real files and virtual files (read from package file).
  * \author Markus Wolf (markus@emedia-solutions-wolf.de)
  */
class ZipPackage : public Package
{
	protected:

		/**
		* Read cluster data from file. Recursive.
		* \param pkDirectory                          Directory to read
		*/
		virtual void                                  ReadCluster( Directory *pkDirectory );


  public:

		/**
		* Open and parse package file. You can also put in a directory in the normal file system and it will be recursivly parsed
		* \param pkParent                             Parent directory
		* \param rstrFile                             Package file name
		* \param pkManager                            File manager we are connected to
		*/
		                                              ZipPackage( Directory *pkParent, const std::string &rstrFile, FileManager *pkManager );

		/**
		* Deallocate hierarchy
		*/
		virtual                                      ~ZipPackage();
};


}; // namespace NeoEngine


#endif  // __NEZIPPACKAGE_H
