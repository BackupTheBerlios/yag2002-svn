/***************************************************************************
                           profile.h  -  Profiler
                             -------------------
    begin                : Sat Aug 31 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, profile.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEPROFILE_H
#define __NEPROFILE_H


#include "base.h"
#include "core.h"
#include "activator.h"
#include "hashstring.h"
#include "callback.h"
#include "renderentity.h"

#include <vector>
#include <string>



/**
  * \file profile.h
  * Useful profiler
  */


namespace NeoEngine
{


#ifdef WIN32
#  ifndef __HAVE_VECTOR_PROFILEDATA
     UDTVectorEXPIMP( class ProfileData* );
#    define __HAVE_VECTOR_PROFILEDATA
#  endif
#endif



/**
  * \brief Data for a profile block
  * A profiling block contains data for an execution block. It is
  * identified by name and has data of total execution time and number
  * of times the block has been executed. A profiling block can have
  * any number of child blocks and a single parent block, arranging
  * the blocks in a tree structure. This way relative percentages can
  * be calculated to see where most of the time in a block is spent.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ProfileData
{
	public:

		/*! Node name */
		HashString                                    m_strName;
		
		/*! Parent data node */
		ProfileData                                  *m_pkParent;

		/*! Child data nodes */
		std::vector< ProfileData* >                   m_vpkChildren;

		/*! Activated heartbeat */
		uint64_t                                      m_ulActivated;

		/*! Accumulated heartbeat time */
		uint64_t                                      m_ulAccTime;

		/*! Counter */
		int                                           m_iCount;

		/*! Recursion level */
		int                                           m_iLevel;

		

		/**
		* \param rstrName                             Node name
		* \param pkParent                             Parent node
		*/
		                                              ProfileData( const std::string &rstrName, ProfileData *pkParent = 0 );

		/**
		* Delete child nodes
		*/
		virtual                                      ~ProfileData();

		/**
		* Dump data
		*/    
		virtual void                                  Dump();

		/**
		* Dump data to string
		* \param pstrDst                              String receiving data
		*/    
		virtual void                                  DumpToString( std::string *pstrDst );

		/**
		* Reset values
		*/
		virtual void                                  Reset();
};



/**
  * \brief Manager for profile data
  * The profile manager keeps track of all profiling blocks, the current
  * block and the total execution time. It can be activated and rendered onscreen
  * from the console with the "<b>showprofile</b>" command, all profile block data can be reset
  * to zero with the "<b>resetprofile</b>" command, and all data cleared with
  * the "<b>clearprofile</b>" command.<br><br>
  * To start a profiling block you use the <b>BEGIN_PROFILE( name )</b> macro, and to
  * end the block you use the <b>END_PROFILE()</b> macro. You must match all begin calls with
  * end calls. It is (naturally) not possible to overlap blocks, since the END_PROFILE macro
  * closes the latest activated block. If the <b>_PROFILE</b> preprocessor symbol is not defined,
  * the BEGIN/END macros resolve to a nothing, making it easy to turn on/off profiling at build time.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ProfileManager : public ProfileData, public ConsoleCmdCallback, public RenderEntity, virtual public Activator
{
	protected:

		/*! Current active profile node */
		ProfileData                                  *m_pkActiveNode;		

		

	public:


		/**
		*/
		                                              ProfileManager();

		/**
		*/
		virtual                                      ~ProfileManager();

		/**
		* Begin a new profile level
		* \param rstrName                             Level name
		*/
		virtual void                                  BeginProfile( const HashString &rstrName );

		/**
		* End last profile level
		*/
		virtual void                                  EndProfile();

		/**
		* Dump data to log (INFO)
		*/
		virtual void                                  Dump();

		/**
		* Dump data to string
		* \param pstrDst                              Pointer to string receiving data
		*/
		virtual void                                  DumpToString( std::string *pstrDst );

		/**
		* Clear all profile data
		*/
		virtual void                                  Clear();

		/**
		* Process console command
		* \param rstrCmd                              Command
		* \param rstrArgs                             Argument string
		*/
		virtual void                                  ConsoleCmd( const HashString &rstrCmd, const HashString &rstrArgs );

		/**
		* Render profile data overlay
		* \param pkFrustum                            Current view frustum (if any)
		* \param bForce                               Render even if rendered previously this frame or deactivated (default false)
		* \return                                     true if we were rendered, false if not (already rendered, not forced)
		*/
		virtual bool                                  Render( Frustum *pkFrustum = 0, bool bForce = false );
};



#ifdef _PROFILE

#define BEGIN_PROFILE( name ) { Core::Get()->GetProfileManager()->BeginProfile( name ); }
#define END_PROFILE() { Core::Get()->GetProfileManager()->EndProfile(); }

#else

#define BEGIN_PROFILE( name )
#define END_PROFILE()

#endif


}; // namespace NeoEngine


#endif  // __NEPROFILE_H
