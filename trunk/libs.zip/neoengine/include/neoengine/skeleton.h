/***************************************************************************
                skeleton.h  -  Skeleton as a hierarchy of bone nodes
                             -------------------
    begin                : Sun Jan 26 2003
    copyright            : (C) 2003 by Realit Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, skeleton.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NESKELETON_H
#define __NESKELETON_H


/**
  * \file neoengine/skeleton.h
  * Skeleton as a hierarchy of bone nodes
  */


#include "base.h"
#include "scenenode.h"
#include "bone.h"
#include "skeletonanimator.h"

#include <string>
#include <vector>


namespace NeoEngine
{


// External classes
class BoneAdaptor;


#ifdef WIN32

#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif

#  ifndef __HAVE_VECTOR_NEBONEDAPTOR
     UDTVectorEXPIMP( class BoneAdaptor* );
#    define __HAVE_VECTOR_NEBONEADAPTOR
#  endif

#endif


/**
  * \brief Master class controlling a hierachy of bones
  * A skeleton is a hierarchy of bone nodes with a single root
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Skeleton : public SceneNode, public SkeletonAnimatorController
{
        private:

                /*! Rest state */
	        bool                                          m_bRestState;

	public:

		DefineVisitable();


	public:

		/*! Root bone */
		Bone                                         *m_pkRoot;

		/*! All bones */
		Bone                                        **m_ppkBones;

		/*! Number of bones */
		unsigned int                                  m_uiNumBones;

		/*! Adaptors */
		std::vector< BoneAdaptor* >                   m_vpkAdaptors;

		/*! Render skeleton flag */
		bool                                          m_bRenderSkeleton;


		/**
		*/
		                                              Skeleton();

		/**
		* Copy skeleton
		* \param rkSkeleton                           Skeleton object to copy
		*/
		                                              Skeleton( Skeleton &rkSkeleton );

		/**
		*/
		virtual                                      ~Skeleton();

		/**
		* Update skeleton
		* \param fDeltaTime                           Delta time passed
		*/
		virtual void                                  Update( float fDeltaTime );

		/**
		* Create duplicate of skeleton object
		* \return                                     New object that is exact copy of this
		*/
		virtual SceneNode                            *Duplicate();

		/**
		* Render bone hierarchy as lines
		* \param pkFrustum                            Current view frustum (if any)
		* \param bForce                               Render even if rendered previously this frame (default false)
		* \return                                     true if we were rendered, false if not (already rendered, not forced)
		*/
		virtual bool                                  Render( Frustum *pkFrustum = 0, bool bForce = false );

		/**
		* Attach an adaptor
		* \param pkAdaptor
		*/
		void                                          AttachAdaptor( BoneAdaptor *pkAdaptor );

		/**
		* Detach an adaptor
		* \param pkAdaptor
		*/
		void                                          DetachAdaptor( BoneAdaptor *pkAdaptor );

  	        /**
		 * Query state of rest
		 */
  	        bool                                          IsResting();

  	        /**
		 * Activate rest state. The current translation and rotation of bones will be used as resting position.
		 */
	        void                                          ActivateRest();

  	        /**
		 * Deactivate rest state
		 */
	        void                                          DeactivateRest();
};


};


#endif
