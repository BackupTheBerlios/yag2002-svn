/***************************************************************************
                 activator.h  -  Base class for objects with
                    activated/deactivated state attribute
                             -------------------
    begin                : Thu Nov 8 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, activator.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEACTIVATOR_H
#define __NEACTIVATOR_H


#include "base.h"


/**
  * \file activator.h
  * Base class for objects with active/deactive state attribute
  */


namespace NeoEngine
{


/**
  * \brief Simple class for activator control, use virtual inheritance
  * Used by any objects that need to keep track of activated/deactivated
  * state. Use virtual inheritance to avoid multiple base objects in
  * inheritance lattice. Remember to call base methods in overridden methods.
  * A class only needs to overload the Activate and Deactivate methods.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Activator
{
	protected:

		/*! Active flag */
		bool                                          m_bActive;

	public:

		/**
		* Initialize state of object
		* \param bActive                              Initial state, default is true (active)
		*/
		inline                                        Activator( bool bActive = true );

		/**
		*/
		inline virtual                               ~Activator();

		/**
		* Query state of object
		* \return                                     true if active, false if not
		*/
		inline bool                                   IsActive() const;

		/**
		* Activate object
		*/
		inline virtual void                           Activate();

		/**
		* Deactivate object
		*/
		inline virtual void                           Deactivate();

		/**
		* Toggle active state. This method does not need to be overloaded, it is only a wrapper to Activate and Deactivate
		* \return                                     true if activated, false if deactivated
		*/
		inline bool                                   Toggle();
};


#include "activator_inl.h"


}; // namespace NeoEngine


#endif

