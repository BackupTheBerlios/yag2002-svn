/***************************************************************************
               animator.h  -  Template base for animator controllers
                             -------------------
    begin                : Sun Jan 26 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, animator.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEANIMATOR_H
#define __NEANIMATOR_H

#ifndef __NEED_VECTOR_BOOL
#  define __NEED_VECTOR_BOOL
#endif

#include "base.h"
#include "updateentity.h"
#include "hashstring.h"

#include <vector>


/**
  * \file animator.h
  * Template base for animator controllers
  */


namespace NeoEngine
{


/**
  * \brief Animation blending stage
  * Animation blending is similar to multitexturing. You setup a blend chain that
  * the animation system will go through sequentially, weighting the result of the
  * previous step with the current stage animation output, using the stage blend
  * weight factor
  * \author Mattias Jansson (mattias@realityrift.com)
  */
template < class AnimationType > class AnimationBlendStage
{
	public:

		/*! Animation object */
		AnimationType                                     *m_pkAnimation;

		/*! Blend weight factor in [0..1] range */
		float                                              m_fWeight;

		/*! Mask */
		std::vector< bool >                               *m_pvbMask;

		/**
		*/
		                                                   AnimationBlendStage();

		/**
		* Deallocate the mask array
		*/
		virtual                                           ~AnimationBlendStage();
};


/**
  * \brief An animator controller manages animations for an object
  * \author Mattias Jansson (mattias@realityrift.com)
  */
template < class AnimationType > class AnimatorController : public virtual UpdateEntity
{
	public:

		typedef AnimationBlendStage< AnimationType >       AnimationBlendStageType;
		typedef std::vector< AnimationBlendStageType* >    AnimationBlendStageTypeVec;
		typedef std::vector< AnimationType* >              AnimationTypeVec;

	protected:

		/*! Automatic blend flag */
		bool                                               m_bAutomaticBlend;

		/*! Animations */
		std::vector< AnimationType* >                      m_vpkAnimations;

		/*! Animation blend chain */
		std::vector< AnimationBlendStageType* >            m_vpkBlendStages;


		/**
		* Add an animation stage
		* \param uiStage                                   Blend stage
		* \param pkAnimation                               Animation object
		* \param fWeight                                   Blend weight factor
		* \param pvbMask                                   Mask array
		* \param bReset                                    Reset animation to start if true
		*/
		void                                               SetStage( unsigned int uiStage, AnimationType *pkAnimation, float fWeight, std::vector< bool > *pvbMask, bool bReset );

		/**
		* Iterate and blend all stages together
		*/
		void                                               BlendStages();

		/**
		* Blend in a new stage in final data. THIS IS REALLY a pure virtual method, but due
		* to the limited template support in VC++ 6 and the required exports of instances from DLL we need to implement a dummy method.
		* \param pkDstAnim                                 Destination animation
		* \param fWeight                                   Blend weight factor
		* \param pvbMask                                   Mask array
		*/
		virtual void                                       BlendStage( AnimationType *pkDstAnim, float fWeight, std::vector< bool > *pvbMask ) {};


	public:

		/**
		*/
		                                                   AnimatorController();

		/**
		* Copy data from reference animator object
		* \param rkController                              Reference animator controller object
		*/
		                                                   AnimatorController( const AnimatorController< AnimationType > &rkController );

		/**
		* Delete animations
		*/
		virtual                                           ~AnimatorController();

		/**
		* Add new animation
		* \param pkAnimation                               New animation
		* \return                                          true if added, false if id or name conflicts with already registered animation
		*/
		inline virtual bool                                AddAnimation( AnimationType *pkAnimation );

		/**
		* Update current animation
		* \param fDeltaTime                                Time passed since last update
		*/
		virtual void                                       Update( float fDeltaTime );

		/**
		* Set animation in blend chain by name
		* \param rstrAnimName                              Animation name
		* \param uiStage                                   Blend stage
		* \param fWeight                                   Blend weight factor
		* \param pvbMask                                   Mask array (will be managed and deallocated internally)
		* \param bReset                                    Reset animation to start if true
		* \return                                          true if set, false if error (invalid animation name)
		*/
		bool                                               SetAnimation( const HashString &rstrAnimName, unsigned int uiStage = 0, float fWeight = 1.0f, std::vector< bool > *pvbMask = 0, bool bReset = true );

		/**
		* Set animation in blend chain by ID
		* \param uiAnimID                                  Animation ID
		* \param uiStage                                   Blend stage
		* \param fWeight                                   Blend weight factor
		* \param pvbMask                                   Mask array
		* \param bReset                                    Reset animation to start if true
		* \return                                          true if set, false if error (invalid animation ID)
		*/
		bool                                               SetAnimation( unsigned int uiAnimID, unsigned int uiStage = 0, float fWeight = 1.0f, std::vector< bool > *pvbMask = 0, bool bReset = true );

		/**
		* Clear animation blend stage
		*/
		void                                               ClearAnimation();

		/**
		* Get current animation at specified blend stage
		* \param uiStage                                   Blend stage
		* \return                                          Current animation set to stage
		*/
		inline AnimationType                              *GetAnimation( unsigned int uiStage = 0 );

		/**
		* \return                                          All animations
		*/
		inline const std::vector< AnimationType* >        &GetAnimations() const;
};


// Template method implementations
#include "animator_inl.h"


};


#endif
