/***************************************************************************
                      vertex.h  -  Basic vertex types
                             -------------------
    begin                : Thu Jul 31 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, vertex.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEVERTEX_H
#define __NEVERTEX_H

#include "base.h"
#include "nemath.h"
#include "color.h"
#include "vertexdecl.h"



/**
  * \file vertex.h
  * Basic vertex types
  */


namespace NeoEngine
{




/**
  * \brief Basic vertex class with position data
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Vertex
{
	public:

		/*! Position */
		Vector3d                                      m_kPosition;


		/*! Vertex declaration */
		static VertexDeclaration                      s_kDecl;
};



/**
  * \brief Basic vertex class with position and normal data
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API NormalVertex
{
	public:

		/*! Position */
		Vector3d                                      m_kPosition;

		/*! Normal */
		Vector3d                                      m_kNormal;


		/*! Vertex declaration */
		static VertexDeclaration                      s_kDecl;
};



/**
  * \brief Basic vertex with position and diffuse color
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API DiffuseVertex
{
	public:

		/*! Position */
		Vector3d                                      m_kPosition;

		/*! Diffuse color */
		Color32                                       m_kColor;


		/*! Vertex declaration */
		static VertexDeclaration                      s_kDecl;
};



/**
  * \brief Basic vertex class with position and one 2-dim texture coordinate
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API TexVertex
{
	public:

		/*! Position */
		Vector3d                                      m_kPosition;

		/*! Texture coordinate */
		float                                         m_afTexCoord[2];


		/*! Vertex declaration */
		static VertexDeclaration                      s_kDecl;
};



/**
  * \brief Basic vertex class with position, normal and diffuse color data
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API NormalDiffuseVertex
{
	public:

		/*! Position */
		Vector3d                                      m_kPosition;

		/*! Normal */
		Vector3d                                      m_kNormal;

		/*! Diffuse color */
		Color32                                       m_kColor;


		/*! Vertex declaration */
		static VertexDeclaration                      s_kDecl;
};



/**
  * \brief Basic vertex class with position, normal and a 2-dim texture coordinate
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API NormalTexVertex
{
	public:

		/*! Position */
		Vector3d                                      m_kPosition;

		/*! Normal */
		Vector3d                                      m_kNormal;

		/*! Texture coordinate */
		float                                         m_afTexCoord[2];


		/*! Vertex declaration */
		static VertexDeclaration                      s_kDecl;
};



/**
  * \brief Basic vertex with position, a 2-dim texture coordinate and diffuse color
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API DiffuseTexVertex
{
	public:

		/*! Position */
		Vector3d                                      m_kPosition;

		/*! Diffuse color */
		Color32                                       m_kColor;

		/*! Texture coordinate */
		float                                         m_afTexCoord[2];


		/*! Vertex declaration */
		static VertexDeclaration                      s_kDecl;
};



/**
  * \brief Basic vertex class with position, normal, diffuse and a 2-dim texture coordinate
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API NormalDiffuseTexVertex
{
	public:

		/*! Position */
		Vector3d                                      m_kPosition;

		/*! Normal */
		Vector3d                                      m_kNormal;

		/*! Diffuse color */
		Color32                                       m_kColor;

		/*! Texture coordinate */
		float                                         m_afTexCoord[2];


		/*! Vertex declaration */
		static VertexDeclaration                      s_kDecl;
};


}; // namespace NeoEngine


#endif // __NEVERTEX_H
