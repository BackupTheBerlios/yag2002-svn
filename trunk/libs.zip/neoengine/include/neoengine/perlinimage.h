/***************************************************************************
               perlinimage.h  -  Texture generator from perlin noise
                             -------------------
    begin                : Wed Oct 16 2002
    copyright            : (C) 2002 by Rob Wanders
    email                : forteq@softhome.net
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, perlinimage.h

 The Initial Developer of the Original Code is Rob Wanders.
 Portions created by Rob Wanders are Copyright (C) 2002
 Rob Wanders. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEPERLINIMAGE_H
#define __NEPERLINIMAGE_H



/**
* \file perlinimage.h
* Perlin Noise image generation class, contains function for generating procedural textures
*/



#include "base.h"
#include "perlin.h"
#include "texture.h"


namespace NeoEngine
{


/**
  * \class PerlinImage
  * \brief Perlin Noise image generation class
  *
  * Class contains functions to generate clouds,wood,marble textures
  *
  * \author Rob Wanders (forteq@softhome.net)
  */

class NEOENGINE_API PerlinImage : public ImageData
{
	public:

		/**
		* \enum PERLINIMAGETYPE
		* \brief Image type to be generated
		*/
		enum PERLINIMAGETYPE
		{
		  CLOUDS                        = 0x0001,
		  WOOD                          = 0x0002
		};


	protected:

		/*! Type of image */
		PERLINIMAGETYPE                 m_iType;

		/*! true if a image is generated, false if not */
		bool                            m_bGenerated;


	public:

		/**
		* Sets width and height
		* \param iWidth                 Width of image
		* \param iHeight                Height of image
		*/
		                                PerlinImage( int iWidth, int iHeight );

		/**
		* Generates an image
		* \param eType                  Type of image
		* \param iData                  Image generation data (uncloudiness, 0 completely clouded, 255 clear sky)
		*/
		void                            GenerateImage( PERLINIMAGETYPE eType, int iData );

		/**
		* \param iWidth                 New width
		*/
		void                            SetWidth( int iWidth );

		/**
		* \param iHeight                New height
		*/
		void                            SetHeight( int iHeight );
};


}; // namespace NeoEngine


#endif // __NEPERLINIMAGE_H

