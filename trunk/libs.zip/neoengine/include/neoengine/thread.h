/***************************************************************************
                          thread.h  -  Thread abstraction
                             -------------------
    begin                : Tue Feb 12 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, thread.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NETHREAD_H
#define __NETHREAD_H



#include "base.h"

#if defined(POSIX) || defined(__APPLE__)
#  include <pthread.h>
#  include <sys/time.h>
#endif


/**
  * \file thread.h
  * Thread abstraction
  */

namespace NeoEngine
{


//external classes
class TaskManager;


//forward declarations
class Thread;
class ThreadMethod;
class ThreadCallback;







/**
  * \class Thread
  * \brief Thread abstraction class
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Thread
{
	public:

		/*! Events */
		enum THREADEVENT
		{
			START,
			TERMINATE
		};


	protected:

#ifdef WIN32
		/*! Windows thread ID */
		unsigned long                 m_ulThread;
#elif defined(POSIX) || defined(__APPLE__)
		/*! Thread identifier/data */
		pthread_t                     m_kThread;
#endif		

		/*! User-specified data */
		void                         *m_pUserData;

		/*! Thread ID */
		int                           m_iThreadID;

		/*! Task manager */
		TaskManager                  *m_pkTaskManager;

		/*! Thread method object */
		ThreadMethod                 *m_pkMethod;		

		/*! Callback */
		ThreadCallback               *m_pkCallback;
		
		/*! Static counter of all thread objects */
		static int                    s_iThreadCounter;


	public:

		/*! Terminate flag */
		bool                          m_bTerminate;

		/*! Flag indicating thread has terminated */
		bool                          m_bTerminated;

		/*! Flag inficating thread has started */
		bool                          m_bStarted;


		/**
		* Create and start new thread
		* \param pkMethod             Thread method object
		* \param pData                User-specified data
		* \param pkCallback           Callback object recieving thread event notifications
		* \param pkTaskManager        Task manager owning thread (if any, null otherwise)
		*/
		                              Thread( ThreadMethod *pkMethod, void *pData, ThreadCallback *pkCallback = 0, TaskManager *pkTaskManager = 0 );

		/**
		* Terminate thread
		*/
		virtual                      ~Thread();

		/**
		* \return                     Thread method
		*/
		ThreadMethod                 *GetThreadMethod() { return m_pkMethod; }

		/**
		* \return                     User data
		*/
		void                         *GetUserData() { return m_pUserData; }

		/**
		* \return                     Thread ID
		*/
		int                           GetThreadID() const { return m_iThreadID; }

		/**
		* Needed for dll export of STL containers with UDTs under Win32
		*/
		bool operator < ( const Thread &rkThread ) const { return( m_iThreadID < rkThread.GetThreadID() ); }

		/**
		* Needed for dll export of STL containers with UDTs under Win32
		*/
		bool operator == ( const Thread &rkThread ) const { return( m_iThreadID == rkThread.GetThreadID() ); }
};




/**
  * \class ThreadMethod
  * \brief Method for entry point for thread execution
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ThreadMethod
{
	public:

		/**
		* Thread execution entry point
		* \param pkThread            Thread object
		* \param pData               Pointer to thread-specific data
		*/
		virtual void                *ThreadEntry( Thread *pkThread, void *pData ) = 0;

		/**
		* Sleep
		* \param iTime               Time to sleep in milliseconds
		*/
		static void                  Sleep( int iTime );
};






/**
  * \class ThreadCallback
  * \brief Callback class for thread event notification
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ThreadCallback
{
	public:

		/**
		* Called for thread event dispatch
		* \param iThreadID           Thread ID
		* \param eEvent              Event occured
		* \param pData               Pointer to thread-specific data
		*/
		virtual void                 ThreadEvent( int iThreadID, Thread::THREADEVENT eEvent, void *pData = 0 ) = 0;
};


}; // namespace NeoEngine


#endif

