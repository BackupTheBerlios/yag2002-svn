/***************************************************************************
                          skydome.h  -  Skydome class
                             -------------------
    begin                : Sat Dec 14 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, skydome.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NESKYDOME_H
#define __NESKYDOME_H


/**
  * \file neoengine/skydome.h
  * Skydome class
  */


#include "base.h"
#include "sceneentity.h"
#include "material.h"
#include "vertexbuffer.h"
#include "polygonbuffer.h"
#include "nemath.h"


namespace NeoEngine
{


//External classes
class Quaternion;


/**
  * \brief Wrapper class for skydome rendering
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SkyDome : public SceneEntity
{
	public:
		DefineVisitable()

	public:

		/**
		* \brief Skydome planes
		*/
		enum SKYDOMEPLANE
		{
		  /*! Front plane (-Z) */
		  FRONT        = 0,

		  /*! Back plane (+Z) */
		  BACK         = 1,

		  /*! Left plane (-X) */
		  LEFT         = 2,

		  /*! Right plane (+X) */
		  RIGHT        = 3,

		  /*! Up plane (+Y) */
		  UP           = 4,

		  /*! Number of planes in skydome */
		  NUMPLANES    = 5
		};


	protected:

		/*! Materials */
		MaterialPtr                   m_apkMaterial[NUMPLANES];

		/*! Vertex buffers */
		VertexBufferPtr               m_apkVertexBuffer[NUMPLANES];

		/*! Polygon buffer */
		PolygonBufferPtr              m_pkPolygonBuffer;

		/*! Orientation */
		Matrix                        m_kOrientation;



	public:


		/**
		*/
		                                SkyDome();

		/**
		*/
		virtual                        ~SkyDome();

		/**
		* Setup skydome
		* \param rkOrientation          Orientation of dome
		* \param fDistance              Distance to dome
		* \param fCurvature             Dome curvature
		* \param iSegments              Number of segments along each axis of the planes
		* \param fTiles                 Number of tiles of the material along each axis of the planes
		*/
		void                            Set( const Quaternion &rkOrientation, float fDistance, float fCurvature, int iSegments = 16, float fTiles = 1.0f );

		/**
		* Set material for plane
		* \param ePlane                 Skydome plane
		* \param pkMaterial             New material (will modify and set zbuffer mode)
		*/
		void                            SetMaterial( SKYDOMEPLANE ePlane, MaterialPtr &pkMaterial );

		/**
		* Render skydome
		* \param pkFrustum              Current view frustum
		* \param bForce                 If true, force rendering even if rendered this frame
		*/
		virtual bool                    Render( Frustum *pkFrustum = 0, bool bForce = false );
};


};


#endif
