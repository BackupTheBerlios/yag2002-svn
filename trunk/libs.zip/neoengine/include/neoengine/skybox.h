/***************************************************************************
                       skybox.h  -  Simple skybox class
                             -------------------
    begin                : Mon Nov 19 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, skybox.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NESKYBOX_H
#define __NESKYBOX_H


#include "base.h"
#include "sceneentity.h"
#include "material.h"
#include "vertexbuffer.h"
#include "polygonbuffer.h"


/**
  * \file neoengine/skybox.h
  * Skybox wrapper
  */


namespace NeoEngine
{


/**
  * \brief Wrapper class for skybox rendering
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SkyBox : public SceneEntity
{
	public:
		DefineVisitable()

	public:

		/**
		* \brief Skybox planes
		*/
		enum SKYBOXPLANE
		{
		  /*! -Z plane */
		  FRONT                                       = 0,

		  /*! +Z plane */
		  BACK                                        = 1,

		  /*! -X plane */
		  LEFT                                        = 2,

		  /*! +X plane */
		  RIGHT                                       = 3,

		  /*! +Y plane */
		  UP                                          = 4,

		  /*! -Y plane */
		  DOWN                                        = 5,

		  /*! Number of planes in box */
		  NUMPLANES                                   = 6
		};


	protected:

		/*! Vertex buffers  */
		VertexBufferPtr                               m_apkVertexBuffer[NUMPLANES];

		/*! Polygon buffer */
		PolygonStripBufferPtr                         m_pkPolygonBuffer;

		/*! Materials for all sides */
		MaterialPtr                                   m_apkMaterial[NUMPLANES];



	public:


		/**
		* \param fSize                                Size
		* \param rkOffset                             Offset vector
		*/
		                                              SkyBox( float fSize = 100.0f, const Vector3d &rkOffset = Vector3d::ZERO );

		/**
		* Deallocate memory, free textures
		*/
		virtual                                      ~SkyBox();


		/**
		* Set material for plane
		* \param ePlane                               Plane
		* \param pkMaterial                           New material
		*/
		void                                          SetMaterial( SKYBOXPLANE ePlane, MaterialPtr &pkMaterial );

		/**
		* Render skybox
		*/
		virtual bool                                  Render( Frustum *pkFrustum = 0, bool bForce = false );
};


};


#endif
