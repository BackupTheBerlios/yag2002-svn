/***************************************************************************
                            plane.h  -  3D plane
                             -------------------
    begin                : Wed Sep 18 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, plane.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEPLANE_H
#define __NEPLANE_H


#include "base.h"
#include "nemath.h"


/**
  * \file plane.h
  * 3D plane object
  */

  
namespace NeoEngine
{


/**
  * \class Plane
  * \brief 3D plane
  * Class describing a 3D plane
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Plane
{
	public:

		/*! Plane normal */
		Vector3d                      m_kNormal;

		/*! Distance to origo along normal */
		float                           m_fDistance;



		/**
		* Reset data (normal [0,0,0], distance 0)
		*/
		                                Plane() : m_kNormal( 0.0f, 0.0f, 0.0f ), m_fDistance( 0.0f ) {}

		/**
		* Copy data
		* \param rkPlane                Plane to copy data from
		*/
		                                Plane( const Plane &rkPlane ) : m_kNormal( rkPlane.m_kNormal ), m_fDistance( rkPlane.m_fDistance ) {}

		/**
		* Set data
		* \param rkNormal               Plane normal
		* \param fDistance              Distance
		*/
		                                Plane( const Vector3d &rkNormal, float fDistance ) : m_kNormal( rkNormal ), m_fDistance( fDistance ) {}

		/**
		* Set data
		* \param rkPointOne             First point in plane
		* \param rkPointTwo             Second point in plane
		* \param rkPointThree           Third point in plane
		*/
		                                Plane( const Vector3d &rkPointOne, const Vector3d &rkPointTwo, const Vector3d &rkPointThree ) : m_kNormal(), m_fDistance( 0.0f ) { m_kNormal = ( rkPointTwo - rkPointOne ) % ( rkPointThree - rkPointOne ); m_kNormal.Normalize(); m_fDistance = -( rkPointOne * m_kNormal ); }

		/**
		* Set data
		* \param rkNormal               Plane normal
		* \param rkPoint                Point in plane
		*/
		                                Plane( const Vector3d &rkNormal, const Vector3d &rkPoint ) : m_kNormal( rkNormal ), m_fDistance( -( rkPoint * m_kNormal ) ) {}

		/**
		* Set data
		* \param rkNormal               Plane normal
		* \param fDistance              Distance
		*/
		inline void                     Set( const Vector3d &rkNormal, float fDistance ) { m_kNormal = rkNormal, m_fDistance = fDistance; }

		/**
		* Set data
		* \param rkPointOne             First point
		* \param rkPointTwo             Second point
		* \param rkPointThree           Third point
		*/
		inline void                     Set( const Vector3d &rkPointOne, const Vector3d &rkPointTwo, const Vector3d &rkPointThree ) { m_kNormal = ( rkPointTwo - rkPointOne ) % ( rkPointThree - rkPointOne ); m_kNormal.Normalize(); m_fDistance = -( rkPointOne * m_kNormal ); }

		/**
		* Set data
		* \param rkNormal               Plane normal
		* \param rkPoint                Point in plane
		*/
		inline void                     Set( const Vector3d &rkNormal, const Vector3d &rkPoint ) { m_kNormal = rkNormal; m_fDistance = -( rkPoint * m_kNormal ); }
		                                
		/**
		* Get distance from plane to point
		* \return                       Distance
		*/
		inline float                    Distance( const Vector3d &rkPoint ) const { return( m_kNormal * rkPoint + m_fDistance ); }

		/**
		* \return                       A point on the plane
		*/
		inline Vector3d               GetPointOnPlane() const { return( m_kNormal * -m_fDistance ); }

		/**
		* Query if planes are identical
		* \param rkPlane                Plane to compare with
		*/
		inline bool                     operator == ( const Plane &rkPlane ) const { return( ( m_kNormal == rkPlane.m_kNormal ) && ( m_fDistance == rkPlane.m_fDistance ) ); }
};


}; // namespace NeoEngine



#endif  // __NEPLANE_H
