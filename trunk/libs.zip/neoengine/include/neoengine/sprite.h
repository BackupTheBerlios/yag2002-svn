/***************************************************************************
                      sprite.h  -  Quad always facing camera
                             -------------------
    begin                : Tue Jun 4 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, sprite.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NESPRITE_H
#define __NESPRITE_H


#include "base.h"
#include "sceneentity.h"
#include "material.h"
#include "vertexbuffer.h"
#include "polygonbuffer.h"
#include "vertex.h"


/**
  * \file sprite.h
  * Sprite classes
  */


namespace NeoEngine
{


//External classes
class PolygonBuffer;





/**
  * \class Sprite
  * \brief A sprite always faces the camera, but can have size, position and rotation around viewing axis
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Sprite : public SceneEntity
{
	public:

		DefineVisitable();

	protected:

		/*! Size */
		float                                         m_afSize[2];

		/*! Rotation around viewing axis */
		float                                         m_fRotation;


	public:

		/*! Vertex buffer */
		VertexBufferPtr                             m_pkVertexBuffer;

		/*! Polygon buffer */
		PolygonStripBufferPtr                       m_pkPolygonBuffer;

		/*! Material */
		MaterialPtr                                 m_pkMaterial;
		


		/**
		* Create vertex and polygon buffers, setup position (and optionally default texture) data in vertex buffer
		* \param pkMaterial                           Material for sprite
		* \param fSizeX                               Size in x direction
		* \param fSizeY                               Size in y direction
		* \param pkFormat                             Vertex format declaration
		*/
		                                              Sprite( const MaterialPtr &pkMaterial, float fSizeX = 0.0f, float fSizeY = 0.0f, const VertexDeclaration *pkFormat = &TexVertex::s_kDecl );

		/**
		*/
		virtual                                      ~Sprite();


		/**
		* Render the sprite
		* \param pkFrustum                            Current frustum
		* \param bForce                               If true, force rendering even if rendered this frame
		*/
		virtual bool                                  Render( Frustum *pkFrustum = 0, bool bForce = false );

		/**
		* Set sprite size
		* \param fSizeX                               Size in x direction
		* \param fSizeY                               Size in y direction
		* \param bSetDefaultTexCoords                 flag to set default texcoords
		*/
		void                                          SetSize( float fSizeX, float fSizeY, bool bSetDefaultTexCoords = false );

		/**
		* Set rotation around view axis
		* \param fRot                                 Rotation in radians
		*/
		void                                          SetRotation( float fRot ) { m_fRotation = fRot; }

		/**
		* Rotate sprite around view axis
		* \param fRot                                 Rotation in radians
		*/
		void                                          Rotate( float fRot ) { m_fRotation += fRot; }
};


}; // namespace NeoEngine


#endif
