/***************************************************************************
                      renderwindow.h  -  Render window data
                             -------------------
    begin                : Thu Mar 27 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, renderwindow.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NERENDERWINDOW_H
#define __NERENDERWINDOW_H


#include "base.h"
#include "renderresolution.h"
#include "rendercaps.h"


/**
  * \file renderwindow.h
  * Render window data
  */


namespace NeoEngine
{


/**
  * \brief Device and/or OS specific data for window.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API RenderWindow
{
	public:

		/**
		* \brief Window flags
		*/
		enum RENDERWINDOWFLAG
		{
		  /*! Window was created by device, only for internal use, DO NOT set this flag manually */
		  DEVICECREATED                               = 0x00000001,

		  /*! Use specified window dimensions */
		  USEDIMENSIONS                               = 0x00000004
		};


		/*! Flags */
		unsigned int                                  m_uiFlags;

#ifdef WIN32

		/*! Window handle (real type [HWND]) */
		void                                         *m_hWnd;

		/*! Application instance handle (real type [HINSTANCE]) */
		void                                         *m_hInstance;

		/*! Requested adapter ordinal, 0 for default */
		unsigned int                                  m_uiAdapter;

		/*! Padding */
		void                                         *m_apData[5];

#elif defined(__APPLE__)

		/*! Window */
		void                                         *m_pWindow;

		/*! Padding */
		void                                         *m_apData[7];

#elif defined(POSIX)

		/*! Window (real type [Window]) */
		void                                         *m_Window;

		/*! Display (real type [Display*]) */
		void                                         *m_pDisplay;

		/*! Padding */
		void                                         *m_apData[6];

#else

		/*! Padding */
		void                                         *m_apData[8];

#endif

		/*! Render window name */
		std::string                                   m_strWindowName;

		/*! Capabilities */
		RenderCaps                                    m_kCaps;

		/*! Original desktop resolution */
		RenderResolution                              m_kDesktopResolution;

		/*! Window resolution */
		RenderResolution                              m_kResolution;


		/**
		* Reset data
		*/
		                                              RenderWindow() { Reset(); }

		/**
		* Set data
		* \param rstrWindowName                       Window name
		* \param rkCaps                               Render caps
		* \param rkResolution                         Window resolution
		*/
		                                              RenderWindow( const std::string &rstrWindowName, const RenderCaps &rkCaps, const RenderResolution &rkResolution ) : m_strWindowName( rstrWindowName ), m_kCaps( rkCaps ), m_kResolution( rkResolution ) { ResetPlatformData(); }

		/**
		* Reset platform-specific data
		*/
		void                                          ResetPlatformData()
		{
#if defined( WIN32 )
			m_hWnd      = 0;
			m_hInstance = 0;
			m_uiAdapter = 0;
#elif defined( __APPLE__ )
			m_pWindow   = 0;
#elif defined( POSIX )
			m_Window    = 0;
			m_pDisplay  = 0;
#endif
		}

		/**
		* Reset data
		*/
		void                                          Reset() { ResetPlatformData(); m_strWindowName = ""; m_kCaps.ResetAll(); memset( &m_kDesktopResolution, 0, sizeof( RenderResolution ) ); memset( &m_kResolution, 0, sizeof( RenderResolution ) ); }
};


};


#endif

