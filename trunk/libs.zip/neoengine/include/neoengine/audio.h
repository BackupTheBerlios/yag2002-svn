/***************************************************************************
                           audio.h  -  Audio device
                             -------------------
    begin                : Wed Mar 17 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, audio.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEAUDIO_H
#define __NEAUDIO_H

#include "base.h"
#include "sound.h"
#include "renderwindow.h"

#include <string>
#include <vector>


/** 
  * \file audio.h
  * Audio device
  */


namespace NeoEngine
{


#ifdef WIN32

#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif

#  ifndef __HAVE_VECTOR_NESOUNDCODEC
     UDTVectorEXPIMP( class SoundCodec* );
#    define __HAVE_VECTOR_NESOUNDCODEC
#  endif

#endif


/**
  * \brief Audio device
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API AudioDevice
{
	friend class Core;

	protected:

		/*! Device module */
		ModulePtr                                          m_pkModule;

		/*! Loaders */
		std::vector< SoundCodec* >                         m_vpkCodecs;

		/*! File manager */
		FileManager                                       *m_pkFileManager;


	public:

		/**
		* \param pkFileManager                             File manager, will use core global object if null (default)
		*/
		                                                   AudioDevice( FileManager *pkFileManager = 0 );

		/**
		*/
		virtual                                           ~AudioDevice();

		/**
		* Open the audio device
		* \param rkWindow                                  Window to initialize sound device in
		*/
		virtual bool                                       Open( const RenderWindow &rkWindow ) = 0;

		/**
		* Close the audio device
		*/
		virtual void                                       Close() = 0;

		/**
		* Register new sound file type loader (codec)
		* \param rstrName                                  Codec name
		* \return                                          true if successful, false otherwise
		*/
		bool                                               LoadSoundCodec( const std::string &rstrName );

		/**
		* Load a sound file
		* \param rstrFilename                              File name
		* \return                                          Ptr to sound
		*/
		virtual Sound                                     *LoadSound( const std::string &rstrFilename ) = 0;
};


};


#endif

