/***************************************************************************
             entity.h  -  Base class for objects processing input
                             -------------------
    begin                : Mon Sep 11 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, entity.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NEINPUTENTITY_H
#define __NEINPUTENTITY_H


/**
  * \file inputentity.h
  * Base class for objects processing input
  */


#include "base.h"
#include "activator.h"

#include <string>


namespace NeoEngine
{


//External classes
class InputGroup;
class InputEvent;


/**
  * \brief Interface for objects processing input
  * Input entites receive input events from the master
  * InputGroup object the entity is attached to. Derived
  * from Activator for easy on/off management. A deactivated
  * input entity will not receive any events from the
  * master InputGroup object.
  *
  * Derived classes must implement the Input process method
  * to handle the events received.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API InputEntity : public virtual Activator
{
	protected:

		/*! Input group we belong to */
		InputGroup                                   *m_pkGroup;


	public:

		/**
		* Attach to group
		* \param pkGroup                              Input group to attach to
		*/
		                                              InputEntity( InputGroup *pkGroup = 0 );

		/**
		* Detach from group
		*/
		virtual                                      ~InputEntity();

		/**
		* Attach to an input group (will detach from any current group)
		* \param pkGroup                              Input group to attach to
		*/
		void                                          AttachToGroup( InputGroup *pkGroup );
		
		/**
		* Process input
		* \param pkEvent                              Event
		*/
		virtual void                                  Input( const InputEvent *pkEvent ) = 0;
};


}; // namespace NeoEngine


#endif
