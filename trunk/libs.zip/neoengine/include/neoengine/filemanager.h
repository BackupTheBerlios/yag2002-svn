/***************************************************************************
                 filemanager.h  -  File and package management
                             -------------------
    begin                : Fri Nov 2 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, filemanager.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEFILEMANAGER_H
#define __NEFILEMANAGER_H


/**
* \file filemanager.h
* File management superclass
*/


#include "base.h"

#include <string>

using namespace std;

namespace NeoEngine
{


//external classes
class Package;
class Directory;
class File;
class FileCodec;



/**
  * \brief Package and file manager
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class FileManager
{
	protected:

		/*! File manager counter */
		static int                                     s_iFileManagers;


	protected:

		/*! Name */
		std::string                                    m_strName;

		/*! Root directory */
		Directory                                     *m_pkRoot;

		/*! Change flag */
		bool                                           m_bChanged;

	protected:

		/**
		* Returns the package
		* \param pkParent                             Parent directory
		* \param rstrFile                             Package file name
		* \param pkManager                            File manager we are connected to
		* \return                                     The loaded package or 0 on failure
		*/
		virtual Package                               *DeterminePackageType( Directory *pkParent, const string &rstrFile, FileManager *pkManager );


	public:

		/**
		* \param rstrName                              Name of file manager
		*/
		                                               FileManager( const std::string &rstrName );

		/**
		*
		*/
		virtual                                       ~FileManager();

		/**
		* Register new file type loader (codec)
		* \param iFileFlag                             File flag this codec parses
		* \param rstrName                              Codec name
		* \return                                      true if successful, false otherwise
		*/
		static bool                                    LoadCodec( const std::string &rstrName );

		/**
		* Find matching codec
		* \param iFileFlag                             File flag
		* \return                                      Ptr to codec object, null if no match
		*/
		static FileCodec                              *FindCodec( int iFileFlag );

		/**
		* Add a resource package
		* \param rstrPackage                           Package name
		* \return                                      false if error loading/parsing package data, true if successful
		*/
		bool                                           AddPackage( const std::string &rstrPackage );

		/**
		* Search for file
		* \param rstrName                              File name
		* \return                                      Pointer to file object (not opened!) if found, null ptr if not found
		*/
		File                                          *GetByName( const std::string &rstrName );

		/**
		* \return                                      Root directory
		*/
		Directory                                     *GetRoot() { return m_pkRoot; }

		/**
		* Clear file hierarchy
		*/
		void                                           Clear();

		/**
		* Query if hierarchy has changed since last call to HasChanged
		* \return                                      true if hierarchy has changed, false if not
		*/
		bool                                           HasChanged();

		/**
		* Print hierarchy
		* \param iDepth                                Current recurse depth
		*/
		void                                           PrintHierarchy( int iDepth = 0 );
};


};


#endif
