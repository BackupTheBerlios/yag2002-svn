/***************************************************************************
          npacpackage.h  -  File management in virtual file system
                             -------------------
    begin                : Sat Jun 12 2004
    copyright            : (C) 2004 by emedia-solutions wolf
    email                : markus@emedia-solutions-wolf.de
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, npacpackage.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.
 Portions created by Markus Wolf are Copyright (C) 2004
 emedia-solutions wolf. All Rights Reserved.

 ***************************************************************************/

#ifndef __NENPACPACKAGE_H
#define __NENPACPACKAGE_H


/**
  * \file package.h
  * File management in packages
  */


#include "package.h"
#include "base.h"
#include "loadableentity.h"
#include "directory.h"

#include <string>


namespace NeoEngine
{


// External classes
class FileManager;


/**
  * \brief File management in packages
  * A package can both contain real files and virtual files (read from package file).
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API NpacPackage : public Package
{
	protected:

		/**
		* Skips the file header if necessary
		*/
		virtual void                                  SkipHeader();

		/**
		* Read cluster data from file. Recursive.
		* \param pkDirectory                          Directory to read
		*/
		virtual void                                  ReadCluster( Directory *pkDirectory );


  public:

		/**
		* Open and parse package file. You can also put in a directory in the normal file system and it will be recursivly parsed
		* \param pkParent                             Parent directory
		* \param rstrFile                             Package file name
		* \param pkManager                            File manager we are connected to
		*/
		                                              NpacPackage( Directory *pkParent, const std::string &rstrFile, FileManager *pkManager );

		/**
		* Deallocate hierarchy
		*/
		virtual                                      ~NpacPackage();
};


}; // namespace NeoEngine


#endif  // __NENPACPACKAGE_H
