/***************************************************************************
           nodeanimator.h  -  Animator controller classes for nodes
                             -------------------
    begin                : Sun Jan 26 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, nodeanimator.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NENODEANIMATOR_H
#define __NENODEANIMATOR_H


#include "base.h"
#include "keyframe.h"
#include "animation.h"
#include "animator.h"


/**
  * \file nodeanimator.h
  * Animator control classes for nodes
  */


namespace NeoEngine
{


/**
  * \brief Data for a node keyframe
  * A node keyframe holds rotation and translation data
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API NodeKeyframe : public Keyframe
{
	public:

		/*! Rotation */
		Quaternion                         m_kRotation;

		/*! Translation */
		Vector3d                           m_kTranslation;

		/**
		* \param fTime                     Timestamp
		*/
		                                   NodeKeyframe( float fTime = 0.0f ) : Keyframe( fTime ) {}

		/**
		* \param rkKeyframe                Keyframe reference object
		*/
		                                   NodeKeyframe( const NodeKeyframe &rkKeyframe ) : Keyframe( rkKeyframe ), m_kRotation( rkKeyframe.m_kRotation ), m_kTranslation( rkKeyframe.m_kTranslation ) {}

		/**
		*/
		virtual                           ~NodeKeyframe() {}
};


#ifdef WIN32

#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif

class NodeKeyframe;
class NodeAnimation;

#  ifndef __HAVE_VECTOR_NENODEKEYFRAME
     UDTVectorEXPIMP( NodeKeyframe* );
#    define __HAVE_VECTOR_NENODEKEYFRAME
#  endif

#  ifndef __HAVE_VECTOR_NENODEANIMATION
     UDTVectorEXPIMP( NodeAnimation* );
#    define __HAVE_VECTOR_NENODEKEYFRAME
#  endif

#  ifdef _MSC_VER
#    ifndef __HAVE_NEANIMATION_NENODEKEYFRAME
       EXPIMP_TEMPLATE template class NEOENGINE_API Animation< NodeKeyframe >;
#      define __HAVE_NEANIMATION_NENODEKEYFRAME
#    endif
#    ifndef __HAVE_NEANIMATIONBLENDSTAGE_NENODEANIMATION
       EXPIMP_TEMPLATE template class NEOENGINE_API AnimationBlendStage< NodeAnimation >;
#      define __HAVE_NEANIMATIONBLENDSTAGE_NENODEANIMATION
#    endif
#  endif

#  ifndef __HAVE_VECTOR_NEANIMATIONBLENDSTAGE_NENODEANIMATION
     UDTVectorEXPIMP( AnimationBlendStage< NodeAnimation >* );
#    define __HAVE_VECTOR_NEANIMATIONBLENDSTAGE_NENODEANIMATION
#  endif

#  ifdef _MSC_VER
#    ifndef __HAVE_NEANIMATORCONTROLLER_NENODEANIMATION
       EXPIMP_TEMPLATE template class NEOENGINE_API AnimatorController< NodeAnimation >;
#      define __HAVE_NEANIMATORCONTROLLER_NENODEANIMATION
#    endif
#  endif

#endif


/**
  * \brief An animation for a node
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API NodeAnimation : public Animation< NodeKeyframe >
{
	public:

		/**
		*/
		                                   NodeAnimation() : Animation<NodeKeyframe>() {}

		/**
		* \param rkAnimation               Reference animation object
		*/
		                                   NodeAnimation( const NodeAnimation &rkAnimation ) : Animation< NodeKeyframe >( rkAnimation ) {}

		/**
		*/
		virtual                           ~NodeAnimation() {}
};


/**
  * \brief Animator controller for scene nodes
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API NodeAnimatorController : public AnimatorController< NodeAnimation >
{
	protected:

		/**
		* Blend in a new stage in final data
		* \param pkDstAnim                                 Destination animation
		* \param fWeight                                   Blend weight factor
		* \param pvbMask                                   Mask array
		*/
		virtual void                                       BlendStage( NodeAnimation *pkDstAnim, float fWeight, std::vector< bool > *pvbMask );


	public:

		/*! Final blended position */
		Vector3d                                           m_kTranslation;

		/*! Final blended rotation */
		Quaternion                                         m_kRotation;

		/*! Final blended scaling */
		float                                              m_fScaling;


		/**
		*/
		                                                   NodeAnimatorController() : AnimatorController< NodeAnimation >(), m_fScaling( 1.0f ) {}

		/**
		* \param rkController                              Reference controller object to copy
		*/
		                                                   NodeAnimatorController( const NodeAnimatorController &rkController ) : AnimatorController< NodeAnimation >( rkController ), m_kTranslation( rkController.m_kTranslation ), m_kRotation( rkController.m_kRotation ), m_fScaling( rkController.m_fScaling ) {}

		/**
		*/
		virtual                                           ~NodeAnimatorController() {}
};


};


#endif
