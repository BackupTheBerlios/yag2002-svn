/***************************************************************************
                     perlin.h  -  Perlin noise generator
                             -------------------
    begin                : Mon Oct 14 2002
    copyright            : (C) 2002 by Rob Wanders
    email                : forteq@softhome.net
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, perlin.h

 The Initial Developer of the Original Code is Rob Wanders.
 Portions created by Rob Wanders are Copyright (C) 2002
 Rob Wanders. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEPERLIN_H
#define __NEPERLIN_H


/**
  * \file perlin.h
  * Perlin Noise base class, contains function for generating 1d,2d and 3d perlin noise
  */


#include "base.h"


namespace NeoEngine
{


/**
  * \brief Perlin Noise generation class
  *
  * Perlin Noise generation class. Class contains functions to generate 
  * 1D, 2D and 3D perlin noise.
  *
  * \author Rob Wanders (forteq@softhome.net)
  */
class NEOENGINE_API PerlinNoise
{
	protected:

		/*! Prime number one */
		unsigned int                    m_uiPrimeOne;

		/*! Prime number two */
		unsigned int                    m_uiPrimeTwo;

		/*! Prime number three */
		unsigned int                    m_uiPrimeThree;

		/*! Lookup table */
		float                          *m_afLookUp;

		/*! Maximum x value (for lookup table) */
		unsigned int                    m_uiMaxX;

		/*! Maximum y value (for lookup table) */
		unsigned int                    m_uiMaxY;

		/*! Maximum z value (for lookup table) */
		unsigned int                    m_uiMaxZ;


	public:

		/**
		* Set standard prime numbers
		*/
		                                PerlinNoise();

		/**
		* Free Lookup table
		*/
		                               ~PerlinNoise();

		/**
		* Sets new (random) prime numbers
		*/
		void                            NewPrimeNumbers();

		/**
		* Function checks if the given value is a prime number.
		* \param uiA                    number
		* \return                       returns true if the number is a prime, false when it's not.
		*/
		bool                            IsPrime( unsigned int uiA );

		/**
		* Prime number generator. Prime numbers are used by the pseudo-random number generator. 
		* If you use different primes each time you generate a texture, you'll get unique textures.
		* Which comes in handy if you want to create natural-looking textures.
		* \return                       a random prime number
		*/
		unsigned int                    RandomPrime();

		/**
		* 1d Pseude-random number generator. Generates a pseudo-random number based upon one value(dimension).
		* \param iX                     x value
		* \return                       Returns a number between -1,1
		*/
		float                           Noise( int iX );

		/**
		* 2d Pseudo-random number generator. Generates a pseudo-random number based upon two values(dimensions).
		* \param iX                     x value
		* \param iY                     y value
		* \return                       Returns a number between -1,1
		*/
		float                           Noise( int iX, int iY );

		/**
		* 3d Pseudo-random number generator. Generates a pseudo-random number based upon three values(dimensions).
		* \param iX                     x value
		* \param iY                     y value
		* \param iZ                     z value
		* \return                       Returns a number between -1,1
		*/
		float                           Noise( int iX, int iY, int iZ );

		/**
		* Standard cosine interpolate function. Interpolates between two points. It interpolates between two points, using the third input.
		* \param fA                     first point
		* \param fB                     second point
		* \param fX                     point between the first two point.
		* \return                       Interpolated value. When fX is 0, fA is returned. When fX is 1, fB is returned. And when dX is a value between 0 and 1, a value between fA and fB is returned.
		*/
		float                           Interpolate( float fA, float fB, float fX );

		/**
		* 1d Smooth function. Function takes the average of the neighbours to make the noise look less sharp.
		* \param iX                     x value
		* \return                       smooth 1d noise value
		*/
		float                           SmoothNoise( int iX );

		/**
		* 2d Smooth function. Function takes the average of the neigbours (sides,corners,center) to make it look less sharp.
		* \param iX                     x value
		* \param iY                     y value
		* \return                       smooth 2d noise value
		*/
		float                           SmoothNoise( int iX, int iY );

		/**
		* 3d Smooth function. Functions takes the average of the neighbours to make it look less sharp.
		* \param iX                     x value
		* \param iY                     y value
		* \param iZ                     z value
		* \return                       smooth 3d noise value
		*/
		float                           SmoothNoise( int iX, int iY, int iZ );

		/**
		* 1d Interpolate function. Function interpolates between the smoothed noise values.
		* \param fX                     x value
		* \return                       smooth interpolated 1d noise value
		*/
		float                           InterpolateNoise( float fX );

		/**
		* 2d Interpolate function. Function interpolates between the smoothed 2d noise values.
		* \param fX                     x value
		* \param fY                     y value
		* \return                       smooth interpolated 2d noise value
		*/
		float                           InterpolateNoise( float fX, float fY );

		/**
		* 3d Interpolate function. Function interpolates between the smoothed 3d noise values.
		* \param fX                     x value
		* \param fY                     y value
		* \param fZ                     z value
		* \return                       smooth interpolated 3d noise value
		*/
		float                           InterpolateNoise( float fX, float fY, float fZ );

		/**
		* 1d Perlin Noise function. Generates perlin noise, using the given amplitude and frequency.
		* \param fX                     x value
		* \param fAmplitude             amplitude
		* \param fXfrequency            x frequency
		* \return                       1d noise
		*/
		float                           PerlinNoise1d( float fX, float fAmplitude, float fXfrequency );

		/**
		* 2d Perlin Noise function. Generates perlin noise, using the given amplitude and frequency.
		* \param fX                     x value
		* \param fY                     y value
		* \param fAmplitude             amplitude
		* \param fXFrequency            x frequency
		* \param fYFrequency            y frequency
		* \return                       2d noise
		*/
		float                           PerlinNoise2d( float fX, float fY, float fAmplitude, float fXFrequency, float fYFrequency );

		/**
		* 3d Perlin Noise function. Generates perlin noise, using the given amplitude and frequency.
		* \param fX                     x value
		* \param fY                     y value
		* \param fZ                     z value
		* \param fAmplitude             amplitude
		* \param fXfrequency            x frequency
		* \param fYfrequency            y frequency
		* \param fZfrequency            z frequency
		* \return                       3d noise
		*/
		float                           PerlinNoise3d( float fX, float fY, float fZ, float fAmplitude, float fXfrequency, float fYfrequency, float fZfrequency );

		/**
		* Generates the 1d noise and stores it in the lookup table (for faster processing).
		* \param uiMaxX                 max x value (generates noise from 0 to uiMaxX)
		*/
		void                            GenerateLookup( unsigned int uiMaxX );

		/**
		* Generates the 2d noise and stores it in the lookup table (for faster processing).
		* \param uiMaxX                 max x value (generates noise from 0 to uiMaxX)
		* \param uiMaxY                 max y value (generates noise from 0 to uiMaxY)
		*/
		void                            GenerateLookup( unsigned int uiMaxX, unsigned int uiMaxY );

		/**
		* Generates the 3d noise and stores it in the lookup table (for faster processing).
		* \param uiMaxX                 max x value (generates noise from 0 to uiMaxX)
		* \param uiMaxY                 max y value (generates noise from 0 to uiMaxY)
		* \param uiMaxZ                 max z value (generates noise from 0 to uiMaxZ)
		*/
		void                            GenerateLookup( unsigned int uiMaxX, unsigned int uiMaxY, unsigned int uiMaxZ );
};


}; // namespace NeoEngine


#endif // __NEPERLIN_H
