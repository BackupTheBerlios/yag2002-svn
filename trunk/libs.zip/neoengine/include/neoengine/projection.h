/***************************************************************************
                       projection.h  -  Projection modes
                             -------------------
    begin                : Thu Mar 27 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, projection.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NEPROJECTION_H
#define __NEPROJECTION_H


/**
  * \file projection.h
  * Projection modes
  */

#include "base.h"
#include "nemath.h"


namespace NeoEngine
{


/*! External classes */
class Viewport;





/**
  * \class Projection
  * \brief Data describing a projection mode
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Projection
{
	public:

		/**
		* \enum PROJECTIONMODE
		* \brief Projection modes
		*/
		enum PROJECTIONMODE
		{
		  /*! Invalid mode */
		  INVALIDPROJECTION                           = -1,

		  /*! Perspective projection */
		  PERSPECTIVE                                 = 0,

		  /*! Orthographic projection */
		  ORTHOGRAPHIC                                = 1,

		  /*! Custom projection */
		  CUSTOM                                      = 2
		};


		/*! Projection mode */
		PROJECTIONMODE                                m_eMode;

		/*! Z near clipping plane distance */
		float                                         m_fZNear;

		/*! Z far clipping plane distance */
		float                                         m_fZFar;

		/*! Projection matrix */
		Matrix                                        m_kMatrix;


		/**
		*/
		                                              Projection();

		/**
		* Build projection matrix
		* \param rkViewport                           Current viewport
		*/
		virtual void                                  BuildProjection( const Viewport &rkViewport ) {}
};





/**
  * \class PerspectiveProjection
  * \brief Data describing perspective projection mode
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API PerspectiveProjection : public Projection
{
	public:

		/*! FOV angle */
		float                                         m_fFOV;

		/**
		* Set default values
		*/
		                                              PerspectiveProjection();


		/**
		* Build projection matrix
		* \param rkViewport                           Current viewport
		*/
		virtual void                                  BuildProjection( const Viewport &rkViewport );
};







/**
  * \class OrthographicProjection
  * \brief Data describing orthographic projection mode
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API OrthographicProjection : public Projection
{
	public:

		/*! Left plane */
		float                                         m_fLeft;

		/*! Top plane */
		float                                         m_fTop;

		/*! Right plane */
		float                                         m_fRight;

		/*! Bottom plane */
		float                                         m_fBottom;

		/*! Z near plane */
		float                                         m_fZNear;

		/*! Z far plane */
		float                                         m_fZFar;

		/**
		* Set default values
		*/
		                                              OrthographicProjection();


		/**
		* Build projection matrix
		* \param rkViewport                           Current viewport
		*/
		virtual void                                  BuildProjection( const Viewport &rkViewport );
};


}; // namespace NeoEngine


#endif  // __NEPROJECTION_H

