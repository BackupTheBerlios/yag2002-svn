/***************************************************************************
          adaptor.h  -  Adaptor classes between hierarchy node types
                             -------------------
    begin                : Wed Nov 26 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, adaptor.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEADAPTOR_H
#define __NEADAPTOR_H


/**
  * \file adaptor.h
  * Adaptor classes between hierarchy node types
  */


#include "base.h"
#include "bone.h"
#include "scenenode.h"
#include "skeleton.h"


namespace NeoEngine
{


/**
  * \brief Adaptor between bone and scene node
  * An adaptor allowing scene nodes to be attached to bones
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API BoneAdaptor : public virtual BaseVisitable, public Bone
{
	friend class Skeleton;

	public:

		DefineVisitable();


	protected:

		/*! Skeleton */
		Skeleton                                            *m_pkSkeleton;

		/*! Node type */
		SceneNode                                           *m_pkSceneNode;


	public:

		/**
		* Create adaptor for a scene node
		* \param pkSkeleton                                  Skeleton object
		* \param pkParent                                    Parent bone
		* \param pkNode                                      Scene node
		*/
		inline                                               BoneAdaptor( Skeleton *pkSkeleton, Bone *pkParent, SceneNode *pkNode );

		/**
		* Create adaptor from reference object (including duplicating child nodes)
		* \param rkNode                                      Reference adaptor object to copy
		* \param pkSkeleton                                  Skeleton object for new adaptor
		* \param pkParent                                    Parent bone for new adaptor
		*/
		inline                                               BoneAdaptor( BoneAdaptor &rkNode, Skeleton *pkSkeleton, Bone *pkParent );

		/**
		* Deallocates child nodes and detaches from parent
		*/
		virtual                                             ~BoneAdaptor();

		/**
		* Set world update flag. If flag is set, a call to any of the
		* GetWorldScaling, GetWorldRotation, GetWorldTranslation will
		* cause world cache data to be updated. Optionally recurses on
		* all child nodes (default).
		* \param bRecurse                                    Recurse on children
		*/
		inline virtual void                                  NotifyUpdate( bool bRecurse = true );

		/**
		* Duplicate adaptor
		* \param pkSkeleton                                  Skeleton object for new adaptor
		* \param pkParent                                    Parent bone for new adaptor
		* \return                                            New adaptor
		*/
		virtual BoneAdaptor                                 *Duplicate( Skeleton *pkSkeleton, Bone *pkParent );
};


};


#endif
