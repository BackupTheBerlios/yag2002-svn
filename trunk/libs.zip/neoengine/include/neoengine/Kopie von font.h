/***************************************************************************
                    font.h  -  Font class for text rendering
                             -------------------
    begin                : Fri Nov 16 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, font.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEFONT_H
#define __NEFONT_H


#include "base.h"
#include "loadableentity.h"
#include "texture.h"
#include "material.h"
#include "pointer.h"


/**
  * \file font.h
  * Font support for printing text to render window
  */

namespace NeoEngine
{


// External classes
class RenderDevice;



/**
  * \brief Data for a single character in font
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API FontCharacter
{
	public:

		/*! U coord in texture */
		float                           m_fU;

		/*! V coord in texture */
		float                           m_fV;

		/*! Width in texture coords */
		float                           m_fUWidth;

		/*! Height in texture coords */
		float                           m_fVHeight;

		/*! Pixel X coord in texture */
		int                             m_iX;

		/*! Pixel Y coord in texture */
		int                             m_iY;

		/*! Width in pixels */
		int                             m_iWidth;

		/*! Height in pixels */
		int                             m_iHeight;
};





/**
  * \brief Font abstraction. Loads, prints and other methods.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Font : public RefCounter, public LoadableEntity
{
	friend class FontManager;

	public:

		/**
		* \enum FONTALIGN
		* \brief Font alignment
		*/
		enum FONTALIGN
		{
		  LEFT,
		  RIGHT
		};

		/**
		* \enum FONTLINEWRAP
		* \brief Line wrapping modes
		*/
		enum FONTLINEWRAP
		{
			NOWRAP,
			WORDWRAP
		};



	protected:

		/*! Material */
		MaterialPtr                     m_pkMaterial;

		/*! Characters */
		FontCharacter                   m_akCharacters[256];

		/*! Space between characters */
		int                             m_iSpacing;

		/*! Line height */
		int                             m_iLineHeight;

		/*! Width of space character */
		int                             m_iSpaceWidth;

		/*! Clip box x coord */
		int                             m_iClipX;

		/*! Clip box y coord */
		int                             m_iClipY;

		/*! Clip box width */
		int                             m_iClipWidth;

		/*! Clip box height */
		int                             m_iClipHeight;

		/*! Line wrap flag */
		FONTLINEWRAP                    m_eLineWrap;

		/*! Font name */
		std::string                     m_strName;

		/*! Font manager */
		FontManager                    *m_pkFontManager;

		/*! Word separators */
		std::string                     m_strWordSeparators;

		/*! Font horizontal alignment */
		FONTALIGN                       m_eHorizontalAlign;

		/*! Current color */
		Color                           m_kColor;


		/**
		* Main loader method. Called by LoadableEntity to load object if file was opened successfully
		* \param uiFlags                Loader flags (currently ignored for fonts)
		* \return                       true if load was successful, false otherwise
		*/
		bool                            LoadNode( unsigned int uiFlags );


		/**
		* Fonts are created by the font manager
		* \param pkFontManager          Font manager
		*/
		                                Font( FontManager *pkFontManager );


  public:

		/*! Subpixel texture alignment set by render device */
		static NE_STATIC float          s_fSubPixelOffset;

		/**
		*/
		virtual                        ~Font();

		/**
		* Printf to screen
		* \param iX                     Start x coord in pixels
		* \param iY                     Start y coord in pixels
		* \param pszFormat              Format specifier (see printf function)
		* \return                       number of lines printed
		*/
		int                             Printf( int iX, int iY, const char *pszFormat, ... );

		/**
		* Printf to screen
		* \param fX                     Start x coord in screen coords ( range 0.0f < x < 1.0f )
		* \param fY                     Start y coord in screen coords ( range 0.0f < y < 1.0f )
		* \param pszFormat              Format specifier (see printf function)
		* \return                       number of lines printed
		*/
		int                             Printf( float fX, float fY, const char *pszFormat, ... );

		/**
		* Set clip box. Will not blit any pixels outside this box, and will (optionally) line wrap
		* \param iX                     x coordinate of clip box
		* \param iY                     y coordinate
		* \param iWidth                 width
		* \param iHeight                height
		*/
		void                            SetClipBox( int iX, int iY, int iWidth, int iHeight );

		/**
		* Get clip box
		* \param piX                    Ptr to var receiving x coordinate of clip box
		* \param piY                    Ptr to y coordinate
		* \param piWidth                Ptr to width
		* \param piHeight               Ptr to height
		*/
		void                            GetClipBox( int *piX, int *piY, int *piWidth, int *piHeight );

		/**
		* Reset clip box
		*/
		void                            ResetClipBox();

		/**
		* Set line wrap flag
		* \param eWrap                  New line wrapping mode
		* \return                       Previous wrap mode
		*/
		FONTLINEWRAP                    SetLineWrap( FONTLINEWRAP eWrap ) { FONTLINEWRAP eRet = m_eLineWrap; m_eLineWrap = eWrap; return eRet; }

		/**
		* \return                       Line wrap mode
		*/
		FONTLINEWRAP                    GetLineWrap() const { return m_eLineWrap; }

		/**
		* \return                       Line height in pixels
		*/
		int                             GetLineHeight() const { return m_iLineHeight; }

		/**
		* \param rstrString             String
		* \return                       Unclipped total string length in pixels
		*/
		int                             GetStringLength( const std::string &rstrString );

		/**
		* \param rstrString             String
		* \param iX                     Start x coordinate
		* \return                       Number of pixels string would occupy if printed with the current settings (clipbox, linewrap...)
		*/
		int                             GetStringHeight( const std::string &rstrString, int iX );

		/**
		* \return                       Font name
		*/
		const std::string              &GetName() const { return m_strName; }

		/**
		* \return                       Current font color
		*/
		const Color                    &GetColor() const;

		/**
		* \param rkColor                New font color to set
		* \return                       Old font color
		*/
		Color                           SetColor( const Color &rkColor );

		/**
		* Set word separator characters
		* \param rstrSeparators         String with all separator characters
		*/
		void                            SetWordSeparators( const std::string &rstrSeparators );

		/**
		* Set alignment
		* \param eAlign                 New horizontal alignment
		* \return                       Old alignment
		*/
		FONTALIGN                       SetHorizontalAlign( FONTALIGN eAlign );

		/**
		* \return                       Current horizontal alignment
		*/
		FONTALIGN                       GetHorizontalAlign();

		/**
		* Clip line to clipbox, applying line wrap modes and current print direction
		* \param rstrLine               String to clip
		* \param iX                     Start x coordinate
		* \param iY                     Start y coordinate
		* \param piLines                Optional pointer to integer receiving number of resulting lines
		* \return                       Clipped and formatted line
		*/
		std::string                     ClipLine( const std::string &rstrLine, int iX, int iY, int *piLines = 0 );
};

// botorabi( 09/04/2004 ): removed the preprocessor defines
//#ifndef __NESMARTPOINTER_FONT
   //Define smart pointer
   SmartPointer(Font);
//#  define __NESMARTPOINTER_FONT
//#endif


#ifdef WIN32
#  ifndef __HAVE_VECTOR_NEFONT
#    ifdef _MSC_VER
#      pragma warning( disable : 4231 )
#    endif
     UDTVectorEXPIMP( class Font* );
#    define __HAVE_VECTOR_NEFONT
#  endif
#endif




/**
  * \brief A collection of fonts
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API FontManager
{
	friend class Font;
		
	protected:

		/*! Fonts */
		std::vector< Font* >            m_vpkFonts;

		/**
		* Deregister font
		* \param pkFont                 Font
		*/
		void                            DeregisterFont( Font *pkFont );


	public:

		/**
		*/
		                                FontManager();

		/**
		*/
		                               ~FontManager();

		/**
		* Create new font
		* \param rstrName               Font name. If font not found (previously loaded), will try loading font file.
		* \param bLoad                  Will try to load new font if true, if false return unloaded font
		* \return                       New font object. If font name is not null string, and font was not found and load failed, a null pointer is returned
		*/
		FontPtr                         CreateFont( const std::string &rstrName, bool bLoad = true );

		/**
		* Locate font
		* \param rstrName               Font name
		* \return                       Font ptr if found
		*/
		FontPtr                         FindFont( const std::string &rstrName );
};


}; // namespace NeoEngine


#endif
