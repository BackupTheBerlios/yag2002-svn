/***************************************************************************
                   rigidbody.h  -  Rigid body physics node
                             -------------------
    begin                : Sat Jan 3 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, rigidbody.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NERIGIDBODY_H
#define __NERIGIDBODY_H


/**
  * \file rigidbody.h
  * Rigid body physics node
  */


#include "base.h"
#include "massparticle.h"

#include <vector>


namespace NeoEngine
{


class Joint;


/**
  * \brief State data for a rigid body
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API RigidBodyState
{
	public:

		/*! Inverted body inertia tensor */
		Matrix                                        m_kInvBodyInertiaTensor;

		/*! Inverted inertia tensor */
		Matrix                                        m_kInvInertiaTensor;

		/*! Angular velocity */
		Vector3d                                      m_kAngularVelocity;

		/*! Torque */
		Vector3d                                      m_kTorque;

		/*! Rotation as matrix */
		Matrix                                        m_kRotation;


		/**
		*/
		                                              RigidBodyState() {}

		/**
		* \param rkInvBodyInertiaTensor               Inverse body inertia tensor
		* \param rkInvInertiaTensor                   Inverse world inertia tensor
		* \param rkAngularVelocity                    Angular velocity
		* \param rkTorque                             Torque
		* \param rkRotation                           Rotation matrix
		*/
		                                              RigidBodyState( const Matrix &rkInvBodyInertiaTensor, const Matrix &rkInvInertiaTensor, const Vector3d &rkAngularVelocity, const Vector3d &rkTorque, const Matrix &rkRotation ) : m_kInvBodyInertiaTensor( rkInvBodyInertiaTensor ), m_kInvInertiaTensor( rkInvInertiaTensor ), m_kAngularVelocity( rkAngularVelocity ), m_kTorque( rkTorque ), m_kRotation( rkRotation ) {}

		/**
		* \param rkState                              Reference state object to copy
		*/
													  RigidBodyState( const RigidBodyState &rkState ) : m_kInvBodyInertiaTensor( rkState.m_kInvBodyInertiaTensor ), m_kInvInertiaTensor( rkState.m_kInvInertiaTensor ), m_kAngularVelocity( rkState.m_kAngularVelocity ), m_kTorque( rkState.m_kTorque ), m_kRotation( rkState.m_kRotation ) {}

		/**
		* Needed for STL exports of UDTs under Win32
		* \param rkState                              State data to compare with
		* \return                                     false
		*/
		bool                                          operator < ( const RigidBodyState &rkState ) const { return( false ); }

		/**
		* Query if states are equal
		* \param rkState                              State data to compare with
		* \return                                     true if all elements are equal, false if not
		*/
		bool                                          operator == ( const RigidBodyState &rkState ) const { return( ( m_kInvBodyInertiaTensor == rkState.m_kInvBodyInertiaTensor ) && ( m_kInvInertiaTensor == rkState.m_kInvInertiaTensor ) && ( m_kAngularVelocity == rkState.m_kAngularVelocity ) && ( m_kTorque == rkState.m_kTorque ) && ( m_kRotation == rkState.m_kRotation ) ); }
};


#ifdef WIN32
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif
#  ifndef __HAVE_VECTOR_NERIGIDBODYSTATEOBJ
     UDTVectorEXPIMP( RigidBodyState );
#    define __HAVE_VECTOR_NERIGIDBODYSTATEOBJ
#  endif
#  ifndef __HAVE_VECTOR_NEJOINT
     UDTVectorEXPIMP( Joint* );
#    define __HAVE_VECTOR_NEJOINT
#  endif
#  ifndef __HAVE_VECTOR_NERIGIDBODY
     UDTVectorEXPIMP( class RigidBody* );
#    define __HAVE_VECTOR_NERIGIDBODY
#  endif
#endif


/**
  * \brief Rigidbody physics simulation class
  * Simulate a rigid body physics
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API RigidBody : public MassParticle
{
	friend class PhysicsManager;

	private:

		/*! State stack */
		std::vector< RigidBodyState >                 m_vkStateStack;



	protected:

		/*! Angular velocity */
		Vector3d                                      m_kAngularVelocity;

		/*! Torque */
		Vector3d                                      m_kTorque;

		/*! Inverted body space inertia tensor */
		Matrix                                        m_kInvBodyInertiaTensor;

		/*! Inverted inertia tensor */
		Matrix                                        m_kInvInertiaTensor;

		/*! Rotation as matrix */
		Matrix                                        m_kRotationMatrix;

		/*! Coefficient of restitution */
		float                                         m_fRestitutionCoeff;

		/*! Coefficient of friction */
		float                                         m_fFrictionCoeff;


	public:

		/*! Flag indicating if this node is managed by physics simulator, if set will force Update method to not integrate equations */
		bool                                          m_bManaged;

		/*! Used by manager to identify body */
		unsigned int                                  m_uiID;

		/*! Used by manager to flag body as resting */
		bool                                          m_bResting;

		/*! Body is penetrating */
		bool                                          m_bPenetrating;

		/*! Rest on bodies */
		std::vector< RigidBody* >                     m_vpkRestOn;

		/*! Joints constraining this rigidbody */
		std::vector< Joint* >                         m_vpkJoints;


		/**
		*/
		                                              RigidBody();

		/**
		*/
		virtual                                      ~RigidBody();

		/**
		* Duplicate node
		* \return                                     New node that is exact copy of this node
		*/
		virtual SceneNode                            *Duplicate();

		/**
		* Apply force to object
		* \param rkForce                              Force
		* \param rkPos                                Position where to apply force
		* \param bLocal                               Is force and pos in local coordinate system (true), or in world coordinates (false)
		* \return                                     Resulting force vector acting on body
		*/
		const Vector3d                               &ApplyForce( const Vector3d &rkForce, const Vector3d& rkPos, bool bLocal = false );

		/**
		* Apply impulse to object
		* \param rkImpulse                            Impulse
		* \param rkPos                                Position where to apply impulse
		* \param bLocal                               Is impulse and pos in local coordinate system (true), or in world coordinates (false)
		*/
		void                                          ApplyImpulse( const Vector3d& rkImpulse, const Vector3d& rkPos, bool bLocal = false );

		/**
		* Reset torque acting on body
		*/
		void                                          ResetTorque();

		/**
		* Reset both force and torque acting on body
		*/
		inline void                                   ResetForceAndTorque() { ResetForce(); ResetTorque(); }

		/**
		* Update by integrating the equations for laws of motion
		* \param fDeltaTime                           Delta time passed since last update
		*/
		virtual void                                  Update( float fDeltaTime );

		/**
		* Set angular velocity
		* \param rkVelocity
		*/
		virtual void                                  SetAngularVelocity( const Vector3d &rkVelocity );

		/**
		* Get velocity of point relative center of rigidbody
		* \param rkPoint                              Point
		* \param bLocal                               Is point in local coordinate system (true), or in world coordinates (false)
		* \return                                     Velocity of point in world coordinates
		*/
		Vector3d                                      GetPointVelocity( const Vector3d &rkPoint, bool bLocal = false );

		/**
		* \return                                     Angular velocity
		*/
		inline const Vector3d                        &GetAngularVelocity() const { return m_kAngularVelocity; }

		/**
		* Set body as massive block
		* \param rkDim                                Dimentions of block
		* \param fMass                                Mass of block
		*/
		void                                          SetMassiveBlock( const Vector3d &rkDim, float fMass );

		/**
		* Set inverse inertia tensor (in local body space)
		* \param rkInvBodyInertiaTensor               Inverse body-speace inertia teO5Dnsor
		*/
		void                                          SetInvBodyInertiaTensor( const Matrix &rkInvBodyInertiaTensor );

		/**
		* \return                                     Inverse world-space inertia tensor
		*/
		inline const Matrix                          &GetInvInertiaTensor() const { return m_kInvInertiaTensor; }

		/**
		* Set coefficient of restitution
		* \param fCoeff                               New coefficient of restitution, in [0..1] range
		*/
		void                                          SetRestitution( float fCoeff ) { m_fRestitutionCoeff = CLAMP< float >( fCoeff, 0.0f, 1.0f ); }

		/**
		* \return                                     Coefficient of restitution, in [0..1] range
		*/
		inline float                                  GetRestitution() const { return m_fRestitutionCoeff; }

		/**
		* Set coefficient of friction
		* \param fCoeff                               New coefficient of friction, in [0..1] range
		*/
		void                                          SetFriction( float fCoeff ) { m_fFrictionCoeff = CLAMP< float >( fCoeff, 0.0f, 1.0f ); }

		/**
		* \return                                     Coefficient of friction, in [0..1] range
		*/
		inline float                                  GetFriction() const { return m_fFrictionCoeff; }

		/**
		* Push current state to stack
		*/
		virtual void                                  PushState();

		/**
		* Restore state from stack
		* \param bSet                                 If true, restore node to state popped off stack, otherwise ignore popped state
		*/
		virtual void                                  PopState( bool bSet = true );

		/**
		* Clear state stack
		*/
		virtual void                                  ClearState();
};


};


#endif
