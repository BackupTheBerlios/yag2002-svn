/***************************************************************************
                    animatednode.h  -  Animated scene node
                             -------------------
    begin                : Sat Jan 25 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, animatednode.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEANIMATEDNODE_H
#define __NEANIMATEDNODE_H


/**
  * \file animatednode.h
  * Animated scene node
  */


#include "base.h"
#include "scenenode.h"
#include "nodeanimator.h"


namespace NeoEngine
{


#ifdef WIN32
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif
#  ifndef __HAVE_VECTOR_NEANIMATEDNODE
     UDTVectorEXPIMP( class AnimatedNode* );
#    define __HAVE_VECTOR_NEANIMATEDNODE
#  endif
#endif


/**
  * \brief Animated scene node
  * An animated scene node extends the basic scene node with
  * node animator control.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API AnimatedNode : public SceneNode, public NodeAnimatorController
{
	public:

		DefineVisitable();

	public:

		/**
		* Create named, attached node. Will initially have same world position as parent
		* (i.e zero relative rotation and translation, no scaling)
		* \param rstrName                             Node name
		* \param pkParent                             Parent node
		* \param eVolume                              Desired bounding volume type (default axis-aligned box)
		*/
		                                              AnimatedNode( const HashString &rstrName = "", SceneNode *pkParent = 0, BoundingVolume::BOUNDINGVOLUMETYPE eVolume = BoundingVolume::BV_AABB );

		/**
		* Create node from reference object
		* \param rkNode                               Reference node object to copy
		*/
		                                              AnimatedNode( AnimatedNode &rkNode );

		/**
		* Deallocates child nodes and detaches from parent
		*/
		virtual                                      ~AnimatedNode();

		/**
		* If node is active, update node and any child nodes. Also calls
		* Update on the entity object, if any.
		* \param fDeltaTime                           Delta time passed
		*/
		virtual void                                  Update( float fDeltaTime );

		/**
		* Duplicate node
		* \return                                     New node that is exact duplicate of this node
		*/
		virtual SceneNode                            *Duplicate();
};


};


#endif
