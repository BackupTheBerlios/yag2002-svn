/***************************************************************************
                       mesh.h  -  Mesh highlevel class
                             -------------------
    begin                : Thu Nov 1 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, mesh.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEMESH_H
#define __NEMESH_H


/**
  * \file neoengine/mesh.h
  * Highlevel representation of a model based on a blueprint
  */


#include "base.h"
#include "pointer.h"
#include "sceneentity.h"
#include "pool.h"

#include <vector>
#include <string>


namespace NeoEngine
{


// External classes
class SubMesh;
class Skeleton;


// Forward declarations
class Mesh;
class MeshEntity;

#ifdef WIN32
#  ifndef __HAVE_VECTOR_NESUBMESH
     UDTVectorEXPIMP( class SubMesh* );
#    define __HAVE_VECTOR_NESUBMESH
#  endif
#endif


PoolExport( Mesh );

typedef Pool< Mesh > MeshPool;


/**
  * \brief A blueprint for a mesh
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Mesh : public RefCounter
{
	protected:

		/*! Owner pool */
		MeshPool                                     *m_pkPool;

		/*! Name */
		HashString                                    m_strName;


	public:
	
		/*! Sub meshes */
		std::vector< SubMesh* >                       m_vpkSubMeshes;

		/*! Skeleton object */
		Skeleton                                     *m_pkSkeleton;
		

		/**
		* \param rstrName                             Mesh name
		* \param pkPool                               Pool object, if null default core pool will be used
		*/
		                                              Mesh( const HashString &rstrName = "", MeshPool *pkPool = 0 );

		/**
		*/
		virtual                                      ~Mesh();

		/**
		* \return                                     Current name
		*/
		inline const HashString                      &GetName() const { return m_strName; }

		/**
		* Set new name
		* \param rstrName                             New name
		*/
		void                                          SetName( const HashString &rstrName );
};


SmartPointer( Mesh );


/**
  * \brief An instance of a mesh in a scene
  * A mesh scene entity, an instance of a mesh
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API MeshEntity : public SceneEntity
{
	public:

		DefineVisitable()


	public:

		/**
		* \brief Mesh flags
		*/
		enum MESHFLAG
		{
		  NOFLAGS                                     = 0x00000000,

		  /*! Use only bounding volume for intersection tests */
		  VOLUMEINTERSECTION                          = 0x00000001,

		  /*! Automatically re-generate bounding volume when submeshes change */
		  AUTOGENVOLUME                               = 0x00000002
		};


	protected:

		/*! Mesh blueprint this object instantiates */
		MeshPtr                                       m_pkMesh;

		/*! Skeleton */
		Skeleton                                     *m_pkSkeleton;
		
		/*! Sub meshes */
		std::vector< SubMesh* >                       m_vpkSubMeshes;

		/*! Flags */
		unsigned int                                  m_uiFlags;


		/**
		* Called by scene node when we have been set to a node
		*/
		virtual void                                  SetNode();


	public:

		/**
		* \param pkMesh                               Mesh to instantiate
		*/
		                                              MeshEntity( const MeshPtr &pkMesh );

		/**
		* \param rkMesh                               Mesh entity to copy
		*/
		                                              MeshEntity( MeshEntity &rkMesh );

		/**
		*/
		virtual                                      ~MeshEntity();

		/**
		* Render this mesh instance
		* \param pkFrustum                            Current frustum
		* \param bForce                               If true, force rendering even if already rendered this frame
		* \return                                     true if rendered, false if already rendered this frame and not forced
		*/
		virtual bool                                  Render( Frustum *pkFrustum = 0, bool bForce = false );

		/**
		* Update this mesh instance
		* \param fDeltaTime                           Delta time passed
		*/
		virtual void                                  Update( float fDeltaTime );

		/**
		* Duplicate mesh (create new entity based on mesh)
		* \return                                     New mesh entity that is exact copy of this entity
		*/
		virtual SceneEntity                          *Duplicate();

		/**
		* Intersection test with unknown object type
		* \param pkObj                                Bounding volume object to test for intersection with
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \param bInvertNormal                        If false, collision normal will point from passed object to this. If true, normal will point in other direction
		* \return                                     true if volumes intersect, false if not
		*/
		virtual bool                                  Intersection( BoundingVolume *pkObj, ContactSet *pkContactSet = 0, bool bInvertNormal = false );

		/**
		* Intersection test with ray
		* \param rkRay                                Ray
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \return                                     true if volumes intersect, false if not
		*/
		virtual bool                                  Intersection( const Ray &rkRay, ContactSet *pkContactSet = 0 );

		/**
		* Set flags
		* \param uiFlags                              Flags to set
		*/
		virtual void                                  SetFlags( unsigned int uiFlags );

		/**
		* Reset flags
		* \param uiFlags                              Flags to reset
		*/
		virtual void                                  ResetFlags( unsigned int uiFlags );

		/**
		* \return                                     All submeshes
		*/
		inline const std::vector< SubMesh* >         &GetSubMeshes() const { return m_vpkSubMeshes; }

		/**
		* \return                                     Skeleton (if any)
		*/
		inline Skeleton                              *GetSkeleton() { return m_pkSkeleton; }

		/**
		* \return                                     Mesh blueprint this entity was instantiated from
		*/
		inline MeshPtr                                GetMesh() { return m_pkMesh; }

		/**
		* Generate bounding volume from submesh vertices
		*/
		void                                          GenerateBoundingVolume();

		/**
		* Force recalculation of tangents and binormals on all submeshes
		*/
		void                                          CalculateTangents();
};


};


#endif
