/***************************************************************************
        renderresolution.h  -  Resolution descriptor for a render area
                             -------------------
    begin                : Sun Oct 26 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, renderresolution.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NERENDERRESOLUTION_H
#define __NERENDERRESOLUTION_H


/**
  * \file renderresolution.h
  * Resolution descriptor for a render area
  */


#include "base.h"


namespace NeoEngine
{


/**
  * \brief Data for a rendering area resolution
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API RenderResolution
{
	public:

		/*! Width in pixels */
		unsigned int                                  m_uiWidth;

		/*! Height in pixels */
		unsigned int                                  m_uiHeight;

		/*! Bits per pixel */
		unsigned int                                  m_uiBPP;

		/*! Depth bits */
		unsigned int                                  m_uiDepthBits;

		/*! Stencil bits */
		unsigned int                                  m_uiStencilBits;

		/*! Refresh rate */
		unsigned int                                  m_uiRefreshRate;

		/**
		* Reset data
		*/
		                                              RenderResolution() : m_uiWidth( 0 ), m_uiHeight( 0 ), m_uiBPP( 0 ), m_uiDepthBits( 0 ), m_uiStencilBits( 0 ), m_uiRefreshRate( 0 ) {}

		/**
		* \param uiWidth                              Width
		* \param uiHeight                             Height
		* \param uiBPP                                Bits per pixel
		* \param uiDepthBits                          Bitdepth of z buffer, 0 for default
		* \param uiStencilBits                        Bitdepth of stencil buffer, 0 for default
		* \param uiRefreshRate                        Refresh rate, 0 for default
		*/
		                                              RenderResolution( unsigned int uiWidth, unsigned int uiHeight, unsigned int uiBPP, unsigned int uiDepthBits = 0, unsigned int uiStencilBits = 0, unsigned int uiRefreshRate = 0 ) : m_uiWidth( uiWidth ), m_uiHeight( uiHeight ), m_uiBPP( uiBPP ), m_uiDepthBits( uiDepthBits ), m_uiStencilBits( uiStencilBits ), m_uiRefreshRate( uiRefreshRate ) {}

		/**
		* Compare resolutions in order of total area, bits per pixel and refresh rate
		* \param rkRes                                Reference resolution
		* \return                                     true if this resolutions is "less" than reference resolution
		*/
		bool                                          operator < ( const RenderResolution &rkRes ) const;
};


};


#endif
