/***************************************************************************
                planarreflection.h  -  Planar reflection class
                             -------------------
    begin                : Sun Apr 27 2003
    copyright            : (C) 2003 by Cody Russell
    email                : cody [at] jhu.edu
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, planarreflection.h

 The Initial Developer of the Original Code is Cody Russell.
 Portions created by Cody Russell are Copyright (C) 2003
 Cody Russell. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEPLANARREFLECTION_H
#define __NEPLANARREFLECTION_H

#include "material.h"
#include "nemath.h"
#include "plane.h"
#include "polygon.h"
#include "render.h"
#include "room.h"
#include "sceneentity.h"
#include "vertex.h"

namespace NeoEngine
{

class NEOENGINE_API PlanarReflection : public FrameCallback, public SceneEntity, public Plane
{
	public:
		
		DefineVisitable();

	protected:

	Vector3d                                       m_akPoints[3];

	VertexBufferPtr                                m_pkVertexBuffer;

	PolygonBufferPtr                               m_pkPolygonBuffer;

	Texture                                       *m_pkTexture;

	bool                                           m_bIsRendering;

	void                                           Draw();

public:

	MaterialPtr                                    m_pkMaterial;

	                                               PlanarReflection( const MaterialPtr &rkMaterial, VertexBufferPtr &pkVertexBuffer, PolygonBufferPtr &pkPolygonBuffer );

	virtual                                       ~PlanarReflection();

	virtual VertexBufferPtr                       &GetVertexBuffer();

	virtual PolygonBufferPtr                      &GetPolygonBuffer();

	virtual void                                   SetVertexBuffer( VertexBufferPtr pkVertexBuffer );

	virtual void                                   SetPolygonBuffer( PolygonBufferPtr pkPolygonBuffer );

	virtual void                                   FrameEvent( FrameCallback::FRAMECALLBACKTYPE eType, void *pData );

	virtual bool                                   Render( Frustum *pkFrustum = 0, bool bForce = false );
};

}; // namespace NeoEngine

#endif // NEPLANARREFLECTION_H
