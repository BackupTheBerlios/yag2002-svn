/***************************************************************************
                     directory.h  -  Directory abstraction
                             -------------------
    begin                : Wed Sep 18 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, directory.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEDIRECTORY_H
#define __NEDIRECTORY_H


/**
  * \file directory.h
  * Directory abstraction class
  */


#include "base.h"
#include "hashtable.h"

#include <string>
#include <vector>


namespace NeoEngine
{


// External classes
class File;


// Forward declarations
class Directory;



#ifdef WIN32
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif
#  ifndef __HAVE_VECTOR_NEDIRECTORY
     UDTVectorEXPIMP( class Directory* );
#    define __HAVE_VECTOR_NEDIRECTORY
#  endif
#endif



/**
  * \brief Data for a file in directory/package hierarchy
  * A file template holds information about a file in the directory/package
  * hierarchy, and is responsible for allocating File objects on
  * request. Specific implementations for normal and package files can
  * then allocate the spcific class for the type of the requested file.
  * For example, a file in a compressed package will be allocated
  * of type VirtualFile, while a file in the normal file system will be
  * of the base File type. With this construct the directory/package class
  * does not need to know about the which implementation of the file
  * type that needs to be allocated on request.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API FileTemplate
{
	public:

		/**
		* Allocate new file object from template
		* \param rstrName                                    File name
		* \param pkParent                                    Parent directory object
		* \return                                            New file object
		*/
		virtual File                                        *AllocateFile( const std::string &rstrName, Directory *pkParent );
};



HashTableExport( FileTemplate );


/**
  * \brief Directory abstraction
  * A directory can contain files and other directories, and is the
  * base class for packages. Each directory contains templates for
  * all files, and the actual File objects gets allocated on request, the
  * GetByName or GetAllFiles methods.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Directory
{
	friend class NpacPackage;
	friend class ZipPackage;

	protected:

		/*! Files in this directory */
		HashTable< FileTemplate >                           *m_pkFiles;

		/*! Subdirectories */
		std::vector< Directory* >                            m_vpkDirectories;

		/*! Parent directory */
		Directory                                           *m_pkParent;

		/*! Name of this directory */
		std::string                                          m_strName;

		/*! Full path */
		std::string                                          m_strFullPath;

		/*! Parsed flag */
		bool                                                 m_bIsParsed;

		/*! Package flag */
		bool                                                 m_bIsPackage;


  public:

		/**
		* Create directory and attach to parent, if any
		* \param rstrName                                    Directory name
		* \param pkParent                                    Parent directory
		* \param bParse                                      Parse rstrName as a directory in the native file system
		* \param bRecurse                                    Recursive parsing flag
		*/
		                                                     Directory( const std::string &rstrName, Directory *pkParent, bool bParse = false, bool bRecurse = true );

		/**
		* Deallocate objects and detach from parent
		*/
		virtual                                             ~Directory();

		/**
		* Parse directory in native file system
		* \param bRecurse                                    Recursive parsing flag
		* \return                                            true if parsing successful, false if error (not found)
		*/
		bool                                                 Parse( bool bRecurse = true );

		/**
		* \return                                            Name of this directory
		*/
		const std::string                                   &GetName() const { return m_strName; }

		/**
		* \return                                            Full path for this directory
		*/
		const std::string                                   &GetFullPath();

		/**
		* Attach a directory
		* \param pkDirectory                                 Directory to attach
		*/
		void                                                 AttachNode( Directory *pkDirectory );

		/**
		* Detach a directory
		* \param pkDirectory                                 Directory to detach
		*/
		void                                                 DetachNode( Directory *pkDirectory );

		/**
		* Search hierarchy for file
		* \param rstrName                                    Name of file
		* \param bRecurse                                    Recursively look for file in subdirectories if true (default)
		* \return                                            Ptr to file if found, null if not (must be deleted after use)
		*/
		File                                                *GetByName( const std::string &rstrName, bool bRecurse = true );

		/**
		* Search hierarchy for directory
		* \param rstrName                                    Name of directory
		* \return                                            Ptr to node if found, null if not (should NOT be deleted after use)
		*/
		Directory                                           *GetDirectoryByName( const std::string &rstrName );

		/**
		* Get all files (must be deallocated when finished using)
		* \param pvpkFiles                                   Vector receiving pointers to files
		*/
		void                                                 GetFiles( std::vector< File* > *pvpkFiles ) const;

		/**
		* Get vector of all directories
		* \return                                            const vector with all directories
		*/
		const std::vector< Directory* >                     &GetDirectories() const { return m_vpkDirectories; }

		/**
		* \return                                            Parent directory (if any)
		*/
		Directory                                           *GetParentDirectory();

		/**
		* Query if we are a package or directory
		* \return                                            true if package, false if directory
		*/
		bool                                                 IsPackage() const { return m_bIsPackage; }

		/**
		* \return                                            true if directory has been parsed, false if not
		*/
		bool                                                 IsParsed() const { return m_bIsParsed; }

		/**
		* Print hierarchy
		* \param iDepth                                      Recurse depth
		*/
		void                                                 PrintHierarchy( int iDepth );
};


}; // namespace NeoEngine


#endif
