/***************************************************************************
       file.h  -  File abstraction. Normal files, memory buffer files
                       and virtual files in packages
                             -------------------
    begin                : Thu Nov 1 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, file.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEFILE_H
#define __NEFILE_H


/**
  * \file file.h
  * File I/O abstraction as normal files, memory files and virtual (package) files
  */


#include "base.h"
#include "core.h"

#include <string>
#include <fstream>


namespace NeoEngine
{


// External classes
class Directory;
class Package;
class HashString;



/**
  * \brief OS independant file wrapper with useful operations
  * The File class gives access to a file in the file system, and
  * abstracts away all platform and architecture specific issues
  * for reading and writing. You can access a little/big endian file from
  * a little/big endian system with no changes to your code. You can
  * use the DetermineByteOrder method to support different endian versions
  * of your data files on different systems (loading a little endian file
  * on a little endian system is faster than a big endian file, and vice versa
  * for big endian systems).<br><br>
  * The file class supports methods for reading and writing bytes, shorts,
  * integers and strings, as well as raw byte arrays. It also has the
  * standard printf and scanf style methods for easy text parsing.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API File
{
	protected:

		/*! Stream */
		std::iostream                                *m_pkStream;

		/*! Open mode */
		std::ios_base::openmode                       m_uiOpenMode;

		/*! Binary mode */
		bool                                          m_bBinary;

		/*! Byte order */
		Core::BYTEORDER                               m_eByteOrder;

		/* Path */
		std::string                                   m_strPath;

		/* Filename */
		std::string                                   m_strName;

		/*! Directory we are attached to (if any) */
		Directory                                    *m_pkDirectory;


		/**
		* Allocate the stream object
		* \param rstrFullPath                         Full path name
		*/
		virtual void                                  AllocStream( const std::string &rstrFullPath );


	public:

		/**
		* Initialize file data and optionally open file.
		* \param rstrPath                             Path
		* \param rstrFilename                         Filename
		* \param uiOpenMode                           Open mode (read, write, binary...). Default is in|binary
		* \param bOpen                                Open file if true
		* \param pkDirectory                          Parent directory
		*/
		                                              File( const std::string &rstrPath = "", const std::string &rstrFilename = "", std::ios_base::openmode uiOpenMode = ( std::ios_base::in | std::ios_base::binary ), bool bOpen = false, Directory *pkDirectory = 0 );

		/**
		* Deallocate memory, close file if open
		*/
		virtual                                      ~File();

		/**
		* Open file. Close any open handles. If null are passed as args, previously stored names will be used
		* \param rstrPath                             Path
		* \param rstrFilename                         Filename
		* \param uiOpenMode                           Open mode, default is in|binary
		* \return                                     true if successful, false if error
		*/
		virtual bool                                  Open( const std::string &rstrPath = "", const std::string &rstrFilename = "", std::ios_base::openmode uiOpenMode = (std::ios_base::openmode)0 );

		/**
		* Close any open handle
		*/
		virtual void                                  Close();

		/**
		* Query if file is valid (file exists and is open)
		* \return                                     true if file is open, false otherwise
		*/
		virtual bool                                  IsValid() const { return( m_pkStream && !( !*m_pkStream  ) ); }

		/**
		* Set byte order of file
		* \param eByteOrder                           New byte order
		*/
		void                                          SetByteOrder( Core::BYTEORDER eByteOrder ) { m_eByteOrder = eByteOrder; }

		/**
		* Get file size. File does not have to be open. Returns -1 if error (unable to open file)
		* \return                                     File size
		*/
		virtual int                                   GetSize();

		/**
		* Get current get (read) pointer position
		* \return                                     Position in stream of get pointer
		*/
		inline std::streampos                         Tellg() const { return( m_pkStream ? m_pkStream->tellg() : (std::streampos)0 ); }

		/**
		* Get current put (write) pointer position
		* \return                                     Position in stream of put pointer
		*/
		inline std::streampos                         Tellp() const { return( m_pkStream ? m_pkStream->tellp() : (std::streampos)0 ); }

		/**
		* Read raw data
		* \param pBuffer                              Destination buffer
		* \param iNumBytes                            Number of bytes to read
		* \return                                     File self-reference
		*/
		virtual File                                 &Read( void *pBuffer, int iNumBytes );

		/**
		 * Write raw data
		 * \param pBuffer                             Buffer of data to write
		 * \param iNumBytes                           Number of bytes to write
		 * \return                                    File self-reference
		 */
		virtual File                                 &Write( const void *pBuffer, int iNumBytes );

		/**
		* Get up to uiCount characters, discarding delimiter
		* \param pcDest                               Destination buffer, null if input is to be ignored
		* \param uiCount                              Maximum number of characters to extract
		* \param cDelimiter                           Delimiter, default '\n'
		* \return                                     File self-reference
		*/
		virtual File                                 &GetLine( char *pcDest, unsigned int uiCount, char cDelimiter = '\n' );

		/**
		* Reposition the get (read) pointer
		* \param uiOffset                             Offset in bytes
		* \param uiDirection                          Seek direction,
		* \return                                     File self-reference
		*/
		inline File                                  &Seekg( std::streamoff uiOffset, std::ios_base::seekdir uiDirection ) { if( m_pkStream ) m_pkStream->seekg( uiOffset, uiDirection ); return( *this ); }

		/**
		* Reposition the put (write) pointer
		* \param uiOffset                             Offset in bytes
		* \param uiDirection                          Seek direction,
		* \return                                     File self-reference
		*/
		inline File                                  &Seekp( std::streamoff uiOffset, std::ios_base::seekdir uiDirection ) { if( m_pkStream ) m_pkStream->seekp( uiOffset, uiDirection ); return( *this ); }

		/**
		* \return                                     Directory path
		*/
		const std::string                            &GetPath() const { return m_strPath; }

		/**
		* \return                                     Name of file
		*/
		const std::string                            &GetName() const { return m_strName; }

		/**
		* \return                                     Ptr to parent directory if any
		*/
		Directory                                    *GetDirectory() { return m_pkDirectory; }

		/**
		* \return                                     Current file byte order
		*/
		virtual Core::BYTEORDER                       GetByteOrder() const { return m_eByteOrder; }

		/**
		* Try to determine file byte ordering by reading integer and comparing with reference
		* Integer will be read from file at current position, and compared to reference value.
		* If determination was successful, the file byte ordering will be set.
		* File pointer will be restored to original position in any case.
		* \param iReferenceValue                      Reference integer
		* \return                                     true if byte order identification was successful, false if not
		*/
		bool                                          DetermineByteOrder( int iReferenceValue );

		/**
		* Set binary/ascii mode flag
		* \param bBinary                              Set file mode to binary if true, set to ascii if false
		* \return                                     true if file mode was binary before this call, false if file mode was ascii
		*/
		bool                                          SetBinary( bool bBinary );

		/**
		* Query if binary/ascii mode
		* \return                                     true if file mode is binary, false if file mode is ascii
		*/
		bool                                          IsBinary() const;

		/**
		* Try to determine file mode by reading four binary values and comparing with reference array.
		* If matching the file mode will be set to binary, if not matching file mode will be set to ascii
		* \param pucReferenceValues                   Pointer to four reference values
		* \return                                     true if file mode identification was successful, false if not
		*/
		bool                                          DetermineBinaryMode( const unsigned char *pucReferenceValues );

		/**
		* Write boolean to file
		* \param bData                                Boolean to write
		* \return                                     File self-reference
		*/
		File                                         &operator << ( bool bData );

		/**
		* Write char to file
		* \param cData                                Char to write
		* \return                                     File self-reference
		*/
		File                                         &operator << ( int8_t cData );

		/**
		* Write byte to file
		* \param ucData                               Byte to write
		* \return                                     File self-reference
		*/
		File                                         &operator << ( uint8_t ucData );

		/**
		* Write short to file
		* \param sData                                Short to write
		* \return                                     File self-reference
		*/
		File                                         &operator << ( int16_t sData );

		/**
		* Write unsigned short to file
		* \param usData                               Unsigned short to write
		* \return                                     File self-reference
		*/
		File                                         &operator << ( uint16_t usData );

		/**
		* Write integer to file
		* \param iData                                Integer to write
		* \return                                     File self-reference
		*/
		File                                         &operator << ( int32_t iData );

		/**
		* Write unsigned integer to file
		* \param uiData                               Unsigned integer to write
		* \return                                     File self-reference
		*/
		File                                         &operator << ( uint32_t uiData );

		/**
		* Write float to file
		* \param fData                                Float to write
		* \return                                     File self-reference
		*/
		File                                         &operator << ( float fData );

		/**
		* Write null-terminated string to file
		* \param pszData                              String to write
		* \return                                     File self-reference
		*/
		File                                         &operator << ( const char *pszData );

		/**
		* Write string to file
		* \param rstrData                             String to write
		* \return                                     File self-reference
		*/
		File                                         &operator << ( const std::string &rstrData );

		/**
		* Write string to file
		* \param rstrData                             String to write
		* \return                                     File self-reference
		*/
		File                                         &operator << ( const HashString &rstrData );

		/**
		* Read boolean from file
		* \param rbData                               Boolean to read to
		* \return                                     File self-reference
		*/
		File                                         &operator >> ( bool &rbData );

		/**
		* Read char from file
		* \param rcData                               Char to read to
		* \return                                     File self-reference
		*/
		File                                         &operator >> ( int8_t &rcData );

		/**
		* Read byte from file
		* \param rucData                              Byte to read to
		* \return                                     File self-reference
		*/
		File                                         &operator >> ( uint8_t &rucData );

		/**
		* Read short from file
		* \param rsData                               Short to read to
		* \return                                     File self-reference
		*/
		File                                         &operator >> ( int16_t &rsData );

		/**
		* Read unsigned short from file
		* \param rusData                              Unsigned short to read to
		* \return                                     File self-reference
		*/
		File                                         &operator >> ( uint16_t &rusData );

		/**
		* Read integer from file
		* \param riData                               Integer to read to
		* \return                                     File self-reference
		*/
		File                                         &operator >> ( int32_t &riData );

		/**
		* Read unsigned integer from file
		* \param ruiData                              Unsigned integer to read to
		* \return                                     File self-reference
		*/
		File                                         &operator >> ( uint32_t &ruiData );

		/**
		* Read float from file
		* \param rfData                               Float to read to
		* \return                                     File self-reference
		*/
		File                                         &operator >> ( float &rfData );

		/**
		* Read string from file
		* \param rstrData                             String to read to
		* \return                                     File self-reference
		*/
		File                                         &operator >> ( std::string &rstrData );

		/**
		* Read string from file
		* \param rstrData                             Hash string to read to
		* \return                                     File self-reference
		*/
		File                                         &operator >> ( HashString &rstrData );

		/**
		* Insert stream manipulator
		* \return                                     File self-reference
		*/
		inline File                                  &operator << ( std::ios_base &( NE_CDECL *pfnManip )( std::ios_base& ) )
		{
			(*pfnManip)( *( std::ios_base* )m_pkStream );
			return( *this );
		}

		/**
		* Insert stream manipulator
		* \return                                     File self-reference
		*/
		inline File                                  &operator << ( std::basic_ostream< char > &( NE_CDECL *pfnManip )( std::basic_ostream< char >& ) )
		{
			(*pfnManip)( *( std::basic_ostream< char >* )m_pkStream );
			return( *this );
		}

		/**
		* Insert stream manipulator
		* \return                                     File self-reference
		*/
		inline File                                  &operator >> ( std::ios_base &( NE_CDECL *pfnManip )( std::ios_base& ) )
		{
			(*pfnManip)( *( std::ios_base* )m_pkStream );
			return( *this );
		}

		/**
		* Insert stream manipulator
		* \return                                     File self-reference
		*/
		inline File                                  &operator >> ( std::basic_ostream< char > &( NE_CDECL *pfnManip )( std::basic_ostream< char >& ) )
		{
			(*pfnManip)( *( std::basic_ostream< char >* )m_pkStream );
			return( *this );
		}

		/**
		* Test for valid/invalid state and EOF
		* \return                                     false if file is valid, true if invalid ro EOF
		*/
		inline bool                                   operator !() const { return !IsValid(); }

		/**
		* Get base file name (no path and no extension) from full path name
		* \param rstrPath                             Full path
		* \return                                     File base name
		*/
		static std::string                            ExtractBaseFileName( const std::string &rstrPath );

		/**
		* Get file extension (no path and no name) from full path name
		* \param rstrPath                             Full path
		* \return                                     File extension
		*/
		static std::string                            ExtractFileExtension( const std::string &rstrPath );

		/**
		* Get file name (no path but with extension) from full path name
		* \param rstrPath                             Full path
		* \return                                     File full name
		*/
		static std::string                            ExtractFileName( const std::string &rstrPath );

		/**
		* Get path name from full path name including file name
		* \param rstrPath                             Full path
		* \return                                     Path name
		*/
		static std::string                            ExtractPathName( const std::string &rstrPath );
};



/**
  * \brief Stream buffer implementation for buffered files
  * Stream buffer that reads and writes to a memory, used by BufferFile
  * to provide the stream buffer interface for the stream.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API BufferFileStreamBuf : public std::basic_streambuf< char >
{
	public:

		typedef std::basic_streambuf< char >::pos_type pos_type;
		typedef std::basic_streambuf< char >::off_type off_type;
		typedef std::basic_streambuf< char >::int_type int_type;

	protected:

		/*! Current buffer */
		unsigned char                                *m_pucBuffer;

		/*! Current buffer size */
		unsigned int                                  m_uiSize;

		/*! Current get offset */
		unsigned int                                  m_uiGetOffset;


		/**
		* Set buffer for file
		* \param pcBuffer                             Buffer
		* \param uiSize                               Buffer size
		* \return                                     Self-reference
		*/
		virtual std::basic_streambuf< char >         *setbuf( char *pcBuffer, std::streamsize uiSize );

		/**
		* Change position of get/put pointer, according to offset, direction and mode
		* \param iOffset                              Offset
		* \param uiDir                                Direction
		* \param uiMode                               Mode
		* \return                                     Current position
		*/
		virtual pos_type                              seekoff( off_type iOffset, std::ios_base::seekdir uiDir, std::ios_base::openmode uiMode );

		/**
		* Change position of get/put pointer to specified position, according to mode
		* \param uiPosition                           Position
		* \param uiMode                               Mode
		* \return                                     Current position
		*/
		virtual pos_type                              seekpos( pos_type uiPosition, std::ios_base::openmode uiMode );

		/**
		* Get a character from stream but don't point past it
		* \return                                     Character, or eof if end of stream
		*/
		virtual int_type                              underflow();


	public:

		/**
		* Initialize stream buffer
		* \param pucBuffer                            Initial buffer
		* \param uiSize                               Initial buffer size
		*/
		                                              BufferFileStreamBuf( unsigned char *pucBuffer, unsigned int uiSize );

		/**
		* Deallocate buffer
		*/
		virtual                                      ~BufferFileStreamBuf();
};


/**
  * \brief Emulate File object on data buffer
  * A buffer file implements file operations on an arbitrary memory buffer.
  * This can be useful if you want to load resources from data embedded
  * in your application, you can then create a BufferFile object and pass
  * to all classes and methods accepting a File object for loading (all
  * classes that are derived LoadableEntity supports loading from a File object)
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API BufferFile : public File
{
	protected:

		/*! Ptr to stream buffer */
		BufferFileStreamBuf                          *m_pkBuffer;


		/**
		* Allocate the stream object
		* \param rstrFullPath                         Full path name
		*/
		virtual void                                  AllocStream( const std::string &rstrFullPath );


	public:

		/**
		* \param pucBuffer                            Buffer
		* \param iSize                                Size of buffer
		* \param rstrPath                             Path
		* \param rstrFilename                         Filename
		* \param uiOpenMode                           Open mode
		* \param bOpen                                Open file
		* \param pkDirectory                          Parent directory
		*/
		                                              BufferFile( unsigned char *pucBuffer = 0, int iSize = 0, const std::string &rstrPath = "", const std::string &rstrFilename = "", std::ios_base::openmode uiOpenMode = ( std::ios_base::in | std::ios_base::binary ), bool bOpen = false, Directory *pkDirectory = 0 );

		/**
		*/
		virtual                                      ~BufferFile();

		/**
		* Deallocate buffer
		*/
		virtual void                                  Close();

		/**
		* Set buffer to use
		* \param pucBuffer                            Buffer
		* \param iSize                                Size in bytes of buffer
		*/
		void                                          SetBuffer( unsigned char *pucBuffer, int iSize );
};






/**
  * \brief Virtual file in package
  * A virtual file exists inside an (optionally compressed) package, and
  * is derived from BufferFile since it acts on a memory buffer. For compressed
  * packages, the data for the file is uncompressed to a memory buffer when
  * the file is opened, and released when the file is closed.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API VirtualFile : public BufferFile
{
	friend class Package;
	friend class VirtualFileTemplate;

	protected:

		/*! File offset in package */
		int                                           m_iFileOffset;

		/*! File flags */
		int                                           m_iFileFlags;

		/*! Package */
		Package                                      *m_pkPackage;

		/*! File data (specific to flags) */
		int                                           m_iFileData[4];

		/*! Stored file size */
		int                                           m_iStoredFileSize;
		

		/**
		* Allocate the stream object
		* \param rstrFullPath                         Full path name
		*/
		virtual void                                  AllocStream( const std::string &rstrFullPath );

	
	public:

		/**
		* \param rstrPath                             Path
		* \param rstrFilename                         Filename
		* \param pkDirectory                          Parent directory
		*/
		                                              VirtualFile( const std::string &rstrPath = "", const std::string &rstrFilename = "", Directory *pkDirectory = 0 );

		/**
		*/
		virtual                                      ~VirtualFile();
};


};


#endif
