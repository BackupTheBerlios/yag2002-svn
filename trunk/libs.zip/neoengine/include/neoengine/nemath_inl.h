/***************************************************************************
                nemath_inl.h  -  Implementation of math classes
                             -------------------
    begin                : Fri Sep 27 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, nemath_inl.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

//#include <assert.h>

#if defined( WIN32 ) && defined( __MINGW32__ )
#  undef NEOENGINE_API
#  define NEOENGINE_API
#endif

NEOENGINE_API int RoundFloat( float fNum )
{
#if defined( ARCH_X86 ) && defined( _MSC_VER )
	int iNum;

	__asm
	{
		fld fNum
		fistp iNum
	};
	return iNum;
#elif defined( ARCH_X86 ) && defined( __GNUC__ )
	int iNum;

	asm( "fld %0; fistp %0" : "=r" ( iNum ) : "0" ( fNum ) );
	return iNum;
#else
	return int( fNum + 0.5f );
#endif
}

NEOENGINE_API int TruncFloat( float fNum )
{
#if defined( ARCH_X86 ) && defined( _MSC_VER )
	return ( int ) fNum;
#else
	return ( int ) fNum;
#endif
}

NEOENGINE_API float FastInvSqrt( float fN )
{
	unsigned int iN;
	float fTemp;

	fTemp  = fN;
	iN     = *(long*)&fTemp;
	iN     = 0x5f3759df - ( iN >> 1 );
	fTemp  = *(float*)&iN;
	fTemp  = fTemp * ( 1.5f - ( fN * 0.5f * fTemp * fTemp ) );

	return fTemp;
}



NEOENGINE_API Vector3d::Vector3d() : x( 0.0f ), y( 0.0f ), z( 0.0f ) {}

NEOENGINE_API Vector3d::Vector3d( float fX, float fY, float fZ ) : x( fX ), y( fY ), z( fZ ) {}

NEOENGINE_API Vector3d::Vector3d( float afComponents[] ) : x( afComponents[0] ), y( afComponents[1] ), z( afComponents[2] ) {}


NEOENGINE_API Vector3d &Vector3d::Set( float fX, float fY, float fZ )
{
	x = fX;
	y = fY;
	z = fZ;
	return( *this );
}


NEOENGINE_API Vector3d &Vector3d::Set( float afComponents[] )
{
	x = afComponents[0];
	y = afComponents[1];
	z = afComponents[2];
	return( *this );
}


NEOENGINE_API Vector3d &Vector3d::Reset()
{
	x = y = z = 0.0f;
	return( *this );
}


NEOENGINE_API float Vector3d::Len() const
{
	return( sqrtf( x*x + y*y + z*z ) );
}


NEOENGINE_API float Vector3d::Len2() const
{
	return( x*x + y*y + z*z );
}


NEOENGINE_API Vector3d &Vector3d::Normalize()
{
	float fNorm = x*x + y*y + z*z;

	if( ( fabsf( fNorm - 1.0f ) > SQREPSILON ) && ( fNorm > SQREPSILON ) )
	{
#ifdef USE_FASTINVSQRT
		float fInvNorm = FastInvSqrt( fNorm );
#else
		float fInvNorm = 1.0f / sqrtf( fNorm );
#endif

		x *= fInvNorm;
		y *= fInvNorm;
		z *= fInvNorm;
	}

	return( *this );
}


NEOENGINE_API Vector3d &Vector3d::ScaleTo( float fLen )
{
	float fSqrLen = x * x + y * y + z * z;

	if( ( fSqrLen > SQREPSILON ) && ( fabsf( fSqrLen - ( fLen * fLen ) ) > SQREPSILON ) )
	{
#ifdef USE_FASTINVSQRT
		float fFactor = fLen * FastInvSqrt( fSqrLen );
#else
		float fFactor = fLen / sqrtf( fSqrLen );
#endif

		x *= fFactor;
		y *= fFactor;
		z *= fFactor;
	}

	return( *this );
}


NEOENGINE_API bool Vector3d::operator ==( const Vector3d &rkVector ) const
{
	return( ( fabs( x - rkVector.x ) < EPSILON ) && ( fabs( y - rkVector.y ) < EPSILON ) && ( fabs( z - rkVector.z ) < EPSILON ) );
}


NEOENGINE_API bool Vector3d::operator !=( const Vector3d &rkVector ) const
{
	return( ( fabs( x - rkVector.x ) > EPSILON ) || ( fabs( y - rkVector.y ) > EPSILON ) || ( fabs( z - rkVector.z ) > EPSILON ) );
}


NEOENGINE_API float Vector3d::operator *( const Vector3d &rkVector ) const
{
	return( x * rkVector.x + y * rkVector.y + z * rkVector.z );
}


NEOENGINE_API Vector3d Vector3d::operator %( const Vector3d &rkVector ) const
{
	return Vector3d( y * rkVector.z - z * rkVector.y, z * rkVector.x - x * rkVector.z, x * rkVector.y - y * rkVector.x );
}


NEOENGINE_API Vector3d &Vector3d::operator %=( const Vector3d &rkVector )
{
	Set( y * rkVector.z - z * rkVector.y, z * rkVector.x - x * rkVector.z, x * rkVector.y - y * rkVector.x );
	return( *this );
}


NEOENGINE_API Vector3d Vector3d::operator *( float fScalar ) const
{
  	return Vector3d( x * fScalar, y * fScalar, z * fScalar );
}


NEOENGINE_API Vector3d &Vector3d::operator *=( float fScalar )
{
	x *= fScalar;
	y *= fScalar;
	z *= fScalar;

	return( *this );
}


NEOENGINE_API Vector3d Vector3d::operator +( const Vector3d &rkVector ) const
{
	return Vector3d( x + rkVector.x, y + rkVector.y, z + rkVector.z );
}


NEOENGINE_API Vector3d &Vector3d::operator +=( const Vector3d &rkVector )
{
	x += rkVector.x;
	y += rkVector.y;
	z += rkVector.z;

	return( *this );
}


NEOENGINE_API Vector3d Vector3d::operator -( const Vector3d &rkVector ) const
{
	return Vector3d( x - rkVector.x, y - rkVector.y, z - rkVector.z );
}


NEOENGINE_API Vector3d &Vector3d::operator -=( const Vector3d &rkVector )
{
	x -= rkVector.x;
	y -= rkVector.y;
	z -= rkVector.z;

	return( *this );
}


NEOENGINE_API Vector3d Vector3d::operator -() const
{
	return Vector3d( -x, -y, -z );
}


NEOENGINE_API float &Vector3d::operator []( int iComponent )
{
	return( ((float*)&x)[ iComponent ] );
}


NEOENGINE_API const float &Vector3d::operator []( int iComponent ) const
{
	return( ((float*)&x)[ iComponent ] );
}






NEOENGINE_API Quaternion::Quaternion() : qx(0.0f), qy(0.0f), qz(0.0f), qw(1.0f) {}

NEOENGINE_API Quaternion::Quaternion( float fX, float fY, float fZ, float fW ) : qx( fX ), qy( fY ), qz( fZ ), qw( fW ) {}

NEOENGINE_API Quaternion::Quaternion( const Matrix &rkMatrix ) { *this = rkMatrix; }

NEOENGINE_API Quaternion::Quaternion( const AxisAngle &rkAxisAngle ) { *this = rkAxisAngle; }

NEOENGINE_API Quaternion::Quaternion( const EulerAngles &rkAngles ) { *this = rkAngles; }


NEOENGINE_API Quaternion &Quaternion::Reset()
{
	qx = qy = qz = 0.0f;
	qw = 1.0f;

	return( *this );
}


NEOENGINE_API Quaternion &Quaternion::Set( float fX, float fY, float fZ, float fW )
{
	qx = fX;
	qy = fY;
	qz = fZ;
	qw = fW;

	return( *this );
}


NEOENGINE_API Quaternion &Quaternion::Inverse()
{
	qx = -qx;
	qy = -qy;
	qz = -qz;

	return( *this );
}


NEOENGINE_API Quaternion Quaternion::operator ~() const
{
	return Quaternion( -qx, -qy, -qz, qw );
}


NEOENGINE_API Quaternion &Quaternion::Normalize()
{
	float fNorm = qx * qx + qy * qy + qz * qz + qw * qw;

	if( fNorm < SQREPSILON )
	{
		qx = 0.0f;
		qy = 0.0f;
		qz = 0.0f;
		qw = 1.0f;
	}
	else if( fabs( fNorm - 1.0f ) > SQREPSILON )
	{
#ifdef USE_FASTINVSQRT
		float fScale = FastInvSqrt( fNorm );
#else
		float fScale = 1.0f / sqrtf( fNorm );
#endif
	
		qx *= fScale;
		qy *= fScale;
		qz *= fScale;
		qw *= fScale;
		
		return( *this );
	}

	return( *this );
}


NEOENGINE_API Matrix &Quaternion::ToMatrix( Matrix *pkMatrix ) const
{
	float fTX  = 2.0f * qx;
	float fTY  = 2.0f * qy;
	float fTZ  = 2.0f * qz;
	float fTWX = fTX * qw;
	float fTWY = fTY * qw;
	float fTWZ = fTZ * qw;
	float fTXX = fTX * qx;
	float fTXY = fTY * qx;
	float fTXZ = fTZ * qx;
	float fTYY = fTY * qy;
	float fTYZ = fTZ * qy;
	float fTZZ = fTZ * qz;

	float *pfMat = &pkMatrix->m_aafMatrix[0][0];

	pfMat[0]  = 1.0f - ( fTYY + fTZZ );
	pfMat[1]  = fTXY - fTWZ;
	pfMat[2]  = fTXZ + fTWY;

	pfMat[4]  = fTXY + fTWZ;
	pfMat[5]  = 1.0f - ( fTXX + fTZZ );
	pfMat[6]  = fTYZ - fTWX;
	
	pfMat[8]  = fTXZ - fTWY;
	pfMat[9]  = fTYZ + fTWX;
	pfMat[10] = 1.0f - ( fTXX + fTYY );

	return( *pkMatrix );
}


NEOENGINE_API AxisAngle Quaternion::ToAxisAngle() const
{
	float fSqrLength = qx * qx + qy * qy + qz * qz;
	float fAngle;
	Vector3d kAxis;

	if ( fSqrLength > 0.0 )
	{
		fAngle = 2.0f * acosf( qw );

		float fInvLength = 1.0f/ logf( fSqrLength );

		kAxis.x = qx * fInvLength;
		kAxis.y = qy * fInvLength;
		kAxis.z = qz * fInvLength;
	}
	else
	{
		fAngle = 0.0f;

		kAxis.x = 1.0f;
		kAxis.y = 0.0f;
		kAxis.z = 0.0f;
	}

	return AxisAngle( kAxis, fAngle );
}


NEOENGINE_API Quaternion &Quaternion::Slerp( float fT, const Quaternion &rkDest, bool bAcuteAngle )
{
	fT = CLAMP< float >( fT, 0.0f, 1.0f );

	Quaternion kD = rkDest;

	float fCos   = qx * kD.qx + qy * kD.qy + qz * kD.qz + qw * kD.qw;

	//if fCos < 0 use Slerp( fT, -rkDest ) to get acute angle
	//between quaternions and avoid extra spins
	if( bAcuteAngle && ( fCos < 0.0f ) )
	{
		kD.qx   = -rkDest.qx;
		kD.qy   = -rkDest.qy;
		kD.qz   = -rkDest.qz;
		kD.qw   = -rkDest.qw;

		fCos = qx * kD.qx + qy * kD.qy + qz * kD.qz + qw * kD.qw;
	}

	float fAngle = 0.0f;

	if( -1.0f < fCos )
	{
		if( fCos < 1.0 )
			fAngle = acosf( fCos );
		else
			fAngle = 0.0f;
	}
	else
		fAngle = PI;

	if( fabs( fAngle ) < 0.001f )
		return( *this );

	float fSin      = sinf( fAngle );
	float fInvSin   = 1.0f / fSin;
	float fCoeffOne = sinf( ( 1.0f - fT ) * fAngle ) * fInvSin;
	float fCoeffTwo = sinf( fT * fAngle ) * fInvSin;

	qx = qx * fCoeffOne + kD.qx * fCoeffTwo;
	qy = qy * fCoeffOne + kD.qy * fCoeffTwo;
	qz = qz * fCoeffOne + kD.qz * fCoeffTwo;
	qw = qw * fCoeffOne + kD.qw * fCoeffTwo;

	return( *this );
}


NEOENGINE_API Quaternion &Quaternion::operator =( const Matrix &rkMatrix )
{
    // Algorithm in Ken Shoemake's article in 1987 SIGGRAPH course notes
    // article "Quaternion Calculus and Fast Animation".

	float fTrace = rkMatrix[0][0] + rkMatrix[1][1] + rkMatrix[2][2];
	float fRoot;

	if( fTrace > 0.0 )
	{
		fRoot = sqrtf( fTrace + 1.0f );

		qw = 0.5f * fRoot;

		fRoot = 0.5f / fRoot;

		qx = ( rkMatrix[2][1] - rkMatrix[1][2] ) * fRoot;
		qy = ( rkMatrix[0][2] - rkMatrix[2][0] ) * fRoot;
		qz = ( rkMatrix[1][0] - rkMatrix[0][1] ) * fRoot;
	}
	else
	{
		int iNext[3] = { 1, 2, 0 };

		int i = 0;
		if( rkMatrix[1][1] > rkMatrix[0][0] )
			i = 1;

		if( rkMatrix[2][2] > rkMatrix[i][i] )
			i = 2;

		int j = iNext[i];
		int k = iNext[j];

		fRoot = sqrtf( rkMatrix[i][i] - rkMatrix[j][j] - rkMatrix[k][k] + 1.0f );

		float *apfQuat[3] = { &qx, &qy, &qz };

		*(apfQuat[i]) = 0.5f * fRoot;

		fRoot = 0.5f / fRoot;

		qw = ( rkMatrix[k][j] - rkMatrix[j][k] ) * fRoot;

		*(apfQuat[j]) = ( rkMatrix[j][i] + rkMatrix[i][j] ) * fRoot;
		*(apfQuat[k]) = ( rkMatrix[k][i] + rkMatrix[i][k] ) * fRoot;
	}

	return Normalize();
}


NEOENGINE_API Quaternion &Quaternion::operator =( const AxisAngle &rkAxisAngle )
{
	float fHalfAngle = 0.5f * rkAxisAngle.m_fAngle;
	float fSin       = sinf( fHalfAngle );

	qx = fSin * rkAxisAngle.m_kAxis.x;
	qy = fSin * rkAxisAngle.m_kAxis.y;
	qz = fSin * rkAxisAngle.m_kAxis.z;
	qw = cosf( fHalfAngle );

	return Normalize();
}


NEOENGINE_API Vector3d Quaternion::operator *( const Vector3d &rkVector ) const
{
	Vector3d kVec0( qx, qy, qz );
	Vector3d kVec1( kVec0 % rkVector );

	kVec1 += rkVector * qw;

	Vector3d kVec2 = kVec1 % kVec0;

	kVec0 *= rkVector * kVec0;

	kVec0 += kVec1 * qw;

	return Vector3d( kVec0 - kVec2 );
}


NEOENGINE_API Quaternion &Quaternion::operator *=( const Quaternion &rkQuat )
{
	Vector3d kVecOne( qx, qy, qz );
	Vector3d kVecTwo( rkQuat.qx, rkQuat.qy, rkQuat.qz );

	Vector3d kVecResult = ( kVecOne % kVecTwo ) + kVecTwo * qw + kVecOne * rkQuat.qw;

	return( Set( kVecResult.x, kVecResult.y, kVecResult.z, qw * rkQuat.qw - kVecOne * kVecTwo ) );
}


NEOENGINE_API Quaternion Quaternion::operator *( const Quaternion &rkQuat ) const
{
	Vector3d kVecOne( qx, qy, qz );
	Vector3d kVecTwo( rkQuat.qx, rkQuat.qy, rkQuat.qz );

	Vector3d kVecResult = ( kVecOne % kVecTwo ) + kVecTwo * qw + kVecOne * rkQuat.qw;

	return( Quaternion( kVecResult.x, kVecResult.y, kVecResult.z, qw * rkQuat.qw - kVecOne * kVecTwo ) );
}


NEOENGINE_API Quaternion Quaternion::operator *( float fScalar ) const
{
	return( Quaternion( qx * fScalar, qy * fScalar, qz * fScalar, qw * fScalar ) );
}


NEOENGINE_API Quaternion &Quaternion::operator *=( float fScalar )
{
	qx *= fScalar;
	qy *= fScalar;
	qz *= fScalar;
	qw *= fScalar;

	return( *this );
}


NEOENGINE_API Quaternion Quaternion::operator +( const Quaternion &rkQuat ) const
{
	return( Quaternion( qx + rkQuat.qx, qy + rkQuat.qy, qz + rkQuat.qz, qw + rkQuat.qw ) );
}


NEOENGINE_API bool Quaternion::operator ==( const Quaternion &rkQuat ) const
{
	return( ( fabs( qx - rkQuat.qx ) < EPSILON ) && ( fabs( qy - rkQuat.qy ) < EPSILON ) && ( fabs( qz - rkQuat.qz ) < EPSILON ) && ( fabs( qw - rkQuat.qw ) < EPSILON ) );
}


NEOENGINE_API bool Quaternion::operator !=( const Quaternion &rkQuat ) const
{
	return( ( fabs( qx - rkQuat.qx ) > EPSILON ) || ( fabs( qy - rkQuat.qy ) > EPSILON ) || ( fabs( qz - rkQuat.qz ) > EPSILON ) || ( fabs( qw - rkQuat.qw ) > EPSILON ) );
}



NEOENGINE_API Matrix::Matrix() { fmemcpy( m_aafMatrix, g_afIdentityMatrix, 64 ); }

NEOENGINE_API Matrix::Matrix( const Matrix &rkMatrix ) { fmemcpy( m_aafMatrix, rkMatrix.m_aafMatrix, 64 ); }

NEOENGINE_API Matrix::Matrix( const float afComponents[] ) { fmemcpy( m_aafMatrix, afComponents, 64 ); }

NEOENGINE_API Matrix::Matrix( const Quaternion &rkQuat ) { rkQuat.ToMatrix( this ); m_aafMatrix[0][3] = m_aafMatrix[1][3] = m_aafMatrix[2][3] = m_aafMatrix[3][0] = m_aafMatrix[3][1] = m_aafMatrix[3][2] = 0.0f; m_aafMatrix[3][3] = 1.0f; }

NEOENGINE_API Matrix::Matrix( const Quaternion &rkQuat, const Vector3d &rkTranslation ) { rkQuat.ToMatrix( this ); m_aafMatrix[0][3] = rkTranslation.x; m_aafMatrix[1][3] = rkTranslation.y; m_aafMatrix[2][3] = rkTranslation.z; m_aafMatrix[3][0] = m_aafMatrix[3][1] = m_aafMatrix[3][2] = 0.0f; m_aafMatrix[3][3] = 1.0f; }

NEOENGINE_API Matrix::Matrix( const Vector3d &rkVector ) { Set( rkVector ); }

NEOENGINE_API Matrix &Matrix::Reset()
{
	fmemcpy( m_aafMatrix, g_afIdentityMatrix, 64 );
	return( *this );
}


NEOENGINE_API Matrix &Matrix::Set( float afComponents[] )
{
	fmemcpy( m_aafMatrix, afComponents, 64 );
	return( *this ); 
}


NEOENGINE_API Matrix &Matrix::Set( const Quaternion &rkQuat, const Vector3d &rkTranslation )
{
	rkQuat.ToMatrix( this );
	m_aafMatrix[0][3] = rkTranslation.x;
	m_aafMatrix[1][3] = rkTranslation.y;
	m_aafMatrix[2][3] = rkTranslation.z;
	return( *this );
}


NEOENGINE_API Matrix &Matrix::Set( const Vector3d &rkVector )
{
	float *pfDst = &m_aafMatrix[0][0];

	*pfDst++ =  0.0f;
	*pfDst++ = -rkVector.z;
	*pfDst++ =  rkVector.y;
	*pfDst++ =  0.0f;

	*pfDst++ =  rkVector.z;
	*pfDst++ =  0.0f;
	*pfDst++ = -rkVector.x;
	*pfDst++ =  0.0f;

	*pfDst++ = -rkVector.y;
	*pfDst++ =  rkVector.x;
	*pfDst++ =  0.0f;
	*pfDst++ =  0.0f;

	*pfDst++ =  0.0f;
	*pfDst++ =  0.0f;
	*pfDst++ =  0.0f;
	*pfDst   =  1.0f;

	return( *this );
}


NEOENGINE_API Matrix &Matrix::SetRotation( const Quaternion &rkQuat )
{
	rkQuat.ToMatrix( this );
	return( *this );
}


NEOENGINE_API Matrix &Matrix::SetTranslation( const Vector3d &rkTranslation )
{
	m_aafMatrix[0][3] = rkTranslation.x;
	m_aafMatrix[1][3] = rkTranslation.y;
	m_aafMatrix[2][3] = rkTranslation.z;
	return( *this );
}


NEOENGINE_API Matrix &Matrix::SetScaling( const Vector3d &rkScaling )
{
	m_aafMatrix[0][0] = rkScaling.x;
	m_aafMatrix[1][1] = rkScaling.y;
	m_aafMatrix[2][2] = rkScaling.z;
	return( *this );
}


NEOENGINE_API Matrix &Matrix::Transpose()
{
	float fTemp       = m_aafMatrix[1][0];
	m_aafMatrix[1][0] = m_aafMatrix[0][1];
	m_aafMatrix[0][1] = fTemp;

	fTemp             = m_aafMatrix[2][0];
	m_aafMatrix[2][0] = m_aafMatrix[0][2];
	m_aafMatrix[0][2] = fTemp;

	fTemp             = m_aafMatrix[3][0];
	m_aafMatrix[3][0] = m_aafMatrix[0][3];
	m_aafMatrix[0][3] = fTemp;

	fTemp             = m_aafMatrix[2][1];
	m_aafMatrix[2][1] = m_aafMatrix[1][2];
	m_aafMatrix[1][2] = fTemp;

	fTemp             = m_aafMatrix[3][1];
	m_aafMatrix[3][1] = m_aafMatrix[1][3];
	m_aafMatrix[1][3] = fTemp;

	fTemp             = m_aafMatrix[3][2];
	m_aafMatrix[3][2] = m_aafMatrix[2][3];
	m_aafMatrix[2][3] = fTemp;

	return( *this );
}


NEOENGINE_API Matrix &Matrix::TransposeTo( Matrix *pkMatrix )
{
	float *pfDst = &pkMatrix->m_aafMatrix[0][0];
	float *pfSrc = &m_aafMatrix[0][0];

	*pfDst++ = pfSrc[0];
	*pfDst++ = pfSrc[4];
	*pfDst++ = pfSrc[8];
	*pfDst++ = pfSrc[12];
	*pfDst++ = pfSrc[1];
	*pfDst++ = pfSrc[5];
	*pfDst++ = pfSrc[9];
	*pfDst++ = pfSrc[13];
	*pfDst++ = pfSrc[2];
	*pfDst++ = pfSrc[6];
	*pfDst++ = pfSrc[10];
	*pfDst++ = pfSrc[14];
	*pfDst++ = pfSrc[3];
	*pfDst++ = pfSrc[7];
	*pfDst++ = pfSrc[11];
	*pfDst   = pfSrc[15];

	return( *pkMatrix );
}


NEOENGINE_API Vector3d Matrix::GetColumn( int iColumn ) const
{
	return Vector3d( m_aafMatrix[ 0 ][ iColumn ], m_aafMatrix[ 1 ][ iColumn ], m_aafMatrix[ 2 ][ iColumn ] );
}


NEOENGINE_API Matrix &Matrix::operator =( const Matrix &rkMatrix )
{
	fmemcpy( m_aafMatrix, rkMatrix.m_aafMatrix, 64 );
	return( *this );
}


NEOENGINE_API Matrix &Matrix::operator =( const Quaternion &rkQuat )
{
	rkQuat.ToMatrix( this );
	
	m_aafMatrix[0][3] = m_aafMatrix[1][3] = m_aafMatrix[2][3] = m_aafMatrix[3][0] = m_aafMatrix[3][1] = m_aafMatrix[3][2] = 0.0f;
	m_aafMatrix[3][3] = 1.0f;
	
	return( *this );
}


NEOENGINE_API Matrix Matrix::operator *( const Matrix &rkMatrix ) const
{
	Matrix kProd;
	
	for( int iRow = 0; iRow < 4; ++iRow )
		for( int iCol = 0; iCol < 4; ++iCol )
			kProd.m_aafMatrix[ iRow ][ iCol ] =
			  m_aafMatrix[ iRow ][ 0 ] * rkMatrix.m_aafMatrix[ 0 ][ iCol ] +
			  m_aafMatrix[ iRow ][ 1 ] * rkMatrix.m_aafMatrix[ 1 ][ iCol ] +
			  m_aafMatrix[ iRow ][ 2 ] * rkMatrix.m_aafMatrix[ 2 ][ iCol ] +
			  m_aafMatrix[ iRow ][ 3 ] * rkMatrix.m_aafMatrix[ 3 ][ iCol ];
		
	return kProd;
}


NEOENGINE_API Matrix &Matrix::operator *=( const Matrix &rkMatrix )
{
	float aafProd[4][4];
	
	for( int iRow = 0; iRow < 4; ++iRow )
		for( int iCol = 0; iCol < 4; ++iCol )
			aafProd[ iRow ][ iCol ] =
			  m_aafMatrix[ iRow ][ 0 ] * rkMatrix.m_aafMatrix[ 0 ][ iCol ] +
			  m_aafMatrix[ iRow ][ 1 ] * rkMatrix.m_aafMatrix[ 1 ][ iCol ] +
			  m_aafMatrix[ iRow ][ 2 ] * rkMatrix.m_aafMatrix[ 2 ][ iCol ] +
			  m_aafMatrix[ iRow ][ 3 ] * rkMatrix.m_aafMatrix[ 3 ][ iCol ];
		
	return Set( &aafProd[0][0] );
}


NEOENGINE_API Matrix Matrix::operator *( float fScale ) const
{
	return( Matrix( *this ) *= fScale );
}


NEOENGINE_API Matrix &Matrix::operator *=( float fScale )
{
	float *pfVal = &m_aafMatrix[0][0];

	for( int i = 0; i < 16; ++i )
		*pfVal++ *= fScale;
		
	return( *this );
}


NEOENGINE_API Matrix Matrix::operator -( const Matrix &rkMatrix ) const
{
	return( Matrix( *this ) -= rkMatrix );
}


NEOENGINE_API Matrix &Matrix::operator -=( const Matrix &rkMatrix )
{
	float *pfVal = &m_aafMatrix[0][0];
	const float *pfSrc = &rkMatrix.m_aafMatrix[0][0];

	for( int i = 0; i < 16; ++i )
		*pfVal++ -= *pfSrc++;
		
	return( *this );
}


NEOENGINE_API Matrix Matrix::operator +( const Matrix &rkMatrix ) const
{
	return( Matrix( *this ) += rkMatrix );
}


NEOENGINE_API Matrix &Matrix::operator +=( const Matrix &rkMatrix )
{
	float *pfVal = &m_aafMatrix[0][0];
	const float *pfSrc = &rkMatrix.m_aafMatrix[0][0];

	for( int i = 0; i < 16; ++i )
		*pfVal++ += *pfSrc++;
		
	return( *this );
}


NEOENGINE_API Vector3d Matrix::operator *( const Vector3d &rkVector ) const
{
	Vector3d kResult;

	kResult.x = m_aafMatrix[0][0] * rkVector.x + m_aafMatrix[0][1] * rkVector.y + m_aafMatrix[0][2] * rkVector.z + m_aafMatrix[0][3];
	kResult.y = m_aafMatrix[1][0] * rkVector.x + m_aafMatrix[1][1] * rkVector.y + m_aafMatrix[1][2] * rkVector.z + m_aafMatrix[1][3];
	kResult.z = m_aafMatrix[2][0] * rkVector.x + m_aafMatrix[2][1] * rkVector.y + m_aafMatrix[2][2] * rkVector.z + m_aafMatrix[2][3];

	return kResult;
}


NEOENGINE_API bool Matrix::operator ==( const Matrix &rkMatrix ) const
{
	for( int iRow = 0; iRow < 4; ++iRow )
		for( int iCol = 0; iCol < 4; ++iCol )
			if( fabs( m_aafMatrix[ iRow ][ iCol ] - rkMatrix.m_aafMatrix[ iRow ][ iCol ] ) > EPSILON )
				return false; 
			
	return true;
}


NEOENGINE_API bool Matrix::operator !=( const Matrix &rkMatrix ) const
{
	for( int iRow = 0; iRow < 4; ++iRow )
		for( int iCol = 0; iCol < 4; ++iCol )
			if( fabs( m_aafMatrix[ iRow ][ iCol ] - rkMatrix.m_aafMatrix[ iRow ][ iCol ] ) < EPSILON )
				return false; 
			
	return true;
}


NEOENGINE_API       float *Matrix::operator []( int iRow )       { return (float*)&m_aafMatrix[ iRow ][ 0 ]; }
NEOENGINE_API const float *Matrix::operator []( int iRow ) const { return (float*)&m_aafMatrix[ iRow ][ 0 ]; }


#if defined( WIN32 ) && defined( __MINGW32__ )
#  undef NEOENGINE_API
#  define NEOENGINE_API
#endif
