/***************************************************************************
      submeshanimator.h  -  Animator controller classes for submeshes
                             -------------------
    begin                : Wed Jan 29 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, submeshanimator.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NESUBMESHANIMATOR_H
#define __NESUBMESHANIMATOR_H


#include "base.h"
#include "keyframe.h"
#include "animation.h"
#include "animator.h"
#include "vertexbuffer.h"


/**
  * \file submeshanimator.h
  * Animator control classes for submeshes
  */


namespace NeoEngine
{


/**
  * \brief Data for a submesh keyframe
  * A submesh keyframe holds a vertex buffer
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SubMeshKeyframe : public Keyframe
{
	public:

		/*! Target vertex data */
		VertexBufferPtr                 m_pkBuffer;

		/**
		*/
		                                SubMeshKeyframe( float fTime = 0.0f ) : Keyframe( fTime ), m_pkBuffer( 0 ) {}

		/**
		* \param rkKeyframe             Reference keyframe object
		*/
		                                SubMeshKeyframe( const SubMeshKeyframe &rkKeyframe ) : Keyframe( rkKeyframe ), m_pkBuffer( rkKeyframe.m_pkBuffer ) {}
};


#ifdef WIN32

#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif

#  ifndef __HAVE_VECTOR_NESUBMESHKEYFRAME
     UDTVectorEXPIMP( class SubMeshKeyframe* );
#    define __HAVE_VECTOR_NESUBMESHKEYFRAME
#  endif

#  ifdef _MSC_VER
#    ifndef __HAVE_NEANIMATION_NESUBMESHKEYFRAME
       EXPIMP_TEMPLATE template class NEOENGINE_API Animation< class SubMeshKeyframe >;
#      define __HAVE_NEANIMATION_NESUBMESHKEYFRAME
#    endif
#  endif

#endif


/**
  * \brief An animation for a submesh
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SubMeshAnimation : public Animation< SubMeshKeyframe >
{
	public:

		/**
		*/
		                                   SubMeshAnimation() : Animation< SubMeshKeyframe >() {}

		/**
		* \param rkAnimation               Reference animation object
		*/
		                                   SubMeshAnimation( const SubMeshAnimation &rkAnimation ) : Animation< SubMeshKeyframe >( rkAnimation ) {}
};


#ifdef WIN32

#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif

#  ifndef __HAVE_VECTOR_NESUBMESHANIMATION
     UDTVectorEXPIMP( SubMeshAnimation* );
#    define __HAVE_VECTOR_NESUBMESHANIMATION
#  endif

#  ifdef _MSC_VER
#    ifndef __HAVE_NEANIMATIONBLENDSTAGE_NESUBMESHANIMATION
       EXPIMP_TEMPLATE template class NEOENGINE_API AnimationBlendStage< SubMeshAnimation >;
#      define __HAVE_NEANIMATIONBLENDSTAGE_NESUBMESHANIMATION
#    endif
#    ifndef __HAVE_VECTOR_NEANIMATIONBLENDSTAGE_NESUBMESHANIMATION
       UDTVectorEXPIMP( AnimationBlendStage< SubMeshAnimation >* );
#      define __HAVE_VECTOR_NEANIMATIONBLENDSTAGE_NESUBMESHANIMATION
#    endif
#    ifndef __HAVE_NEANIMATORCONTROLLER_NESUBMESHANIMATION
       EXPIMP_TEMPLATE template class NEOENGINE_API AnimatorController< SubMeshAnimation >;
#      define __HAVE_NEANIMATORCONTROLLER_NESUBMESHANIMATION
#    endif
#  endif

#endif


/**
  * \brief Animator controller for submeshes
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SubMeshAnimatorController : public AnimatorController< SubMeshAnimation >
{
	protected:

		/*! Temporary interpolator buffer */
		VertexBufferPtr                                m_pkInterpolated;

		/*! Target vertex buffer for blending */
		VertexBufferPtr                                m_pkTarget;


		/**
		* Blend in a new stage in final data
		* \param pkDstAnim                             Destination animation
		* \param fWeight                               Blend weight factor
		* \param pvbMask                               Mask array
		*/
		virtual void                                   BlendStage( SubMeshAnimation *pkDstAnim, float fWeight, std::vector< bool > *pvbMask );


	public:


		/**
		*/
		                                               SubMeshAnimatorController() : AnimatorController< SubMeshAnimation >() { m_bAutomaticBlend = false; }

		/**
		* \param rkController                          Reference controller object to copy
		*/
		                                               SubMeshAnimatorController( const SubMeshAnimatorController &rkController ) : AnimatorController< SubMeshAnimation >( rkController ) {}

		/**
		* Interpolate vertices
		* \param pkBuffer                              Vertex buffer receiving data
		*/
		void                                           InterpolateVertices( VertexBufferPtr pkBuffer );
};


};


#endif
