/***************************************************************************
                    capsule.h  -  Capsule bounding volume
                             -------------------
    begin                : Sun Jul 13 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, capsule.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NECAPSULE_H
#define __NECAPSULE_H



#include "base.h"
#include "boundingvolume.h"


/**
  * \file capsule.h
  * Capsule bounding volume
  */


namespace NeoEngine
{



/**
  * \brief Capsule bounding volume
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Capsule : public BoundingVolume
{
	public:

		/*! Length of cylinder from midpoint to end (half total length) */
		float                                         m_fLength;

		/* ! Radius of cylinder and end half-spheres*/
		float                                         m_fRadius;



		/**
		* \param fLength                              Length
		* \param fRadius                              Radius
		*/
		                                              Capsule( float fLength = 0.0f, float fRadius = 0.0f );

		/**
		* \param rkCapsule                            Reference object to copy
		*/
		                                              Capsule( const Capsule &rkCapsule ) : BoundingVolume( rkCapsule ), m_fLength( rkCapsule.m_fLength ), m_fRadius( m_fRadius ) {}

		/**
		* Intersection test with unknown object type
		* \param pkObj                                Bounding volume object to test for intersection with
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \param bInvertNormal                        If false, collision normal will point from passed object to this. If true, normal will point in other direction
		* \return                                     true if objects intersect, false if not
		*/
		inline virtual bool                           Intersection( BoundingVolume *pkObj, ContactSet *pkContactSet = 0, bool bInvertNormal = false )
		{
			BOUNDINGVOLUMETYPE eType = pkObj->GetType();

			if( eType == BV_AABB )
				return NeoEngine::Intersection( (AABB*)pkObj, this, pkContactSet, !bInvertNormal );
			else if( eType == BV_OBB )
				return NeoEngine::Intersection( (OBB*)pkObj, this, pkContactSet, !bInvertNormal );
			else if( eType == BV_SPHERE )
				return NeoEngine::Intersection( (Sphere*)pkObj, this, pkContactSet, !bInvertNormal );
			else // BV_CAPSULE
				return NeoEngine::Intersection( this, (Capsule*)pkObj, pkContactSet, bInvertNormal );
		}

		/**
		* Intersection with AABB
		* \param pkAABB                               AABB
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \param bInvertNormal                        If false, collision normal will point from passed object to this. If true, normal will point in other direction
		* \return                                     true if the AABB intersect with this object, false if not
		*/
		inline virtual bool                           Intersection( AABB *pkAABB, ContactSet *pkContactSet = 0, bool bInvertNormal = false ) { return NeoEngine::Intersection( pkAABB, this, pkContactSet, !bInvertNormal ); }
	
		/**
		* Intersection with OBB
		* \param pkOBB                                OBB
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \param bInvertNormal                        If false, collision normal will point from passed object to this. If true, normal will point in other direction
		* \return                                     true if OBB intersect with this object, false if not
		*/
		inline virtual bool                           Intersection( OBB *pkOBB, ContactSet *pkContactSet = 0, bool bInvertNormal = false ) { return NeoEngine::Intersection( pkOBB, this, pkContactSet, bInvertNormal ); }

		/**
		* Intersection with sphere
		* \param pkSphere                             Sphere
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \param bInvertNormal                        If false, collision normal will point from passed object to this. If true, normal will point in other direction
		* \return                                     true if sphere intersect with this object, false if not
		*/
		inline virtual bool                           Intersection( Sphere *pkSphere, ContactSet *pkContactSet = 0, bool bInvertNormal = false ) { return NeoEngine::Intersection( pkSphere, this, pkContactSet, !bInvertNormal ); }

		/**
		* Intersection with capsule
		* \param pkCapsule                            Capsule
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \param bInvertNormal                        If false, collision normal will point from passed object to this. If true, normal will point in other direction
		* \return                                     true if capsule intersect with this object, false if not
		*/
		inline virtual bool                           Intersection( Capsule *pkCapsule, ContactSet *pkContactSet = 0, bool bInvertNormal = false ) { return NeoEngine::Intersection( this, pkCapsule, pkContactSet, bInvertNormal ); }

		/**
		* Intersection with frustum
		* \param pkFrustum                            Frustum
		* \return                                     true if frustum intersects with this object, false if not
		*/
		inline virtual bool                           Intersection( Frustum *pkFrustum ) { return NeoEngine::Intersection( this, pkFrustum ); }

		/**
		* Intersection with polygon
		* \param rkV0                                 First corner
		* \param rkV1                                 Second corner
		* \param rkV2                                 Third corner
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \param bForceTriNormal                      If true force use of triangle normal as separating plane when calculating contact points and depths
		* \param rkNormal                             Optional precalculated normal
		* \return                                     true if polygon intersects with this object, false if not
		*/
		virtual bool                                  Intersection( const Vector3d &rkV0, const Vector3d &rkV1, const Vector3d &rkV2, ContactSet *pkContactSet = 0, bool bForceTriNormal = true, const Vector3d &rkNormal = Vector3d::ZERO );

		/**
		* Intersection with point
		* \param rkPoint                              Point
		* \return                                     true if plane intersects with this object, false if not
		*/
		virtual bool                                  Intersection( const Vector3d &rkPoint );

		/**
		* Intersection with ray
		* \param rkRay                                Ray
		* \param pkContactSet                         Contact set object receiving collision contact data, 0 if not needed
		* \return                                     true if ray intersects with this object, false if not
		*/
		virtual bool                                  Intersection( const Ray &rkRay, ContactSet *pkContactSet = 0 );

		/**
		* Intersection with line
		* \param rkLine                               Line
		* \return                                     true if line intersects with this object, false if not
		*/
		virtual bool                                  Intersection( const Line &rkLine );

		/**
		* Intersection with plane
		* \param rkPlane                              Plane
		* \return                                     true if plane intersects with this object, false if not
		*/
		virtual bool                                  Intersection( const Plane &rkPlane );

		/**
		* Generate from AABB
		* \param pkAABB                               Source AABB object
		*/
		virtual void                                  Generate( AABB *pkAABB );

		/**
		* Generate from OBB
		* \param pkOBB                                Source OBB object
		*/
		virtual void                                  Generate( OBB *pkOBB );

		/**
		* Generate from sphere
		* \param pkSphere                             Source sphere object
		*/
		virtual void                                  Generate( Sphere *pkSphere );

		/**
		* Generate from capsule
		* \param pkCapsule                            Source capsule object
		*/
		virtual void                                  Generate( Capsule *pkCapsule );

		/**
		* Generate from vertex soup
		* \param pkVertexBuffer                       Vertex buffer
		*/
		virtual void                                  Generate( VertexBufferPtr &pkVertexBuffer );

		/**
		* Merge with AABB
		* \param pkAABB                               Source AABB object
		*/
		virtual void                                  Merge( AABB *pkAABB );

		/**
		* Merge with OBB
		* \param pkOBB                                Source OBB object
		*/
		virtual void                                  Merge( OBB *pkOBB );

		/**
		* Merge with sphere
		* \param pkSphere                             Source sphere object
		*/
		virtual void                                  Merge( Sphere *pkSphere );

		/**
		* Merge with capsule
		* \param pkCapsule                            Source capsule object
		*/
		virtual void                                  Merge( Capsule *pkCapsule );

		/**
		* \return                                     Bounding volume type identifier
		*/
		inline virtual BOUNDINGVOLUMETYPE             GetType() { return BV_CAPSULE; }

		/**
		* \return                                     New AABB that is exact copy of this
		*/
		virtual BoundingVolume                       *Duplicate() const;

		/**
		* Render volume outlines
		* \param rkColor                              Color of outlines
		*/
		virtual void                                  RenderOutlines( const Color &rkColor = Color::GREEN ) const;
};


}; // namespace NeoEngine



#endif

