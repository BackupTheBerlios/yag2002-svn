/***************************************************************************
             package.h  -  File management in virtual file system
                             -------------------
    begin                : Wed Sep 18 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, package.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEPACKAGE_H
#define __NEPACKAGE_H


/**
  * \file package.h
  * File management in packages
  */


#include "base.h"
#include "loadableentity.h"
#include "directory.h"

#include <string>


namespace NeoEngine
{


// External classes
class FileManager;
class Package;


/**
  * \brief Data for a file in directory/package hierarchy
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API VirtualFileTemplate : public FileTemplate
{
	public:

		/*! Offset in package file */
		int                                           m_iOffset;

		/*! Size */
		int                                           m_iSize;

		/*! Flags */
		int                                           m_iFlags;

		/*! Auxiliary data */
		int                                           m_aiData[4];

		/*! Package */
		Package                                      *m_pkPackage;


		/**
		* Allocate new file object from template
		* \param rstrName                             File name
		* \param pkParent                             Parent directory object
		* \return                                     New file object
		*/
		virtual File                                 *AllocateFile( const std::string &rstrName, Directory *pkParent );
};




/**
  * \brief File management in packages
  * A package can both contain real files and virtual files (read from package file).
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Package : public Directory, public LoadableEntity
{
	public:

		/**
		* \brief File flags for package manager
		* (should be somewhere between package.h and zippackage.h)
		*/
		enum FILEFLAG
		{
		  /*! Normal uncompressed data for file */
		  FILEFLAG_NORMAL                             = 0x00000000,
		
		  /*! File is bzip2 compressed */
		  FILEFLAG_BZIP2_COMPRESSED                   = 0x00000001,

		  /*! File is zip compressed */
		  FILEFLAG_ZIP_COMPRESSED                     = 0x00000002
		};


	protected:

		/**
		* Main loader method. Called by LoadableEntity to load object if file was opened successfully
		* \param uiFlags                              Loader flags (currently ignored for packages)
		* \return                                     true if load was successful, false otherwise
		*/
		virtual bool                                  LoadNode( unsigned int uiFlags );

		/**
		* Skips the file header if necessary
		*/
		virtual void                                  SkipHeader();

		/**
		* Read cluster data from file. Recursive.
		* \param pkDirectory                          Directory to read
		*/
		virtual void                                  ReadCluster( Directory *pkDirectory ) = 0;


  public:

		/**
		* Open and parse package file. You can also put in a directory in the normal file system and it will be recursivly parsed
		* \param pkParent                             Parent directory
		* \param rstrFile                             Package file name
		* \param pkManager                            File manager we are connected to
		*/
		                                              Package( Directory *pkParent, const std::string &rstrFile, FileManager *pkManager );

		/**
		* Deallocate hierarchy
		*/
		virtual                                      ~Package();

		/**
		* Get package file ptr
		* \return                                     File ptr
		*/
		inline File                                  *GetBaseFile() { return m_pkFile; }
};


}; // namespace NeoEngine


#endif  // __NEPACKAGE_H
