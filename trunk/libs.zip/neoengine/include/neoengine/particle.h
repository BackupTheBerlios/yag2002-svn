/***************************************************************************
                     particle.h  -  Particle system classes
                             -------------------
    begin                : Thu May 9 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, particle.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEPARTICLE_H
#define __NEPARTICLE_H


/**
  * \file particle.h
  * Classes for particle systems
  */


#define __NEED_VECTOR_FLOAT

#include "base.h"
#include "scenenode.h"
#include "physicsnode.h"

#include <vector>


namespace NeoEngine
{


// External classes
class Room;


typedef PhysicsNode Particle;


/**
  * \brief Callback class for particle generation
  * Will be called by generator for allocating particles
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ParticleAllocatorCallback
{
	public:

		/**
		* Implement this to handle new particle allocation and initialization. If a pointer in
		* the array is not null, no new particle should be allocated but the particle pointed
		* to should be re-initialized. For null pointer elements, allocate and initialize new particle
		* \param uiNumParticles                       Number of particles to allocate
		* \param ppkParticles                         Pointer to array of pointers receiving new pointers to new particles
		*/
		virtual void                                  AllocateParticles( unsigned int uiNumParticles, Particle **ppkParticles ) = 0;
};


/**
  * \brief Base class for particle generators
  * Generate particles for a particle system
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ParticleGenerator
{
	friend class ParticleSystem;

	protected:

		/*! Fraction part of last generation (if a Generate call produces 0.9 particles, we want to store this to next call) */
		float                                         m_fFraction;

		/*! Initial velocity of new particles */
		float                                         m_fVelocity;

		/*! Accuracy of initial velocity */
		float                                         m_fVelocityAccuracy;

		/*! Density (particles per second we will generate) */
		float                                         m_fDensity;

		/*! Allocation callback. Will be called for each new particle this generator allocates */
		ParticleAllocatorCallback                  *m_pkAllocatorCallback;


		/**
		* Allocate new particles
		* \param uiNumParticles                       Number of particles to allocate
		* \param ppkParticles                         Pointer to array of pointers receiving new particles
		*/
		virtual void                                  Allocate( unsigned int uiNumParticles, Particle **ppkParticles );


	public:

		/**
		* \param fVelocity                            Initial velocity of generated particles
		* \param fVelocityAccuracy                    Accuracy of initial velocity. 1.0f mean all particles will have _exactly_ fVelocity, 0.0f means a range of 0.0f < vel < 2.0f*fVelocity
		* \param fDensity                             Density (particles per second)
		* \param pkAllocatorCallback                  Callback to call when new particle is generated
		*/
		                                              ParticleGenerator( float fVelocity, float fVelocityAccuracy, float fDensity, ParticleAllocatorCallback *pkAllocatorCallback = 0 ) : m_fFraction(0.0f), m_fVelocity( fVelocity ), m_fVelocityAccuracy( fVelocityAccuracy ), m_fDensity( fDensity ), m_pkAllocatorCallback( pkAllocatorCallback ) {}

		/**
		*/
		virtual                                      ~ParticleGenerator() {}

		/**
		* Implement for specific generator
		* \param fDeltaTime                           Deltatime (time*density = particles_to_generate)
		* \param uiMaxParticles                       Maximum number of particles to generate or 0 if infinite
		* \param ppkParticles                         Pointer to array of pointers receiving new particles
		* \param kPos                                 Position of generator
		* \return                                     Number of particles generated
		*/
		virtual unsigned int                          Generate( float fDeltaTime, unsigned int uiMaxParticles, Particle **ppkParticles, const Vector3d &kPos ) = 0;
};


/**
  * \brief Particle generator, spherical generation volume
  * Generate particles in spherical outbursts
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SphereParticleGenerator : public ParticleGenerator
{
	public:

		/**
		* Generate particles in spherical outbursts
		*
		* \param fVelocity                            Initial velocity of generated particles
		* \param fVelocityAccuracy                    Accuracy of initial velocity. 1.0f mean all particles will have _exactly_ fVelocity, 0.0f means a range of 0.0f < vel < 2.0f*fVelocity
		* \param fDensity                             Density (particles per second)
		* \param pkAllocatorCallback                  Callback to call when new particle is generated
		*/

		                                              SphereParticleGenerator( float fVelocity, float fVelocityAccuracy, float fDensity, ParticleAllocatorCallback *pkAllocatorCallback = 0 );

		/**
		*/
		virtual                                      ~SphereParticleGenerator();

		/**
		* Generate particles
		* \param fDeltaTime                           Deltatime passed
		* \param uiMaxParticles                       Maximum number of particles to generate or 0 if infinite
		* \param ppkParticles                         Pointer to array of pointers receiving new particles
		* \param kPos                                 Position of generator
		* \return                                     Number of particles generated
		*/
		virtual unsigned int                          Generate( float fDeltaTime, unsigned int uiMaxParticles, Particle **ppkParticles, const Vector3d &kPos );
};


/**
  * \brief Particle system
  * Manage system of particles
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ParticleSystem : public SceneNode
{
	public:
		DefineVisitable()

	protected:


		/**
		  * \class ParticleSubSystem
		  * \brief An array of a fixed numer of particles
		  * \author Mattias Jansson (mattias@realityrift.com)
		  */
		class NEOENGINE_API ParticleSubSystem
		{
			public:

				/**
				* \enum PARTICLESUBSYSTEMDEF
				* \brief Defined for a particle subsystem
				*/
				enum PARTICLESUBSYSTEMDEF
				{
				  /*! Number of particles in a subsystem */
				  NUMPARTICLES                        = 10
				};


				/*! Particles */
				Particle                             *m_apkParticles[ NUMPARTICLES ];

				/*! Lifetime of each particle */
				float                                 m_afLifetime[ NUMPARTICLES ];

				/*! TTL of each particle */
				float                                 m_afTTL[ NUMPARTICLES ];

				/*! Number of used slots */
				unsigned int                          m_uiNumUsedSlots;


				/**
				*/
				                                      ParticleSubSystem() { memset( m_apkParticles, 0, sizeof( Particle* ) * NUMPARTICLES ); m_uiNumUsedSlots = 0; }

				/**
				* Deallocate remaining particles
				*/
				                                     ~ParticleSubSystem();

				/**
				* \return                             Index to free slot (-1 if none)
				*/
				inline int                            GetFreeSlot() { if( m_uiNumUsedSlots >= NUMPARTICLES ) return -1; return m_uiNumUsedSlots; }

				/**
				* Free slot
				* \param uiSlot                       Slot to free
				*/
				inline void                           FreeSlot( unsigned int uiSlot )				
				{
					if( uiSlot >= m_uiNumUsedSlots )
						return;

					for( unsigned int uiNextSlot = uiSlot + 1; uiNextSlot < m_uiNumUsedSlots; ++uiNextSlot, ++uiSlot )
					{
						m_apkParticles[ uiSlot ] = m_apkParticles[ uiNextSlot ];
						m_afLifetime[ uiSlot ]   = m_afLifetime[ uiNextSlot ];
						m_afTTL[ uiSlot ]        = m_afTTL[ uiNextSlot ];
					}

					m_apkParticles[ --m_uiNumUsedSlots ] = 0;
				}
		};


		/*! Particles */
		ParticleSubSystem                           **m_ppkSubSystems;

		/*! Number of particles currently in system */
		unsigned int                                  m_uiNumParticles;

		/*! Max number of particles */
		unsigned int                                  m_uiMaxParticles;

		/*! Number of subsystem pointers in array */
		unsigned int                                  m_uiNumSubSystemPointers;

		/*! Number of valid subsystems in array */
		unsigned int                                  m_uiNumSubSystems;

		/*! Normal lifetime for a particle, if any */
		float                                         m_fNormalTTL;

		/*! TTL accuracy */
		float                                         m_fTTLAccuracy;

		/*! Particle generator */
		ParticleGenerator                            *m_pkGenerator;

		/*! Generate array */
		Particle                                    **m_ppkGeneratePool;

		/*! Number of pointers in generate pool */
		unsigned int                                  m_uiGeneratePoolSize;

		/*! Number of freed particles */
		unsigned int                                  m_uiNumFreeParticles;

		/*! Room to attach new particles to */
		Room                                         *m_pkRoom;

		/*! Generate flag */
		bool                                          m_bGenerate;


	public:

		/**
		* \param pkGenerator                          Particle generator (will be deleted by dtor)
		* \param uiMaxParticles                       Maximum number of particles
		* \param fTTL                                 Time-To-Live for particles
		* \param fTTLAccuracy                         Deviation from normal TTL value. A value of 1.0f will cause all particle to live _exactly_ fTTL seconds, a value of 0.0f will cause a particle to live in max 2.0f*fTTL and minimum 0.0f seconds.
		*/
		                                              ParticleSystem( ParticleGenerator *pkGenerator, unsigned int uiMaxParticles, float fTTL = 0.0f, float fTTLAccuracy = 0.0f );

		/**
		* Also deletes generator object and all particles
		*/
		virtual                                      ~ParticleSystem();

		/**
		* Update system and generate particles
		* \param fDeltaTime                           Deltatime passed
		*/
		virtual void                                  Update( float fDeltaTime = 0.0f );

		/**
		* Duplicate system
		* \return                                     New node that is exact duplicate of this node
		*/
		virtual SceneNode                            *Duplicate();

		/**
		* \return                                     Number of particles in system
		*/
		unsigned int                                  GetNumParticles() { return m_uiNumParticles; }

		/**
		* Set room to attach new particles to
		* \param pkRoom                               Room
		*/
		void                                          SetRoom( Room *pkRoom );

		/**
		* Set generate flag
		* \param bGenerate                            Generate flag, if true system will generate particles
		*/
		inline void                                   SetGenerate( bool bGenerate ) { m_bGenerate = bGenerate; }

		/**
		* Toggle generate flag
		*/
		inline void                                   ToggleGenerate() { m_bGenerate = !m_bGenerate; }
};


};


#endif
