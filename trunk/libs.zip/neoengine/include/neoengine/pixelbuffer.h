/***************************************************************************
                pixelbuffer.h  -  Buffer for offscreen rendering
                             -------------------
    begin                : Sat April 26, 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, pixelbuffer.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEPIXELBUFFER_H
#define __NEPIXELBUFFER_H



#include "base.h"
#include "render.h"
#include "texture.h"


namespace NeoEngine
{



/**
  * \brief Pixel buffer for offscreen rendering
  * Pixelbuffers are used for render-to-texture effects. Create a pixelbuffer
  * through the render device method CreatePixelBuffer.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API PixelBuffer
{
	protected:

		/*! ID */
		unsigned int                                  m_uiID;

		/*! Width, in pixels, of buffer */
		unsigned int                                  m_uiWidth;

		/*! Height, in pixels, of buffer */
		unsigned int                                  m_uiHeight;

		/*! Bits per pixel */
		unsigned int                                  m_uiBPP;

		/**
		*/
		                                              PixelBuffer();


	public:

		/**
		*/
		virtual                                      ~PixelBuffer();

		/**
		* Set active target cubemap face. Ignored for non-cubemap target texture types
		* \param eCubeMapFace                         Which cubemap face to render to
		*/
		virtual void                                  SetCubeMapFace( Texture::TEXTURECUBEMAPFACE eCubeMapFace ) = 0;

		/**
		* \return                                     Render target identifier
		*/
		unsigned int                                  GetTargetID() const { return( RenderDevice::PIXELBUFFER | ( m_uiID & 0x00FFFFFF ) ); }

		/**
		* Get texture object from this pixel buffer
		* \return                                     Texture
		*/
		virtual const TexturePtr                     &GetTexture() = 0;

		inline unsigned int                           GetWidth() { return m_uiWidth; }

		inline unsigned int                           GetHeight() { return m_uiHeight; }
};


};


#endif
