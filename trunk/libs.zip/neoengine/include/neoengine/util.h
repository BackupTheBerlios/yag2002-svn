/***************************************************************************
                          util.h  -  Utility functions
                             -------------------
    begin                : Tue May 14 2002
    copyright            : (C) 2002 by David Holm
    email                : david@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, util.h

 The Initial Developer of the Original Code is David Holm.
 Portions created by David Holm are Copyright (C) 2002
 David Holm. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEUTIL_H
#define __NEUTIL_H


#include "base.h"


#if defined(POSIX) || defined(__APPLE__)
#  include <unistd.h>
#endif

#ifdef __cplusplus
extern "C"
{
#endif
	/**
	* Optimized memcpy
	* \param pDest                   Destination buffer
	* \param pSrc                    Source buffer
	* \param nBytes                  Number of bytes to copy
	* \return                        pDest
	*/
	extern NEOENGINE_API void* (*fmemcpy)( void *pDest, const void *pSrc, size_t nBytes );
#ifdef __cplusplus
}
#endif

#ifdef ARCH_X86
	void *memcpy_sse( void *dst, const void *src, size_t len );
#endif /* ARCH_X86 */

#endif /* __NEUTIL_H */
