/***************************************************************************
              polygonbuffer.h  -  Polygon and polygon strip buffers
                             -------------------
    begin                : Fri Nov 2 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, polygonbuffer.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEPOLYGONBUFFER_H
#define __NEPOLYGONBUFFER_H


#include "base.h"
#include "polygon.h"
#include "pointer.h"
#include "buffer.h"
#include "vertexbuffer.h"
#include "material.h"
#include "nemath.h"
#include "util.h"

#include <assert.h>

#include <vector>


/**
  * \file polygonbuffer.h
  * Polygon and polygon strip storage in buffers
  */


namespace NeoEngine
{


/**
  * \brief Triangle polygon strip buffer class
  * Triangle strip buffers hold data for a single triangle strip
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API PolygonStripBuffer : public Buffer
{
	friend class PolygonBuffer;

	protected:

		/*! Real buffer */
		unsigned short                               *m_pusBuffer;

		/*! Indices (m_uiNumAllocated+2 of them) */
		unsigned short                               *m_pusIndices;

		/**
		* Acquire lock
		* \return                                     true if lock successful, false if not
		*/
		virtual bool                                  AcquireLock() { m_pusIndices = m_pusBuffer; return true; }

		/**
		* Release lock
		*/
		virtual void                                  ReleaseLock() { m_pusIndices = 0; }


	public:


		/**
		* \param uiType                               Buffer type
		* \param uiNumPolygons                        Number of polygons in this strip
		* \param pusData                              Pointer to index data
		*/
		                                              PolygonStripBuffer( unsigned int uiType, unsigned int uiNumPolygons, const unsigned short *pusData = 0 ) : Buffer( uiType ), m_pusBuffer( 0 ), m_pusIndices( 0 ) { AllocateStrip( uiNumPolygons, pusData ); }

		/**
		* Free memory
		*/
		virtual                                      ~PolygonStripBuffer();

		/**
		* Allocate strip buffer. There must be no lock held on the buffer when calling this method
		* \param uiNumPolygons                        Number of polygons
		* \param pusData                              Data (will read uiNumPolygons + 2 indices)
		*/
		virtual void                                  AllocateStrip( unsigned int uiNumPolygons, const unsigned short *pusData = 0 );

		/**
		* Load strip data. Must have active WRITE lock
		* \param pusData                              Strip data, reads m_uiNumPolygons + 2 indices
		*/
		inline void                                   LoadStripData( const unsigned short *pusData ) { fmemcpy( m_pusIndices, pusData, sizeof( unsigned short ) * ( m_uiNumCurrent + 2 ) ); }

		/**
		* Lock (READ or WRITE) must be held for pointer to be valid
		* \return                                     Pointer to index data
		*/
		inline unsigned short                        *GetIndices() { return m_pusIndices; }

		/**
		* Get pointer to render data. Used by derived buffer classes in device with AGP/video RAM storage to return
		* pointer to data used for rendering.
		* \return                                     Render data pointer 
		*/
		virtual const void                           *GetRenderData() const { return m_pusBuffer; }
};


#ifndef __HAVE_SMARTPOINTER_NEPOLYGONSTRIPBUFFER
   //Define smart pointer
#  ifdef _MSC_VER
#    pragma warning( disable : 4786 )
#  endif
   SmartPointer( PolygonStripBuffer );
#  define __HAVE_SMARTPOINTER_NEPOLYGONSTRIPBUFFER
#endif


/**
  * \brief Buffer for storing polygons (triangles)
  * A polygon buffer holds data for a number of polygons (triangles) and optionally a strip, material and
  * vertex buffer. Polygon buffers are managed and reference counted.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API PolygonBuffer : public Buffer
{
	protected:

		/**
		  * \class AdjacencyData
		  * \brief Adjacency data for triangles
		  * Used in stripification process
		  * \author Mattias Jansson (mattias@realityrift.com)
		  */
		class AdjacencyData
		{
			public:

				/*! Edges of triangle */
				unsigned int                          m_uiEdges[3][2];

				/*! Adjacent triangles along each edge */
				unsigned int                          m_uiAdjTri[3];
	
				/*! Opposite vertex for each edge */
				unsigned short                        m_uiOtherVertex[3];
		};

		/*! Real buffer */
		Polygon                                      *m_pkBuffer;

		/*! Buffer */
		Polygon                                      *m_pkPolygons;

		/*! Normals */
		Vector3d                                     *m_pkNormals;

		/*! Edges */
		Edge                                         *m_pkEdges;


		/**
		* Helper method in stripify process
		* \param uiPolygon                            Start polygon
		* \param uiEdge                               Start edge
		* \param pkAdj                                Adjacency data buffer
		* \param puiStrip                             Destination polygon index strip buffer
		* \param puiStripLen                          Pointer to int with strip length
		* \param pucAdded                             Flag buffer for added triangles
		*/
		void                                          ExtendStrip( unsigned int uiPolygon, unsigned int uiEdge, AdjacencyData *pkAdj, unsigned int *puiStrip, unsigned int *puiStripLen, unsigned char *pucAdded );


		/**
		* Acquire lock
		* \return                                     true if lock successful, false if not
		*/
		virtual bool                                  AcquireLock() { m_pkPolygons = m_pkBuffer; return true; }

		/**
		* Release lock
		*/
		virtual void                                  ReleaseLock() { m_pkPolygons = 0; }


	public:

		/*! Triangle strip */
		PolygonStripBufferPtr                         m_pkStrip;

		/*! Vertex buffer we use (optional). Will not be deallocated by dtor */
		VertexBufferPtr                               m_pkVertexBuffer;

		/*! Material we use (optional) */
		MaterialPtr                                   m_pkMaterial;


		/**
		* \param uiType                               Buffer type
		* \param uiNumPolygons                        Number of polygons
		* \param pkData                               Source data
		* \param bStripify                            Stripify polygon buffer if true
		*/
		                                              PolygonBuffer( unsigned int uiType, unsigned int uiNumPolygons, const Polygon *pkData = 0, bool bStripify = false ) : Buffer( uiType ), m_pkBuffer( 0 ), m_pkPolygons( 0 ), m_pkNormals( 0 ), m_pkEdges( 0 ) { AllocatePolygons( uiNumPolygons, pkData, bStripify ); }

		/**
		* Deallocate memory (normal and edge buffers)
		*/
		virtual                                      ~PolygonBuffer();

		/**
		* Allocate memory. There must be no lock held on buffer when calling this method
		* \param iNumPolygons                         Number of polygons to allocate memory for
		* \param pkData                               Source data
		* \param bStripify                            Stripify buffer
		*/
		virtual void                                  AllocatePolygons( unsigned int iNumPolygons, const Polygon *pkData = 0, bool bStripify = false );
	
		/**
		* Load data, must hold active WRITE lock
		* \param pkPolygons                           Polygon data (m_uiNumPolygons of them)
		* \param bStripify                            If true create triangle strip cache of data, clear any existing strips if false
		*/
		inline void                                   LoadPolygonData( const Polygon *pkPolygons, bool bStripify = false ) { fmemcpy( m_pkPolygons, pkPolygons, sizeof( Polygon ) * m_uiNumCurrent ); if( bStripify ) Stripify(); else m_pkStrip = 0; }

		/**
		* Stripify buffer. Buffer must not be locked. Will replace the current strip
		*/
		void                                          Stripify();

		/**
		* \return                                     true if buffer has been successfully cached in triangle strips
		*/
		inline bool                                   IsStripped() const { return( (bool)m_pkStrip ); }

		/**
		* Force recalucation of polygon normals. Buffer must not be locked.
		* \param pkVertexBuffer                       Optional vertex buffer to use if no buffer set in m_pkVertexBuffer. Vertex buffer should be unlocked.
		* \param bNormalize                           If true, normalize normals. If false, just use cross product of edges
		*/
		void                                          CalculateNormals( VertexBufferPtr pkVertexBuffer = 0, bool bNormalize = true );

		/**
		* Force recalculation of edges. Buffer must not be locked.
		* \param pkVertexBuffer                       Optional vertex buffer to use if no buffer set in m_pkVertexBuffer. Vertex buffer should be unlocked.
		*/
		void                                          CalculateEdges( VertexBufferPtr pkVertexBuffer = 0 );

		/**
		* Force recalculation of tangents and optionally binormals of the vertex buffer
		* \param pkVertices                           Vertex buffer
		* \param pkNormalElem                         Normal element
		* \param pkTexCoordElem                       Texture coord element
		* \param pkTangentElem                        Tangent element
		* \param pkBinormalElem                       Binormal element
		*/
		void                                          CalculateTangents( VertexBufferPtr pkVertices, const VertexElement *pkNormalElem, const VertexElement *pkTexCoordElem, const VertexElement *pkTangentElem, const VertexElement *pkBinormalElem = 0 );

		/**
		* \return                                     Pointer to normal array
		*/
		inline Vector3d                              *GetNormals() { return m_pkNormals; }

		/**
		* \return                                     Pointer to edge array
		*/
		inline Edge                                  *GetEdges() { return m_pkEdges; }

		/**
		* \return                                     Strip buffer object
		*/
		inline PolygonStripBufferPtr                 &GetStrip() { return m_pkStrip; }

		/**
		* \param uiElement                            Element to access
		* \return                                     Polygon object
		*/
		inline Polygon                               *GetPolygon( unsigned int uiElement = 0 ) { assert( uiElement < m_uiNumCurrent ); return &m_pkPolygons[ uiElement ]; }

		/**
		* Get pointer to render data. Used by derived buffer classes in device with AGP/video RAM storage to return
		* pointer to data used for rendering.
		* \return                                     Render data pointer 
		*/
		virtual const void                           *GetRenderData() const { return m_pkBuffer; }

		/**
		* Array access
		* \param uiElement                            Element to access
		*/
		inline Polygon                               &operator []( unsigned int uiElement ) { assert( uiElement < m_uiNumCurrent ); return m_pkPolygons[ uiElement ]; }
};


#ifndef __HAVE_SMARTPOINTER_NEPOLYGONBUFFER
   //Define smart pointer
#  ifdef _MSC_VER
#    pragma warning( disable : 4786 )
#  endif
   SmartPointer( PolygonBuffer );
#  define __HAVE_SMARTPOINTER_NEPOLYGONBUFFER
#endif


};


#endif
