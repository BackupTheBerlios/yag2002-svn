/***************************************************************************
              bone.h  -  Bone hierarchy node for building skeletons
                             -------------------
    begin                : Sun Jun 16 2002
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, bone.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEBONE_H
#define __NEBONE_H


/**
  * \file neoengine/bone.h
  * Bone hierarchy node for building skeletons
  */


#include "base.h"
#include "hierarchynode.h"


namespace NeoEngine
{


#ifdef WIN32

#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif

#  ifndef __HAVE_VECTOR_NEBONE
     UDTVectorEXPIMP( class Bone* );
#    define __HAVE_VECTOR_NEBONE
#  endif

#  ifdef _MSC_VER
#    ifndef __HAVE_NEHIERARCHYNODE_NEBONE
       EXPIMP_TEMPLATE template class NEOENGINE_API HierarchyNode< class Bone >;
#      define __HAVE_NEHIERARCHYNODE_NEBONE
#    endif
#  endif

#endif


/**
  * \brief Data defining a single bone
  * A bone is a simple node in a hierarchy (a skeleton).
  * Bones are managed by skeleton, and must belong to a 
  * single master skeleton object. A skeleton can only have
  * a single root bone.
  * \author Mattias Jansson (mattias@realityrift.com)
  * \author Anders Dahnielson (anders @ dahnielson.com)
  */
class NEOENGINE_API Bone : public HierarchyNode< Bone >
{
        protected:

                /*! Rest state */
	        bool                                          m_bRestState;

	        /*! Rest translation */
  	        Vector3d                                      m_kRestTranslation;

	        /*! Rest rotation */
 	        Quaternion                                    m_kRestRotation;

	public:

		/*! Bone ID */
		unsigned int                                  m_uiID;


		/**
		* \param uiID                                 Bone ID
		* \param rstrName                             Bone node name
		* \param pkParent                             Parent bone
		*/
		                                              Bone( unsigned int uiID = 0, const std::string &rstrName = "", Bone *pkParent = 0 );

		/**
		* Create bone from reference object, will also duplicate hierarchy (child nodes)
		* \param rkBone                               Reference bone object to copy
		*/
		                                              Bone( Bone &rkBone );
		
		/**
		* Deregister bone with skeleton
		*/
		virtual                                      ~Bone();

		/**
		* Duplicate bone
		* \return                                     New bone that is exact duplicate of this node
		*/
		virtual Bone                                 *Duplicate();

		/**
		* Set translation for bone. If bone is resting any translation will be relative to the resting position.
		* \param rkTranslation                        New translation for bone
		* \param bNotifyUpdate                        Used by derived classes to indicate if to set update flag to child tree
		*/
		inline virtual void                           SetTranslation( const Vector3d &rkTranslation, bool bNotifyUpdate = true ) { m_kTranslation = m_bRestState ? m_kRestTranslation + rkTranslation : rkTranslation; NotifyUpdate( bNotifyUpdate ); }

		/**
		* Set rotation for bone. If bone is resting any rotation will be relative to the resting position.
		* \param rkRotation                           New rotation for bone
		* \param bNotifyUpdate                        Used by derived classes to indicate if to set update flag to child tree (true default, use false with caution)
		*/
		inline virtual void                           SetRotation( const Quaternion &rkRotation, bool bNotifyUpdate = true ) { m_kRotation = m_bRestState ? m_kRestRotation * rkRotation : rkRotation; NotifyUpdate( bNotifyUpdate ); }

  	        /**
		 * Query state of rest
		 */
 	        virtual bool                                  IsResting();

  	        /**
		 * Activate rest state. Current translation and rotation will be used as resting position.
		 */
	        virtual void                                  ActivateRest();

  	        /**
		 * Deactivate rest state
		 */
	        virtual void                                  DeactivateRest();
};


};


#endif
