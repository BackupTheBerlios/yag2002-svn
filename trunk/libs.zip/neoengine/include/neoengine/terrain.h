/***************************************************************************
                     terrain.h  -  Classes for terrain
                             -------------------
    begin                : Mon Sep 8 2003
    copyright            : (C) 2003-2004 by Cody Russell
    email                : cody `at' jhu.edu
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, terrain.h

 The Initial Developer of the Original Code is Cody Russell.
 Portions created by Cody Russell are Copyright (C) 2003-2004
 Cody Russell. All Rights Reserved.

 ***************************************************************************/

#ifndef __NETERRAIN_H
#define __NETERRAIN_H

#include "base.h"
#include "render.h"
#include "room.h"
#include "scenenode.h"
#include "sceneentity.h"
#include "terrainmaterial.h"
#include "texture.h"


/**
  * \file terrain.h
  * Abstract classes for NeoEngine's terrain systems.  All terrain implementations reside in
  * loadable modules that are accessed through the Core object's GetTerrainManager().
  *
  * Regarding coordinate systems, we will define heightmap-space coordinates such that the
  * x and y coordinates are considered horizontal, ground-level coordinates and z could be
  * considered as the elevation.  This is natural if you're thinking from an overhead
  * perspective, but not from a first-person shooter perspective.
  * \author Cody Russell (cody jhu edu)
  */


namespace NeoEngine
{

class TerrainBlock;



/**
  * \brief Heightmap for terrain pages
  * This object contains the elevation data and various other properties for
  * storing terrain data in memory.  Once the heightmap is created, scaling
  * properties cannot be changed and elevation data cannot be changed.  Heightmaps
  * are necessarily square in shape, so the size property reflects the number of
  * grid points of one side of it.
  * \author Cody Russell (cody jhu edu)
  */
class TerrainHeightmap
{
	friend class TerrainPage;

	protected:

		/*! The elevation data */
		float                                         *m_pfData;

		/*! Size of one side of the heightmap.  Heightmaps must be square. */
		int                                            m_iSize;

		/*! The normals */
		Vector3d                                      *m_pkNormalData;

		/*! Scale factor in XY domains */
		float                                          m_fHScale;

		/*! Scale factor in the Z domain */
		float                                          m_fVScale;

		/*! The highest height value in the map */
		float                                          m_fMaxHeight;

		/*! The lowest height value in the map */
		float                                          m_fMinHeight;

	public:

		/**
		* Initialize heightmap
		* \param fHScale                               Horizontal scaling property.
		* \param fVScale                               Vertical/elevation scaling property
		*/
		                                               TerrainHeightmap( float fHScale = 10.0f, float fVScale = 5.0f );

		/**
		*/
		virtual                                       ~TerrainHeightmap();

		void                                           PostLoadInit();

		/**
		* Load the elevation data and size from an ImageData object.
		* \param pkImage                               Image to load
		*/
		void                                           Load( ImageData *pkImage );

		/**
		* Load the elevation data from a file
		* \param rstrFilename                          Filename of image to load
		* \param iSize                                 Size of each side of the square image
		*/
		void                                           Load( const std::string &rstrFilename, int iSize );

		/**
		* Get the index
		* \param x                                     x coord
		* \param y                                     y coord
		* \return                                      int index
		*/
		int                                            GetIndex( int x, int y ) const;

		/**
		* Get the height of a point in heightmap-space.
		* \param x                                     x coordinate
		* \param y                                     y (depth) coordinate, as if looking down on the terrain
		* \return                                      float value of height here, already scaled by VScale
		*/
		float                                          GetHeight( int x, int y ) const;

		/**
		* Get vertex normal of a point in heightmap-space
		* \param x                                     x coordinate
		* \param y                                     y (depth) coordinate
		* \return                                      Normal vector
		*/
		const Vector3d&                                GetNormal( int x, int y ) const;

		/**
		* Gets elevation in world units (eg, between elevation grid), where x and y are still considered ground-level
		* \param x                                     x coordinate
		* \param y                                     y coordinate
		* \return                                      float value of height here, already scaled by VScale
		*/
		float                                          GetWorldHeight( float x, float y );

		float                                          GetWorldHeight( int iIndex );

		/**
		* Returns the maximum height of any point in the heightmap
		* \return                                      Elevation of highest point
		*/
		float                                          GetMaxHeight() { return m_fMaxHeight; }

		/**
		* Returns the minimum height of any point in the heightmap
		* \return                                      Elevation of lowest point
		*/
		float                                          GetMinHeight() { return m_fMinHeight; }

		/**
		* Returns the size of one side of the heightmap
		* \return                                      Size of one side of the heightmap
		*/
		inline const int                               GetSize() const { return m_iSize; }

		/**
		* Get the horizontal scaling factor for the heightmap
		* \return                                      Horizontal scaling factor
		*/
		const float                                    GetHScale() const { return m_fHScale; }

		/**
		* Get the vertical scaling factor for the heightmap
		* \return                                      Vertical scaling factor
		*/
		const float                                    GetVScale() const { return m_fVScale; }
};


class TerrainBlock : public SceneEntity
{
	protected:

		/*! The x offset into the blockmap */
		int                                            m_iOffsetX;

		/*! The y offset into the blockmap */
		int                                            m_iOffsetY;

		/*! Size of one side of the block, in vertices */
		int                                            m_iSize;

		/*! Index into the vector of blocks */
		int                                            m_iBlockIndex;

		/*! Flag indicating update needed */
		bool                                           m_bNeedUpdate;

		/**
		 * Update data
		 */
		virtual void                                   UpdateData() { neolog << "TerrainBlock::UpdateData()" << std::endl; }

	public:

		                                               TerrainBlock( int iOffsetX, int iOffsetY, int iSize, int iIndex );

		virtual                                       ~TerrainBlock() {}

		int                                            GetOffsetX() { return m_iOffsetX; }

		int                                            GetOffsetY() { return m_iOffsetY; }

		int                                            GetSize() { return m_iSize; }

		virtual VertexBufferPtr                       &GetVertexBuffer() = 0;

		virtual PolygonBufferPtr                      &GetPolygonBuffer() = 0;

		virtual bool                                   Render( Frustum *pkFrustum, bool bForce = false ) = 0;

		virtual void                                   GenerateAABB() = 0;

		virtual void                                   Update( float fDelta ) { UpdateData(); }
};

#ifdef WIN32

#ifndef __HAVE_VECTOR_NETERRAINBLOCK
     UDTVectorEXPIMP( TerrainBlock* );
#    define __HAVE_VECTOR_NETERRAINBLOCK
#  endif

#endif // WIN32



/**
  * \class QuadtreeNode
  * \brief A quadtree node maintains either zero or four children, depending upon
  * whether it is a leaf node or a regular node.
  * \author Cody Russell (cody jhu edu)
  */
class QuadtreeNode : public NeoEngine::SceneNode
{
	friend class Quadtree;

	public:

		DefineVisitable();

		/**
		* \brief Node type identifiers
		*/
		enum NODETYPE
		{
			/*! Node */
			NODE,

			/*! Leaf */
			LEAF
		};

	protected:

		/*! We'll always have either exactly four children, or exactly zero, depending upon m_eType */
		QuadtreeNode   *m_pkChildren;

		/*! Are we a regular node, or a leaf node? */
		NODETYPE        m_eType;

		/* FIXME: Currently unused.. */
		/*! Dense quadtrees will store data at non-leaf nodes */
		bool            m_bDense;

		/* FIXME: Do we really need this? */
		/*! This is our data. */
		TerrainBlock   *m_pkData;

	protected:

		/**
		* Recursively initializes the quadtree.
		* \param pkTerrain                            Pointer to terrain page
		* \param x                                    x coordinate
		* \param y                                    y coordinate
		* \param iSize                                Size of this node
		* \param iDepth                               Depth of this node
		*/
		void Initialize( TerrainPage *pkTerrain, int x, int y, int iSize, int iDepth );

	public:

		/**
		 */
		                                              QuadtreeNode();

		/**
		 */
		virtual                                      ~QuadtreeNode();

		/*! Our render method. */
		virtual bool                                  Render( Frustum *pkFrustum = 0, bool bForce = false );

		/**
		* If node is active, update node and any child nodes. Also calls
		* Update on the entity object, if any.
		* \param fDeltaTime                           Delta time passed
		*/
		virtual void                                  Update( float fDeltaTime ); // { m_pkData->Update( fDeltaTime ); }

		void                                          UpdateVisible( Frustum *pkFrustum = 0 );
};


/**
  * \class Quadtree
  * \brief Room class that is useful for terrain systems and frustum culling.
  * \author Cody Russell (cody jhu edu)
  */
class Quadtree : public NeoEngine::Room
{
	protected:

		/*! The root node */
		QuadtreeNode                                 *m_pkRoot;

		/*! How deep does our quadtree run? */
		int                                           m_iDepth;

		bool                                          m_bDirty;

	public:

		/**
		 */
		                                              Quadtree( TerrainPage *pkPage, const NeoEngine::HashString &rstrName = "" );

		/**
		 */
		virtual                                      ~Quadtree();

		/*! Render the quadtree and its terrain */
		virtual bool                                  Render( Frustum *pkFrustum = 0, bool bForce = false );

		void                                          UpdateVisible( Frustum *pkFrustum ) { m_pkRoot->UpdateVisible( pkFrustum ); }

		/*! Get the depth */
		int                                           GetDepth() { return m_iDepth; }

		bool                                          Dirty() { return m_bDirty; }

		void                                          SetDirty( bool bDirty ) { m_bDirty = bDirty; }
};


class TerrainPage
{
	friend class TerrainMaterialFactory;

	protected:

		/*! Terrain's heightmap */
		TerrainHeightmap                              *m_pkHeightmap;

		/*! Our blocks of terrain */
		std::vector< TerrainBlock* >                   m_vpkBlocks;

		/*! The size of one side of a block */
		int                                            m_iBlockSize;

		/*! Depth */
		int                                            m_iDepth;

		/*! Our texture generator */
		TerrainMaterialFactory                        *m_pkMaterialFactory;

		bool                                           m_bMaterialGenerated;

	public:

		/**
		 */
		                                               TerrainPage( TerrainHeightmap *pkHeightmap, TerrainMaterialFactory *pkMaterialFactory, int iDepth );

		/**
		 */
		virtual                                       ~TerrainPage();

		/**
		* Get the heightmap
		* \return                                      Pointer to the terrain's heightmap
		*/
		TerrainHeightmap                              *GetHeightmap();

		/**
		* Get the Nth terrain block.
		* \param iIndex                                Index to the terrain block to get
		* \return                                      Pointer to the requested terrain block
		*/
		TerrainBlock                                  *GetBlock( int iIndex );

		/**
		* Get the terrain block from its (x,y) coordinates
		* \param x                                     x-axis coordinate
		* \param y                                     y-axis coordinate
		* \return                                      Pointer to the requested terrain block
		*/
		TerrainBlock                                  *GetBlock( int x, int y );

		/**
		* Query the total number of terrain blocks
		* \return                                      The number of terrain blocks
		*/
		int                                            GetTotalBlocks();

		/**
		* Query the number of terrain blocks on one side.  Since the page is
		* square-shaped in terms of numbers of terrain blocks, this number is
		* is true of sides on both axes.
		* \return                                      Number of blocks on a side
		*/
		int                                            GetNumBlocksOnSide();

		/**
		* Query the size of one block
		* \return                                      The size of a single block
		*/
		int                                            GetBlockSize();

		/**
		* Query the depth of the terrain system
		* \return                                      Depth of terrain system
		*/
		int                                            GetDepth();

		void                                           GenerateMaterial();

		/**
		* Queries the size of the terrain system.  This is the number of vertices on
		* one side of the terrain.
		* \return                                      Size of terrain page
		*/
		int                                            GetSize();

		/*! FIXME: Remove this */
		void                                           GenerateAABB();

		/**
		 * Render terrain geometry
		 * \param pkFrustum                            Current view frustum
		 * \param bForce                               Force
		 */
		virtual bool                                   Render( Frustum *pkFrustum, bool bForce = false ) = 0;
};

#ifdef WIN32

#ifndef __HAVE_VECTOR_NETERRAINPAGE
     UDTVectorEXPIMP( TerrainPage* );
#    define __HAVE_VECTOR_NETERRAINPAGE
#  endif

#endif // WIN32

/**
  * \class TerrainManager
  * \brief Manages modules for external terrain implementations
  * \author Cody Russell (cody jhu edu)
  */
class TerrainManager
{

	protected:

		/*! Loaded terrain modules */
		std::vector< ModulePtr >                       m_vpkModules;

		/*! Terrain pages */
		std::vector< TerrainPage* >                    m_vpkPages;

	public:

		/**
		 */
		                                               TerrainManager();

		/**
		 */
		virtual	                                      ~TerrainManager();

		/**
		* Load terrain module
		* \param rstrName                              Module name
		* \return                                      true if module loaded successfully, false otherwise
		*/
		ModulePtr                                      LoadModule( const HashString &rstrName );

		/**
		* Create terrain page of specified type (will try to load terrain module if no matching module is found)
		* \param rstrType                              Terrain type
		* \return                                      New terrain object or null if error
		*/
		virtual TerrainPage                           *CreateTerrain( TerrainHeightmap *pkHeightmap, TerrainMaterialFactory *pkMaterialFactory ) = 0;

		virtual void                                   ResetFrame() { }
};


}; // namespace NeoEngine


#endif // __NETERRAIN_H
