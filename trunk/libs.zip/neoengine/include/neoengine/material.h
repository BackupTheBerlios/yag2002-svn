/***************************************************************************
         material.h  -  Material classes. Z buffer modes, blend modes,
                      texture layers, material effects
                             -------------------
    begin                : Wed Oct 31 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, material.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEMATERIAL_H
#define __NEMATERIAL_H


/**
  * \file neoengine/material.h
  * Material abstraction
  */


#include "base.h"
#include "color.h"
#include "shader.h"
#include "texture.h"
#include "texmatrixgen.h"
#include "color.h"
#include "hashtable.h"
#include "hashstring.h"
#include "util.h"

#include <string>
#include <vector>


namespace NeoEngine
{


// Forward declaractions
class Material;


/**
  * \brief Data describing fog information
  * \author Cody Russell (cody jhu edu)
  */
class FogMode
{
	public:

		/**
		* \brief Fog equation
		* These describe which fog equation to use.  z is the
		* eye-coordinate distance between the viewport and the fragment center.
		*/
		enum FOGMODE
		{
		  /*! Disable fog                     */
		  NONE,

		  /*! e ^ ( - ( density * z ) )       */
		  EXP,

		  /*! e ^ ( - ( density * z ) ^ 2 )   */
		  EXP2,

		  /*! ( end - z ) / ( end - start )   */
		  LINEAR
		};

		/**
		* \brief Provides quality hints to the render device.
		* This is not guaranteed to do anything.
		*/
		enum FOGHINT
		{
		  /*! Let the render device pick the fog quality */
		  DONTCARE,

		  /*! Specify per-vertex calculations.  Faster, but not quite as nice-looking. */
		  PERVERTEX,

		  /*! Specify per-pixel calculations.  Looks better. */
		  PERPIXEL
		};

		enum FOGSOURCE
		{
		  FRAGMENT_DEPTH,
		  FOG_COORDINATE
		};

	public:

		/*! The fog equation */
		int                                           m_iMode;

		/*! The density of the fog. */
		float                                         m_fDensity;

		/*! Fog start depth */
		float                                         m_fStart;

		/*! Fog end depth */
		float                                         m_fEnd;

		/*! Hint to the quality of the fog. */
		int                                           m_iHint;

		/*! The fog color. */
		Color                                         m_kColor;

	public:

		                                              FogMode() : m_iMode( FogMode::NONE ), m_iHint( FogMode::DONTCARE ) { }

		virtual                                      ~FogMode() { }

		void                                          SetDepth( float fStart, float fEnd );

		inline bool                                   operator ==( const FogMode &rkFogMode ) const
		{
			return( ( m_iMode    == rkFogMode.m_iMode    ) &&
			        ( m_fDensity == rkFogMode.m_fDensity ) &&
			        ( m_fStart   == rkFogMode.m_fStart   ) &&
			        ( m_fEnd     == rkFogMode.m_fEnd     ) &&
			        ( m_iHint    == rkFogMode.m_iHint    ) );
		}
};


/**
  * \brief Data describing a blend mode
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class BlendMode
{
	public:

		/**
		* \brief Source blend modes
		* Source factor (S_factor) in blend equation, where final output fragment color is S_factor * S_rgb + D_factor * D_rgb
		*/
		enum SRCBLENDMODE
		{
		  /*! 1 * S_rgb */
		  SRC_ONE                                     = 0x00000000,

		  /*! 0 * S_rgb */
		  SRC_ZERO                                    = 0x00000001,

		  /*! D_rgb * S_rgb */
		  SRC_DESTCOLOR                               = 0x00000004,

		  /*! ( 1 - D_rgb ) * S_rgb */
		  SRC_ONEMINUSDESTCOLOR                       = 0x00000005,

		  /*! S_rgb * S_rgb */
		  SRC_SRCCOLOR                                = 0x00000007,

		  /*! S_rgb * factor (only allowed in conjunction with DEST_ONEMINUSFACTOR, otherwise results are undefined) */
		  SRC_FACTOR                                  = 0x00000008,

		  /*! S_alpha * S_rgb */
		  SRC_SRCALPHA                                = 0x00000009,

		  /*! ( 1 - S_alpha ) * S_rgb */
		  SRC_ONEMINUSSRCALPHA                        = 0x0000000a,

		  /*! D_alpha * S_rgb */
		  SRC_DESTALPHA                               = 0x0000000b,

		  /*! ( 1 - D_alpha ) * S_rgb */
		  SRC_ONEMINUSDESTALPHA                       = 0x0000000c,

		  /* min( S_alpha, 1 - D_alpha ) * S_rgb */
		  SRC_ALPHASATURATE                           = 0x0000000d,

  		  SRC_LERPCOLOR                               = 0x0000000e,

		  SRC_LERPALPHA                               = 0x0000000f,

		  /*! Bitmask for bits by source blend factor identifiers */
		  SRCBITS                                     = 0x0000000f
		};


		/**
		* \brief Destination blend modes
		* Destination factor (D_factor) in blend equation, where final output fragment color is S_factor * S_rgb + D_factor * D_rgb
		*/
		enum DESTBLENDMODE
		{
		  /*! 0 * D_rgb */
		  DEST_ZERO                                   = 0x00000000,

		  /*! 1 * D_rgb */
		  DEST_ONE                                    = 0x00000010,

		  /*! S_rgb * D_rgb */
		  DEST_SRCCOLOR                               = 0x00000040,

		  /*! ( 1 - S_rgb ) * D_rgb */
		  DEST_ONEMINUSSRCCOLOR                       = 0x00000050,

		  /*! ( 1 - factor ) * D_rgb (only allowed in conjunction with SRC_FACTOR, otherwise results are undefined) */
		  DEST_ONEMINUSFACTOR                         = 0x00000060,

		  /*! S_alpha * D_rgb */
		  DEST_SRCALPHA                               = 0x00000080,

		  /*! ( 1 - S_alpha ) * D_rgb */
		  DEST_ONEMINUSSRCALPHA                       = 0x00000090,

		  /*! D_alpha * D_rgb */
		  DEST_DESTALPHA                              = 0x000000b0,

		  /*! ( 1 - D_alpha ) * D_rgb */
		  DEST_ONEMINUSDESTALPHA                      = 0x000000c0,

  		  DEST_LERPCOLOR                              = 0x000000e0,

		  DEST_LERPALPHA                              = 0x000000f0,

		  /*! Bitmask for bits used by destination blend factor identifiers */
		  DESTBITS                                    = 0x000000f0
		};


		/**
		* \brief Predefined combined blend modes
		*/
		enum BLENDMODE
		{
		  /*! OUT = S_rgb */
		  NORMAL                                      = 0x00000000,

		  /*! OUT = S_alpha * S_rgb + ( 1 - S_alpha ) * D_rgb */
		  DECAL                                       = ( SRC_SRCALPHA          | DEST_ONEMINUSSRCALPHA ),

		  /*! OUT = factor * S_rgb + ( 1 - factor ) * D_rgb */
		  DECALFACTOR                                 = ( SRC_FACTOR            | DEST_ONEMINUSFACTOR   ),

		  /*! OUT = D_rgb * S_rgb */
		  MODULATE                                    = ( SRC_DESTCOLOR         | DEST_ZERO             ),

		  /*! OUT = S_rgb * D_rgb */
		  MODULATE_ALT                                = ( SRC_ZERO              | DEST_SRCCOLOR         ),

		  /*! OUT = D_rgb * S_rgb * 2 */
		  MODULATE_2X                                 = ( SRC_DESTCOLOR         | DEST_SRCCOLOR         ),

		  /*! OUT = S_rgb + D_rgb */
		  ADD                                         = ( SRC_ONE               | DEST_ONE              ),

		  /*! OUT = S_rgb + ( 1 - S_rgb ) * D_rgb */
		  ADDSMOOTH                                   = ( SRC_ONE               | DEST_ONEMINUSSRCCOLOR ),

		  /*! OUT = ( 1 - D_rgb ) * S_rgb + D_rgb */
		  ADDSMOOTH_ALT                               = ( SRC_ONEMINUSDESTCOLOR | DEST_ONE              ),

		  /*! OUT = 0 */
		  ZERO                                        = ( SRC_ZERO              | DEST_ZERO             ),

  		  /*! OUT = */
		  LERP_COLOR                                  = ( SRC_LERPCOLOR         | DEST_LERPCOLOR     ),

		  LERP_ALPHA                                  = ( SRC_LERPALPHA         | DEST_LERPALPHA     ),

		  /*! Bitmask for bits used by combined blend factor identifiers */
		  BITS                                        = ( SRCBITS               | DESTBITS              )
		};


	protected:

		/*! Src and dest blend func */
		unsigned int                                  m_uiMode;

	public:

		/*! Factor */
		float                                         m_fFactor;


		/**
		*/
		                                              BlendMode() : m_uiMode( NORMAL ), m_fFactor( 1.0f ) {}

		/**
		* \param rkMode                               Reference mode
		*/
		                                              BlendMode( const BlendMode &rkMode ) : m_uiMode( rkMode.m_uiMode ), m_fFactor( rkMode.m_fFactor ) {}

		/**
		* Set blend mode
		* \param uiSrcMode                            Source mode
		* \param uiDestMode                           Dest mode
		*/
		void                                          Set( unsigned int uiSrcMode, unsigned int uiDestMode ) { m_uiMode = ( ( uiSrcMode & SRCBITS ) | ( uiDestMode & DESTBITS ) ); }

		/**
		* Set from predefined constant
		* \param uiMode                               Blend mode
		*/
		void                                          Set( unsigned int uiMode ) { m_uiMode = uiMode & BITS; }

		/**
		* Access mode as integer
		* \return                                     Blend mode
		*/
		int                                           Get() const { return m_uiMode; }

		/**
		* Get src mode as string
		* \param uiMode                               Mode identifier
		* \return                                     Src mode
		*/
		static std::string                            GetSrcModeAsString( unsigned int uiMode );

		/**
		* Get dest mode as string
		* \param uiMode                               Mode identifier
		* \return                                     Dest mode
		*/
		static std::string                            GetDestModeAsString( unsigned int uiMode );

		/**
		* Get src mode from string
		* \param rstrMode                             Mode name string
		* \return                                     Src mode
		*/
		static unsigned int                           GetSrcModeFromString( const std::string &rstrMode );

		/**
		* Get dest mode from string
		* \param rstrMode                             Mode name string
		* \return                                     Src mode
		*/
		static unsigned int                           GetDestModeFromString( const std::string &rstrMode );
};


/**
  * \brief Data describing a Z buffer mode
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class ZBufferMode
{
	public:

		/**
		* \brief Z buffer test functions
		*/
		enum ZTESTFUNC
		{
		  /*! Pass if z value less than buffer */
		  LESS                                        = 0x00000000,

		  /*! Pass if z value less than or equal than buffer */
		  LEQUAL                                      = 0x00000001,

		  /*! Pass if z value equal to buffer */
		  EQUAL                                       = 0x00000002,

		  /*! Pass if z value greater than or equal tp buffer */
		  GEQUAL                                      = 0x00000003,

		  /*! Pass if z value greater than buffer */
		  GREATER                                     = 0x00000004,

		  /*! Always pass (no test) */
		  ALWAYSPASS                                  = 0x00000005,

		  /*! Bitmask for bits used by Z buffer test identifiers */
		  FUNCBITS                                    = 0x00000007
		};

		/**
		* \brief Z buffer write modes
		*/
		enum ZWRITEMODE
		{
		  /*! Update Z buffer */
		  ENABLED                                     = 0x00000000,

		  /*! Do not update > buffer */
		  DISABLED                                    = 0x00000010,

		  /*! Bitmaks for bits used by Z buffer write mode identifiers */
		  MODEBITS                                    = 0x00000010
		};

		/**
		* \brief Combined Z buffer modes (test and write)
		*/
		enum ZBUFFERMODE
		{
		  /*! Pass if z value less than or equal than buffer, update buffer */
		  NORMAL                                      = ( LEQUAL     | ENABLED  ),

		  /*! Pass if z value less than buffer, update buffer */
		  LESSWRITE                                   = ( LESS       | ENABLED  ),

		  /*! Pass if z value less than or equal to buffer, update buffer */
		  LEQUALWRITE                                 = ( LEQUAL     | ENABLED  ),

		  /*! Pass if z value equal to buffer, update buffer */
		  EQUALWRITE                                  = ( EQUAL      | ENABLED  ),

		  /*! Pass if z value greater than or equal to buffer, update buffer */
		  GEQUALWRITE                                 = ( GEQUAL     | ENABLED  ),

		  /*! Pass if z value greater than buffer, update buffer */
		  GREATERWRITE                                = ( GREATER    | ENABLED  ),

		  /*! Always pass (no test), update buffer */
		  ALWAYSWRITE                                 = ( ALWAYSPASS | ENABLED  ),

		  /*! Pass if z value less than buffer, do not update buffer */
		  LESSNOWRITE                                 = ( LESS       | DISABLED ),

		  /*! Pass if z value less than or equal to buffer, do not update buffer */
		  LEQUALNOWRITE                               = ( LEQUAL     | DISABLED ),

		  /*! Pass if z value equal to buffer, do not update buffer */
		  EQUALNOWRITE                                = ( EQUAL      | DISABLED ),

		  /*! Pass if z value greater than or equal to buffer, do not update buffer */
		  GEQUALNOWRITE                               = ( GEQUAL     | DISABLED ),

		  /*! Pass if z value greater than buffer, do not update buffer */
		  GREATERNOWRITE                              = ( GREATER    | DISABLED ),

		  /*! Always pass (no test), do not update buffer */
		  ALWAYSNOWRITE                               = ( ALWAYSPASS | DISABLED ),

		  /*! Bitmask for bits used by combined Z buffer test/write mode identifiers */
		  BITS                                        = ( FUNCBITS   | MODEBITS )
		};


	protected:

		/*! Z buffer mode */
		unsigned int                                  m_uiMode;


	public:
	
		/**
		*/
		                                              ZBufferMode() : m_uiMode( NORMAL ) {}

		/**
		* \param rkMode                               Reference mode
		*/
		                                              ZBufferMode( const ZBufferMode &rkMode ) : m_uiMode( rkMode.m_uiMode ) {}

		/**
		* Set Z buffer mode
		* \param uiZTest                              Test func
		* \param uiZWrite                             Write mode
		*/
		void                                          Set( unsigned int uiZTest, unsigned int uiZWrite ) { m_uiMode = ( uiZTest | uiZWrite ) & BITS; }

		/**
		* Set from predefined constant
		* \param uiMode                               Z buffer mode
		*/
		void                                          Set( unsigned int uiMode ) { m_uiMode = uiMode & BITS; }

		/**
		* Access mode as integer
		* \return                                     Z buffer mode
		*/
		int                                           Get() const { return m_uiMode; }
		
		/**
		* Get write mode as string
		* \param uiMode                               Mode identifier
		* \return                                     Write mode
		*/
		static std::string                            GetWriteModeAsString( unsigned int uiMode );

		/**
		* Get test mode as string
		* \param uiMode                               Mode identifier
		* \return                                     Test mode
		*/
		static std::string                            GetTestFuncAsString( unsigned int uiMode );

		/**
		* Get write mode from string
		* \param rstrMode                             Mode name string
		* \return                                     Write mode
		*/
		static unsigned int                           GetWriteModeFromString( const std::string &rstrMode );

		/**
		* Get test func from string
		* \param rstrFunc                             Func name string
		* \return                                     Test mode
		*/
		static unsigned int                           GetTestFuncFromString( const std::string &rstrFunc );
};


/**
  * \brief Data for a single texture layer
  * Base for texture in materials. Also used for multi-texturing
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class TextureLayer
{
	public:

		/**
		* \brief Texture layer flags
		*/
		enum TEXTURELAYERFLAG
		{
		  /*! Default rendering mode */
		  NOFLAGS                                     = 0x0000,

		  /*! Force multipass rendering */
		  MULTIPASS                                   = 0x0001
		};


		/**
		* \brief Texture addressing modes
		* To set texture addressing modes, set the wrap to either WRAP or CLAMP for all coordinates, or use
		* WRAP_x or CLAMP_x combinations for detailed control. Default is WRAP for all dimensions.
		*/
		enum TEXTUREADDRESSMODE
		{
		  /*! Wrap all coordinates */
		  WRAP                                        = 0x00000000,

		  /*! Wrap U coordinates */
		  WRAP_U                                      = 0x00000000,

		  /*! Wrap V coordinates */
		  WRAP_V                                      = 0x00000000,

		  /*! Wrap V coordinates */
		  WRAP_W                                      = 0x00000000,

		  /*! Clamp all coordinates */
		  CLAMP                                       = 0x00001111,

		  /*! Clamp U coordinates */
		  CLAMP_U                                     = 0x00000001,

		  /*! Clamp V coordinates */
		  CLAMP_V                                     = 0x00000010,

		  /*! Clamp W coordinates */
		  CLAMP_W                                     = 0x00000100
		};

		/**
		* \brief Automatic texture coordinate generation
		*/
		enum TEXCOORDGENERATION
		{
		  /*! No special texcoord generator */
		  NOGEN                                       = 0,

		  /*! Reflection vector */
		  REFLECTION                                  = 1,

		  /*! Normal vector */
		  NORMAL                                      = 2
		};



	public:
	
		/*! Blend mode */
		BlendMode                                     m_kBlendMode;
		
		/*! Texture object */
		TexturePtr                                    m_pkTexture;

		/*! UV layer to use, 0 to indicate base layer */
		unsigned int                                  m_uiUVLayer;

		/*! Texture addressing mode */
		unsigned int                                  m_uiUVAddress;

		/*! Texture matrix generators */
		std::vector< TextureMatrixGen* >              m_vpkTexMatrixGen;

		/*! Flags */
		unsigned int                                  m_uiLayerFlags;

		/*! Texture coord generation */
		TEXCOORDGENERATION                            m_eTexCoordGen;


		/**
		*/
		                                              TextureLayer() : m_uiUVLayer( 0 ), m_uiUVAddress( WRAP ), m_uiLayerFlags( NOFLAGS ), m_eTexCoordGen( NOGEN ) {}

		/**
		* \param rkLayer                              Layer reference object to copy values from
		*/
													  TextureLayer( const TextureLayer &rkLayer );
		                              		
		/**
		*/
		virtual                                      ~TextureLayer();

		/**
		* Assignment
		* \param rkLayer                              Texture layer to copy values from
		* \return                                     Self-reference
		*/
		TextureLayer                                 &operator =( const TextureLayer &rkLayer );


		/**
		* \return                                     Layer flags identifier as integer matching define
		*/
		static unsigned int                           GetFlagsFromString( const std::string &rstrIdentifier );

		/**
		* \return                                     Layer flags as string identifier
		*/
		static std::string                            GetFlagsAsString( const unsigned int uiFlags );

		/**
		* \return                                     Address mode identifier as integer matching define
		*/
		static unsigned int                           GetAddressFromString( const std::string &rstrIdentifier );

		/**
		* \return                                     Address mode as string identifier
		*/
		static std::string                            GetAddressAsString( const unsigned int uiUVAddress );

		/**
		* \return                                     Texcoord gen identifier as integer matching define
		*/
		static unsigned int                           GetTexCoordGenFromString( const std::string &rstrIdentifier );

		/**
		* \return                                     Texcoord gen as string identifier
		*/
		static std::string                            GetTexCoordGenAsString( const unsigned int uiTexCoordGen );
};


#ifdef WIN32
#  ifndef __HAVE_VECTOR_NETEXTURELAYER
     UDTVectorEXPIMP( class TextureLayer* );
#    define __HAVE_VECTOR_NETEXTURELAYER
#  endif
#endif


/**
  * \brief Material for one rendering pass
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class MaterialPass : public TextureLayer
{
	public:

		/*! Ambient color, only used in vertex-lighting path */
		Color                                                 m_kAmbient;

		/*! Diffuse color, only used in vertex-lighting path */
		Color                                                 m_kDiffuse;

		/*! Specular color, only used in vertex-lighting path */
		Color                                                 m_kSpecular;

		/*! Emission color, only used in vertex-lighting path */
		Color                                                 m_kEmission;

		/*! Shininess (specular exponent), only used in vertex-lighting path (range [0..1]) */
		float                                                 m_fShininess;

		/*! Z buffer mode */
		ZBufferMode                                           m_kZBufferMode;

		/*! Fog mode */
		FogMode                                               m_kFogMode;
		
		/*! Vertex shader */
		ShaderPtr                                             m_pkVertexShader;

		/*! Fragment shader */
		ShaderPtr                                             m_pkFragmentShader;

		/*! Texture layers */
		std::vector< TextureLayer* >                          m_vpkTextureLayers;

		/*! Number of lights this technique pass can handle in one pass, 0 for infinite */
		unsigned int                                          m_uiMaxLights;


		/**
		*/
		                                                      MaterialPass();

		/**
		* \param rkPass                                       Pass to copy values from
		*/
		                                                      MaterialPass( const MaterialPass &rkPass );

		/**
		* Delete data
		*/
		virtual                                              ~MaterialPass();

		/**
		* Assignment
		* \param rkPass                                       Pass to copy values from
		* \return                                             Self-reference
		*/
		MaterialPass                                         &operator =( const MaterialPass &rkPass );
};


HashTableExport(Material);

typedef HashTable< Material > MaterialTable;

/**
  * \brief Full material description
  * A material is a primary pass from inheritance, and can have any number of auxiliary passes
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class Material : public RefCounter, public MaterialPass
{
	protected:

		/*! Material table */
		MaterialTable                                        *m_pkTable;

		/*! Name */
		HashString                                            m_strName;

	public:

		/*! Secondary passes */
		std::vector< MaterialPass* >                          m_vpkPasses;

		/*! Object should cast dynamic shadows */
		bool                                                  m_bDynamicShadows;

		/*! Object should't be affected by lights */
		bool                                                  m_bNoLighting;

		/**
		* \param rstrName                                     Name
		* \param pkTable                                      Material table
		*/
		                                                      Material( const HashString &rstrName, MaterialTable *pkTable = 0 );

		/**
		* Copy data
		* \param rkMaterial                                   Reference material to copy
		*/
		                                                      Material( const Material &rkMaterial );

		/**
		* Delete data
		*/
		virtual                                              ~Material();

		/**
		* \param rstrName                                     New name
		*/
		void                                                  SetName( const HashString &rstrName );

		/**
		* \return                                             Name
		*/
		const HashString                                     &GetName() const { return m_strName; }

		/**
		* Set table we are managed by
		* \param pkTable                                      Material table
		*/
		void                                                  SetTable( MaterialTable *pkTable );

		/**
		* Assignment
		* \param rkMaterial                                   Material to copy values from
		* \return                                             Self-reference
		*/
		Material                                             &operator =( const Material &rkMaterial );
};


#ifndef __HAVE_SMARTPOINTER_NEMATERIAL
   SmartPointer( Material );
#  define __HAVE_SMARTPOINTER_NEMATERIAL
#endif


};


#endif
