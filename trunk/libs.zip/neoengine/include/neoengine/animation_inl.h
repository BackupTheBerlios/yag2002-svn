/***************************************************************************
                 animation_inl.h  -  Template base for animations
                             -------------------
    begin                : Fri Oct 24 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, animation_inl.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


template < class KeyframeType > Animation< KeyframeType >::Animation() :
	UpdateEntity(),
	m_uiID( 0 ),
	m_fLength( 0.0f ),
	m_fCurTime( 0.0f ),
	m_iLastKeyframe( 0 ),
	m_iNextKeyframe( 0 ),
	m_fOffset( 0.0f )
{
}


template < class KeyframeType > Animation< KeyframeType >::Animation( const Animation< KeyframeType > &rkAnimation ) :
	UpdateEntity( rkAnimation ),
	m_uiID( rkAnimation.m_uiID ),
	m_strName( rkAnimation.m_strName ),
	m_fLength( rkAnimation.m_fLength ),
	m_fCurTime( rkAnimation.m_fCurTime ),
	m_iLastKeyframe( rkAnimation.m_iLastKeyframe ),
	m_iNextKeyframe( rkAnimation.m_iNextKeyframe ),
	m_fOffset( rkAnimation.m_fOffset )
{
	if( !rkAnimation.IsActive() )
		Deactivate();

	m_vpkKeyframes.resize( rkAnimation.m_vpkKeyframes.size() );

	typename KeyframeVec::iterator       ppkDest     = m_vpkKeyframes.begin();
	typename KeyframeVec::const_iterator ppkKeyframe = rkAnimation.m_vpkKeyframes.begin();
	typename KeyframeVec::const_iterator ppkEnd      = rkAnimation.m_vpkKeyframes.end();

	for( ; ppkKeyframe != ppkEnd; ++ppkKeyframe, ++ppkDest )
		*ppkDest = new KeyframeType( *(*ppkKeyframe) );
}


template < class KeyframeType > Animation< KeyframeType >::~Animation()
{
	typename KeyframeVec::iterator ppkKeyframe = m_vpkKeyframes.begin();
	typename KeyframeVec::iterator ppkEnd      = m_vpkKeyframes.end();

	for( ; ppkKeyframe != ppkEnd; ++ppkKeyframe )
		delete( *ppkKeyframe );
}


template < class KeyframeType > inline void Animation< KeyframeType >::AddKeyframe( KeyframeType *pkKeyframe )
{
	assert( pkKeyframe );

	typename KeyframeVec::iterator ppkKeyframe = m_vpkKeyframes.begin();
	typename KeyframeVec::iterator ppkEnd      = m_vpkKeyframes.end();

	for( ; ppkKeyframe != ppkEnd; ++ppkKeyframe )
	{
		if( pkKeyframe->m_fT < (*ppkKeyframe)->m_fT )
		{
			m_vpkKeyframes.insert( ppkKeyframe, pkKeyframe );
			return;
		}
	}

	m_vpkKeyframes.push_back( pkKeyframe );
}


template < class KeyframeType > inline void Animation< KeyframeType >::Update( float fDeltaTime )
{
	int iNumKeyframes = ( int )m_vpkKeyframes.size();

	if( iNumKeyframes <= 1 )
		return;

	m_fCurTime += fDeltaTime / m_fLength;

	if( m_fCurTime >= 1.0f )
		m_fCurTime = (float)fmod( m_fCurTime, 1.0f );

	m_iLastKeyframe   = 0;

	while( ( m_iLastKeyframe < iNumKeyframes ) && ( m_vpkKeyframes[ m_iLastKeyframe ]->m_fT <= m_fCurTime ) )
		++m_iLastKeyframe;

	if( --m_iLastKeyframe < 0 )
		m_iLastKeyframe = iNumKeyframes - 1;

	m_iNextKeyframe = ( m_iLastKeyframe + 1 ) % iNumKeyframes;

	float fInterval = m_vpkKeyframes[ m_iNextKeyframe ]->m_fT - m_vpkKeyframes[ m_iLastKeyframe ]->m_fT;

	if( fInterval < 0.0f )
		fInterval += 1.0f;

	float fOffset   = m_fCurTime - m_vpkKeyframes[ m_iLastKeyframe ]->m_fT;

	if( fOffset < 0.0f )
		fOffset += 1.0f;

	m_fOffset = fOffset / fInterval;
}

