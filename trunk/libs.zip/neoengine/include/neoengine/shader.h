/***************************************************************************
                       shader.h  -  Pipeline shaders
                             -------------------
    begin       : Mon May 05 2003
    copyright   : (C) 2003 by Reality Rift Studios
    email       : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, shader.h

 The Initial Developer of the Original Code is Matt Holmes.
 Portions created by Matt Holmes are Copyright (C) 2003
 Matt Holmes. All Rights Reserved.

 Contributors: Mattias Jansson (mattias@realityrift.com)
               Cody Russell (cody@jhu.edu)

 ***************************************************************************/

#ifndef __NESHADER_H
#define __NESHADER_H


/**
  * \file shader.h
  * Programmable pipeline shaders
  */


#include "base.h"
#include "hashtable.h"
#include "loadableentity.h"
#include "pointer.h"


namespace NeoEngine
{


// External classes
class RenderDevice;
class Vector3d;
class Color;
class Matrix;
class Quaternion;


// Forward declarations
class Shader;


/**
  * \brief Pipeline shader parameter definition
  * \author Matt Holmes (kerion@houston.rr.com)
  * \author Cody Russell (cody [at] jhu.edu)
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ShaderParam
{
	public:

		/**
		* \enum SHADERPARAMTYPE
		* \brief Type definitions for shader parameters
		*/
		enum SHADERPARAMTYPE
		{
		  PPT_NULL,
		  PPT_SYSTEM,
		  PPT_FLOAT4,
		  PPT_VECTOR,
		  PPT_COLOR,
		  PPT_QUAT,
		  PPT_MATRIX
		};

		/**
		* \enum SHADERSYSTEMPARAM
		* \brief List of available system parameters for pipeline shaders
		*/
		enum SHADERSYSTEMPARAM
		{
		  /*! Bit set for all system matrix parameters */
		  SYSTEMMATRIXPARAM                          = 0x00010000,

		  /*! Current model matrix */
		  PSP_MODEL_MATRIX                           = 0x00010001,

		  /*! Current view matrix */
		  PSP_VIEW_MATRIX                            = 0x00010002,

		  /*! Current projection matrix */
		  PSP_PROJECTION_MATRIX                      = 0x00010003,

		  /*! Current concatenated model and view matrix */
		  PSP_MODELVIEW_MATRIX                       = 0x00010004,

		  /*! Current concatenated model, view and projection matrix */
		  PSP_MODELVIEWPROJ_MATRIX                   = 0x00010005,

		  /*! Inverted current model matrix */
		  PSP_INV_MODEL_MATRIX                       = 0x00010006,


		  /*! Bit set for all light parameters */
		  LIGHTPARAM                                 = 0x00020000,

		  /*! Current light position in world space */
		  PSP_LIGHT_POSITION                         = 0x00020001,

		  /*! Current light direction in world space */
		  PSP_LIGHT_DIRECTION                        = 0x00020002,

		  /*! Current light diffuse color */
		  PSP_LIGHT_DIFFUSE_COLOR                    = 0x00020003,

		  /*! Current light ambient color */
		  PSP_LIGHT_AMBIENT_COLOR                    = 0x00020004,

		  /*! Current light specular color */
		  PSP_LIGHT_SPECULAR_COLOR                   = 0x00020005,

		  /*! Current light position in object space */
		  PSP_LIGHT_POSITION_OBJECTSPACE             = 0x00020006,

		  /*! Current light direction in object space */
		  PSP_LIGHT_DIRECTION_OBJECTSPACE            = 0x00020007,

		  /*! Attenuation, values are 1.0f / ( constant | linear | quadratic ) for rgb channels respectively */
		  PSP_LIGHT_ATTENUATION                      = 0x00020008,

		  /*! Reciprocal attenuation, values are 1.0f / ( constant | linear | quadratic ) for rgb channels respectively */
		  PSP_LIGHT_REP_ATTENUATION                  = 0x00020009,


		  /*! Bit set for all mics system parameters */
		  MISCPARAM                                  = 0x00040000,

		  /*! Total ambient light color contributed by all lights, including directional and point lights */
		  PSP_TOTAL_LIGHT_AMBIENT_COLOR              = 0x00040001,

		  /*! Total ambient light color contributed by ambient lights, NOT including directional and point lights */
		  PSP_TOTAL_AMBIENTLIGHT_AMBIENT_COLOR       = 0x00040002,

		  /*! Eye position in object space */
		  PSP_EYE_POSITION_OBJECTSPACE               = 0x00040003
		};

		/*! Parameter index */
		unsigned int                                 m_uiIndex;

		/*! Parameter type */
		SHADERPARAMTYPE                              m_eType;

		/*! Value (depending on type) */
		union ShaderParamValue
		{
		  /*! System parameter (PPT_SYSTEM) */
		  SHADERSYSTEMPARAM                          m_eSystemID;

		  /*! Float (PPT_FLOAT4) */
		  float                                      m_afFloat[4];

		  /*! Vector (PPT_VECTOR), will be padded with 1.0f for w */
		  const Vector3d                            *m_pkVector;

		  /*! Color (PPT_COLOR) */
		  const Color                               *m_pkColor;

		  /*! Quaternion (PPT_QUAT) */
		  const Quaternion                          *m_pkQuaternion;

		  /*! Matrix (PPT_MATRIX) */
		  const Matrix                              *m_pkMatrix;

		}                                            m_Value;

		/*! Light index */
		unsigned int                                 m_uiLight;
};


HashTableExport( ShaderParam );
typedef HashTable<ShaderParam> ShaderParamHash;


#ifdef WIN32
#  ifndef __HAVE_VECTOR_NESHADERPARAM
     UDTVectorEXPIMP( class ShaderParam* );
#    define __HAVE_VECTOR_NESHADERPARAM
#  endif
#endif



/**
  * \brief Pipeline shader
  * Base class for pipeline shaders, real implementation created by render device
  * The shader expects source code in format compatible with the target for the type of shader that
  * the render device selects during initialization. Shaders are reference counted and should
  * <b>always</b> be accessed through a smart pointer. When a shader is loaded from file,
  * the name of the shader is automatically set to the base file name (i.e without extension)
  * Shader sources can be extended with special comments that automatically binds parameters
  * to various system params. The comments should be on the form:<br>
  * # var &lt;type&gt; &lt;name&gt; c[&lt;reg&gt;]<br>
  * # bind &lt;name&gt; = &lt;identifier&gt;<br><br>
  * The <b>var</b> statement is compatible with the output from the Cg compiler<br>
  * <b>&lt;type&gt;</b> should be one of the following types: <b>float2</b>, <b>float3</b>, <b>float4</b>, <b>float4x4</b>, the first
  * three matching an input of four floats (one register) and the last matching an input of a 4x4 matrix
  * (four registers).<br>
  * <b>&lt;name&gt;</b> should be a string identifying the parameter by a name<br>
  * <b>&lt;reg&gt;</b> should be the register the parameter is to be bound to (for a matrix parameter, the start register)<br><br>
  * The <b>bind</b> statement is used to automatically setup the parameter type and bindings to system parameters<br>
  * <b>&lt;name&gt;</b> identifies a parameter as named in a <b>var</b> statement
  * <b>&lt;identifier&gt;</b> specifies a system parameter name, and is given on a hierarchial path-style format:<br>
  * <b>System</b>.<b>Matrix</b>|<b>Light</b>.<b>&lt;name&gt;</b>[.<b>&lt;name&gt;</b>...]<br>
  * where <b>System</b> specifies that the parameter is a system parameter, <b>Matrix</b> and <b>Light</b> specifies which
  * category of system parameters to use and <b>&lt;name&gt;</b> idenfies which system parameter of the given type to bind to. Some
  * system parameters might require additional path names.<br>
  * For <b>Matrix</b> category, the supported names are:<ul>
  * <li><b>MODEL</b></li>
  * <li><b>VIEW</b></li>
  * <li><b>PROJECTION</b></li>
  * <li><b>MODELVIEW</b></li>
  * <li><b>MODELVIEWPROJECTION</b></li>
  * <li><b>INVERSEMODEL</b></li>
  * </ul>
  * Each name corresponds to the system matrix parameter of the same name.<br>
  * For <b>Light</b> category, the first path name must be the light index, a single integer (0,1,...). The second path name
  * is one of the following:<ul>
  * <li><b>POSITION</b></li>
  * <li><b>DIRECTION</b></li>
  * <li><b>POSITION_OBJECTSPACE</b></li>
  * <li><b>DIRECTION_OBJECTSPACE</b></li>
  * <li><b>AMBIENT</b> (ambient color)</li>
  * <li><b>DIFFUSE</b> (diffuse color)</li>
  * <li><b>SPECULAR</b> (specular color)</li>
  * <li><b>ATTENUATION</b> (attenuation factors)</li>
  * <li><b>REP_ATTENUATION</b> (reciprocal attenuation factors)</li>
  * </ul>
  * For <b>Misc</b> category, the supported names are:<ul>
  * <li><b>TOTAL_AMBIENT_COLOR</b> (total ambient light of scene, including all point and directional lights)</li>
  * <li><b>EYE_POSITION_OBJECTSPACE</b> (eye position in object space)</li>
  * </ul>
  * \author Matt Holmes (kerion@houston.rr.com)
  * \author Cody Russell (cody [at] jhu.edu)
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Shader : public RefCounter, public LoadableEntity
{
	friend class RenderDevice;

	public:

		/**
		* \enum SHADERTYPE
		* \brief Shader type identifier
		*/
		enum SHADERTYPE
		{
		  /*! Vertex shader */
		  VERTEXSHADER                                      = 0,

		  /*! Fragment shader */
		  FRAGMENTSHADER                                    = 1
		};

		/**
		* \enum SHADERTARGET
		* \brief Supported pipeline shader native types
		*/
		enum SHADERTARGET
		{
		  /*! Shader type is not supported */
		  NOTSUPPORTED                                       = 0,


		  /*! DX9 vertex shader group */
		  NEPT_DX9_VS_MASK                                   = 0x110,

		  /*! DX9 vertex shader 1.1 */
		  NEPT_DX9_VS_1_1                                    = 0x111,

		  /*! DX9 vertex shader 2.0 */
		  NEPT_DX9_VS_2_0                                    = 0x112,

		  /*! DX9 vertex shader 2.x */
		  NEPT_DX9_VS_2_X                                    = 0x113,


		  /*! DX9 pixel shader group */
		  NEPT_DX9_PS_MASK                                   = 0x120,

		  /*! DX9 pixel shader 1.1 */
		  NEPT_DX9_PS_1_1                                    = 0x121,

		  /*! DX9 pixel shader 1.2 */
		  NEPT_DX9_PS_1_2                                    = 0x122,

		  /*! DX9 pixel shader 1.3 */
		  NEPT_DX9_PS_1_3                                    = 0x123,

		  /*! DX9 pixel shader 1.4 */
		  NEPT_DX9_PS_1_4                                    = 0x124,

		  /*! DX9 pixel shader 2.0 */
		  NEPT_DX9_PS_2_0                                    = 0x125,

		  /*! DX9 pixel shader 2.x */
		  NEPT_DX9_PS_2_X                                    = 0x126,


		  /*! OpenGL vertex shader group */
		  NEPT_GL_VS_MASK                                    = 0x210,

		  /*! OpenGL ARB_vertex_program extension */
		  NEPT_GL_ARBVP_1                                    = 0x211,


		  /*! OpenGL fragment program group */
		  NEPT_GL_FS_MASK                                    = 0x220,

		  /*! OpenGL ARB_fragment_program extension */
		  NEPT_GL_ARBFP_1                                    = 0x221,

		  /*! OpenGL ATI_fragment_shader extension */
		  NEPT_GL_ATIFS                                      = 0x222,

		  /*! OpenGL NV_register_combiners extension */
		  NEPT_GL_NVRC                                       = 0x223,

		  /*! OpenGL NV_register_combiners2 extension */
		  NEPT_GL_NVRC_2                                     = 0x224
		};


#ifdef WIN32
#  ifndef __HAVE_VECTOR_NESHADERTARGET
     UDTVectorEXPIMP( SHADERTARGET );
#    define __HAVE_VECTOR_NESHADERTARGET
#  endif
#endif


	protected:

		/*! Current vertexshader target, set by render device */
		static NE_STATIC SHADERTARGET                        s_eVSTarget;

		/*! Current fragmentshader target, set by render device */
		static NE_STATIC SHADERTARGET                        s_eFSTarget;

		/*! Priority list of vertex shader profiles requested by application */
		static NE_STATIC std::vector< SHADERTARGET >         s_veVSPriority;

		/*! Priority list of fragment shader profiles requested by application */
		static NE_STATIC std::vector< SHADERTARGET >         s_veFSPriority;

		/*! Shader count */
		static NE_STATIC unsigned int                        s_uiCount;


		/*! Shader source code */
		std::string                                          m_strSource;

		/*! Shader type */
		SHADERTYPE                                           m_eShaderType;

		/*! Shader name */
		HashString                                           m_strName;

		/*! Shader ID */
		unsigned int                                         m_uiID;

		/*! Hashtable of currently registered parameters */
		ShaderParamHash                                      m_kParams;

		/*! Parameters by index */
		ShaderParam                                        **m_ppkParams;

		/*! All parameters */
		std::vector< ShaderParam* >                          m_vpkParams;

		/*! Parameters in need of rebinding */
		std::vector< ShaderParam* >                           m_vpkUpdatedParams;



		/**
		* Load the script source for this shader from the given file
		* \param uiFlags                                     Load flags
		* \return                                            True if loaded, or false
		*/
		bool                                                 LoadNode( unsigned int uiFlags );

		/**
		* Delete and clear all parameters
		*/
		void                                                 ClearParams();

		/**
		* Parse parameters and special neoengine comments for parameter bindings in the source
		*/
		void                                                 ParseParams();


	public:

		/**
		* Construct a new pipeline shader
		* \param eType                                       The type of shader to create (vertex or fragment)
		* \param pkFileManager                               File manager that loaded this shader shader, will use core file manager if null (default)
		*/
		                                                     Shader( SHADERTYPE eType, FileManager *pkFileManager = 0 );

		/**
		* Destroy this pipeline shader instance
		*/
		virtual                                             ~Shader();

		/**
		* Compile the shader
		* \param pstrSource                                  Pointer to source string, or null if already loaded
		* \return                                            True if succesful, false otherwise.
		*/
		virtual bool                                         Compile( const std::string *pstrSource = 0 ) = 0;

		/**
		* Set name of shader
		* \param rstrName                                    New name
		*/
		virtual void                                         SetName( const HashString &rstrName );

		/**
		* \return                                            Name of shader
		*/
		inline const HashString                             &GetName() const { return m_strName; }

		/**
		* \return                                            Shader ID
		*/
		inline unsigned int                                  GetID() const { return m_uiID; }

		/**
		* Get named parameter
		* \param rstrName                                    Name of parameter to get type of
		* \return                                            Parameter object
		*/
		inline ShaderParam                                  *GetParameter( const HashString &rstrName ) { return m_kParams.Find( rstrName ); }

		/**
		* Get parameter by index (register)
		* \param uiIndex                                     Register index
		* \return                                            Parameter object
		*/
		inline ShaderParam                                  *GetParameter( unsigned int uiIndex ) { return m_ppkParams[ uiIndex ]; }

		/**
		* Get all parameters for shader
		* \return                                            Vector with all parameters
		*/
		inline const std::vector< ShaderParam* >            &GetAllParameters() { return m_vpkParams; }

		/**
		* Notify shader that parameter has been updated
		* \param pkParameter                                 Parameter object
		*/
		void                                                 UpdateParameter( ShaderParam *pkParameter );

		/**
		* \return                                            Shader type (vertex or fragment)
		*/
		inline SHADERTYPE                                    GetType() const { return m_eShaderType; }

		/**
		* \param eType                                       Shader type (vertex or fragment)
		* \return                                            Current native target for shader type
		*/
		static inline SHADERTARGET                           GetTarget( SHADERTYPE eType ) { return( eType == VERTEXSHADER ? s_eVSTarget : s_eFSTarget ); }

		/**
		* Set priority list of profiles for a shader type. The backend will only choose among the profiles in this list
		* and will choose profiles in the order of the list.
		* \param eType                                       Shader type (vertex or fragment)
		* \param rvePriority                                 Vector of requested profiles in priority order (highest priority first)
		*/
		static void                                          SetPriority( SHADERTYPE eType, const std::vector< SHADERTARGET > &rvePriority );

		/**
		* Get shader target name as string
		* \param eTarget                                     Shader target identifier
		* \return                                            Name of shader target as string
		*/
		static std::string                                   GetTargetAsString( SHADERTARGET eTarget );

		/**
		* Get shader target identifier from string
		* \param rstrTarget                                  Shader target name as string
		* \return                                            Shader target identifier
		*/
		static SHADERTARGET                                  GetTargetFromString( const std::string &rstrTarget );
};


#ifndef __HAVE_SMARTPOINTER_NESHADER
   //Define smart pointer
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif
   SmartPointer( Shader );
#  define __HAVE_SMARTPOINTER_NESHADER
#endif


};


#endif

