/***************************************************************************
              updateentity.h  -  Base class for updateable entities
                             -------------------
    begin                : Mon Sep 11 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, updateentity.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NEUPDATEENTITY_H
#define __NEUPDATEENTITY_H


/**
  * \file updateentity.h
  * Base class for updateable entities
  */


#include "base.h"
#include "activator.h"

#include <string>


namespace NeoEngine
{


/**
  * \brief Interface for updateable objects
  * An updateable object overloads and implements the Update
  * method for updating the object using the deltatime passed
  * since last call as passed by the caller. Derived from the
  * Activator class for easy on/off management.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API UpdateEntity : public virtual Activator
{
	public:

		/**
		* Update object
		* \param fDeltaTime                           Time passed since last update
		*/
		virtual void                                  Update( float fDeltaTime ) {};
};


}; // namespace NeoEngine


#endif
