/***************************************************************************
           animator_inl.h  -  Template base for animator controllers
                             -------------------
    begin                : Thu Jan 22 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, animator_inl.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/



template < class AnimationType > AnimationBlendStage< AnimationType >::AnimationBlendStage() :
	m_pkAnimation( 0 ),
	m_fWeight( 1.0f ),
	m_pvbMask( 0 )
{
}


template < class AnimationType > AnimationBlendStage< AnimationType >::~AnimationBlendStage()
{
	delete m_pvbMask;
}




template < class AnimationType > AnimatorController< AnimationType >::AnimatorController() :
	m_bAutomaticBlend( true )
{
}


template < class AnimationType > AnimatorController< AnimationType >::AnimatorController( const AnimatorController< AnimationType > &rkController ) :
	m_bAutomaticBlend( rkController.m_bAutomaticBlend )
{
	m_vpkBlendStages.resize( rkController.m_vpkBlendStages.size() );
	m_vpkAnimations.resize( rkController.m_vpkAnimations.size() );

	typename AnimationBlendStageTypeVec::const_iterator ppkSrcStage;
	typename AnimationBlendStageTypeVec::iterator       ppkDstStage    = m_vpkBlendStages.begin();
	typename AnimationBlendStageTypeVec::iterator       ppkDstStageEnd = m_vpkBlendStages.end();

	for( ; ppkDstStage != ppkDstStageEnd; ++ppkDstStage )
		*ppkDstStage = new AnimationBlendStageType;

	typename AnimationTypeVec::iterator       ppkDstAnim    = m_vpkAnimations.begin();
	typename AnimationTypeVec::const_iterator ppkSrcAnim    = rkController.m_vpkAnimations.begin();
	typename AnimationTypeVec::const_iterator ppkSrcAnimEnd = rkController.m_vpkAnimations.end();

	for( ; ppkSrcAnim != ppkSrcAnimEnd; ++ppkSrcAnim, ++ppkDstAnim )
	{
		*ppkDstAnim = new AnimationType( *(*ppkSrcAnim) );

		ppkDstStage    = m_vpkBlendStages.begin();
		ppkSrcStage    = rkController.m_vpkBlendStages.begin();

		for( ; ppkDstStage != ppkDstStageEnd; ++ppkDstStage, ++ppkSrcStage )
		{
			if( (*ppkSrcStage)->m_pkAnimation == (*ppkSrcAnim) )
				(*ppkDstStage)->m_pkAnimation = *ppkDstAnim;
		}
	}

	ppkDstStage    = m_vpkBlendStages.begin();
	ppkSrcStage    = rkController.m_vpkBlendStages.begin();

	for( ; ppkDstStage != ppkDstStageEnd; ++ppkDstStage, ++ppkSrcStage )
	{
		(*ppkDstStage)->m_fWeight = (*ppkSrcStage)->m_fWeight;
		(*ppkDstStage)->m_pvbMask = ( (*ppkSrcStage)->m_pvbMask ? new std::vector< bool >( *(*ppkSrcStage)->m_pvbMask ) : 0 );
	}
}


template < class AnimationType > AnimatorController< AnimationType >::~AnimatorController()
{
	typename AnimationTypeVec::iterator ppkAnim    = m_vpkAnimations.begin();
	typename AnimationTypeVec::iterator ppkAnimEnd = m_vpkAnimations.end();

	for( ; ppkAnim != ppkAnimEnd; ++ppkAnim )
		delete( *ppkAnim );

	typename AnimationBlendStageTypeVec::iterator ppkStage    = m_vpkBlendStages.begin();
	typename AnimationBlendStageTypeVec::iterator ppkStageEnd = m_vpkBlendStages.end();

	for( ; ppkStage != ppkStageEnd; ++ppkStage )
		delete( *ppkStage );
}


template < class AnimationType > bool AnimatorController< AnimationType >::AddAnimation( AnimationType *pkAnimation )
{
	typename std::vector< AnimationType* >::iterator ppkAnim = m_vpkAnimations.begin();
	typename std::vector< AnimationType* >::iterator ppkEnd  = m_vpkAnimations.end();

	for( ; ppkAnim != ppkEnd; ++ppkAnim )
	{
		if( (*ppkAnim) == pkAnimation )
			return true;

		if( ( (*ppkAnim)->m_uiID == pkAnimation->m_uiID ) || ( (*ppkAnim)->m_strName == pkAnimation->m_strName ) )
			return false;
	}

	m_vpkAnimations.push_back( pkAnimation );

	pkAnimation->Deactivate();

	return true;
}


template < class AnimationType > bool AnimatorController< AnimationType >::SetAnimation( const HashString &rstrAnimName, unsigned int uiStage, float fWeight, std::vector< bool > *pvbMask, bool bReset )
{
	typename AnimationTypeVec::iterator ppkAnim = m_vpkAnimations.begin();
	typename AnimationTypeVec::iterator ppkEnd  = m_vpkAnimations.end();

	for( ; ppkAnim != ppkEnd; ++ppkAnim )
	{
		if( (*ppkAnim)->m_strName == rstrAnimName )
		{
			SetStage( uiStage, *ppkAnim, fWeight, pvbMask, bReset );
			return true;
		}
	}

	return false;
}


template < class AnimationType > bool AnimatorController< AnimationType >::SetAnimation( unsigned int uiAnimID, unsigned int uiStage, float fWeight, std::vector< bool > *pvbMask, bool bReset )
{
	typename AnimationTypeVec::iterator ppkAnim = m_vpkAnimations.begin();
	typename AnimationTypeVec::iterator ppkEnd  = m_vpkAnimations.end();

	for( ; ppkAnim != ppkEnd; ++ppkAnim )
	{
		if( (*ppkAnim)->m_uiID == uiAnimID )
		{
			SetStage( uiStage, *ppkAnim, fWeight, pvbMask, bReset );
			return true;
		}
	}

	return false;
}


template < class AnimationType > void AnimatorController< AnimationType >::Update( float fDeltaTime )
{
	typename AnimationTypeVec::iterator ppkAnim = m_vpkAnimations.begin();
	typename AnimationTypeVec::iterator ppkEnd  = m_vpkAnimations.end();

	for( ; ppkAnim != ppkEnd; ++ppkAnim )
	{
		if( (*ppkAnim)->IsActive() )
			(*ppkAnim)->Update( fDeltaTime );
	}

	if( m_bAutomaticBlend )
		BlendStages();
}


template < class AnimationType > void AnimatorController< AnimationType >::ClearAnimation()
{
	typename AnimationBlendStageTypeVec::iterator ppkStage    = m_vpkBlendStages.begin();
	typename AnimationBlendStageTypeVec::iterator ppkStageEnd = m_vpkBlendStages.end();

	for( ; ppkStage != ppkStageEnd; ++ppkStage )
	{
		(*ppkStage)->m_pkAnimation->Deactivate();
		delete *ppkStage;
	}

	m_vpkBlendStages.clear();
}


template < class AnimationType > const std::vector< AnimationType* > &AnimatorController< AnimationType >::GetAnimations() const
{
	return m_vpkAnimations;
}


template < class AnimationType > AnimationType *AnimatorController< AnimationType >::GetAnimation( unsigned int uiStage )
{
	if( uiStage >= m_vpkBlendStages.size() )
		return 0;

	return m_vpkBlendStages[ uiStage ]->m_pkAnimation;
}


template < class AnimationType > void AnimatorController< AnimationType >::SetStage( unsigned int uiStage, AnimationType *pkAnimation, float fWeight, std::vector< bool > *pvbMask, bool bReset )
{
	if( m_vpkBlendStages.size() <= uiStage )
	{
		size_t uiCur = m_vpkBlendStages.size();

		m_vpkBlendStages.resize( uiStage + 1 );

		for( ; uiCur <= uiStage; ++uiCur )
			m_vpkBlendStages[ uiCur ] = new AnimationBlendStageType;
	}

	AnimationBlendStageType *pkCurStage = m_vpkBlendStages[ uiStage ];

	if( pkCurStage->m_pkAnimation )
	{
		typename AnimationBlendStageTypeVec::iterator ppkStage    = m_vpkBlendStages.begin();
		typename AnimationBlendStageTypeVec::iterator ppkStageEnd = m_vpkBlendStages.end();

		for( ; ppkStage != ppkStageEnd; ++ppkStage )
			if( ( (*ppkStage) != pkCurStage ) && ( (*ppkStage)->m_pkAnimation == pkCurStage->m_pkAnimation ) )
				break;

		if( ppkStage == ppkStageEnd )
			pkCurStage->m_pkAnimation->Deactivate();
	}

	if( pkCurStage->m_pvbMask )
		delete pkCurStage->m_pvbMask;

	pkCurStage->m_pkAnimation = pkAnimation;
	pkCurStage->m_fWeight     = fWeight;
	pkCurStage->m_pvbMask     = ( pvbMask ? new std::vector< bool >( *pvbMask ) : 0 );

	pkAnimation->Activate();
}


template < class AnimationType > void AnimatorController< AnimationType >::BlendStages()
{
	typename AnimationBlendStageTypeVec::iterator ppkStage    = m_vpkBlendStages.begin();
	typename AnimationBlendStageTypeVec::iterator ppkStageEnd = m_vpkBlendStages.end();

	for( ; ppkStage != ppkStageEnd; ++ppkStage )
		if( (*ppkStage)->m_pkAnimation )
			BlendStage( (*ppkStage)->m_pkAnimation, (*ppkStage)->m_fWeight, (*ppkStage)->m_pvbMask );
}



