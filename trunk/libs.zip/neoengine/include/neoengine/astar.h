/***************************************************************************
                  astar.h  -  A* Pathfinding implementation
                             -------------------
    begin                : Fri Jan 30 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : kmullis@zianet.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, astar.h

 The Initial Developer of the Original Code is Keaton Mullis.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __ASTAR_H
#define __ASTAR_H

#include "base.h"
#include "node.h"
#include "nemath.h"

#include <vector>
#include <limits>

namespace NeoEngine
{
	class AStarNode;
	class AStar;

#ifdef WIN32

#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif

#  ifndef __HAVE_VECTOR_NEASTARNODELINK
     UDTVectorEXPIMP( class AStarNodeLink* );
#    define __HAVE_VECTOR_NEASTARNODELINK
#  endif

#  ifndef __HAVE_VECTOR_NEASTARNODE
     UDTVectorEXPIMP( class AStarNode* );
#    define __HAVE_VECTOR_NEASTARNODE
#  endif

#endif // WIN32

	class NEOENGINE_API AStarNodeLink
	{
	public:
		AStarNodeLink( AStarNode *pkTarget = 0, float fLength = std::numeric_limits< float >::max() );

		AStarNodeLink( const AStarNodeLink &rkLink );

		~AStarNodeLink();

		AStarNode *m_pkTarget;

		float m_fLength;

	};

	class NEOENGINE_API AStarNode : public SRTNode
	{
	public:
		AStarNode();

		AStarNode( const AStarNode &rkNode );

		virtual ~AStarNode();

		void AddLink( const AStarNodeLink &rkLink );

		bool operator==( AStarNode kNode ) { if( GetTranslation() == kNode.GetTranslation() ) return true; else return false; }

		std::vector< AStarNodeLink* > m_vpkLinks;

		AStarNode *m_pkParent;

		float m_fCost;

		float m_fEstimate;

		bool m_bOpen;

	};

	class NEOENGINE_API AStar
	{
	public:
		enum Status
		{
			NOPATH = 0,
			SUCCESS = 1,
			NOTFINISHED = 2
		};

		AStar();

		~AStar();

		void AddNode( const AStarNode &rkNode );

		Status GeneratePath( const Vector3d &rkFrom, const Vector3d &rkTo, float fThreshold, std::vector< SRTNode > &rvpkPath, float fMaxTime = std::numeric_limits< float >::max() );

		std::vector< AStarNode* > m_vpkNodes;

	protected:
		std::vector< AStarNode* > m_vpkOpenNodes;

		Vector3d m_kFrom;

		Vector3d m_kTo;

	};

};

#endif
