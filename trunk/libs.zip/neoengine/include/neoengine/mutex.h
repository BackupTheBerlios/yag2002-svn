/***************************************************************************
                  mutex.h  -  Mutex wrapper and automatic lock
                             -------------------
    begin                : Tue Feb 12 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, mutex.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEMUTEX_H
#define __NEMUTEX_H


#include "base.h"

#ifdef WIN32
#  ifndef WIN32_LEAN_AND_MEAN
#    define WIN32_LEAN_AND_MEAN
#  endif
#  ifndef NOGDI
#    define NOGDI
#  endif
#  include <windows.h>
#elif defined(POSIX) || defined(__APPLE__)
#  include <pthread.h>
#endif

#include <string>


namespace NeoEngine
{


/**
  * \brief Mutex object for thread safe programming
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API MutexObject
{
	private:

#ifdef WIN32

		/*! Mutex handle */
		HANDLE                                        m_kMutex;

		/*! Event handle */
		HANDLE                                        m_kEvent;

#elif defined(POSIX) || defined(__APPLE__)

		/*! Mutex object */
		pthread_mutex_t                               m_kMutex;

		/*! Condition object */
		pthread_cond_t                                m_kCond;

#endif

		/*! Name */
		std::string                                   m_strMutexName;
  
  
	public:
  
		/**
		* Create a new named mutex object
		* \param rstrMutexName                        Name
		*/
		                                              MutexObject( const std::string &rstrMutexName = "_noname" );

		/**
		* Delete mutex object
		*/
		virtual                                      ~MutexObject();

		/**
		* Lock mutex (will block until lock obtained)
		*/
		void                                          Lock();

		/**
		* Unlock mutex
		*/
		void                                          Unlock();

		/**
		* Block until event occurs
		*/
		void                                          WaitForEvent();

		/**
		* Broadcast event, wake up all waiting for event
		*/
		void                                          BroadcastEvent();

		/**
		* Set mutex name
		* \param rstrName                             New mutex name
		*/
		void                                          SetName( const std::string &rstrName ) { Lock(); m_strMutexName = rstrName; Unlock(); }
};




/**
  * \brief Simple class for automatic locking/unlocking mutex object
  * Makes it easier to manage a mutex lock by automatic lock on creation
  * and unlock on destruction. An example:
  * <pre>
  * void foo()
  * {
  *   MutexLock kLock( &kSomeMutex );
  *
  *   //kSomeMutex is now locked
  *   if( someTestThatFails() )
  *     return;
  *
  *   doSomething();
  *
  * } //The kSomeMutex is automatically unlocked whenever the function returns
  *   //since the kLock object is destroyed when it runs out of scope
  * </pre>
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API MutexLock
{
	private:
	
		/*! Mutex object we have locked */
		MutexObject                                  *m_pkMutexObject;
		

	public:
	
		/**
		* Lock mutex object
		* \param pkMutexObject                        Mutex object
		*/
		                                              MutexLock( MutexObject *pkMutexObject );
		
		/**
		* Unlock mutex object
		*/
		virtual                                      ~MutexLock();
};


}; // namespace NeoEngine


#endif  // __NEMUTEX_H
