/***************************************************************************
                 collision.h  -  Collision detection framework
                             -------------------
    begin                : Tue Apr 9 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, collision.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NECOLLISION_H
#define __NECOLLISION_H

#include "base.h"
#include "nemath.h"
#include "util.h"


/**
  * \file collision.h
  * Collision detection framework
  */


namespace NeoEngine
{


// External classes
class AABB;
class OBB;
class Sphere;
class Capsule;
class Frustum;
class Ray;
class Line;
class Plane;
class Contact;
class ContactSet;


/**
 * Intersection between two AABBs
 * \param pkAABBOne                                First AABB
 * \param pkAABBTwo                                Second AABB
 * \param pkContactSet                             Contact set object receiving collision contact data, 0 if not needed
 * \param bInvertNormal                            If false, collision normal will point from second object to first. If true, normal will point from first object to second.
 * \return                                         true if the AABBs intersect
 */
bool NEOENGINE_API                                 Intersection( AABB *pkAABBOne, AABB *pkAABBTwo, ContactSet *pkContactSet = 0, bool bInvertNormal = false );

/**
 * Intersection between AABB and OBB
 * \param pkAABB                                   AABB
 * \param pkOBB                                    OBB
 * \param pkContactSet                             Contact set object receiving collision contact data, 0 if not needed
 * \param bInvertNormal                            If false, collision normal will point from second object to first. If true, normal will point from first object to second.
 * \return                                         true if AABB and OBB intersect
 */
bool NEOENGINE_API                                 Intersection( AABB *pkAABB, OBB *pkOBB, ContactSet *pkContactSet = 0, bool bInvertNormal = false );

/**
 * Intersection between AABB and sphere
 * \param pkAABB                                   AABB
 * \param pkSphere                                 Sphere
 * \param pkContactSet                             Contact set object receiving collision contact data, 0 if not needed
 * \param bInvertNormal                            If false, collision normal will point from second object to first. If true, normal will point from first object to second.
 * \return                                         true if AABB and sphere intersect
 */
bool NEOENGINE_API                                 Intersection( AABB *pkAABB, Sphere *pkSphere, ContactSet *pkContactSet = 0, bool bInvertNormal = false );

/**
 * Intersection between AABB and capsule
 * \param pkAABB                                   AABB
 * \param pkCapsule                                Capsule
 * \param pkContactSet                             Contact set object receiving collision contact data, 0 if not needed
 * \param bInvertNormal                            If false, collision normal will point from second object to first. If true, normal will point from first object to second.
 * \return                                         true if AABB and capsule intersect
 */
bool NEOENGINE_API                                 Intersection( AABB *pkAABB, Capsule *pkCapsule, ContactSet *pkContactSet = 0, bool bInvertNormal = false );

/**
 * Intersection between two OBBs
 * \param pkOBBOne                                 First OBB
 * \param pkOBBTwo                                 Second OBB
 * \param pkContactSet                             Contact set object receiving collision contact data, 0 if not needed
 * \param bInvertNormal                            If false, collision normal will point from second object to first. If true, normal will point from first object to second.
 * \return                                         true if OBBs intersect
 */
bool NEOENGINE_API                                 Intersection( OBB *pkOBBOne, OBB *pkOBBTwo, ContactSet *pkContactSet = 0, bool bInvertNormal = false );

/**
 * Intersection between OBB and sphere
 * \param pkOBB                                    OBB
 * \param pkSphere                                 Sphere
 * \param pkContactSet                             Contact set object receiving collision contact data, 0 if not needed
 * \param bInvertNormal                            If false, collision normal will point from second object to first. If true, normal will point from first object to second.
 * \return                                         true if OBB and sphere intersect
 */
bool NEOENGINE_API                                 Intersection( OBB *pkOBB, Sphere *pkSphere, ContactSet *pkContactSet = 0, bool bInvertNormal = false );

/**
 * Intersection between OBB and capsule
 * \param pkOBB                                    OBB
 * \param pkCapsule                                Capsule
 * \param pkContactSet                             Contact set object receiving collision contact data, 0 if not needed
 * \param bInvertNormal                            If false, collision normal will point from second object to first. If true, normal will point from first object to second.
 * \return                                         true if OBB and capsule intersect
 */
bool NEOENGINE_API                                 Intersection( OBB *pkOBB, Capsule *pkCapsule, ContactSet *pkContactSet = 0, bool bInvertNormal = false );

/**
 * Intersection between two spheres
 * \param pkSphereOne                              First sphere
 * \param pkSphereTwo                              Second sphere
 * \param pkContactSet                             Contact set object receiving collision contact data, 0 if not needed
 * \param bInvertNormal                            If false, collision normal will point from second object to first. If true, normal will point from first object to second.
 * \return                                         true if spheres intersect
 */
bool NEOENGINE_API                                 Intersection( Sphere *pkSphereOne, Sphere *pkSphereTwo, ContactSet *pkContactSet = 0, bool bInvertNormal = false );

/**
 * Intersection between sphere and capsule
 * \param pkSphere                                 Sphere
 * \param pkCapsule                                Capsule
 * \param pkContactSet                             Contact set object receiving collision contact data, 0 if not needed
 * \param bInvertNormal                            If false, collision normal will point from second object to first. If true, normal will point from first object to second.
 * \return                                         true if sphere and capsule intersect
 */
bool NEOENGINE_API                                 Intersection( Sphere *pkSphere, Capsule *pkCapsule, ContactSet *pkContactSet = 0, bool bInvertNormal = false );

/**
 * Intersection between two capsules
 * \param pkCapsuleOne                             First capsule
 * \param pkCapsuleTwo                             Second capsule
 * \param pkContactSet                             Contact set object receiving collision contact data, 0 if not needed
 * \param bInvertNormal                            If false, collision normal will point from second object to first. If true, normal will point from first object to second.
 * \return                                         true if capsules intersect
 */
bool NEOENGINE_API                                 Intersection( Capsule *pkCapsuleOne, Capsule *pkCapsuleTwo, ContactSet *pkContactSet = 0, bool bInvertNormal = false );

/**
 * Intersection between AABB and frustum
 * \param pkAABB                                   AABB
 * \param pkFrustum                                Frustum
 * \return                                         true if AABB and frustum intersect
 */
bool NEOENGINE_API                                 Intersection( AABB *pkAABB, Frustum *pkFrustum );

/**
 * Intersection between OBB and frustum
 * \param pkOBB                                    OBB
 * \param pkFrustum                                Frustum
 * \return                                         true if OBB and frustum intersect
 */
bool NEOENGINE_API                                 Intersection( OBB *pkOBB, Frustum *pkFrustum );

/**
 * Intersection between sphere and frustum
 * \param pkSphere                                 Sphere
 * \param pkFrustum                                Frustum
 * \return                                         true if sphere and frustum intersect
 */
bool NEOENGINE_API                                 Intersection( Sphere *pkSphere, Frustum *pkFrustum );

/**
 * Intersection between capsule and frustum
 * \param pkCapsule                                Capsule
 * \param pkFrustum                                Frustum
 * \return                                         true if capsule and frustum intersect
 */
bool NEOENGINE_API                                 Intersection( Capsule *pkCapsule, Frustum *pkFrustum );

/**
 * Intersection between ray and polygon
 * \param rkRay                                    Ray
 * \param rkV0                                     First vertex, first polygon
 * \param rkV1                                     Second vertex, first polygon
 * \param rkV2                                     Third vertex, first polygon
 * \param pkContactSet                             Contact set object receiving collision contact data, 0 if not needed
 * \param rkNormal                                 Optional precalculated normal
 * \return                                         true if ray and polygon intersect
 */
bool NEOENGINE_API                                 Intersection( const Ray &rkRay, const Vector3d &rkV0, const Vector3d &rkV1, const Vector3d &rkV2, ContactSet *pkContactSet = 0, const Vector3d &rkNormal = Vector3d::ZERO );

/**
 * Slice two polygons and calculate intersection line
 * \param rkV0                                     First vertex, first polygon
 * \param rkV1                                     Second vertex, first polygon
 * \param rkV2                                     Third vertex, first polygon
 * \param rkU0                                     First vertex, second polygon
 * \param rkU1                                     Second vertex, second polygon
 * \param rkU2                                     Third vertex, second polygon
 * \param pkPoint0                                 Pointer to vector receiving first intersection point
 * \param pkPoint1                                 Pointer to vector receiving second intersection point
 * \param piCoplanar                               Optional pointer to integer receiving coplanar state (non-null indicates polygons are coplanar)
 */
bool NEOENGINE_API                                 Slice( const Vector3d &rkV0, const Vector3d &rkV1, const Vector3d &rkV2, const Vector3d &rkU0, const Vector3d &rkU1, const Vector3d &rkU2, Vector3d *pkPoint0, Vector3d *pkPoint1, int *piCoplanar = 0 );

/**
 * Helper method, clip polygon (triangle or quad) by rectangle (axis aligned) in 2D space
 * \param pfRect                                   Rectangle dimensions (x,y)
 * \param pfPoly                                   Polygon points, xy pairs
 * \param iNum                                     Number of points (only supports 3 or 4 at the moment)
 * \param pfClipped                                Array receiving clipped points, must be dimensioned to take maximum number of clipped points (6/8 for 3/4 point polys)
 * \return                                         Number of points in final array
 */
int NEOENGINE_API                                  ClipRectPoly2D( float *pfRect, float *pfPoly, int iNum, float *pfClipped );

/**
 * Helper method, clip polygons (triangles or quad) in 2D space
 * \param pfRefPoly                                Clipper polygon points, xy pairs
 * \param pfRefPolyNormals                         Normals (pointing away from polygon) for each edge in polygon
 * \param iNumRef                                  Number of points in clipper polygon
 * \param pfPoly                                   Polygon points for polygon to be clipped
 * \param iNum                                     Number of points (only supports 3 or 4 at the moment)
 * \param pfClipped                                Array receiving clipped points, must be dimensioned to take maximum number of clipped points
 * \return                                         Number of points in final array
 */
int NEOENGINE_API                                  ClipPolyPoly2D( float *pfRefPoly, float *pfRefPolyNormals, int iNumRef, float *pfPoly, int iNum, float *pfClipped );

/**
 * Helper method, calculate closes points of two lines
 * \param rkP0                                     Point on first line
 * \param rkD0                                     Direction vector of first line ( l0 = rkP0 + t * rkD0 )
 * \param rkP1                                     Point on first line
 * \param rkD1                                     Direction vector of first line ( l0 = rkP0 + t * rkD0 )
 * \param pfT0                                     Pointer to float receiving factor for first line
 * \param pfT1                                     Pointer to float receiving factor for second line
 */
void NEOENGINE_API                                 ClosestPointLineLine( const Vector3d &rkP0, const Vector3d &rkD0, const Vector3d &rkP1, const Vector3d &rkD1, float *pfT0, float *pfT1 );


};


#endif
