/***************************************************************************
         logstream.h  -  Filtered logging to multiple output targets
                             -------------------
    begin                : Tue Aug 26 2003
    copyright            : (C) 2003 by Cody Russell
    email                : cody `at' jhu.edu 
***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, logstream.h

 The Initial Developer of the Original Code is Cody Russell.
 Portions created by Cody Russell are Copyright (C) 2003
 Cody Russell. All Rights Reserved.

 Contributors: Mattias Jansson (mattias@realityrift.com)
               Bert van der Weerd
 
***************************************************************************/

#ifndef __NELOGSTREAM_H
#define __NELOGSTREAM_H

#include "base.h"

#include <ios>
#include <vector>
#include <iostream>


/**
  * \file logstream.h
  * C++ stream-style logging.  The basic use is just like any other C++ ostreams
  * like cout.
  *
  *      Vector kVec;
  *
  *      neolog << "My vector output: " << kVec << endl;
  *
  * Additionally, engine users can send logging output to different locations by
  * attaching LogSink objects to the LogSource.
  *
  *      neolog.AttachSink( Core::Get()->GetStdoutSink() );
  *      neolog.AttachSink( Core::Get()->GetConsole() );
  *
  * In most cases, this is all an engine user should need to do.  But there may
  * be times when the programmer wants to control what output is sent to stdout
  * and what is sent to the console.  Then an extra LogSource will need to be
  * created.
  *
  * Some logs are more important than others, and so there is the notion of a
  * loglevel.  You can specify the importance of your logging output by doing:
  *
  *      neolog << LogLevel( WARNING ) << "This is a warning." << endl
  *             << LogLevel( INFO ) << "This is just info." << endl
  *             << LogLevel( PANIC ) << "I'm starting to panic." << endl;
  *
  * This alone doesn't mean much, but each logging target (LogSink) can be told
  * what loglevel to listen for, and when you send something to the log it will
  * only be sent to log sinks that are listening for that loglevel or worse.
  * 
  *      Core::Get()->GetStdoutSink().SetLogThreshold( ERROR );
  *      neolog.AttachSink( &Core::Get()->GetStdoutSink() );
  *
  *      neolog << LogLevel( ERROR ) << "Oh, happy days!  An error has occured." << endl
  *             << LogLevel( WARNING ) << "Why aren't you listening to me?" << endl;
  *
  * You can also set a log threshold on the log source to filter any log messages
  * streamed to that source (note that if source filters away a message of less severe
  * level than the source threshold, a sink with higher threshold will NOT get the message)
  *
  *      neolog.SetLogThreshold( ERROR );
  *
  * In this example, only the first line of output will be sent to stdout because
  * loglevel WARNING is below the threshold given to the log sink.
  */


// Stupid Windows headers define ERROR to 0
#ifdef WIN32
#  undef ERROR
#endif


namespace NeoEngine
{


// External classes
class File;


/**
  * \brief Predefined log levels
  * For an example on how to use log levels, look at the documentation for the logstream.h file
  * \author Cody Russell (cody jhu edu)
  */
enum LOGLEVEL
{
	/*! Top-priority message that will never be filtered. DO NOT USE THIS unless you really mean it, future versions might cause abort on this message and print lots of debug info */
	PANIC   = 0x01,

	/*! The normal error level */
	ERROR   = 0x04,

	/*! Warnings that has important information */
	WARNING = 0x08,

	/*! General information that is interesting */
	INFO    = 0x10,

	/*! Debug data, lots of messages on this level */
	DEBUG   = 0x80
};


/**
  * \brief Base class for different log targets
  * A log sink is attached to a log source and given a certain loglevel threshold.
  * Whenever messages are sent to the log source by the program or the engine,
  * the log source forwards it to all the attached log sinks that are listening for that
  * loglevel threshold. The engine provides a number of sinks by default,
  * the stdout sink (LogStdoutSink), the file sink (LogFileSink) and the console
  * sink (Console).
  * For an example, look at the documentation for the logstream.h file
  * \author Cody Russell (cody jhu edu)
  */
class NEOENGINE_API LogSink
{
	friend class LogSource;

	protected:

		/*! Loglevel threshold */
		unsigned int                                m_uiThreshold;


	public:

		/**
		*/
		                                            LogSink();

		/**
		*/
		virtual                                    ~LogSink();

		/**
		* Set the threshold of loglevel
		* \param uiLevel                            The new loglevel threshold
		*/
		void                                        SetLogThreshold( unsigned int uiLevel );

		/**
		* Log sinks implement this to write data
		* \param rstrMsg                            Data to be written
		*/
		virtual void                                Write( const std::string &rstrMsg ) = 0;
};


/**
  * \brief Stdout log sink
  * The stdout sink writes log messages to the stdout stream (cout)
  * For an example, look at the documentation for the logstream.h file
  * \author Cody Russell (cody jhu edu)
  */
class NEOENGINE_API LogStdoutSink : public LogSink
{
	protected:


	public:

		/**
		*/
		                                            LogStdoutSink();

		/**
		*/
		virtual                                    ~LogStdoutSink();

		/**
		* Write data to stdout
		* \param rstrMsg                            Data to be written
		*/
		virtual void                                Write( const std::string &rstrMsg );
};


/**
  * \brief File log sink
  * The file sink writes log messages to a file specified or provided
  * to the constructor. Messages are written per-line.
  * For an example, look at the documentation for the logstream.h file
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API LogFileSink : public LogSink
{
	protected:

		/*! Log file */
		File                                       *m_pkFile;

	public:

		/**
		* \param rstrFileName                       Log file name
		*/
		                                            LogFileSink( const std::string &rstrFileName );

		/**
		* \param pkFile                             Log file object (will be deleted in dtor)
		*/
		                                            LogFileSink( File *pkFile );

		/**
		* Close file
		*/
		virtual                                    ~LogFileSink();

		/**
		* Write data to stdout
		* \param rstrMsg                            Data to be written
		*/
		virtual void                                Write( const std::string &rstrMsg );
};


/**
  * \brief Log sink for MSVC++ debugger
  * \author Bert van der Weerd
  */
class NEOENGINE_API LogMSVCDebugSink : public LogSink
{
	public:

		/**
		*/
		                                            LogMSVCDebugSink();

		/**
		*/
		virtual                                    ~LogMSVCDebugSink();

		/**
		* Write data to VC++ debugger
		* \param rstrMsg                            Data to be written
		*/
		virtual void                                Write( const std::string &rstrMsg );
};


/**
  * \brief Stream buffer for the log source
  * Internal class, engine users probably shouldn't need to ever use this class
  * \author Cody Russell (cody jhu edu)
  */
class NEOENGINE_API LogSourceStreamBuf : public std::basic_streambuf< char >
{
	private:

		/*! The log source */
		LogSource                                  *m_pkLogSource;

		/*! Current log message */
		std::string                                 m_strMsg;

	protected:

		/*! Handles streambuf overload for us. */
		virtual int_type                            overflow( int_type c );

	public:

		/**
		*/
		                                            LogSourceStreamBuf();

		/**
		*/
		virtual                                    ~LogSourceStreamBuf();

		/**
		* Set the log source
		* \param pkSource                           Log source
		*/
		void                                        SetLogSource( LogSource *pkSource );
};


/**
  * \brief Log manipulator
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API LogManipulator
{
	public:

		virtual std::ostream                       &operator ()( std::ostream &rkOut ) const = 0;
};


/**
  * \brief Stream manipulator for the LogSource class
  * Sets the loglevel state for the stream.  Once a loglevel state is set,
  * it will remain until it is changed, so it is not necessary to use this
  * loglevel manipulator for every logging call.
  * For an example, look at the documentation for the logstream.h file
  * \author Cody Russell (cody jhu edu)
  */
class NEOENGINE_API LogLevel : public LogManipulator
{
	private:

		/*! The log level */
		unsigned int                                m_uiLevel;

	public:

		/**
		* \param uiLevel                            Log level
		*/
		                                            LogLevel( unsigned int uiLevel ) : m_uiLevel( uiLevel ) {}

		virtual std::ostream                       &operator ()( std::ostream &rkOut ) const;
};


/**
  * \brief Log manipulator pushing log level
  * Manipulator pushing the current log level onto the stack and 
  * settings a new log level. Use PopLogLevel class to pop and
  * restore stored level from the stack.
  * \author Bert van der Weerd
  */
class NEOENGINE_API LogLevelPush : public LogManipulator
{
	private:

		/*! The log level */
		unsigned int                                m_uiLevel;

	public:
	
		/**
		* \param uiLevel                            Log level
		*/
		                                            LogLevelPush( unsigned int uiLevel ) : LogManipulator(), m_uiLevel( uiLevel ) {}

		virtual std::ostream                       &operator ()( std::ostream &rkOut ) const;
};


/**
  * \brief Log manipulator popping log level
  * Manipulator popping and restoring log level from the stack
  * \author Bert van der Weerd
  */
class NEOENGINE_API LogLevelPop : public LogManipulator
{
	public:
	
		                                            LogLevelPop() : LogManipulator() {}
	
		virtual std::ostream                       &operator ()( std::ostream &rkOut ) const;
};


/**
* Log manipulator operator. Execute the log manipulator on the log source object (the stream)
* \param rkOut                                     Stream (log source)
* \param rkManip                                   Log manipulator object
* \return                                          Stream
*/
NEOENGINE_API std::ostream &operator << ( std::ostream &rkOut, const LogManipulator &rkManip );


/**
  * \brief Simple callback interface for monitoring error log messages
  * Callback method is called by the log source object every time a log
  * messages of level ERROR or more severe is parsed.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API LogErrorCallback
{
	public:

		/**
		* Process error message
		* \param uiLevel                            Log level
		* \param rstrMsg                            Log message
		*/
		virtual void                                ErrorCallback( unsigned int uiLevel, const std::string &rstrMsg ) = 0;
};


#ifdef WIN32
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#    pragma warning( disable : 4660 )
#  endif
#  ifndef __HAVE_VECTOR_LOGSINK
     UDTVectorEXPIMP( LogSink* );
#    define __HAVE_VECTOR_LOGSINK
#  endif
#  ifndef __HAVE_VECTOR_UNSIGNED_INT
     UDTVectorEXPIMP( unsigned int );
#    define __HAVE_VECTOR_UNSIGNED_INT
#  endif
#endif


/**
  * \brief The log source object
  * Contains a loglevel state and a number of data sinks for logging output,
  * each with a loglevel threshold.  When it is given output to log, it
  * gives that output to all sinks that will accept logs equal to the current
  * loglevel state or higher.
  * For an example, look at the documentation for the logstream.h file
  * \author Cody Russell (cody jhu edu)
  */
class NEOENGINE_API LogSource : public std::basic_ostream< char >
{
	friend class LogLevel;

	protected:

		/*! Our stream buffer */
		LogSourceStreamBuf                          m_kStreamBuf;

		/*! List of all data sinks */
		std::vector< LogSink* >                     m_vpkSinks;

		/*! The current loglevel for the source */
		unsigned int                                m_uiLogLevel;

		/*! Current log threshold */
		unsigned int                                m_uiThreshold;

		/*! Error callback */
		LogErrorCallback                           *m_pkErrorCallback;

		/*! Loglevel stack */
		std::vector< unsigned int >                 m_vuiLogLevelStack;


	public:

		/**
		*/
		                                            LogSource();

		/**
		* Attach a data sink to this source
		* \param pkSink                             The sink to attach
		*/
		void                                        AttachSink( LogSink *pkSink );

		/**
		* Detach a data sink from this source
		* \param pkSink                             The sink to detach
		*/
		void                                        DetachSink( LogSink *pkSink );

		/**
		* Writes data to each data sink
		* \param rstrMsg                            Data to be written
		*/
		void                                        Write( const std::string &rstrMsg );

		/**
		* Set current log level
		* \param uiLevel                            Log level
		*/
		void                                        SetLogLevel( unsigned int uiLevel );

		/**
		* \return                                   Current log level
		*/
		unsigned int                                GetLogLevel() { return m_uiLogLevel; }

		/**
		* Push the current log level on the stack and set new level
		* \param uiLevel                            New log level
		*/
		void                                        PushLogLevel( unsigned int uiLevel );

		/**
		* Pop the and restore current log level from the stack
		*/
		void                                        PopLogLevel();

		/**
		* Set log threshold
		* \param uiLevel                            Threshold level (all levels less severe will be ignored)
		*/
		void                                        SetLogThreshold( unsigned int uiLevel );

		/**
		* Set error callback method
		* \param pkCallback                         Error callback object
		*/
		void                                        SetErrorCallback( LogErrorCallback *pkCallback );
};


/*! Global engine log object */
extern NEOENGINE_API LogSource neolog;


};


#endif
