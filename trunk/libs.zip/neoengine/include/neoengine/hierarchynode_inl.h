/***************************************************************************
     hierarchynode_inl.h  -  Hierarchy node inline method implementation
                             -------------------
    begin                : Sun Jan 26 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, hierarchynode_inl.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


template < class NodeType > inline bool HierarchyNode< NodeType >::UpdateWorld()
{
	if( m_bWorldUpdate )
	{
		if( m_pkParent )
		{
			float fParentWorldScaling = m_pkParent->GetWorldScaling();

			m_kWorldRotation    = m_pkParent->GetWorldRotation() * m_kRotation;
			m_fWorldScaling     = fParentWorldScaling * m_fScaling;
			m_kWorldTranslation = m_pkParent->GetWorldTranslation() + ( ( m_pkParent->GetWorldRotation() * m_kTranslation ) * fParentWorldScaling );
		}
		else
		{
			m_kWorldTranslation = m_kTranslation;
			m_kWorldRotation    = m_kRotation;
			m_fWorldScaling     = m_fScaling;
		}

		m_kWorldTransform.Set( m_kWorldRotation, m_kWorldTranslation );

		m_kWorldTransform.TransposeTo( &m_kInverseWorldTransform );

		m_kInverseWorldTransform[3][0] = m_kInverseWorldTransform[3][1] = m_kInverseWorldTransform[3][2] = 0.0f;

		m_kInverseWorldTransform.SetTranslation( m_kInverseWorldTransform * ( -m_kWorldTranslation ) );

		if( fabs( 1.0f - m_fWorldScaling ) > EPSILON )
		{
			float *pfMat = (float*)m_kWorldTransform;

			*pfMat++ *= m_fWorldScaling; *pfMat++ *= m_fWorldScaling; *pfMat++ *= m_fWorldScaling; ++pfMat;
			*pfMat++ *= m_fWorldScaling; *pfMat++ *= m_fWorldScaling; *pfMat++ *= m_fWorldScaling; ++pfMat;
			*pfMat++ *= m_fWorldScaling; *pfMat++ *= m_fWorldScaling; *pfMat   *= m_fWorldScaling;

			float fOOWorldScaling = 1.0f / m_fWorldScaling;

			pfMat = (float*)m_kInverseWorldTransform;

			*pfMat++ *= fOOWorldScaling; *pfMat++ *= fOOWorldScaling; *pfMat++ *= fOOWorldScaling; *pfMat++ *= fOOWorldScaling;
			*pfMat++ *= fOOWorldScaling; *pfMat++ *= fOOWorldScaling; *pfMat++ *= fOOWorldScaling; *pfMat++ *= fOOWorldScaling;
			*pfMat++ *= fOOWorldScaling; *pfMat++ *= fOOWorldScaling; *pfMat++ *= fOOWorldScaling; *pfMat   *= fOOWorldScaling;
		}

		m_bWorldUpdate = false;

		return true;
	}

	return false;
}


template < class NodeType > inline void HierarchyNode< NodeType >::TraverseNode( BaseVisitor &rkVisitor )
{
	Accept( rkVisitor );
}



template < class NodeType > inline NodeType *HierarchyNode< NodeType >::Get()
{
	return dynamic_cast< NodeType* >( this );
}



template < class NodeType > inline HierarchyNode< NodeType >::HierarchyNode( const HashString &rstrName, NodeType *pkParent ) :
	SRTNode(),
	m_bWorldUpdate( false ),
	m_fWorldScaling( 1.0f ),
	m_pkParent( 0 ),
	m_strName( rstrName )
{
	//We can't dynamic_cast yet!
	if( pkParent )
		pkParent->AttachNode( static_cast< NodeType* >( this ) );
}


template < class NodeType > inline HierarchyNode< NodeType >::HierarchyNode( NodeType &rkNode, bool bDuplicateChildren ) :
	SRTNode( rkNode ),
	m_bWorldUpdate( false ),
	m_fWorldScaling( rkNode.GetWorldScaling() ),
	m_kWorldRotation( rkNode.GetWorldRotation() ),
	m_kWorldTranslation( rkNode.GetWorldTranslation() ),
	m_pkParent( 0 ),
	m_strName( rkNode.m_strName )
{
	if( !bDuplicateChildren )
		return;

	typename std::vector< NodeType* >::iterator ppkNode     = rkNode.m_vpkChildren.begin();
	typename std::vector< NodeType* >::iterator ppkEnd      = rkNode.m_vpkChildren.end();

	m_vpkChildren.resize( rkNode.m_vpkChildren.size() );

	//We can't dynamic_cast yet!
	NodeType *pkThis = static_cast< NodeType* >( this );

	typename std::vector< NodeType* >::iterator ppkOurNode = m_vpkChildren.begin();

	for( ; ppkNode != ppkEnd; ++ppkNode, ++ppkOurNode )
	{
		//Don't use AttachNode, since that will try dynamic_cast (not possible yet!) and use this as NodeType (not initialized yet!)
		NodeType *pkNode   = (*ppkNode)->Duplicate();

		pkNode->m_pkParent   = pkThis;

		*ppkOurNode          = pkNode;
	}
}


template < class NodeType > inline HierarchyNode< NodeType >::~HierarchyNode()
{
	//We can't dynamic_cast since derived class is already destroyed!
	NodeType *pkThis = static_cast< NodeType* >( this );

	if( m_pkParent )
		m_pkParent->DetachNode( pkThis );

	typename std::vector< NodeType* >::iterator ppkNode = m_vpkChildren.begin();
	typename std::vector< NodeType* >::iterator ppkEnd  = m_vpkChildren.end();

	//We reset parent pointer to avoid reduntant calls to DetachNode()
	//since we and all children are being destroyed anyway
	for( ; ppkNode != ppkEnd; ++ppkNode )
	{
		assert( (*ppkNode)->m_pkParent == pkThis );

		(*ppkNode)->m_pkParent = 0;

		delete (*ppkNode);
	}
}


template < class NodeType > inline void HierarchyNode< NodeType >::SetTranslation( const Vector3d &rkTranslation, bool bNotifyUpdate )
{
	SRTNode::SetTranslation( rkTranslation );

	NotifyUpdate( bNotifyUpdate );
}


template < class NodeType > inline void HierarchyNode< NodeType >::SetRotation( const Quaternion &rkRotation, bool bNotifyUpdate )
{
	SRTNode::SetRotation( rkRotation );

	NotifyUpdate( bNotifyUpdate );
}


template < class NodeType > inline void HierarchyNode< NodeType >::SetScaling( float fScaling, bool bNotifyUpdate )
{
	SRTNode::SetScaling( fScaling );

	NotifyUpdate( bNotifyUpdate );
}


template < class NodeType > inline void HierarchyNode< NodeType >::SetName( const HashString &rstrName )
{
	m_strName = rstrName;
}


template < class NodeType > inline const HashString &HierarchyNode< NodeType >::GetName() const
{
	return m_strName;
}



template < class NodeType > inline NodeType *HierarchyNode< NodeType >::GetParent()
{
	return m_pkParent;
}


template < class NodeType > inline int HierarchyNode< NodeType >::AttachNode( NodeType *pkNode, bool bKeepWorldSRT )
{
	if( !pkNode || ( pkNode->GetParent() == this ) )
		return -1;

	//This will cause node to store world SRT in local SRT
	pkNode->DetachFromParent();
	pkNode->m_pkParent = Get();

	m_vpkChildren.push_back( pkNode );

	if( bKeepWorldSRT )
	{
		float fOOWorldScaling = 1.0f / GetWorldScaling();

		Quaternion kInvWorldRotation( ~GetWorldRotation() );

		//No need to set update flag, since world SRT data
		//will still be correct
		pkNode->SetTranslation( ( kInvWorldRotation * ( pkNode->GetWorldTranslation() - GetWorldTranslation() ) ) * fOOWorldScaling, false );
		pkNode->RotateWorld( kInvWorldRotation, false );
		pkNode->Scale( fOOWorldScaling, false );
	}
	else
	{
		//If we didn't recalculate local SRT transform
		//we need to update, since world cache is now invalid
		pkNode->NotifyUpdate( true );
	}

	return 0;
}


template < class NodeType > inline int HierarchyNode< NodeType >::DetachNode( NodeType *pkNode )
{
	typename std::vector< NodeType* >::iterator ppkNode = m_vpkChildren.begin();
	typename std::vector< NodeType* >::iterator ppkEnd  = m_vpkChildren.end();

	for( ; ppkNode != ppkEnd; ++ppkNode )
	{
		if( (*ppkNode) == pkNode )
		{
			m_vpkChildren.erase( ppkNode );

			pkNode->m_pkParent = 0;

			pkNode->SetTranslation( pkNode->GetWorldTranslation(), false );
			pkNode->SetRotation( pkNode->GetWorldRotation(), false );
			pkNode->SetScaling( pkNode->GetWorldScaling(), false );

			//No need to set notify flag to update world cache, since
			//it is now correct (and for child nodes as well)
			pkNode->m_bWorldUpdate = false;

			return 0;
		}
	}

	return -1;
}


template < class NodeType > inline void HierarchyNode< NodeType >::DetachFromParent()
{
	if( m_pkParent )
	{
		m_pkParent->DetachNode( Get() );
		m_pkParent = 0;

		m_bWorldUpdate = false;
	}
}


template < class NodeType > inline void HierarchyNode< NodeType >::NotifyUpdate( bool bRecurse )
{
	m_bWorldUpdate = true;

	if( !bRecurse )
		return;

	typename std::vector< NodeType* >::iterator ppkNode = m_vpkChildren.begin();
	typename std::vector< NodeType* >::iterator ppkEnd  = m_vpkChildren.end();

	for( ; ppkNode != ppkEnd; ++ppkNode )
		(*ppkNode)->NotifyUpdate( true );
}


template < class NodeType > inline const Vector3d &HierarchyNode< NodeType >::GetWorldTranslation()
{
	if( m_bWorldUpdate )
		UpdateWorld();

	return m_kWorldTranslation;
}


template < class NodeType > inline const Quaternion &HierarchyNode< NodeType >::GetWorldRotation()
{
	if( m_bWorldUpdate )
		UpdateWorld();

	return m_kWorldRotation;
}


template < class NodeType > inline float HierarchyNode< NodeType >::GetWorldScaling()
{
	if( m_bWorldUpdate )
		UpdateWorld();

	return m_fWorldScaling;
}


template < class NodeType > inline const Matrix &HierarchyNode< NodeType >::GetWorldTransform()
{
	if( m_bWorldUpdate )
		UpdateWorld();

	return m_kWorldTransform;
}


template < class NodeType > inline const Matrix &HierarchyNode< NodeType >::GetInverseWorldTransform()
{
	if( m_bWorldUpdate )
		UpdateWorld();

	return m_kInverseWorldTransform;
}


template < class NodeType > inline const std::vector< NodeType* > &HierarchyNode< NodeType >::GetChildren()
{
	return m_vpkChildren;
}


template < class NodeType > inline NodeType *HierarchyNode< NodeType >::GetByName( const HashString &rstrName, NODESEARCHMODE eMode, bool bInitSearch )
{
	if( eMode == BREADTH_FIRST )
	{
		if( bInitSearch )
		{
			if( GetName() == rstrName )
				return Get();
		}

		//Loop children, breadth first
		NodeType *pkNode;

		typename std::vector< NodeType* >::iterator ppkNode = m_vpkChildren.begin();
		typename std::vector< NodeType* >::iterator ppkEnd  = m_vpkChildren.end();

		for( ; ppkNode != ppkEnd; ++ppkNode )
			if( (*ppkNode)->GetName() == rstrName )
				return( *ppkNode );

		ppkNode = m_vpkChildren.begin();

		for( ; ppkNode != ppkEnd; ++ppkNode )
			if( ( pkNode = (*ppkNode)->GetByName( rstrName, BREADTH_FIRST, false ) ) )
				return pkNode;

		return 0;
	}

	if( GetName() == rstrName )
		return Get();

	NodeType *pkNode = 0;

	typename std::vector< NodeType* >::iterator ppkNode = m_vpkChildren.begin();
	typename std::vector< NodeType* >::iterator ppkEnd  = m_vpkChildren.end();

	for( ; ppkNode != ppkEnd; ++ppkNode )
		if( ( pkNode = (*ppkNode)->GetByName( rstrName, DEPTH_FIRST, false ) ) )
			return pkNode;

	return 0;
}


template < class NodeType > inline void HierarchyNode< NodeType >::Traverse( BaseVisitor &rkVisitor, NODESEARCHMODE eMode, int iDirection, bool bInitSearch )
{
	if( eMode == BREADTH_FIRST )
	{
		if( bInitSearch )
			TraverseNode( rkVisitor );

		typename std::vector< NodeType* >::iterator ppkNode = m_vpkChildren.begin();
		typename std::vector< NodeType* >::iterator ppkEnd  = m_vpkChildren.end();

		for ( ; ppkNode != ppkEnd; ++ppkNode )
			(*ppkNode)->TraverseNode( rkVisitor );

		ppkNode = m_vpkChildren.begin();

		for ( ; ppkNode != ppkEnd; ++ppkNode )
			(*ppkNode)->Traverse( rkVisitor, BREADTH_FIRST, false );

		return;
	}

	if( iDirection >= 0 )
		TraverseNode( rkVisitor );

	typename std::vector< NodeType* >::iterator ppkNode = m_vpkChildren.begin();
	typename std::vector< NodeType* >::iterator ppkEnd  = m_vpkChildren.end();

	for ( ; ppkNode != ppkEnd; ++ppkNode )
		(*ppkNode)->Traverse( rkVisitor, DEPTH_FIRST, false );

	if( iDirection < 0 )
		TraverseNode( rkVisitor );
}

