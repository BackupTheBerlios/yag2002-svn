/***************************************************************************
                          hashtable.h  -  Hash table
                             -------------------
    begin                : Sun Sep 1 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, hashtable.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEHASHTABLE_H
#define __NEHASHTABLE_H


#include "base.h"
#include "hashstring.h"

#include <vector>

#include <assert.h>


/**
  * \file hashtable.h
  * Hash table
  */


namespace NeoEngine
{


/**
  * \brief Hash table node template
  * The hash table node is a container object for the key string and the data object
  * \author Mattias Jansson (mattias@realityrift.com)
  */
template < class HashTableType > class HashTableNode
{
	public:

		/*! Key name */
		HashString                                    m_strKey;

		/*! Data */
		HashTableType                                *m_pkData;


		/**
		* \param rstrKey                              Key name
		* \param pkData                               Data
		*/
		inline                                        HashTableNode( const HashString &rstrKey, HashTableType *pkData );

		/**
		* \param rkNode                               Node
		*/
		inline                                        HashTableNode( const HashTableNode< HashTableType > &rkNode );
};


/**
  * \brief Hash table template
  * Hash table storing pointers to objects of template type.
  * The hash table never deletes any pointers stored in the
  * hash table. Use the GetAllNodeData to get all the pointers
  * stored if you want to delete the data objects.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
template < class HashTableType > class HashTable
{
	public:

		typedef HashTableNode< HashTableType >        HashTableNodeType;
		typedef std::vector< HashTableNodeType  >     HashTableNodeVec;	
		typedef std::vector< HashTableNodeType* >     HashTableNodePtrVec;	

		/**
		* \brief Hash table defines
		*/
		enum HASHTABLEDEF
		{
		  /*! Default number of buckets */
		  DEFAULTSIZE                                 = 256
		};


	protected:

		/*! Hash table */
		HashTableNodeVec                             *m_pvkTable;

		/*! Number of rows in table */
		int                                           m_iSize;

		/*! Number of objects */
		unsigned int                                  m_uiElements;


		/**
		* Helper method to lookup a node
		* \param rstrKey                              Key name
		* \param iIndex                               Precalculated hash index
		* \return                                     Node associated with key
		*/
		inline HashTableNodeType                     *LookupNode( const HashString &rstrKey, int iIndex = 0 );

		
	public:

		/**
		* Allocate and initialize hash table with the specified number of buckets
		* \param iSize                                Initial size of table
		*/
		                                              HashTable( int iSize = DEFAULTSIZE );

		/**
		* Deallocate memory. This <b>will not</b> deallocate the objects stored in the hash table,
		* to do so you must use GetAllNodeData and deallocate the objects yourself.
		*/
		virtual                                      ~HashTable();


		/**
		* Insert key value into hash table. The data will replace any data with the
		* same key previously stored in the table. The old data pointer is returned
		* by this method, it is <b>not</b> deallocated by the hash table.
		* \param rstrKey                              Key name
		* \param pkData                               Data pointer
		* \return                                     Ptr to old data for key if any, 0 if new key
		*/
		HashTableType                                *Insert( const HashString &rstrKey, HashTableType *pkData );

		/**
		* Find data for key
		* \param rstrKey                              Key name
		* \return                                     Data ptr if key found, 0 if not found
		*/
		HashTableType                                *Find( const HashString &rstrKey );

		/**
		* Remove key from hash table. The data for the key is returned
		* by this method, it is <b>not</b> deallocated by the hash table, you must
		* do this manually if needed.
		* \param rstrKey                              Key name
		* \param pkData                               If not null, delete only if pointer for key match pData
		* \return                                     Data ptr associated with key if key in table, 0 if not
		*/
		HashTableType                                *Delete( const HashString &rstrKey, HashTableType *pkData = 0 );

		/**
		* Get pointers to all hash table nodes. You must not deallocate the nodes, or
		* the hash table will cause unpredictable crashes. Deallocating the data
		* pointers in the nodes is perfectly alright, as long as you do not try to
		* use these pointers later (naturally).
		* \param pvpkVector                           Vector recieving all nodes
		*/
		void                                          GetAllNodes( std::vector< HashTableNode< HashTableType >* > *pvpkVector );

		/**
		* Get all data pointers stored for all keys in the hash table. You can use
		* this method if you need to deallocate the data objects before deleting
		* the hash table.
		* \param pvpkVector                           Vector recieving all node data pointers
		*/
		void                                          GetAllNodeData( std::vector< HashTableType* > *pvpkVector );

		/**
		* Clear hash table. This will <b>not</b> deallocate any data objects stored
		* in the table, to do this you must use GetAllNodeData() method and deallocate
		* the objects manually.
		*/
		void                                          Clear();
};


//Macro for easy typing
#define HashTableExport(classname)

#include "hashtable_inl.h"


};


#endif

