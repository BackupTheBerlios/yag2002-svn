/***************************************************************************
               visitor.h  -  Base classes for visitor objects
                             -------------------
    begin                : Fri 7 July 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, visitor.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEVISITOR_H
#define __NEVISITOR_H


#include "base.h"


/**
  * \file visitor.h
  * Base template classes to define visitors.
  */


namespace NeoEngine
{


/**
  * \brief Strawman visitor class.
  * All visitors have to inherit from this class.
  * This class is intended to add RTTI info to all visitor subclasses and a
  * polymorphically correct destruction sequence. And most important, it
  * allows to use dynamic_cast to solve the identification.
  */
class NEOENGINE_API BaseVisitor
{
	public:

		/**
		*/
		virtual                                             ~BaseVisitor() {}
};





/**
  *  \brief This template is to define concrete visitors for each visitable type.
  */
template < class NodeType > class Visitor : public virtual BaseVisitor
{
	public:

		/**
		* Visitor callback method
		* \param rkVisited                                   Node being visited
		*/
		virtual void                                         Visit( NodeType &rkVisited ) = 0;
};



#if defined( _MSC_VER ) && ( _MSC_VER < 1300 )

// MSVC++ 6 can't cope with a static template member method

template < class NodeType > void AcceptImpl( NodeType &rkVisited, BaseVisitor &rkVisitor )
{
	if( Visitor< NodeType > *pkVisitorImpl = dynamic_cast< Visitor< NodeType >* >( &rkVisitor ) )
		pkVisitorImpl->Visit( rkVisited );
}

#endif




/**
  * \brief Base class for the visitable objects
  * This class should be inherited by the base class in an hierarchy of visitable classes
  */
class NEOENGINE_API BaseVisitable
{
	protected:

#if !defined( _MSC_VER ) || ( _MSC_VER >= 1300 )

	 	/**
		* Accept visitors if implementation available
		* \param rkVisited                                   Node being visited
		* \param rkVisitor                                   Visitor
		*/
		template < class NodeType > static void              AcceptImpl( NodeType &rkVisited, BaseVisitor &rkVisitor )
		{
			if( Visitor< NodeType > *pkVisitorImpl = dynamic_cast< Visitor< NodeType >* >( &rkVisitor ) )
				pkVisitorImpl->Visit( rkVisited );
		}

#endif

	public:

		/**
		*/
		virtual                                             ~BaseVisitable() {}

		/**
		* Accept a visitor
		* \param rkVisitor                                   Visitor
		*/
		virtual void                                         Accept( BaseVisitor &rkVisitor ) = 0;
};


}; // namespace NeoEngine


// This define only simplifies the visitable classes
#if defined( _MSC_VER ) && ( _MSC_VER < 1300 )
#  define DefineVisitable() inline virtual void Accept( NeoEngine::BaseVisitor &rkVisitor ) { NeoEngine::AcceptImpl( *this, rkVisitor ); }
#else
#  define DefineVisitable() inline virtual void Accept( NeoEngine::BaseVisitor &rkVisitor ) { AcceptImpl( *this, rkVisitor ); }
#endif

#endif // __NEVISITOR_H
