/***************************************************************************
        terrainmaterial.h  -  Classes for terrain material generation
                             -------------------
    begin                : Mon Mar 22 2004
    copyright            : (C) 2003-2004 by Cody Russell
    email                : cody `at' jhu.edu
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, terrain.h

 The Initial Developer of the Original Code is Cody Russell.
 Portions created by Cody Russell are Copyright (C) 2003-2004
 Cody Russell. All Rights Reserved.

 ***************************************************************************/

#ifndef __NETERRAINMATERIAL_H
#define __NETERRAINMATERIAL_H


#include "material.h"
#include "shader.h"
#include "vertexbuffer.h"

namespace NeoEngine
{


class TerrainHeightmap;
class TerrainPage;


/**
  * \brief Terrain material factory base class
  * This is the interface class used by terrain for generating materials.  Applications
  * that need specialized terrain materials should subclass this object and overload
  * GenerateMaterial() and SetTexCoords() to provide custom materials.  Terrain systems
  * will call those methods while initializing the terrain.
  * \author Cody Russell (cody jhu edu)
  */
class NEOENGINE_API TerrainMaterialFactory
{
	public:

		MaterialPtr                                    m_pkMaterial;

	public:

		                                               TerrainMaterialFactory();

		                                               TerrainMaterialFactory( MaterialPtr &pkMaterial );

		virtual                                       ~TerrainMaterialFactory();

		virtual void                                   GenerateMaterial( TerrainPage *pkPage ) = 0;

		virtual void                                   SetTexCoords( VertexBufferPtr pkVertices, TerrainPage *pkPage );
};


class NEOENGINE_API Terrain1TextureFactory : public TerrainMaterialFactory
{
	protected:

		/*! Filename for our texture */
		std::string                                    m_strFilename;

	public:

		                                               Terrain1TextureFactory( MaterialPtr &pkMaterial );

		virtual                                       ~Terrain1TextureFactory() { }

		virtual void                                   GenerateMaterial( TerrainPage *pkPage );

		void                                           SetTexture( const std::string &rstrFilename );
};


class NEOENGINE_API TerrainTextureComponent
{
        protected:

		float m_fMin;
		float m_fOptimal;
		float m_fMax;

        public:

		void                                       Set( float fMin, float fOpt, float fMax );

		unsigned char                              CalculateBlendFactor( float f, TerrainHeightmap *pkHeightap );
};


class NEOENGINE_API TerrainBlendMaterialFactory : public TerrainMaterialFactory
{
	public:

		enum RANGECOMPONENT
		{
			LOWER  = 0,
			MIDDLE = 1,
			UPPER  = 2
		};

	protected:

		TerrainTextureComponent                         m_akRanges[3];

		/*! Filenames for three textures */
		std::string                                     m_strFile1;
		std::string                                     m_strFile2;
		std::string                                     m_strFile3;
		std::string                                     m_strLightmap;
		std::string                                     m_strBlendmap;

		bool                                            m_bCalculateBlendmap;

		bool                                            m_bUseLightmap;

	public:

		                                               TerrainBlendMaterialFactory( MaterialPtr &pkMaterial );

		virtual                                       ~TerrainBlendMaterialFactory() {}

		TexturePtr                                     CalculateBlendmap( TerrainPage *pkPage, int iSize );

		void                                           CalculateBlendmapVertex( TerrainPage *pkPage );
	
		void                                           SetTextures( const std::string &rstrFile1, const std::string &rstrFile2, const std::string &rstrFile3 );

		void                                           SetBlendmap( const std::string &rstrFile );

		void                                           SetLightmap( const std::string &rstrFile );

		virtual void                                   GenerateMaterial( TerrainPage *pkPage );
};


};      // namespace NeoEngine


#endif  // __NETERRAINMATERIAL_H
