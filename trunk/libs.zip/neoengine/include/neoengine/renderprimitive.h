/***************************************************************************
              renderprimitive.h  -  Render primitive batch data
                             -------------------
    begin                : Mon Sep 16 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, renderprimitive.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NERENDERPRIMITIVE_H
#define __NERENDERPRIMITIVE_H


#include "base.h"
#include "nemath.h"
#include "material.h"
#include "vertexbuffer.h"
#include "polygonbuffer.h"


/**
* \file renderprimitive.h
* Render primitive batch data
*/

namespace NeoEngine
{


/**
  * \struct RenderPrimitive
  * \brief Render batch data
  * Data for a single render operation
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API RenderPrimitive
{
	public:

		/**
		* \enum RENDERPRIMITIVETYPE
		* \brief Supported primitive types
		*/
		enum RENDERPRIMITIVETYPE
		{
		  INVALID                                     = 0x00,
			
		  LINES                                       = 0x02,
		  TRIANGLES                                   = 0x03,   //Will NOT use triangle strip if present in polygon buffer
		  LINESTRIP                                   = 0x04,
		  TRIANGLESTRIP                               = 0x05,   //Will NOT use triangle strip if present in polygon buffer, must use render primitive member ptr variable
		  //TRIANGLEFAN                               = 0x06,   //NOT IMPLEMENTED
		  POINTS                                      = 0x07
		};

		/**
		* \enum RENDERPRIMITIVEFLAG
		* \brief Flags for rendering op
		*/
		enum RENDERPRIMITIVEFLAG
		{
		  NOFLAGS                                     = 0x0000,
		  
		  /*! Do not use camera or model translation, only rotation (useful for sky rendering) */
		  NOTRANSLATION                               = 0x0002 
		};


	public:

		/*! Render primitive type */
		RENDERPRIMITIVETYPE                           m_ePrimitive;

		/*! Model matrix for this render operation */
		Matrix                                        m_kModelMatrix;

		/*! Inverse model matrix for this render operation */
		Matrix                                        m_kInvModelMatrix;

		/*! Vertex data */
		VertexBufferPtr                               m_pkVertexBuffer;

		/*! Polygon data */
		PolygonBufferPtr                              m_pkPolygonBuffer;

		/*! Polygon strip data */
		PolygonStripBufferPtr                         m_pkPolygonStripBuffer;

		/*! Number of primitives to render */
		unsigned int                                  m_uiNumPrimitives;

		/*! Material to use when rendering this operation */
		MaterialPtr                                   m_pkMaterial;

		/*! Line and point width/size */
		float                                         m_fSize;

		/*! Pass to render, used internally by render device */
		unsigned int                                  m_uiPass;

		/*! Unknown data, used internally by render device or future interface changes */
		union
		{
		  void                                       *m_pData;
		  int                                         m_iData;
		  float                                       m_fData;
		} m_aUnknown[6];
};


};


#endif
