/***************************************************************************
     texmatrixgen.h  -  Texture coordinate transform matrix generators
                             -------------------
    begin                : Tue Feb 11 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, texmatrixgen.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NETEXMATRIXGEN_H
#define __NETEXMATRIXGEN_H


/**
  * \file neoengine/texmatrixgen.h
  * Texture coordinate transform matrix generators
  */


#include "base.h"

#include <string>


namespace NeoEngine
{


// External classes
class Matrix;


/**
  * \brief Generator for texture coordinate effects in texture layers
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API TextureMatrixGen
{
	public:

		/**
		* \brief Definitions for texcoord modification functions lookup tables
		*/
		enum TEXMODFUNCTABLEDEF
		{
		  /*! Size of lookup-table */
		  TEXMODFUNCTABLE_SIZE                   = 1024,

		  /*! Mask for clamping to table size */
		  TEXMODFUNCTABLE_MASK                   = ( TEXMODFUNCTABLE_SIZE - 1 )
		};

		/*! Lookup table for sin function */
		static float                             s_afSinTable[ TEXMODFUNCTABLE_SIZE ];

		/*! Lookup table for square function */
		static float                             s_afSquareTable[ TEXMODFUNCTABLE_SIZE ];

		/*! Lookup table for triangle function */
		static float                             s_afTriangleTable[ TEXMODFUNCTABLE_SIZE ];

		/*! Lookup table for sawtooth function */
		static float                             s_afSawToothTable[ TEXMODFUNCTABLE_SIZE ];

		/*! Lookup table for inverse sawtooth function */
		static float                             s_afInverseSawToothTable[ TEXMODFUNCTABLE_SIZE ];


		/**
		* Generate texture transform matrix. The matrix already contains data,
		* this generator should transform the current matrix with own data.
		* \param pkMatrix                       Matrix receiving data
		*/
		virtual void                            GenerateMatrix( Matrix *pkMatrix ) = 0;

		/**
		* Duplicate object
		* \return                               New object that is copy of this
		*/
		virtual TextureMatrixGen               *Duplicate() = 0;
};


/**
  * \brief Generator for scrolling texture coordinate effects in texture layers
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API TextureMatrixGenScroll : public TextureMatrixGen
{
	public:

		/*! Scroll speed in UV directions */
		float                                   m_afScrollSpeed[2];


		/**
		* Generate texture transform matrix
		* \param pkMatrix                       Matrix receiving data
		*/
		virtual void                            GenerateMatrix( Matrix *pkMatrix );

		/**
		* Duplicate object
		* \return                               New object that is copy of this
		*/
		virtual TextureMatrixGen               *Duplicate();
};


/**
  * \brief Generator for scaling texture coordinate effects in texture layers
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API TextureMatrixGenScale : public TextureMatrixGen
{
	public:

		/*! Scaling in UV directions */
		float                                   m_afScale[2];


		/**
		* Generate texture transform matrix
		* \param pkMatrix                       Matrix receiving data
		*/
		virtual void                            GenerateMatrix( Matrix *pkMatrix );

		/**
		* Duplicate object
		* \return                               New object that is copy of this
		*/
		virtual TextureMatrixGen               *Duplicate();
};


/**
  * \brief Generator for stretching texture coordinate effects in texture layers
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API TextureMatrixGenStretch : public TextureMatrixGen
{
	public:

		/*! Function lookup table */
		float                                  *m_pfTable;

		/*! Base */
		float                                   m_fBase;

		/*! Amplitude */
		float                                   m_fAmplitude;

		/*! Phase */
		float                                   m_fPhase;

		/*! Frequency */
		float                                   m_fFrequency;


		/**
		* Generate texture transform matrix
		* \param pkMatrix                       Matrix receiving data
		*/
		virtual void                            GenerateMatrix( Matrix *pkMatrix );

		/**
		* Duplicate object
		* \return                               New object that is copy of this
		*/
		virtual TextureMatrixGen               *Duplicate();
};


/**
  * \brief Generator for turbulence texture coordinate effects in texture layers
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API TextureMatrixGenTurbulence : public TextureMatrixGen
{
	public:

		/*! Base */
		float                                   m_fBase;

		/*! Amplitude */
		float                                   m_fAmplitude;

		/*! Phase */
		float                                   m_fPhase;

		/*! Frequency */
		float                                   m_fFrequency;


		/**
		* Generate texture transform matrix
		* \param pkMatrix                       Matrix receiving data
		*/
		virtual void                            GenerateMatrix( Matrix *pkMatrix );

		/**
		* Duplicate object
		* \return                               New object that is copy of this
		*/
		virtual TextureMatrixGen               *Duplicate();
};


/**
  * \brief Generator for general transform texture coordinate effects in texture layers
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API TextureMatrixGenTransform : public TextureMatrixGen
{
	public:

		/*! A 2x2 UV rotation matrix */
		float                                   m_aafRotate[2][2];

		/*! Translation in UV direction */
		float                                   m_afTranslate[2];

		/**
		* Generate texture transform matrix
		* \param pkMatrix                       Matrix receiving data
		*/
		virtual void                            GenerateMatrix( Matrix *pkMatrix );

		/**
		* Duplicate object
		* \return                               New object that is copy of this
		*/
		virtual TextureMatrixGen               *Duplicate();
};


/**
  * \brief Generator for rotation texture coordinate effects in texture layers
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API TextureMatrixGenRotate : public TextureMatrixGen
{
	public:

		/*! Rotation speed */
		float                                   m_fRotateSpeed;

		/**
		* Generate texture transform matrix
		* \param pkMatrix                       Matrix receiving data
		*/
		virtual void                            GenerateMatrix( Matrix *pkMatrix );

		/**
		* Duplicate object
		* \return                               New object that is copy of this
		*/
		virtual TextureMatrixGen               *Duplicate();
};


/**
  * \brief Create texture generator objects from name
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API TextureMatrixGenFactory
{
	public:

		/**
		* \param rstrName                       Texture coord generator object name
		* \return                               new TextureMatrixGen object
		*/
		static TextureMatrixGen                *CreateTextureMatrixGen( const std::string &rstrName );
};


};


#endif


