/***************************************************************************
             pointer_inl.h  -  Reference counting and smart pointers
                             -------------------
    begin                : Thu Oct 23 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, pointer_inl.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


inline RefCounter::RefCounter() :
	m_iRefCount( 0 )
{
}


inline RefCounter::~RefCounter()
{
}


inline void RefCounter::IncRef()
{
	++m_iRefCount;
}


inline void RefCounter::DecRef()
{
	if( !--m_iRefCount )
		delete this;
}


inline int RefCounter::GetRefCount() const
{
	return m_iRefCount;
}





template < class T > inline Pointer< T >::Pointer( T *pkObject ) :
	m_pkObject( pkObject )
{
	if( m_pkObject )
		m_pkObject->IncRef();
}


template < class T > inline Pointer< T >::Pointer( const Pointer< T > &rkPointer ) :
	m_pkObject( rkPointer.m_pkObject )
{
	if( m_pkObject )
		m_pkObject->IncRef();
}


template < class T > inline Pointer< T >::~Pointer()
{
	if( m_pkObject )
		m_pkObject->DecRef(), m_pkObject = 0;
}


template < class T > inline Pointer< T >::operator const bool () const
{
	return( m_pkObject != 0 );
}


template < class T > inline Pointer< T >::operator T* ()
{
	return m_pkObject;
}


template < class T > inline Pointer< T >::operator const T* () const
{
	return m_pkObject;
}


template < class T > inline T &Pointer< T >::operator * ()
{
	assert( m_pkObject );
	return *m_pkObject;
}


template < class T > inline const T &Pointer< T >::operator * () const
{
	assert( m_pkObject );
	return *m_pkObject;
}

template < class T > inline T *Pointer< T >::operator -> ()
{
	return m_pkObject;
}


template < class T > inline const T *Pointer< T >::operator -> () const
{
	return m_pkObject;
}


template < class T > inline bool Pointer< T >::operator !() const
{
	return( m_pkObject == 0 );
}


template < class T > inline Pointer< T > &Pointer< T >::operator = ( const Pointer< T > &rkPointer )
{
	T *pkOldObject = m_pkObject;

	m_pkObject = rkPointer.m_pkObject;

	if( m_pkObject  )
		m_pkObject->IncRef();
	
	if( pkOldObject )
		pkOldObject->DecRef();

	return( *this );
}


template < class T > inline Pointer< T > &Pointer< T >::operator = ( T *pkObject )
{
	T *pkOldObject = m_pkObject;

	m_pkObject = pkObject;

	if( m_pkObject )
		m_pkObject->IncRef();

	if( pkOldObject )
		pkOldObject->DecRef();

	return( *this );
}


template < class T > inline bool Pointer< T >::operator == ( const T *pkObject ) const
{
	return( m_pkObject == pkObject );
}


template < class T > inline bool Pointer< T >::operator != ( const T *pkObject ) const
{
	return( m_pkObject != pkObject );
}


template < class T > inline bool Pointer< T >::operator < ( const T *pkObject ) const
{
	return( m_pkObject < pkObject );
}


template < class T > inline bool Pointer< T >::operator == ( const Pointer< T > &rkPointer ) const
{
	return( m_pkObject == rkPointer.m_pkObject );
}


template < class T > inline bool Pointer< T >::operator != ( const Pointer< T > &rkPointer ) const
{
	return( m_pkObject != rkPointer.m_pkObject );
}


template < class T > inline bool Pointer< T >::operator < ( const Pointer< T > &rkPointer ) const
{
	return( m_pkObject < rkPointer.m_pkObject );
}

