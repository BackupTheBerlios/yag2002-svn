/***************************************************************************
                  nemath.h  -  Core math routines and classes
                             -------------------
    begin                : Tue Oct 30 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, nemath.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEMATH_H
#define __NEMATH_H


/**
* \file nemath.h
* Base math objects (vector, quaternion, matrix) with useful operators and methods
*/


#include "base.h"
#include "util.h"

#include <math.h>
#include <assert.h>

#include "logstream.h"


namespace NeoEngine
{


/*! Value of sqrt(3) */
extern const NEOENGINE_API float SQRT_3;

/*! Value of 0.5 * sqrt(3) */
extern const NEOENGINE_API float HALF_SQRT_3;

/*! Value of pi */
extern const NEOENGINE_API float PI;

/*! Value of 2.0 * pi */
extern const NEOENGINE_API float TWO_PI;

/*! Value of 0.5 * pi */
extern const NEOENGINE_API float HALF_PI;

/*! Float comparison threshold ( two float values fOne and fTwo are considered equal if fabsf( fOne - fTwo ) < EPSILON ) */
extern const NEOENGINE_API float EPSILON;

/*! Float comparison threshold for squares */
extern const NEOENGINE_API float SQREPSILON;

/**
  * \param a       First value
  * \param b       Second value
  * \return        Min of a and b
  */
template <class T> inline const T                &MIN( const T &a, const T &b ) { return( ( a < b ) ? a : b ); }

/**
  * \param a       First value
  * \param b       Second value
  * \return        Max of a and b
  */
template <class T> inline const T                &MAX( const T &a, const T &b ) { return( ( a > b ) ? a : b ); }

/**
  * \param a       First value
  * \param b       Second value
  * \param c       Third value
  * \return        Min of a, b and c
  */
template <class T> inline const T                &MIN3( const T &a, const T &b, const T &c ) { return( ( a < b ) ? ( ( a < c ) ? a : c ) : ( ( b < c ) ? b : c ) ); }

/**
  * \param a       First value
  * \param b       Second value
  * \param c       Third value
  * \return        Max of a, b and c
  */
template <class T> inline const T                &MAX3( const T &a, const T &b, const T &c ) { return( ( a > b ) ? ( ( a > c ) ? a : c ) : ( ( b > c ) ? b : c ) ); }

/**
  * \param a       First value
  * \param b       Second value
  * \param min     Receives min value
  * \param max     Receives max value
  */
template <class T> inline void                    MINMAX( const T &a, const T &b, T &min, T &max ) { if( a < b ) { min = a; max = b; } else { min = b; max = a; } }

/**
  * \param a       First value
  * \param b       Second value
  * \param c       Third value
  * \param min     Receives min value
  * \param max     Receives max value
  */
template <class T> inline void                    MINMAX3( const T &a, const T &b, const T &c, T &min, T &max ) { min = MIN3( a, b, c ); max = MAX3( a, b, c ); }

/**
  * Clamp value
  * \param val     Value
  * \param min     Min limit
  * \param max     Max limit
  * \return        Min if (val<min), max if (val>max), otherwise val
  */
template <class T> inline const T                 CLAMP( const T &val, const T &min, const T &max ) { if( val <= min ) return min; else if( val >= max ) return max; return val; }

/**
  * Convert from degrees to radians
  * \param fA      Angle in degrees
  * \return        Angle in radians
  */
inline float NEOENGINE_API                        DEGTORAD( float fA ) { return fA * 0.017453292519943295769236907684886f; }

/**
  * Round float to nearest int
  * Warning: x86 assembly, non-x86 just casts (truncates)
  * \param fNum           Value
  * \return               Closest int
  */
inline int NEOENGINE_API                          RoundFloat( float fNum );

/**
  * Drop float to next lowest int (use this instead of float->int casts)
  * Warning: Not implemented, just casts.
  * \param fNum           Value
  * \return               Next lowest int
  */
inline int NEOENGINE_API                          TruncFloat( float fNum );

/**
  * Calculate inverse square root of value
  * \param fN             Value
  * \return               Inverse squre root of value, 1/sqrt(fN)
  */
inline float NEOENGINE_API                        FastInvSqrt( float fN );


//forward declarations
class Matrix;
class Quaternion;
class ODE;



/**
  * \brief 3D vector
  * Simple 3D vector class with useful math operations
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Vector3d
{
	public:

		/*! Components */
		float                                         x, y, z;

		/**
		* Reset components to zero vector
		*/
		inline                                        Vector3d();

		/**
		* Set components
		* \param fX                                   x component
		* \param fY                                   y component
		* \param fZ                                   z component
		*/
		inline                                        Vector3d( float fX, float fY, float fZ );

		/**
		* Set components
		* \param afComponents                         Array of floats to copy components from [x,y,z]
		*/
		inline                                        Vector3d( float afComponents[] );

		/**
		* Set compontents
		* \param fX                                   x component
		* \param fY                                   y component
		* \param fZ                                   z component
		* \return                                     Resulting Vector3d ref (this)
		*/
		inline Vector3d                              &Set( float fX, float fY, float fZ );

		/**
		* Set compontents
		* \param afComponents                         Array of floats to copy components from [x,y,z]
		* \return                                     Resulting Vector3d ref (this)
		*/
		inline Vector3d                              &Set( float afComponents[] );

		/**
		* Reset components to zero vector
		* \return                                     Resulting Vector3d ref (this)
		*/
		inline Vector3d                              &Reset();

		/**
		* Calculate length of vector
		* \return                                     vector length
		*/
		inline float                                  Len() const;

		/**
		* Calculate squared length of vector
		* \return                                     squared vector length
		*/
		inline float                                  Len2() const;

		/**
		* Normalize vector
		* \return                                     Normalized vector
		*/
		inline Vector3d                              &Normalize();

		/**
		* Scale to length
		* \param fLen                                 New length
		* \return                                     Scaled vector
		*/
		inline Vector3d                              &ScaleTo( float fLen );


		/******* operators *******/

		/**
		* Compare vectors with epsilon tolerance
		* \param rkVector                             Vector ref object to compare this to
		* \return                                     true if all components equal (in tolerance zone), false otherwise
		*/
		inline bool                                   operator ==( const Vector3d &rkVector ) const;

		/**
		* Compare vectors with epsilon tolerance
		* \param rkVector                             Vector3d ref object to compare this to
		* \return                                     false if all components equal (in tolerance zone), true otherwise
		*/
		inline bool                                   operator !=( const Vector3d &rkVector ) const;

		/**
		* Dot product
		* \param rkVector                             Vector ref object to multiply with
		* \return                                     Dot product (scalar = x*x + y*y + z*z)
		*/
		inline float                                  operator *( const Vector3d &rkVector ) const;

		/**
		* Cross product
		* \param rkVector                             Vector ref object to cross product with
		* \return                                     resulting vector (result = this X rkVector) (right-hand system)
		*/
		inline Vector3d                               operator %( const Vector3d &rkVector ) const;

		/**
		* Cross product and assignment
		* \param rkVector                             Vector ref object to cross product with, this = this X rkVector
		* \return                                     Resulting Vector3d ref (this)
		*/
		inline Vector3d                              &operator %=( const Vector3d &rkVector );

		/**
		* Scalar product
		* \param fScalar                              Scalar value to multiply this with
		* \return                                     Resulting scaled vector, result( x*fScalar, y*fScalar, z*fScalar)
		*/
		inline Vector3d                               operator *( float fScalar ) const;

		/**
		* Scalar product and assignment
		* \param fScalar                              Scalar value to multiply this with -> this( x*fScalar, y*fScalar, z*fScalar)
		* \return                                     Resulting Vector3d ref (this)
		*/
		inline Vector3d                              &operator *=( float fScalar );

		/**
		* Addition
		* \param rkVector                             Vector to add
		* \return                                     Resulting vector, result = this + rkVector
		*/
		inline Vector3d                               operator +( const Vector3d &rkVector ) const;

		/**
		* Addition and assignment
		* \param rkVector                             Vector to add
		* \return                                     Resulting Vector3d ref (this)
		*/
		inline Vector3d                              &operator +=( const Vector3d &rkVector );

		/**
		* Subtraction
		* \param rkVector                             Vector to subtract
		* \return                                     Resulting vector, result = this - rkVector
		*/
		inline Vector3d                               operator -( const Vector3d &rkVector ) const;

		/**
		* Subtraction and assignment
		* \param rkVector                             Vector to subtract
		* \return                                     Resulting Vector3d ref (this)
		*/
		inline Vector3d                              &operator -=( const Vector3d &rkVector );

		/**
		* Negation
		* \return                                     Negated vector
		*/
		inline Vector3d                               operator -() const;

		/**
		* Array access
		* \param iComponent                           Component to access
		*/
		inline float                                 &operator []( int iComponent );

		/**
		* Array access
		* \param iComponent                           Component to access
		*/
		inline const float                           &operator []( int iComponent ) const;

		/**
		* Dummy operator for Win32 template instantiation
		* \param rkVector                             Vector ref object to compare this to
		* \return                                     false
		*/
		inline bool                                   operator < ( const Vector3d &rkVector ) const { return false; }

		/*! Null vector (0,0,0) */
		static const NE_STATIC Vector3d               ZERO;
		/*! Null vector (0,0,0) */
		static const NE_STATIC Vector3d               ORIGO;
		/*! Axes vectors (1,0,0) (0,1,0) (0,0,1) */
		static const NE_STATIC Vector3d               AXES[3];
};


/**
  * Output vector to stream
  * \param rkStream                                   Stream
  * \param rkVector                                   Vector
  * \return                                           Stream
  */
NEOENGINE_API std::ostream &operator<<( std::ostream &rkStream, const Vector3d &rkVector );


#define GETEULERORDER( i, p, r, f ) ( ( ( ( ( ( i << 1 ) + p ) << 1 ) + r ) << 1 ) + f )


/**
  * \brief Euler angles and order
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API EulerAngles
{
	public:


		enum EULERDEFS
		{
		  X                                           = 0,
		  Y                                           = 1,
		  Z                                           = 2,

		  STATICFRAME                                 = 0,
		  ROTATEFRAME                                 = 1,

		  NOREPEAT                                    = 0,
		  REPEAT                                      = 1,

		  EVEN                                        = 0,
		  ODD                                         = 1,
		};


		enum ORDER
		{
		  XYZs                                        = GETEULERORDER( X, EVEN, NOREPEAT, STATICFRAME ),
		  XYXs                                        = GETEULERORDER( X, EVEN, REPEAT,   STATICFRAME ),
		  XZYs                                        = GETEULERORDER( X, ODD,  NOREPEAT, STATICFRAME ),
		  XZXs                                        = GETEULERORDER( X, ODD,  REPEAT,   STATICFRAME ),
		  YZXs                                        = GETEULERORDER( Y, EVEN, NOREPEAT, STATICFRAME ),
		  YZYs                                        = GETEULERORDER( Y, EVEN, REPEAT,   STATICFRAME ),
		  YXZs                                        = GETEULERORDER( Y, ODD,  NOREPEAT, STATICFRAME ),
		  YXYs                                        = GETEULERORDER( Y, ODD,  REPEAT,   STATICFRAME ),
		  ZXYs                                        = GETEULERORDER( Z, EVEN, NOREPEAT, STATICFRAME ),
		  ZXZs                                        = GETEULERORDER( Z, EVEN, REPEAT,   STATICFRAME ),
		  ZYXs                                        = GETEULERORDER( Z, ODD,  NOREPEAT, STATICFRAME ),
		  ZYZs                                        = GETEULERORDER( Z, ODD,  REPEAT,   STATICFRAME ),

		  ZYXr                                        = GETEULERORDER( X, EVEN, NOREPEAT, ROTATEFRAME ),
		  XYXr                                        = GETEULERORDER( X, EVEN, REPEAT,   ROTATEFRAME ),
		  YZXr                                        = GETEULERORDER( X, ODD,  NOREPEAT, ROTATEFRAME ),
		  XZXr                                        = GETEULERORDER( X, ODD,  REPEAT,   ROTATEFRAME ),
		  XZYr                                        = GETEULERORDER( Y, EVEN, NOREPEAT, ROTATEFRAME ),
		  YZYr                                        = GETEULERORDER( Y, EVEN, REPEAT,   ROTATEFRAME ),
		  ZXYr                                        = GETEULERORDER( Y, ODD,  NOREPEAT, ROTATEFRAME ),
		  YXYr                                        = GETEULERORDER( Y, ODD,  REPEAT,   ROTATEFRAME ),
		  YXZr                                        = GETEULERORDER( Z, EVEN, NOREPEAT, ROTATEFRAME ),
		  ZXZr                                        = GETEULERORDER( Z, EVEN, REPEAT,   ROTATEFRAME ),
		  XYZr                                        = GETEULERORDER( Z, ODD,  NOREPEAT, ROTATEFRAME ),
		  ZYZr                                        = GETEULERORDER( Z, ODD,  REPEAT,   ROTATEFRAME )
		};


		/*! Angles for each axis */
		Vector3d                                      m_kAngle;

		/*! Order */
		unsigned int                                  m_uiOrder;

		/**
		* \param rkAngle                              Rotation around each axis
		* \param uiOrder                              Order rotations are applied
		*/
		                                              EulerAngles( const Vector3d &rkAngle, unsigned int uiOrder = XYZs ) : m_kAngle( rkAngle ), m_uiOrder( uiOrder ) {}

		/**
		* \param fRot0                                Rotation around first axis
		* \param fRot1                                Rotation around second axis
		* \param fRot2                                Rotation around third axis
		* \param uiOrder                              Order rotations are applied
		*/
		                                              EulerAngles( float fRot0, float fRot1, float fRot2, unsigned int uiOrder = XYZs ) : m_kAngle( fRot0, fRot1, fRot2 ), m_uiOrder( uiOrder ) {}
};


/**
  * \brief Rotation expressed as axis-angle
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class AxisAngle
{
	public:

		/*! Axis of rotation */
		Vector3d                                      m_kAxis;

		/*! Angle */
		float                                         m_fAngle;

		/**
		* \param rkAxis                               Axis of rotation
		* \param fAngle                               Angle
		*/
		                                              AxisAngle( const Vector3d &rkAxis, float fAngle ) : m_kAxis( rkAxis ), m_fAngle( fAngle ) {}
};


/**
  * \brief Unit quaternion
  * Simple unit quaternion class with useful math operations
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Quaternion
{
	public:


		/*! Components */
		float                                         qx, qy, qz, qw;


		/**
		* Reset components to identity quat
		*/
		inline                                        Quaternion();

		/**
		* Set components
		* \param fX                                   x component
		* \param fY                                   y component
		* \param fZ                                   z component
		* \param fW                                   w component
		*/
		inline                                        Quaternion( float fX, float fY, float fZ, float fW );

		/**
		* Assignment from matrix (PERFORMANCE WARNING)
		* \param rkMatrix                             Matrix to convert to quaternion
		*/
		inline                                        Quaternion( const Matrix &rkMatrix );

		/**
		* Assignment from axis-angle rotation
		* \param rkAxisAngle                          Axis and rotation
		*/
		inline                                        Quaternion( const AxisAngle &rkAxisAngle );

		/**
		* Assignment from Euler angles
		* \param rkAngles                             Rotation in Euler angles
		*/
		inline                                        Quaternion( const EulerAngles &rkAngles );

		/**
		* Reset components to identity quat
		* \return                                     const Quaternion ref (this)
		*/
		inline Quaternion                            &Reset();

		/**
		* Set components
		* \param fX                                   x component
		* \param fY                                   y component
		* \param fZ                                   z component
		* \param fW                                   w component
		* \return                                     const Quaternion ref (this)
		*/
		inline Quaternion                            &Set( float fX, float fY, float fZ, float fW );

		/**
		* Normalize
		* \return                                     Quaternion ref (this)
		*/
		inline Quaternion                            &Normalize();

		/**
		* Convert to matrix
		* \param pkMatrix                             Matrix
		* \return                                     Matrix
		*/
		inline Matrix                                &ToMatrix( Matrix *pkMatrix ) const;

		/**
		* Convert to axis rotation
		* \return                                     Rotation as axis-angle
		*/
		inline AxisAngle                              ToAxisAngle() const;

		/**
		* Convert to euler angles
		* \param uiOrder                              Requested order of rotation for Euler angles
		* \return                                     Rotation as Euler angles in specified order
		*/
		EulerAngles                                   ToEulerAngles( unsigned int uiOrder = EulerAngles::XYZs ) const;

		/**
		* Inverse quaternion (will change this quat), equal to conjugate
		* \return                                     const Quaternion ref (this)
		*/
		inline Quaternion                            &Inverse();

		/**
		* Spherical linear interpolation
		* \param fT                                   Time (between 0 and 1)
		* \param rkDest                               Destination quaternion
		* \param bActuteAngle                         If not acute angle, negate target quaternion to avoid extra spins
		* \return                                     Resulting interpolated quaternion (this)
		*/
		inline Quaternion                            &Slerp( float fT, const Quaternion &rkDest, bool bActuteAngle = false );



		/******* operators *******/

		/**
		* Assignment from matrix
		* \param rkMatrix                             Matrix to convert to quaternion
		* \return                                     const Quaternion ref (this)
		*/
		inline Quaternion                            &operator =( const Matrix &rkMatrix );

		/**
		* Assignment from axis-angle rotation
		* \param rkAxisAngle                          Axis-angle rotation to convert to quaternion
		* \return                                     const Quaternion ref (this)
		*/
		inline Quaternion                            &operator =( const AxisAngle &rkAxisAngle );

		/**
		* Assignment from euler angles
		* \param rkEulerAngles                        Euler angles to convert to quaternion
		* \return                                     const Quaternion ref (this)
		*/
		Quaternion                                   &operator =( const EulerAngles &rkEulerAngles );

		/**
		* Quaternion multiplication
		* \param rkQuat                               Quaternion ref to multiply this with, result = this * rkQuat
		* \return                                     Quaternion result object
		*/
		inline Quaternion                             operator *( const Quaternion &rkQuat ) const;

		/**
		* Multiplication with scalar (to non-unit quat, Normalize() will ofcourse restore quat)
		* \param fScalar                              Scaling
		* \return                                     Quaternion result
		*/
		inline Quaternion                             operator *( float fScalar ) const;

		/**
		* Quaternion multiplication and assignment
		* \param rkQuat                               Quaternion ref to multiply this with, this = this * rkQuat, result = this
		* \return                                     Quaternion ref (this)
		*/
		inline Quaternion                            &operator *=( const Quaternion &rkQuat );

		/**
		* Multiplication with scalar (to non-unit quat, Normalize() will ofcourse restore quat)
		* \param fScalar                              Scaling
		* \return                                     Quaternion ref (this)
		*/
		inline Quaternion                            &operator *=( float fScalar );

		/**
		* Inverse quaternion (conjugate)
		* \return                                     Quaternion result object
		*/
		inline Quaternion                             operator ~() const;

		/**
		* Multiplication with vector (rotate vector)
		* \param rkVector                             Vector to rotate
		* \return                                     Result vector
		*/
		inline Vector3d                               operator *( const Vector3d &rkVector ) const;

		/**
		* Quaternion addition (to non-unit quat)
		* \param rkQuat                               Quaternion to add
		* \return                                     Quaternion result
		*/
		inline Quaternion                             operator +( const Quaternion &rkQuat ) const;

		/**
		* Compare quaternions with epsilon tolerance
		* \param rkQuat                               Quaternion ref object to compare this to
		* \return                                     true if all components equal (in epsilon zone), false otherwise
		*/
		inline bool                                   operator ==( const Quaternion &rkQuat ) const;

		/**
		* Compare quaternions with epsilon tolerance
		* \param rkQuat                               Quaternion ref object to compare this to
		* \return                                     true if not equal equal, false if all components equal (in epsilon zone)
		*/
		inline bool                                   operator !=( const Quaternion &rkQuat ) const;

		/*! Identity quaternion */
		static const NE_STATIC Quaternion             IDENTITY;
};


/**
  * Output quaternion to stream
  * \param rkStream                                   Stream
  * \param rkQuat                                     Quaternion
  * \return                                           Stream
  */
NEOENGINE_API std::ostream &operator << ( std::ostream &rkStream, const Quaternion &rkQuat );


/**
  * \brief 4x4 matrix
  * Simple 4x4 matrix class with useful math operations
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Matrix
{
    private:
    
        /*! Identity matrix array */
        static const NE_STATIC float                  g_afIdentityMatrix[16];
    

	public:

		/*! Components */
		float                                         m_aafMatrix[4][4];




		/**
		* Reset components to identity matrix
		*/
		inline                                        Matrix();

		/**
		* Set components
		* \param rkMatrix                             Matrix to copy values from
		*/
		inline                                        Matrix( const Matrix &rkMatrix );

		/**
		* Set components
		* \param afComponents                         Array of floats to copy components from
		*/
		inline                                        Matrix( const float afComponents[] );

		/**
		* Build rotation matrix from quaternion
		* \param rkQuat                               Quaternion to convert to matrix
		*/
		inline                                        Matrix( const Quaternion &rkQuat );

		/**
		* Build transformation matrix from rotation and translation
		* \param rkQuat                               Rotation 
		* \param rkTranslation                        Translation
		*/
		inline                                        Matrix( const Quaternion &rkQuat, const Vector3d &rkTranslation );

		/**
		* Create a cross-product matrix M from vector, such that M * a = rkVector x a
		* \param rkVector                             Vector
		*/
		inline                                        Matrix( const Vector3d &rkVector );

		/**
		* Reset components to identity matrix
		* \return                                     Resulting Matrix ref (this)
		*/
		inline Matrix                                &Reset();

		/**
		* Set components
		* \param afComponents                         Array of floats to copy components from
		* \return                                     Resulting Matrix ref (this)
		*/
		inline Matrix                                &Set( float afComponents[] );

		/**
		* Build transformation matrix from rotation and translation
		* \param rkQuat                               Rotation
		* \param rkTranslation                        Translation as vector
		* \return                                     Resulting Matrix ref (this)
		*/
		inline Matrix                                &Set( const Quaternion &rkQuat, const Vector3d &rkTranslation );

		/**
		* Create a cross-product matrix M from vector, such that M * a = rkVector x a
		* \param rkVector                             Vector
		* \return                                     Resulting const Matrix ref (this)
		*/
		inline Matrix                                &Set( const Vector3d &rkVector );

		/**
		* Set rotation part of matrix from quaternion (does not touch translation part)
		* \param rkQuat                               Rotation as quaternion
		* \return                                     Resulting Matrix ref (this)
		*/
		inline Matrix                                &SetRotation( const Quaternion &rkQuat );

		/**
		* Set translation part of matrix from vector (does not touch rotation part)
		* \param rkTranslation                        Translation as vector
		* \return                                     Resulting Matrix ref (this)
		*/
		inline Matrix                                &SetTranslation( const Vector3d &rkTranslation );

		/**
		* Set scaling part of matrix from vector (does not touch translation)
		* \param rkScaling                            Scaling as vector
		* \return                                     Resulting Matrox ref (this)
		*/
		inline Matrix                                &SetScaling( const Vector3d &rkScaling );

		/**
		* Transpose matrix (modifies this matrix!)
		* \return                                     Resulting const Matrix ref (this)
		*/
		inline Matrix                                &Transpose();

		/**
		* Transpose matrix and store in given matrix (does not store in temporary space, DO NOT pass this as argument)
		* \param pkMatrix                             Matrix receiving transpose of this matrix
		* \return                                     Resulting matrix (*pkMatrix)
		*/
		inline Matrix                                &TransposeTo( Matrix *pkMatrix );

		/**
		* Column access
		* \param iColumn                              Column index
		* \return                                     Vector (axis)
		*/
		inline Vector3d                               GetColumn( int iColumn ) const;


		/******* operators *******/

		/**
		* Assignment
		* \param rkMatrix                             Matrix to copy values from
		* \return                                     Resulting Matrix ref (this)
		*/
		inline Matrix                                &operator =( const Matrix &rkMatrix );

		/**
		* Assignment from quaternion, build rotation matrix (resets translations!)
		* \param rkQuat                               Quaternion to convert to matrix
		* \return                                     Resulting Matrix
		*/
		inline Matrix                                &operator =( const Quaternion &rkQuat );

		/**
		* Matrix multiplication
		* \param rkMatrix                             Matrix to multiply with, result = this * rkMatrix
		* \return                                     Result matrix
		*/
		inline Matrix                                 operator *( const Matrix &rkMatrix ) const;

		/**
		* Matrix multiplication and assignment
		* \param rkMatrix                             Matrix to multiply with, this = this * rkMatrix, result = this
		* \return                                     Resulting Matrix ref (this)
		*/
		inline Matrix                                &operator *=( const Matrix &rkMatrix );

		/**
		* Scale matrix by scalar
		* \param fScale                               Scalar value
		* \return                                     Resulting Matrix
		*/
		inline Matrix                                 operator * ( float fScale ) const;

		/**
		* Scale matrix by scalar
		* \param fScale                               Scalar value
		* \return                                     Resulting Matrix ref (this)
		*/
		inline Matrix                                &operator *= ( float fScale );

		/**
		* Matrix subtraction
		* \param rkMatrix                             Matrix to subtract from this
		* \return                                     Resulting Matrix
		*/
		inline Matrix                                 operator - ( const Matrix &rkMatrix ) const;

		/**
		* Matrix subtraction and assignment
		* \param rkMatrix                             Matrix to subtract from this
		* \return                                     Resulting Matrix ref (this)
		*/
		inline Matrix                                &operator -= ( const Matrix &rkMatrix );

		/**
		* Matrix addition
		* \param rkMatrix                             Matrix to add to this
		* \return                                     Resulting Matrix
		*/
		inline Matrix                                 operator + ( const Matrix &rkMatrix ) const;

		/**
		* Matrix addition and assignment
		* \param rkMatrix                             Matrix to add to this
		* \return                                     Resulting Matrix ref (this)
		*/
		inline Matrix                                &operator += ( const Matrix &rkMatrix );

		/**
		* Multiplication with vector (transform vector)
		* \param rkVector                             Vector to transform
		* \return                                     Result vector
		*/
		inline Vector3d                               operator *( const Vector3d &rkVector ) const;

		/**
		* Compare with epsilon tolerance
		* \param rkMatrix                             Matrix to compare with
		* \return                                     true if equal (in epsilon zone), false if not
		*/
		inline bool                                   operator ==( const Matrix &rkMatrix ) const;

		/**
		* Compare with epsilon tolerance
		* \param rkMatrix                             Matrix to compare wtih
		* \return                                     true if not equal, false if equal (in epsilon zone)
		*/
		inline bool                                   operator !=( const Matrix &rkMatrix ) const;

		/**
		* Row access
		* \param iRow                                 Row to access
		* \return                                     float pointer to row
		*/
		inline float                                 *operator []( int iRow );

		/**
		* Conversion to float pointer
		*/
		inline                                        operator float*() { return &m_aafMatrix[0][0]; }

		/**
		* Row access
		* \param iRow                                 Row to access
		* \return                                     float pointer to row
		*/
		inline const float                           *operator []( int iRow ) const;

		/**
		* Conversion to float pointer
		*/
		inline                                        operator const float*() const { return &m_aafMatrix[0][0]; }

		/*! Identity matrix */
		static const NE_STATIC Matrix                 IDENTITY;

		/**
		* Dummy operator for Win32 std::vector DLL exports
		*/
		bool                                          operator < ( const Matrix &rkMatrix ) const { return false; }
};


/**
  * Output matrix to stream
  * \param rkStream                                   Stream
  * \param rkMatrix                                   Matrix
  * \return                                           Stream
  */
NEOENGINE_API std::ostream &operator << ( std::ostream &rkStream, const Matrix &rkMatrix );




/**
  * \brief Base class for ODE calculations
  * Used primarily in physics simulation classes
  * \author Mattias Jansson (mattias@realityrift.com)
  * \todo Add more integrators, for example Runge-Kutta for better accuracy where needed
  */
class NEOENGINE_API ODE
{
	protected:

		/*! State */
		float                         **m_ppfState;

		/*! Derive */
		float                          *m_pfDerive;

		/*! Size of state array */
		int                             m_iStateSize;


	public:

		/**
		*/

		                                ODE();

		/**
		* Deallocate memory
		*/
		virtual                        ~ODE();

		/**
		* Set size of state array
		* \param iStateSize             New size
		*/
		void                            SetStateSize( int iStateSize );

		/**
		* Euler integrator
		* \param fDeltaTime             Deltatime in seconds to integrate
		* \param iSteps                 Subdivision count
		*/
		void                            EulerODE( float fDeltaTime, int iSteps );

		/**
		* Implement in derived class
		*/
		virtual void                    Derive() = 0;

		/**
		* Calculate auxiliary variables. Called after each integrator step
		* \param fStepTime              The deltatime of this step
		*/
		virtual void                    CalcAuxiliary( float fStepTime ) = 0;

		/**
		* Post-integration updates. Called after each integrator finished complete deltatime update
		*/
		virtual void                    PostODE() = 0;
};



// Implementation of inline methods
#include "nemath_inl.h"


}; // namespace NeoEngine


#endif  // __NEMATH_H
