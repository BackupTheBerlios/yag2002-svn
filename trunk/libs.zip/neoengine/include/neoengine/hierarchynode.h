/***************************************************************************
           hierarchynode.h  -  Base classes for hierarchy objects
                             -------------------
    begin                : Sun Jan 26 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, hierarchynode.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEHIERARCHYNODE_H
#define __NEHIERARCHYNODE_H


/**
  * \file hierarchynode.h
  * Base template class for hierarchy nodes
  */



#include "base.h"
#include "node.h"
#include "hashstring.h"
#include "visitor.h"

#include <assert.h>

#include <vector>


namespace NeoEngine
{


/**
  * \brief Base class for node hierarchies
  * A hierarchy node is the building block of a node tree. Derived
  * from the SRT node for basic capabilities, extended with hierarchy
  * data (one parent, mutliple children). World data is cached and
  * updated when needed by overloading SRT node methods and flagging
  * for invalid caches.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
template <class NodeType> class HierarchyNode : public virtual BaseVisitable, public SRTNode
{
	public:

		DefineVisitable()

		/**
		* \enum NODESEARCHMODE
		* \brief Search mode identifiers
		*/
		enum NODESEARCHMODE
		{
		  /*! Search breadth first, i.e all child nodes first before recursing on grandchildren */
		  BREADTH_FIRST,
		  
		  /*! Search depth first, i.e recurse on grandchildren before searching next child node */
		  DEPTH_FIRST
		};



	protected:

		/*! Flag indicating we need to update world relative SRT information */
		bool                                                 m_bWorldUpdate;

		/*! Total scaling relative world (cached) */
		float                                                m_fWorldScaling;

		/*! Total rotation relative world (cached) */
		Quaternion                                           m_kWorldRotation;

		/*! Total translation relative world (cached) */
		Vector3d                                             m_kWorldTranslation;

		/*! Child nodes */
		std::vector< NodeType* >                             m_vpkChildren;

		/*! Parent node */
		NodeType                                            *m_pkParent;

		/*! Name */
		HashString                                           m_strName;

		/*! Total transformation matrix relative world (cached) */
		Matrix                                               m_kWorldTransform;

		/*! Total inverse transformation matrix relative world (cached) */
		Matrix                                               m_kInverseWorldTransform;



		/**
		* Updates cached world-relative SRT data if needed
		* \return                                            true if any world cache data was updated, false if not
		*/
		inline virtual bool                                  UpdateWorld();

		/**
		* Used to get this as correct type
		* \return                                            This node
		*/
		inline virtual NodeType                             *Get();



	public:

		/**
		* Create named, attached node. Will initially have same world position as parent
		* (i.e zero relative rotation and translation, no scaling)
		* \param rstrName                                    Node name
		* \param pkParent                                    Parent node
		*/
		inline                                               HierarchyNode( const HashString &rstrName = "", NodeType *pkParent = 0 );

		/**
		* Create node from reference object (including duplicating child nodes if flag set)
		* \param rkNode                                      Reference node object to copy
		* \param bDuplicateChildren                          Duplicate child nodes if true
		*/
		inline                                               HierarchyNode( NodeType &rkNode, bool bDuplicateChildren );

		/**
		* Deallocates child nodes and detaches from parent
		*/
		virtual                                             ~HierarchyNode();

		/**
		* Set position relative parent node. Will set flag to update world cache data,
		* and optionally recurse and flag child nodes to update data
		* \param rkTranslation                               New translation relative parent node
		* \param bNotifyUpdate                               Set update flag to child tree for world SRT data and parent tree for bounding volume (true default, use false with caution)
		*/
		inline virtual void                                  SetTranslation( const Vector3d &rkTranslation, bool bNotifyUpdate = true );

		/**
		* Set rotation relative parent node. Will set flag to update world cache data,
		* and optionally recurse and flag child nodes to update data
		* \param rkRotation                                  New rotation relative parent node
		* \param bNotifyUpdate                               Set update flag to child tree for world SRT data (true default, use false with caution)
		*/
		inline virtual void                                  SetRotation( const Quaternion &rkRotation, bool bNotifyUpdate = true );

		/**
		* Set uniform scaling relative parent node. Will set flag to update world cache data,
		* and optionally recurse and flag child nodes to update data
		* \param fScaling                                    Uniform scaling factor
		* \param bNotifyUpdate                               Set update flag to child tree for world SRT data (true default, use false with caution)
		*/
		inline virtual void                                  SetScaling( float fScaling, bool bNotifyUpdate = true );

		/**
		* Set name
		* \param rstrName                                    New node name
		*/
		inline void                                          SetName( const HashString &rstrName );

		/**
		* \return                                            Node name
		*/
		inline const HashString                             &GetName() const;

		/**
		* \return                                            Parent node
		*/
		inline NodeType                                     *GetParent();

		/**
		* Attach node. If the node is attached to a parent, detach it first.
		* This will cause the node to get it's world SRT data as local SRT data.
		* If bKeepWorldSRT is set, node will be updated with inverse of this (new parent)
		* node's SRT data, effectively keeping it intact in world space. If flag not
		* set, node will effectivaly get new parent world SRT data added to own (used
		* in initialization phase, for example).
		* \param pkNode                                      Node to attach
		* \param bKeepWorldSRT                               If true, recalculate node relative position to maintain world SRT
		* \return                                            undefined (reserved for future use or derived classes)
		*/
		virtual int                                          AttachNode( NodeType *pkNode, bool bKeepWorldSRT = false );

		/**
		* Detach node. The node will store world SRT data in local SRT data.
		* \param pkNode                                      Node to detach
		* \return                                            undefined (reserved for future use or derived classes)
		*/
		virtual int                                          DetachNode( NodeType *pkNode );

		/**
		* Detach this node from parent, if any. Will store world SRT data (and
		* update first if needed) in local SRT data to remain in same world position
		* and orientation.
		*/
		void                                                 DetachFromParent();

		/**
		* Set world update flag. If flag is set, a call to any of the
		* GetWorldScaling, GetWorldRotation, GetWorldTranslation will
		* cause world cache data to be updated. Optionally recurses on
		* all child nodes (default).
		* \param bRecurse                                    Recurse on children
		*/
		inline virtual void                                  NotifyUpdate( bool bRecurse = true );

		/**
		* Get position relative world coordinate system origo. The world SRT
		* data is the combined hierarchial data of any parent nodes and this node.
		* \return                                            World position
		*/
		inline const Vector3d                               &GetWorldTranslation();

		/**
		* Get rotation relative world unrotated coordinate system. The world SRT
		* data is the combined hierarchial data of any parent nodes and this node.
		* \return                                            World-relative quaternion
		*/
		inline const Quaternion                             &GetWorldRotation();

		/**
		* Get total unform scaling factor relative world scale. The world SRT
		* data is the combined hierarchial data of any parent nodes and this node.
		* \return                                            World scaling factor
		*/
		inline float                                         GetWorldScaling();

		/**
		* Get total transform matrix relative world coordinate system origo. The world SRT
		* data is the combined hierarchial data of any parent nodes and this node.
		* \return                                            World transform matrix
		*/
		inline const Matrix                                 &GetWorldTransform();

		/**
		* Get inverse total transform matrix relative world coordinate system origo. The world SRT
		* data is the combined hierarchial data of any parent nodes and this node.
		* \return                                            Inverse world transform matrix
		*/
		inline const Matrix                                 &GetInverseWorldTransform();

		/**
		* Get all child nodes
		* \return                                            Children node vector
		*/
		inline const std::vector< NodeType* >               &GetChildren();

		/**
		* Search hierarchy for named node, including this node. Will return first node found
		* along selected search mode.
		* \param rstrName                                    Node name to search for
		* \param eMode                                       Search mode (see enum descriptions for details)
		* \param bInitSearch                                 Internal flag
		* \return                                            Ptr to node or null if not found
		*/
		virtual NodeType                                    *GetByName( const HashString &rstrName, NODESEARCHMODE eMode = BREADTH_FIRST, bool bInitSearch = true );

		/**
		* Traverse the hierarchy applying the visitor to the nodes.
		* \param rkVisitor                                   Visitor to apply to each node.
		* \param eMode                                       Search mode (see enum descriptions for details)
		* \param iDirection                                  Direction of traversal (for DEPTH_FIRST, > 0 means top-down, < 0 means bottom up)
		* \param bInitSearch                                 Internal flag
		*/
		virtual void                                         Traverse( BaseVisitor &rkVisitor, NODESEARCHMODE eMode = DEPTH_FIRST, int iDirection = 1, bool bInitSearch = true );

		/**
		* Traverse this nodes
		* \param rkVisitor                                   Visitor
		*/
		inline virtual void                                  TraverseNode( BaseVisitor &rkVisitor );
};



#include "hierarchynode_inl.h"


};


#endif
