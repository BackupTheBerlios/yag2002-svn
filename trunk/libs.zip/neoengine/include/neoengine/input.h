/***************************************************************************
                      input.h  -  Input subsystem classes
                             -------------------
    begin                : Thu Nov 8 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, input.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEINPUT_H
#define __NEINPUT_H


/**
  * \file neoengine/input.h
  * Input processing classes
  */


#include "base.h"
#include "activator.h"
#include "inputentity.h"
#include "module.h"

#include <vector>


#ifdef MB_RIGHT
#	undef MB_RIGHT
#endif


namespace NeoEngine
{


//Forward declarations
class InputGroup;
class InputManager;
class InputDevice;



/**
  * \brief Input event types
  */
enum INPUTEVENT
{
	/*! Invalid */
	IE_NONE       = 0,

	/*! System event, like application close, window resize and other window manager messages */
	IE_SYSEVENT   = 1,

	/*! Key was pressed */
	IE_KEYDOWN    = 10,

	/*! Key was released */
	IE_KEYUP      = 11,

	/*! Mouse has moved */
	IE_MOUSEMOVE  = 20,

	/*! Mouse button pressed */
	IE_MOUSEDOWN  = 21,

	/*! Mouse button released */
	IE_MOUSEUP    = 22
};



/**
  * \brief System event identifiers for IE_SYSEVENT events
  */
enum INPUTSYSEVENT
{
	IE_SYSEVENT_KILL    = 0
};


/**
  * \brief Keycode identifiers for IE_KEYDOWN and IE_KEYUP events
  */
enum KEYCODE
{
	KC_SPACE             = 32,
	KC_0                 = 48,
	KC_1                 = 49,
	KC_2                 = 50,
	KC_3                 = 51,
	KC_4                 = 52,
	KC_5                 = 53,
	KC_6                 = 54,
	KC_7                 = 55,
	KC_8                 = 56,
	KC_9                 = 57,
	KC_A                 = 97,
	KC_B                 = 98,
	KC_C                 = 99,
	KC_D                 = 100,
	KC_E                 = 101,
	KC_F                 = 102,
	KC_G                 = 103,
	KC_H                 = 104,
	KC_I                 = 105,
	KC_J                 = 106,
	KC_K                 = 107,
	KC_L                 = 108,
	KC_M                 = 109,
	KC_N                 = 110,
	KC_O                 = 111,
	KC_P                 = 112,
	KC_Q                 = 113,
	KC_R                 = 114,
	KC_S                 = 115,
	KC_T                 = 116,
	KC_U                 = 117,
	KC_V                 = 118,
	KC_W                 = 119,
	KC_X                 = 120,
	KC_Y                 = 121,
	KC_Z                 = 122,

	KC_RETURN            = 0x1000,
	KC_ESCAPE            = 0x1001,
	KC_BACKSPACE         = 0x1002,
	KC_UP                = 0x1100,
	KC_DOWN              = 0x1101,
	KC_LEFT              = 0x1102,
	KC_RIGHT             = 0x1103,
	KC_F1                = 0x1201,
	KC_F2                = 0x1202,
	KC_F3                = 0x1203,
	KC_F4                = 0x1204,
	KC_F5                = 0x1205,
	KC_F6                = 0x1206,
	KC_F7                = 0x1207,
	KC_F8                = 0x1208,
	KC_F9                = 0x1209,
	KC_F10               = 0x120a,
	KC_F11               = 0x120b,
	KC_F12               = 0x120b,
	KC_F13               = 0x120c,
	KC_F14               = 0x120d,
	KC_F15               = 0x120e,

	KC_DOT               = 0x2000,  // .
	KC_COMMA             = 0x2001,  // ,
	KC_COLON             = 0x2002,  // :
	KC_SEMICOLON         = 0x2003,  // ;
	KC_SLASH             = 0x2004,  // /
	KC_BACKSLASH         = 0x2005,  /* \ */
	KC_PLUS              = 0x2006,  // +
	KC_MINUS             = 0x2007,  // -
	KC_ASTERISK          = 0x2008,  // *
	KC_EXCLAMATION       = 0x2009,  // !
	KC_QUESTION          = 0x200a,  // ?
	KC_QUOTEDOUBLE       = 0x200b,  // "
	KC_QUOTE             = 0x200c,  // '
	KC_EQUAL             = 0x200d,  // =
	KC_HASH              = 0x200e,  // #
	KC_PERCENT           = 0x200f,  // %
	KC_AMPERSAND         = 0x2010,  // &
	KC_UNDERSCORE        = 0x2011,  // _
	KC_LEFTPARENTHESIS   = 0x2012,  // (
	KC_RIGHTPARENTHESIS  = 0x2013,  // )
	KC_LEFTBRACKET       = 0x2014,  // [
	KC_RIGHTBRACKET      = 0x2015,  // ]
	KC_LEFTCURL          = 0x2016,  // {
	KC_RIGHTCURL         = 0x2017,  // }
	KC_DOLLAR            = 0x2018,  // $
	KC_POUND             = 0x2019,  // £
	KC_EURO              = 0x201a,  // $
	KC_LESS              = 0x201b,  // <
	KC_GREATER           = 0x201c,  // >
	KC_BAR               = 0x201d,  // |
	KC_GRAVE             = 0x201e,
	KC_TILDE             = 0x201f,  // ~
	KC_AT                = 0x2020,  // @

	KC_KP_0              = 0x3000,
	KC_KP_1              = 0x3001,
	KC_KP_2              = 0x3002,
	KC_KP_3              = 0x3003,
	KC_KP_4              = 0x3004,
	KC_KP_5              = 0x3005,
	KC_KP_6              = 0x3006,
	KC_KP_7              = 0x3007,
	KC_KP_8              = 0x3008,
	KC_KP_9              = 0x3009,
	KC_KP_PLUS           = 0x300a,
	KC_KP_MINUS          = 0x300b,
	KC_KP_DECIMAL        = 0x300c,
	KC_KP_DIVIDE         = 0x300d,
	KC_KP_ASTERISK       = 0x300e,
	KC_KP_NUMLOCK        = 0x300f,
	KC_KP_ENTER          = 0x3010,

	KC_TAB               = 0x4000,
	KC_CAPSLOCK          = 0x4001,
	KC_LSHIFT            = 0x4002,
	KC_LCTRL             = 0x4003,
	KC_LALT              = 0x4004,
	KC_LWIN              = 0x4005,
	KC_RSHIFT            = 0x4006,
	KC_RCTRL             = 0x4007,
	KC_RALT              = 0x4008,
	KC_RWIN              = 0x4009,
	KC_INSERT            = 0x400a,
	KC_DELETE            = 0x400b,
	KC_HOME              = 0x400c,
	KC_END               = 0x400d,
	KC_PAGEUP            = 0x400e,
	KC_PAGEDOWN          = 0x400f,
	KC_SCROLLLOCK        = 0x4010,
	KC_PAUSE             = 0x4011,

	KC_UNKNOWN           = 0x6fff,

	KC_LAST_BUILTIN      = KC_UNKNOWN
};

/**
  * \brief Mousebutton identifiers for IE_MOUSEDOWN and IE_MOUSEUP events
  */
enum MOUSEBUTTON
{
	MB_1                 = 0,
	MB_LEFT              = 0,
	MB_2                 = 1,
	MB_RIGHT             = 1,
	MB_3                 = 2,
	MB_MIDDLE            = 2,
	MB_4                 = 3,
	MB_5                 = 4,
	MB_6                 = 5,
	MB_7                 = 6,
	MB_8                 = 7
};


/**
  * \class InputEvent
  * \brief Data for a single input event
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API InputEvent
{
	public:

		/*! Event type */
		int                                           m_iType;

		/*! 
		* Input event Data
		* For NEIE_MOUSEMOVE events, data in position 0 holds x coordinate, data in position 1 holds y coordinate (both integers), data in position 2 reserved, data in position 3 is button bitmask
		* For NEIE_MOUSE[DOWN|UP] events, data in position 0 holds which button, data in position 1 holds x coordinate, data in position 2 holds y coordinate (both integers), data in position 3 reserved
		* For NEIE_KEY[DOWN|UP] events, data in position 0 holds KC code, data in position 1 holds ASCII value or 0 if no valid ASCII code for key
		*/
		union
		{
		  float                                       m_fData;
		  int                                         m_iData;
		  void                                       *m_pData;
		} m_aArgs[4];

		/*! Heartbeat time event occurred */
		uint64_t                                      m_ulTimestamp;

		/**
		*/
		                                              InputEvent( int iType = 0, int iData0 = 0, int iData1 = 0, int iData2 = 0, int iData3 = 0 ) { m_iType = iType; m_aArgs[0].m_iData = iData0; m_aArgs[1].m_iData = iData1; m_aArgs[2].m_iData = iData2; m_aArgs[3].m_iData = iData3; }

		/**
		*/
		                                              InputEvent( int iType, float fData0 = 0.0f, float fData1 = 0.0f, float fData2 = 0.0f, float fData3 = 0 ) { m_iType = iType; m_aArgs[0].m_fData = fData0; m_aArgs[1].m_fData = fData1; m_aArgs[2].m_fData = fData2; m_aArgs[3].m_fData = fData3; }

		/**
		*/
		                                              InputEvent( int iType, void *pData0, void *pData1 = 0, void *pData2 = 0, void *pData3 = 0 ) { m_iType = iType; m_aArgs[0].m_pData = pData0; m_aArgs[1].m_pData = pData1; m_aArgs[2].m_pData = pData2; m_aArgs[3].m_pData = pData3; }
};


#ifdef WIN32
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif
#  ifndef __HAVE_VECTOR_NEINPUTENTITY
     UDTVectorEXPIMP( class InputEntity* );
#    define __HAVE_VECTOR_NEINPUTENTITY
#  endif
#endif


/**
  * \class InputGroup
  * \brief Group of input objects for easy management
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API InputGroup : public virtual Activator
{
	friend class InputManager;

	protected:

		/*! Input objects attached to this group */
		std::vector< InputEntity* >                   m_vpkInputObjects;

		/*! Manager */
		InputManager                                 *m_pkManager;



	public:

		/**
		* Attach to manager
		* \param pkManager                            Input manager. If this argument is null (default), the core input manager will be used
		*/
		                                              InputGroup( InputManager *pkManager = 0 );

		/**
		* Detach from manager
		*/
		virtual                                      ~InputGroup();

		/**
		* Attach input entity
		* \param pkObject                             Input entity to attach
		*/
		void                                          AttachEntity( InputEntity *pkObject );

		/**
		* Detach input entity
		* \param pkObject                             Input entity to detach
		*/
		void                                          DetachEntity( InputEntity *pkObject );

		/**
		* Distribute events to active nodes. Do not overload this method, as it is a wrapper to the single-event distribute method.
		* \param rvpkEvents                           vector of events
		*/
		void                                          Distribute( const std::vector< InputEvent* > &rvpkEvents );

		/**
		* Distribute events to active nodes
		* \param pkEvent                              Event object
		*/
		virtual void                                  Distribute( const InputEvent *pkEvent );

		/**
		* \return                                     Manager object
		*/
		InputManager                                 *GetManager() { return m_pkManager; }
};


#ifdef WIN32
#  ifndef __HAVE_VECTOR_NEINPUTDEVICE
     UDTVectorEXPIMP( class InputDevice* );
#    define __HAVE_VECTOR_NEINPUTDEVICE
#  endif
#  ifndef __HAVE_VECTOR_NEINPUTGROUP
     UDTVectorEXPIMP( class InputGroup* );
#    define __HAVE_VECTOR_NEINPUTGROUP
#  endif
#endif


/**
  * \class InputManager
  * \brief Collects input from devices and distributes to groups
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API InputManager
{
	protected:

		/*! Devices */
		std::vector< InputDevice* >                   m_vpkInputDevices;

		/*! Groups */
		std::vector< InputGroup* >                    m_vpkInputGroups;


	public:

		/**
		*/
		                                              InputManager();

		/**
		*/
		virtual                                      ~InputManager();

		/**
		* Attach input device. Manager will NOT delete device objects in dtor, cleanup
		* must be done by device creator.
		* \param pkDevice                             Input device
		*/
		void                                          AttachDevice( InputDevice *pkDevice );

		/**
		* Attach input group. Manager will NOT delete group objects in dtor, cleanup
		* must be done by group creator.
		* \param pkGroup                              Input group
		*/
		void                                          AttachGroup( InputGroup *pkGroup );

		/**
		* Detach input device
		* \param pkDevice                             Input device
		*/
		void                                          DetachDevice( InputDevice *pkDevice );

		/**
		* Detach input group
		* \param pkGroup                              Input group
		*/
		void                                          DetachGroup( InputGroup *pkGroup );

		/**
		* Collect events from devices and distribute to groups
		*/
		void                                          Process();
};




/**
  * \class InputDevice
  * \brief Input event generator
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API InputDevice : public virtual Activator
{
	friend class InputManager;
	friend class Core;

	public:
		/**
		* \brief Inputgroup identifiers
		*/
		enum INPUTEVENTGROUP
		{
		  /*! System input (e.g. kill, window resize) */
		  SYSTEMINPUT                                 = 0x00000001,

		  /*! Keyboard input (e.g. key presses) */
		  KEYBOARDINPUT                               = 0x00000002,

		  /*! Mouse input (e.g. mouse move) */
		  MOUSEINPUT                                  = 0x00000004,

		  /*! Joystick input */
		  JOYSTICKINPUT                               = 0x00000008
		};


	protected:

		/*! Manager */
		InputManager                                 *m_pkManager;

		/*! Managed input event groups */
		unsigned int                                  m_eInputEventGroups;


		/**
		* Attach to manager
		* \param pkManager                            Input manager
		*/
		                                              InputDevice( InputManager *pkManager );

		/**
		* Detach from manager
		*/
		virtual                                      ~InputDevice();


	public:

		/*! Module device was loaded from */
		ModulePtr                                     m_pkModule;

		/**
		* Collect input events
		* \param pkEvent                              Event object to fill with data
		* \return                                     true if events was collected, false if not
		*/
		virtual bool                                  Collect( InputEvent *pkEvent ) = 0;

		/**
		* Enable input handling for the given group(s)
		* \param uiInputEventGroup                    InputGroup(s) to enable; See INPUTGROUP (e.g. SYSTEMINPUT, KEYBOARDINPUT)
		*/
		virtual void                                  AddInputEventGroup( unsigned int uiInputEventGroup ) { m_eInputEventGroups |= uiInputEventGroup; }

		/**
		* Disable input handling for the given group(s)
		* \param uiInputEventGroup                    InputGroup(s) to disable; See INPUTGROUP (e.g. SYSTEMINPUT, KEYBOARDINPUT)
		*/
		virtual void                                  DeleteInputEventGroup( unsigned int uiInputEventGroup ) { m_eInputEventGroups &= ~uiInputEventGroup; }

		/**
		* Check if input handling is enabled of the given group(s)
		* \param uiInputEventGroup                    InputGroup(s) to check; See INPUTGROUP (e.g. SYSTEMINPUT, KEYBOARDINPUT)
		* \return                                     True if input group is enabled, false otherwise
		*/
		virtual bool                                  HasInputEventGroup (unsigned int uiInputEventGroup ) { return (m_eInputEventGroups & uiInputEventGroup) != 0; }
};


};


#endif
