/***************************************************************************
                   submesh.h  -  Part of mesh, single material
                             -------------------
    begin                : Wed Sep 18 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, submesh.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NESUBMESH_H
#define __NESUBMESH_H


/**
  * \file neoengine/submesh.h
  * Mesh primitive building block
  */


#include "base.h"
#include "material.h"
#include "vertexbuffer.h"
#include "polygonbuffer.h"
#include "updateentity.h"


namespace NeoEngine
{


// External classes
class Frustum;
class RenderPrimitive;


/**
  * \brief A chunk of polygons of same material
  * \author Mattias Jansson (mattias@realityrift.com
  * \todo Perhaps derive from BoundingVolume to let parent Mesh
  *       do collision detection with us rather that one big volume itself
  */
class NEOENGINE_API SubMesh : public virtual UpdateEntity
{
	public:

		/**
		* \brief Supported sub mesh types
		*/
		enum SUBMESHTYPE
		{
		  /*! Plain static submesh */
		  SUBMESH                      = 0x0001,

		  /*! Vertex-animated submesh */
		  ANIMATEDSUBMESH              = 0x0002,

		  /*! Skeletal-animated (skinned) submesh */
		  SKELETALSUBMESH              = 0x0003,

		  /*! Patch surface submesh (bezier, nurbs...) */
		  PATCHSURFACE                 = 0x0004
		};


	protected:

		/*! Vertex buffer */
		VertexBufferPtr                m_pkVertices;

		/*! Polygon buffer */
		PolygonBufferPtr               m_pkPolygons;

		/*! Flag indicating	update needed */
		bool                           m_bNeedUpdate;

		/*! Shadow vertex buffer */
		VertexBufferPtr                m_pkShadowVertices;

		/*! Shadow polygon buffer */
		PolygonBufferPtr               m_pkShadowPolygons;

		/**
		* Update data
		*/
		virtual void                   UpdateData();



	public:

		/*! Material */
		MaterialPtr                    m_pkMaterial;

		/*! Flag indicating geometry has changed */
		bool                           m_bChanged;


		/**
		*/
		                               SubMesh();

		/**
		* \param rkSubMesh             Reference submesh object to copy data from
		*/
		                               SubMesh( const SubMesh &rkSubMesh );

		/**
		*/
		virtual                       ~SubMesh();

		/**
		* Update this submesh
		* \param fDeltaTime            Delta time passed
		*/
		virtual void                   Update( float fDeltaTime );

		/**
		* \return                      Vertex buffer
		*/
		virtual VertexBufferPtr       &GetVertexBuffer() { if( m_bNeedUpdate ) UpdateData(); return m_pkVertices; }

		/**
		* \return                      Polygon buffer
		*/
		virtual PolygonBufferPtr      &GetPolygonBuffer() { if( m_bNeedUpdate ) UpdateData(); return m_pkPolygons; }

		/**
		* \param pkVertices            New vertex buffer
		*/
		virtual void                   SetVertexBuffer( VertexBufferPtr pkVertices );

		/**
		* \param pkPolygons            New polygon buffer
		*/
		virtual void                   SetPolygonBuffer( PolygonBufferPtr pkPolygons );

		/**
		* \param pkVertices            New shadow vertex buffer
		*/
		virtual void                   SetShadowVertexBuffer( VertexBufferPtr pkVertices );

		/**
		* \param pkPolygons            New shadow polygon buffer
		*/
		virtual void                   SetShadowPolygonBuffer( PolygonBufferPtr pkPolygons );

		/**
		* \return                      new submesh that is duplicate of this
		*/
		virtual SubMesh               *Duplicate() const;

		/**
		* \return                      Sub mesh type
		*/
		virtual unsigned int           GetType() const { return SUBMESH; }

		/**
		* Render submesh geometry
		* \param pkPrimitive           Presetup render primitive object (needed for inverse mesh transform matrix)
		* \param pkFrustum             Current view frustum
		*/
		virtual void                   Render( RenderPrimitive *pkPrimitive, Frustum *pkFrustum = 0 );

		/**
		* Calculate tangents and binormals
		*/
		void                           CalculateTangents();
};


};


#endif

