/***************************************************************************
                          render.h  -  Render device
                             -------------------
    begin                : Wed Oct 31 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, render.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NERENDERDEVICE_H
#define __NERENDERDEVICE_H


/**
  * \file render.h
  * Render device abstract class
  */


#include "base.h"
#include "buffer.h"
#include "pointer.h"
#include "texture.h"
#include "input.h"
#include "callback.h"
#include "pointer.h"
#include "projection.h"
#include "rendercaps.h"
#include "renderwindow.h"
#include "renderprimitive.h"
#include "viewport.h"
#include "shader.h"


namespace NeoEngine
{


// External classes
class Light;
class PixelBuffer;
class Shader;
class ShadowGenerator;
class Color;
class RenderAdapter;


/**
  * \brief Render device
  *
  * Platform independant pure virtual render device. Implement platform-specific
  * methods and features in derived class. Use CreateRenderDevice() to create device,
  * and call Open() before rendering anything.
  *
  * Derived from InputDevice for easy processing of OS messages (implement Process() method)
  *
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API RenderDevice : public InputDevice, public TextureLoader, public ConfigCallback
{
	friend class Core;

	public:

		/**
		* \brief Render target identifiers
		*/
		enum RENDERTARGET
		{
		  /*! Invalid */
		  INVALIDBUFFER                               = 0xFFFFFFFF,

		  /*! Frame buffer */
		  FRAMEBUFFER                                 = 0x00000000,

		  /*! Pixel buffer (ID in low 24 bits) */
		  PIXELBUFFER                                 = 0x01000000
		};

		/**
		* \brief Flags passed to Begin affecting the rendering of the frame
		*/
		enum RENDERFRAMEFLAGS
		{
		  /*! No flags */
		  NOFLAGS                                     = 0x00000000,

		  /*! No sorting of primitives, render in same order as calls to Render() */
		  NOSORT                                      = 0x00000001
		};

		/**
		* \brief Culling mode identifiers
		*/
		enum CULLMODE
		{
		  /*! No culling */
		  CULLNONE                                    = 0,

		  /*! Cull backfacing polygons */
		  CULLBACK                                    = 1,

		  /*! Cull frontfacing polygons */
		  CULLFRONT                                   = 2,

		  /*! Cull all polygons */
		  CULLBOTH                                    = 3
		};

		/**
		* \brief Stencil op identifiers
		*/
		enum STENCILOP
		{
		  /*! Keep current value */
		  STENCILOP_KEEP                              = 0,

		  /*! Set to zero */
		  STENCILOP_ZERO                              = 1,

		  /*! Set to reference */
		  STENCILOP_REPLACE                           = 2,

		  /* Increment value, clamp to max */
		  STENCILOP_INCR                              = 3,

		  /*! Decrement value, clamp to zero */
		  STENCILOP_DECR                              = 4,

		  /*! Bitwise inverts the current stencil buffer value */
		  STENCILOP_INVERT                            = 5
		};

		/**
		* \brief Stencil test function identifiers
		*/
		enum STENCILFUNC
		{
		  /*! Always fails */
		  STENCILFUNC_NEVER                           = 0,

		  /*! Passes if ( ref & mask ) <  ( stencil & mask ) */
		  STENCILFUNC_LESS                            = 1,

		  /*! Passes if ( ref & mask ) <= ( stencil & mask ) */
		  STENCILFUNC_LEQUAL                          = 2,

		  /*! Passes if ( ref & mask ) >  ( stencil & mask ) */
		  STENCILFUNC_GREATER                         = 3,

		  /*! Passes if ( ref & mask ) >= ( stencil & mask ) */
		  STENCILFUNC_GEQUAL                          = 4,

		  /*! Passes if ( ref & mask ) == ( stencil & mask ) */
		  STENCILFUNC_EQUAL                           = 5,

		  /*! Passes if ( ref & mask ) != ( stencil & mask ) */
		  STENCILFUNC_NOTEQUAL                        = 6,

		  /*! Always passes */
		  STENCILFUNC_ALWAYS                          = 7
		};

		/**
		* \brief Buffer identifiers
		*/
		enum BUFFER
		{
		  /*! Color buffer (framebuffer, pixelbuffer) */
		  COLORBUFFER                                 = 1,

		  /*! Z buffer */
		  ZBUFFER                                     = 2,

		  /*! Stencil buffer */
		  STENCILBUFFER                               = 4
		};


	protected:

		/*! Library module */
		ModulePtr                                     m_pkModule;

		/*! Texture pool */
		TexturePool                                  *m_pkTexturePool;

		/*! Current projection mode object */
		Projection                                   *m_pkProjection;

		/*! Last perspective projection mode */
		PerspectiveProjection                         m_kPerspectiveProjection;

		/*! Last orthographic projection mode */
		OrthographicProjection                        m_kOrthographicProjection;

		/*! Last custom projection mode */
		Projection                                    m_kCustomProjection;

		/*! Current view matrix */
		Matrix                                        m_kViewMatrix;

		/*! Render window */
		RenderWindow                                  m_kWindow;

		/*! Viewport */
		Viewport                                      m_kViewport;

		/*! Cull mode */
		CULLMODE                                      m_eCullMode;

		/*! Default filtering mode */
		unsigned int                                  m_uiDefaultTextureFilter;

		/*! Default max anisotropy */
		unsigned int                                  m_uiDefaultMaxAnisotropy;

		/*! File manager */
		FileManager                                  *m_pkFileManager;


		/**
		* Constructor, may only be called by CreateRenderDevice method
		* \param pkFileManager                        File manager
		* \param pkInputManager                       Input manager to link to
		*/
		                                              RenderDevice( FileManager *pkFileManager, InputManager *pkInputManager );

		/**
		* Closes device
		*/
		virtual                                      ~RenderDevice();

		/**
		* Set projection matrix
		* \param rkMatrix                             Projection matrix
		*/
		virtual void                                  SetProjection( const Matrix &rkMatrix ) = 0;



	public:


		/*! Global fog mode */
		FogMode                                       m_kFogMode;

		/*! Default shadow generator */
		ShadowGenerator                              *m_pkShadowGenerator;


		/**
		* Open device, either by creating a new window internally or in an already existing window, depending on the values filled in
		* the provided render window object. If no valid window data is provided, a new rendering window will be created (optionally
		* fullscreen depending on the render caps filled in) with the specified dimensions.
		* \param rkWndData                            Window specification and OS specific window data
		* \return                                     true if successful, false if not
		*/
		virtual bool                                  Open( const RenderWindow &rkWndData ) = 0;

		/**
		* Close device, restore settings
		*/
		virtual void                                  Close() = 0;

		/**
		* Begin new frame. Call this before any calls to Render
		* \param rkViewMatrix                         View matrix for this batch of render operations
		* \param uiFlags                              Flags for frame
		*/
		virtual void                                  Begin( const Matrix &rkViewMatrix, unsigned int uiFlags = NOFLAGS ) = 0;

		/**
		* End frame
		*/
		virtual void                                  End() = 0;

		/**
		* Render primitive batch
		* \param rkPrimitive                          Render primitive batch data
		* \param uiFlags                              Batch flags
		*/
		virtual void                                  Render( const RenderPrimitive &rkPrimitive, unsigned int uiFlags = RenderPrimitive::NOFLAGS ) = 0;

		/**
		* Set current render target
		* \param uiTarget                             Render target identifier
		* \return                                     Previous render target identifier (you should restore this if other than INVALIDBUFFER)
		*/
		virtual unsigned int                          SetRenderTarget( unsigned int uiTarget ) = 0;

		/**
		* Set culling mode. Must be called outside Begin()-End() block
		* \param eCullMode                            Culling mode identifier
		* \return                                     Last culling mode
		*/
		virtual CULLMODE                              SetCullMode( CULLMODE eCullMode = CULLBACK ) = 0;

		/**
		* Set stencil operations
		* \param eStencilFail                         Operation when stencil buffer test fails
		* \param eZFail                               Operation when stencil buffer test passes and z buffer test fails
		* \param eZPass                               Operation when stencil buffer test passes and z buffer test passes
		*/
		virtual void                                  SetStencilOp( STENCILOP eStencilFail, STENCILOP eZFail, STENCILOP eZPass ) = 0;

		/**
		* Set stencil function, reference value and test mask
		* \param eFunc                                Stencil test func
		* \param uiRefValue                           Reference value
		* \param uiTestMask                           A mask that is ANDed with both the reference value and the stored stencil value when the test is done
		*/
		virtual void                                  SetStencilFunc( STENCILFUNC eFunc, unsigned int uiRefValue, unsigned int uiTestMask ) = 0;

		/**
		* Set stencil write mask
		* \param uiWriteMask                          Write mask
		*/
		virtual void                                  SetStencilMask( unsigned int uiWriteMask ) = 0;

		/**
		* Set render target write mask
		* \param bWrite                               Write flag, if false will disable writing to render target buffer, if true enable writing to render target buffer
		*/
		virtual void                                  SetTargetMask( bool bWrite ) = 0;

		/**
		* Set default texture filtering mode (affects only textures loaded after this call)
		* \param uiMode                               Texture filtering mode
		*/
		virtual void                                  SetDefaultTextureFiltering( unsigned int uiMode );

		/**
		* Set default max anisotropy (affects only textures loaded after this call)
		* \param uiMaxAnisotropy                      Max anisotropy
		*/
		virtual void                                  SetDefaultMaxAnisotropy( unsigned int uiMaxAnisotropy );

		/**
		* Set buffer backing storage size. You must call this method prior to an Open() call, or
		* default sizes will be used.
		* \param uiVertexStorageSize                  Size in bytes of vertex buffer storage (default 3Mb)
		* \param uiPolygonStorageSize                 Size in bytes of polygon buffer storage (default 1Mb)
		* \return                                     true if successful, false if error (called after Open(), unable to allocate memory)
		*/
		virtual bool                                  SetStorageSize( unsigned int uiVertexStorageSize, unsigned int uiPolygonStorageSize ) = 0;

		/**
		* Setup perspective projection (must be outside Begin()-End() block) using last perspective projection
		* values, or if first call use default values (45.0f, 0.5f, 1000.0f)
		*/
		void                                          SetPerspectiveProjection();

		/**
		* Setup perspective projection (must be outside Begin()-End() block)
		* \param fFOV                                 Field-of-view angle
		* \param fZNear                               Distance to z near clipping plane
		* \param fZFar                                Distance to z far clipping plane
		*/
		virtual void                                  SetPerspectiveProjection( float fFOV, float fZNear, float fZFar );

		/**
		* Setup orthographic projection (must be outside Begin()-End() block) using last orthographic projection
		* values, or if first call use default values (0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f). Console and other
		* orthographic objects in the engine relies on default values being set, change only if
		* you know what you're doing :)
		*/
		void                                          SetOrthographicProjection();

		/**
		* Setup orthographic projection (must be outside Begin()-End() block). Console and other
		* orthographic objects in the engine relies on default values being set, change only if
		* you know what you're doing :)
		* \param fLeft                                Left clip plane
		* \param fTop                                 Top clip plane
		* \param fRight                               Right clip plane
		* \param fBottom                              Bottom clip plane
		* \param fZNear                               Z near clip plane
		* \param fZFar                                Z far clip plane
		*/
		virtual void                                  SetOrthographicProjection( float fLeft, float fTop, float fRight, float fBottom, float fZNear = 0.0f, float fZFar = 1.0f );

		/**
		* Set custom projection mode (must be outside Begin()-End() block).
		* \param rkMatrix                             Projection matrix
		*/
		virtual void                                  SetCustomProjection( const Matrix &rkMatrix );

		/**
		* Set rendering viewport (must be outside Begin()-End() block)
		* \param iX                                   Starting x coordinate
		* \param iY                                   Starting y coordinate
		* \param iWidth                               Width
		* \param iHeight                              Height
		*/
		virtual void                                  SetViewport( int iX, int iY, int iWidth, int iHeight ) = 0;

		/**
		* Clear the current viewport (must be outside Begin()-End() block) for framebuffer, 
		* or for other clear targets clear the whole buffer
		* \param uiTargets                            Target bitfield (combination of NEBUFFER enums )
		* \param rkColor                              Color to clear color buffer with
		* \param fZValue                              Value to clear z buffer with
		* \param uiStencilValue                       Value to clear stencil buffer with
		*/
		virtual void                                  Clear( unsigned int uiTargets, const Color &rkColor, float fZValue, unsigned int uiStencilValue ) = 0;

		/**
		* Flip buffers, flush pipeline (must be outside Begin()-End() block)
		*/
		virtual void                                  Flip() = 0;

		/**
		* Add light to rendering pipeline for this Begin()-End() block. This is implementation/hardware specific and is not guaranteed to work in the fixed-function pipeline (max number of lights)
		* \param pkLight                              Light to add
		* \return                                     < 0 if failed
		*/
		virtual int                                   AddLight( Light *pkLight ) = 0;

		/**
		* Load a texture file. Implement in derived class
		* \param rstrFilename                         File name
		* \param eTextureType                         Texture type (2D, cubemap, ...)
		* \param eTextureFormat                       Requested texture format (Texture::DEFAULT if not needed)
		* \param uiFlags                              Load flags (default Texture::NONE)
		* \param uiFiltering                          Texture filtering modes (0 as default, using default set device filtering mode)
		* \param uiMaxAnisotropy                      Max anisotropy
		* \return                                     Ptr to texture
		*/
		virtual TexturePtr                            LoadTexture( const std::string &rstrFilename, Texture::TEXTURETYPE eTextureType = Texture::TEX2D, Texture::TEXTUREFORMAT eTextureFormat = Texture::DEFAULT, unsigned int uiFlags = Texture::NOFLAGS, unsigned int uiFiltering = 0, unsigned int uiMaxAnisotropy = 1 ) = 0;

		/**
		* Find texture by name
		* \param rstrName                             Texture name
		* \return                                     Ptr to texture
		*/
		virtual TexturePtr                            GetTexture( const std::string &rstrName ) = 0;

		/**
		* Create new texture object
		* \param rstrName                             Texture name
		* \param eTextureType                         Texture type (2D, cubemap, ...)
		* \param eTextureFormat                       Requested texture format (Texture::DEFAULT if not needed)
		* \return                                     Ptr to texture
		*/
		virtual TexturePtr                            CreateTexture( const std::string &rstrName, Texture::TEXTURETYPE eTextureType = Texture::TEX2D, Texture::TEXTUREFORMAT eTextureFormat = Texture::DEFAULT ) = 0;

		/**
		* Allocate a vertex buffer
		* \param uiType                               Buffer type
		* \param uiNumVertices                        Number of vertices
		* \param pkFormat                             Flexible vertex format declaration
		* \param pData                                Optional pointer to data to load buffer with
		* \return                                     Ptr to new vertex buffer
		*/
		virtual VertexBufferPtr                       CreateVertexBuffer( unsigned int uiType = Buffer::NORMAL, unsigned int uiNumVertices = 0, const VertexDeclaration *pkFormat = 0, const void *pData = 0 ) = 0;

		/**
		* Allocate a polygon buffer
		* \param uiType                               Buffer type
		* \param uiNumPolygons                        Number of polygons
		* \param pkData                               Optional pointer to data to load buffer with
		* \param bStripify                            Stripify buffer if true
		* \return                                     Ptr to new polygon buffer
		*/
		virtual PolygonBufferPtr                      CreatePolygonBuffer( unsigned int uiType = Buffer::NORMAL, unsigned int uiNumPolygons = 0, const Polygon *pkData = 0, bool bStripify = false ) = 0;

		/**
		* Allocate a polygon strip buffer
		* \param uiType                               Buffer type
		* \param uiNumPolygons                        Number of polygons
		* \param pusData                              Optional pointer to data to load buffer with
		* \return                                     Ptr to new polygon strip buffer
		*/
		virtual PolygonStripBufferPtr                 CreatePolygonStripBuffer( unsigned int uiType = Buffer::NORMAL, unsigned int uiNumPolygons = 0, const unsigned short *pusData = 0 ) = 0;

		/**
		* Create a pixel buffer for offscreen rendering
		* \param uiWidth                              Width of buffer
		* \param uiHeight                             Height of buffer
		* \param uiBPP                                Suggested bit depth (might be ignored if not found or incompatible in windowed mode)
		* \param eTextureType                         Target texture type (2D, cubemap, ...)
		* \return                                     New pixel buffer object, or null if error/unsupported
		*/
		virtual PixelBuffer                          *CreatePixelBuffer( unsigned int uiWidth, unsigned int uiHeight, unsigned int uiBPP, Texture::TEXTURETYPE eTextureType = Texture::TEX2D ) = 0;

		/**
		* Create a new shader object, which can then be loaded and compiled
		* \param eType                                Shader type (vertex or fragment)
		* \return                                     Pointer to the new shader object
		*/
		virtual ShaderPtr                             CreateShader( Shader::SHADERTYPE eType ) = 0;

		/**
		* Find shader by name and type (only successfully compiled shaders are searched)
		* \param eType                                Shader type
		* \param rstrName                             Shader name
		* \return                                     Ptr to shader
		*/
		virtual ShaderPtr                             GetShader( Shader::SHADERTYPE eType, const std::string &rstrName ) = 0;

		/**
		* Read pixels from currently bound buffer (framebuffer, pixelbuffer, stencilbuffer)
		* \return                                     Image data containing pixels
		*/
		virtual ImageData                            *ReadPixels() = 0;

		virtual void                                  SetFog( FogMode &rkFogMode ) { m_kFogMode = rkFogMode; }

		/**
		* Access projection matrix
		* \return                                     Const reference to projection matrix
		*/
		inline const Matrix                          &GetProjectionMatrix() const { return m_pkProjection->m_kMatrix; }

		/**
		* \return                                     Z near clipping plane distance
		*/
		inline float                                  GetZNear() const { return m_pkProjection->m_fZNear; }

		/**
		* \return                                     Z far clipping plane distance
		*/
		inline float                                  GetZFar() const { return m_pkProjection->m_fZFar; }

		/**
		* \return                                     Width in pixels of render window
		*/
		inline unsigned int                           GetWidth() { return m_kWindow.m_kResolution.m_uiWidth; }

		/**
		* \return                                     Height in pixels of render window
		*/
		inline unsigned int                           GetHeight() { return m_kWindow.m_kResolution.m_uiHeight; }

		/**
		* \return                                     Bits per pixel of current rendering target
		*/
		inline unsigned int                           GetBPP() { return m_kWindow.m_kResolution.m_uiBPP; }

		/**
		* \return                                     FOV angle in degrees
		*/
		inline float                                  GetFOV() const { return m_kPerspectiveProjection.m_fFOV; }

		/**
		* Get viewport extents
		* \return                                     Current viewport
		*/
		inline const Viewport                        &GetViewport() const { return m_kViewport; }

		/**
		* \return                                     String with statistics for last frame
		*/
		virtual std::string                           GetStatistics() = 0;

		/**
		* Get device window data (including OS/device specific data)
		* \return                                     Render window object
		*/
		inline const RenderWindow                    &GetWindow() const { return m_kWindow; }

		/**
		* Query caps of device
		* \return                                     Caps object with the current device capabilities flags
		*/
		inline const RenderCaps                      &GetCaps() const { return m_kWindow.m_kCaps; }

		/**
		* \return                                     Current projection mode
		*/
		inline Projection::PROJECTIONMODE             GetProjectionMode() const { return m_pkProjection->m_eMode; }

		/**
		* \return                                     Current view matrix
		*/
		inline const Matrix                          &GetViewMatrix() const { return m_kViewMatrix; }

		/**
		* Get default texture filtering mode
		* \return                                     Default texture filtering mode
		*/
		inline unsigned int                           GetDefaultTextureFiltering() { return m_uiDefaultTextureFilter; }

		/**
		* Set mouse position relative window client area top-left corner.
		* \param iX                                   X coordinate in pixels
		* \param iY                                   Y coordinate in pixels
		*/
		virtual void                                  SetMousePos( int iX, int iY ) = 0;

		/**
		* Capture or release mouse from window
		* \param bCapture                             If true, capture mouse in window. If false, release mouse
		*/
		virtual void                                  CaptureMouse( bool bCapture ) = 0;

		/**
		* Show or hide mouse cursor
		* \param bShow                                If true, show cursor. If false, hide cursor
		*/
		virtual void                                  ShowCursor( bool bShow ) = 0;

		/**
		* Register/deregister frame callback
		* \param eType                                Callback type
		* \param pkCallback                           Callback object
		* \param bRegister                            If true, register new callback. If false, deregister callback
		*/
		virtual void                                  RegisterFrameCallback( FrameCallback::FRAMECALLBACKTYPE eType, FrameCallback *pkCallback, bool bRegister ) = 0;

		/**
		* Query device for available adapters
		* \param pvkAdapters                          Pointer to vector receiving available adapters
		*/
		virtual void                                  QueryAdapters( std::vector< RenderAdapter > *pvkAdapters ) = 0;

		/**
		* Query device for available fullscreen resolutions, sorted by total area, bits per pixel, refresh rate
		* \param pvkResolutions                       Pointer to vector receiving available resolutions
		* \param uiAdapter                            Adapter identifier, 0 for default (primary) adapter
		*/
		virtual void                                  QueryResolutions( std::vector< RenderResolution > *pvkResolutions, unsigned int uiAdapter = 0 ) = 0;
};


};


#endif
