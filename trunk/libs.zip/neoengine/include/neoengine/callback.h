/***************************************************************************
                      callback.h  -  Callback interfaces
                             -------------------
    begin                : Sun Sep 1 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, callback.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NECALLBACK_H
#define __NECALLBACK_H


#include "base.h"
#include "activator.h"
#include "hashstring.h"


/**
  * \file callback.h
  * Callback interfaces used in the engine
  */


namespace NeoEngine
{


/**
  * \brief Callback interface for config change notifications
  * To use a config change callback, derive from this class and implement interface
  * method, and pass object of derived class to register method in configuration repository object.
  *
  * Example:
  * <pre>
  * class MyConfigCallbac : public ConfigCallback
  * {
  *   public:
  *
  *     virtual void ConfigValueChange( const HashString &rstrKey )
  *     {
  *       if( rstrKey == "mycommand" )
  *         doSomething();
  *     }
  * };
  *
  * MyConfigCallback kCallback;
  * Config kConfig;
  *
  * kConfig.RegisterCallback( &kCallback );
  * </pre>
  * Your config callback will now be called every time a configuration value is changed
  * in the repository.
  * \author Mattias Jansson <mattias@realityrift.com>
  */
class NEOENGINE_API ConfigCallback
{
	public:

		/**
		* Called when a value change in configuration repository
		* \param rstrKey                              Key name
		*/
		virtual void                                  ConfigValueChange( const HashString &rstrKey ) = 0;
};




/**
  * \brief Callback interface for console command processing
  * To use a console command callback, derive from this class and implement interface
  * method, and pass object of derived class to register method in console object.
  *
  * Example:
  * <pre>
  * class MyConsoleCmd : public ConsoleCmdCallback
  * {
  *   public:
  *
  *     virtual void ConsoleCmd( const HashString &rstrCmd, const HashString &rstrArgs )
  *     {
  *       if( rstrCmd == "mycommand" )
  *         doSomething( rstrArgs );
  *     }
  * };
  *
  * MyConsoleCmd kCmd;
  * Console kConsole;
  *
  * kConsole.RegisterCommand( &kCmd );
  * </pre>
  * When the command <i>mycommand</i> is executed in the console, your callback will be
  * called with the arguments passed to the command in the console.
  *
  * You can also register a default callback in the console, which will be called for
  * all commands that doesn't have an explicit callback registered.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ConsoleCmdCallback
{
	public:

		/**
		* Process console command
		* \param rstrCmd                              Command
		* \param rstrArgs                             Argument string
		*/
		virtual void                                  ConsoleCmd( const HashString &rstrCmd, const HashString &rstrArgs ) = 0;
};



/**
  * \brief Callback interface for frame listeners
  * Use frame callbacks to listen for frame rendering events, such as
  * frame completion, or to be called for each light active in the frame.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API FrameCallback : public virtual Activator
{
	public:

		/**
		* \enum FRAMECALLBACKTYPE
		* \brief Callback type identifiers
		*/
		enum FRAMECALLBACKTYPE
		{
		  /*! Per light */
		  PERLIGHT                                    = 0,

		  /*! Frame end */
		  FRAMEEND                                    = 1,

		  /*! Number of callback types */
		  NUMCALLBACKS                                = 2
		};


		/**
		* Frame callback method
		* \param eType                                Callback type
		* \param pData                                Data pointer (type specific)
		*/
		virtual void                                  FrameEvent( FRAMECALLBACKTYPE eType, void *pData ) = 0;
};


};


#endif
