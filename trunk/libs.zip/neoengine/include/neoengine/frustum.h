/***************************************************************************
                          frustum.h  -  View frustum 
                             -------------------
    begin                : Wed Sep 18 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, frustum.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEFRUSTUM_H
#define __NEFRUSTUM_H


#include "base.h"
#include "node.h"
#include "plane.h"


/**
  * \file frustum.h
  * Viewing frustum primitive
  */

namespace NeoEngine
{


// External classes
class Line;
class Plane;


/**
  * \brief Basic frustum data container
  *
  * This is a basic class holding data for a frustum.
  * Plane normals and distances for all six frustum planes.
  * Vertex signs used in culling octatree (or any bounding boxes).
  *
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Frustum : public SRTNode
{
	public:

		/**
		* \enum FRUSTUMPLANE
		* \brief Frustum planes
		*/
		enum FRUSTUMPLANE
		{
			LEFT                                      = 0,
			RIGHT                                     = 1,
			TOP                                       = 2,
			BOTTOM                                    = 3,
			FRONT                                     = 4,
			BACK                                      = 5,
			NUMPLANES                                 = 6
		};


	public:

		/*! Vertex signs. These indicate which box corner in the AA box should be used as near and far vertex when culling against frustum during rendering. 6 planes in frustum as first index. Second index is vertex component, 0 = x, 1 = y, 2 = z. A value of 0 is positive and 1 is negative */
		unsigned char                                 m_aiPVertexSign[6][3];

		/*! N is inverted P but precalculate to gain speed */
		unsigned char                                 m_aiNVertexSign[6][3];

		/*! The view matrix corresponding to this frustum */
		Matrix                                        m_kViewMatrix;

		/*! The equation data (normal and distance) for the 6 frustum planes */
		Plane                                         m_akPlanes[6];

		/*! View vector (which is -zvector of rotation of course)*/
		Vector3d                                      m_kDirection;

		/*! Near plane distance along m_kDirection */
		float                                         m_fZNear;

		/*! Far plane distance along m_kDirection */
		float                                         m_fZFar;


		/**
		* Resets member data
		*/
		                                              Frustum();

		/**
		* Test if point is inside volume
		* \param rkPoint                              Point to check
		* \return                                     true if inside volume, false otherwise
		*/
		virtual bool                                  Intersection( const Vector3d &rkPoint );

		/**
		* Test if line intersects with volume
		* \param rkLine                               Line to check
		* \return                                     true if intersection with volume, false otherwise
		*/
		virtual bool                                  Intersection( const Line &rkLine );

		/**
		* Test if intersection with plane
		* \param rkPlane                              Plane to check
		* \return                                     true if intersection, false otherwise
		*/
		virtual bool                                  Intersection( const Plane &rkPlane );

		/**
		* Test if intersection with polygon
		* \param rkV0                                 First corner
		* \param rkV1                                 Second corner
		* \param rkV2                                 Third corner
		* \param rkNormal                             Optional precalculated normal
		* \return                                     true if intersection, false otherwise
		*/
		virtual bool                                  Intersection( const Vector3d &rkV0, const Vector3d &rkV1, const Vector3d &rkV2, const Vector3d &rkNormal = Vector3d::ORIGO );
};


};


#endif
