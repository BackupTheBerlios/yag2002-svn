/***************************************************************************
                      bitparser.h  -  Bit stream parser
                             -------------------
    begin                : Mon Feb 18 2002
    copyright            : (C) 2002 by David Holm
    email                : david@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, bitparser.h

 The Initial Developer of the Original Code is David Holm
 Portions created by David Holm are Copyright (C) 2002
 David holm. All Rights Reserved.

 Contributors: Mattias Jansson (mattias@realityrift.com)

 ***************************************************************************/


#ifndef __NEBITPARSER_H
#define __NEBITPARSER_H


#include "base.h"


/**
  * \file bitparser.h
  * Read bits from stream
  */


namespace NeoEngine
{


/**
  * \brief Read bits from a stream
  * A bitstream parser, capable of reading up to 0 to 32 bits from a stream
  * in one method call.
  * \author Mattias Jansson (mattias@realityrift.com)
  * \author David Holm (david@realityrift.com)
  */
class NEOENGINE_API BitParser
{
	protected:
	
		/*! Base stream pointer */
		uint8_t                                      *m_pucBase;

		/*! Current stream pointer */
		uint8_t                                      *m_pucBits;
		
		/*! Bit offset */
		uint8_t                                       m_ucBitOffset;
		
		/*! Byte offset */
		uint64_t                                      m_ulByteOffset;
				
		
	public:
		
		/**
		* Initialize bitstream parser
		* \param pucBitstream                         Bit stream pointer
		*/
		                                              BitParser( uint8_t *pucBitstream = 0 ) : m_pucBase( pucBitstream ), m_pucBits( pucBitstream ), m_ucBitOffset(0), m_ulByteOffset(0) {}
		
		/**
		*/
		virtual                                      ~BitParser();

		/**
		* Read bits from stream
		* \param iBits                                Number of bits to read
		* \return                                     Value read
		*/
		virtual uint32_t                              ReadBits( int32_t iBits );
		
		/**
		* Align bits in stream to next even byte
		*/
		virtual void                                  Align();

		/**
		* Seek in stream
		* \param iBits                                Number of bits to seek from offset
		* \param iMode                                Seek mode, like normal fseek modes (SEEK_CUR, SEEK_END, SEEK_SET)
		*/
		virtual void                                  Seek( int32_t iBits, int32_t iMode );
		
		/**
		* Set new read pointer. Also resets offset to zero (start of stream)
		* \param pucBitstream                         Bitstream pointer
		*/
		virtual void                                  SetPointer( uint8_t *pucBitstream );
		
		/**
		* \return                                     Byte offset from start of stream
		*/
		uint64_t                                      GetByteOffset() { return m_ulByteOffset; }

		/**
		* \return                                     Bit offset from start of stream
		*/
		uint64_t                                      GetBitOffset() { return( ( m_ulByteOffset * 8 ) + m_ucBitOffset ); }
};


};


#endif

