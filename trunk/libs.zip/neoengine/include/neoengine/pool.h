/***************************************************************************
                       pool.h  -  Multi-node hash table
                             -------------------
    begin                : Wed Feb 12 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, pool.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEPOOL_H
#define __NEPOOL_H


/**
  * \file pool.h
  * A pool is a hash table with mutliple objects per key
  */


#ifndef __NEED_VECTOR_STRING
#  define __NEED_VECTOR_STRING
#endif

#include "base.h"
#include "hash.h"
#include "hashstring.h"

#include <vector>


namespace NeoEngine
{


/**
  * \brief Pool node template
  * The pool table node is a container object for the key string and the data objects associated with the key
  * \author Mattias Jansson (mattias@realityrift.com)
  */
template < class PoolDataType > class PoolNode
{
	public:

		typedef std::vector< PoolDataType* >          PoolDataVec;

		/*! Key name */
		HashString                                    m_strKey;

		/*! Data */
		PoolDataVec                                   m_vpkData;


		/**
		* \param rstrKey                              Key name
		* \param pkData                               Data
		*/
		inline                                        PoolNode( const HashString &rstrKey, PoolDataType *pkData );
};



/**
  * \brief Pool template
  * A pool is a hash table with mutliple objects per key. For more detailed
  * description of the properties, read the HashTable documentation concerning
  * the management and non-deletion principle of the data.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
template < class PoolDataType > class Pool
{
	public:

		typedef PoolNode< PoolDataType >              PoolNodeType;
		typedef std::vector< PoolNodeType  >          PoolNodeVec;	
		typedef std::vector< PoolNodeType* >          PoolNodePtrVec;	
		typedef std::vector< PoolDataType* >          PoolDataVec;

		/**
		* \brief Pool defines
		*/
		enum POOLDEF
		{
		  /*! Default number of buckets */
		  DEFAULTSIZE                                 = 256
		};


	protected:

		/*! Pool */
		PoolNodeVec                                  *m_pvkTable;

		/*! Number of rows in table */
		int                                           m_iSize;


		/**
		* Helper method to lookup a node
		* \param rstrKey                              Key name
		* \param iIndex                               Precalculated hash index
		* \return                                     Node associated with key
		*/
		inline PoolNodeType                          *LookupNode( const HashString &rstrKey, int iIndex = 0 );

		
	public:

		/**
		* \param iSize                                Initial size of table
		*/
		                                              Pool( int iSize = DEFAULTSIZE );

		/**
		*/
		                                             ~Pool();


		/**
		* Insert key value into pool
		* \param rstrKey                              Key name
		* \param pkData                               Data pointer
		*/
		void                                          Insert( const HashString &rstrKey, PoolDataType *pkData );

		/**
		* Find data for key
		* \param rstrKey                              Key name
		* \return                                     Vector with data pointers if key found, 0 if not found
		*/
		const PoolDataVec                            *Find( const HashString &rstrKey );

		/**
		* Remove data from pool
		* \param rstrKey                              Key name
		* \param pkData                               Data ptr
		*/
		void                                          Delete( const HashString &rstrKey, PoolDataType *pkData );

		/**
		* \param pvpkVector                           Vector recieving all nodes
		*/
		void                                          GetAllNodes( PoolNodePtrVec *pvpkVector );

		/**
		* \param pvpkVector                           Vector recieving all node data pointers
		*/
		void                                          GetAllNodeData( PoolDataVec *pvpkVector );
};



//Macro for easy typing
#define PoolExport(classname)

#include "pool_inl.h"

};


#endif

