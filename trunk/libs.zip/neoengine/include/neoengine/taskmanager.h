/***************************************************************************
                          taskmanager.h  -  description
                             -------------------
    begin                : Tue Feb 12 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, taskmanager.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NETASKMANAGER_H
#define __NETASKMANAGER_H


#include "base.h"
#include "mutex.h"
#include "thread.h"

#include <vector>


/**
  * \file taskmanager.h
  * Task management
  */

namespace NeoEngine
{


#ifdef WIN32
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif
#  ifndef __HAVE_VECTOR_THREAD
     UDTVectorEXPIMP( class Thread* );
#    define __HAVE_VECTOR_THREAD
#  endif
#  ifndef __HAVE_VECTOR_THREADMETHOD
     UDTVectorEXPIMP( class ThreadMethod* );
#    define __HAVE_VECTOR_THREADMETHOD
#  endif
#endif


/**
  * \brief Managing tasks in threads
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API TaskManager : public MutexObject
{
	friend class Thread;

	protected:
	
		/*! Worker threads */
		std::vector< Thread* >                 m_vpkThreads;
		
		/*! Task queue */
		std::vector< ThreadMethod* >           m_vpkQueue;
		
		/*! Max number of active worker threads */
		unsigned int                           m_iMaxThreads;

		
		/**
		* Remove terminated thread from worker vector
		* \param pkThread                      Thread to remove
		*/
		void                                   Remove( Thread *pkThread );
				

	public:
	
		/**
		* Create manager with worker threads
		* \param iWorkerThreads                Number of worker threads
		*/
		                                       TaskManager( int iWorkerThreads );
		
		/**
		* Terminate all worker threads and clear queue
		*/		
		virtual                               ~TaskManager();
		
		/**
		* Add task
		* \param pkTask                        Task method
		*/
		void                                   Schedule( ThreadMethod *pkTask );
};


}; // namespace NeoEngine


#endif /* __NETASKMANAGER_H */

