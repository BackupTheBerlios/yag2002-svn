/***************************************************************************
                        core.h  -  Core engine object
                             -------------------
    begin                : Mon Jun 28 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, core.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NECORE_H
#define __NECORE_H

#include "base.h"

#include <string>


/**
  * \file core.h
  * Core engine object
  */


/**
* \brief Engine namespace
* All classes, global objects and other symbols are placed
* inside this namespace. To save some typing, use the construct
* <b>using namespace NeoEngine;</b>
* in your source files. We advise against using the "using" keyword
* in headers, or you can get problems with other headers/source
* files including it and not expecting to bring all symbols from
* the namespace into global scope
*/
namespace NeoEngine
{


// External classes
class ModuleManager;
class Material;
class Console;
class Config;
class FontManager;
class RoomManager;
class TerrainManager;
class Font;
class Mesh;
class ProfileManager;
class RenderDevice;
class InputDevice;
class InputManager;
class FileManager;
class LogSink;
class AudioDevice;

template < class T > class HashTable;
template < class T > class Pool;

typedef HashTable< Material > MaterialTable;
typedef Pool< Mesh >          MeshPool;


// Internal private class you'll never see made public.. a la GTK-style, woo!
struct TerrainPrivate;



/**
  * \brief Core engine object
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Core
{
	public:

		/**
		* \brief Byte order of system
		*/
		enum BYTEORDER
		{
		  /*! System is little endian (x86) */
		  BYTEORDER_LITTLEENDIAN,
		  
		  /*! System is big endian (ppc) */
		  BYTEORDER_BIGENDIAN
		};



	public:

		//******** PROCESSOR AND SYSTEM ATTRIBUTES AND FEATURES ********//

		/*! System byte order */
		static const BYTEORDER                        BYTEORDER_SYSTEM;

#ifdef __APPLE__

		/*! Flag indicating AltiVec support in CPU */
		int                                           m_iHasAltiVec;

#endif


#if defined( ARCH_X86 ) || defined( ARCH_X86_64 )

		/*! Flag indicating MMX support in CPU */
		int                                           m_iHasMMX;

		/*! Flag indicating FXSR support in CPU */
		int                                           m_iHasFXSR;

		/*! Flag indicating SSE support in CPU */
		int                                           m_iHasSSE;

		/*! Flag indicating SSE2 support in CPU */
		int                                           m_iHasSSE2;

		/*! Flag indicating 3DNow! support in CPU */
		int                                           m_iHas3DNow;

		/*! Flag indicating 3DNowEx! support in CPU */
		int                                           m_iHas3DNowEx;

#endif

	private:

		/*! Singleton object */
		static NE_STATIC Core                        *s_pkSingleton;


	protected:

		//******** CORE ENGINE OBJECTS ********//

		/*! Module manager */
		static ModuleManager                         *s_pkModuleManager;

		/*! File manager */
		FileManager                                  *m_pkFileManager;

		/*! Input manager */
		InputManager                                 *m_pkInputManager;

		/*! Material manager */
		MaterialTable                                *m_pkMaterialManager;

		/*! Mesh blueprint manager */
		MeshPool                                     *m_pkMeshManager;

		/*! Room manager */
		RoomManager                                  *m_pkRoomManager;

		/*! Terrain manager */
		TerrainManager                               *m_pkTerrainManager;

		/*! Terrain private stuff */
		TerrainPrivate                               *m_pkTerrainPrivate;

		/*! Font manager */
		FontManager                                  *m_pkFontManager;

		/*! Profile manager */
		ProfileManager                               *m_pkProfileManager;

		/*! Console */
		Console                                      *m_pkConsole;

		/*! Configuration repository */
		Config                                       *m_pkConfig;

		/*! Render device */
		RenderDevice                                 *m_pkRenderDevice;

		/*! stdout sink object */
		LogSink                                      *m_pkStdoutSink;

		/*! Audio device */
		AudioDevice                                  *m_pkAudioDevice;


		/**
		* Prevent outside allocations
		*/
		                                              Core();


	public:


		/**
		*/
		virtual                                      ~Core();


		//******** INITIALIZATION AND SHUTDOWN METHODS ********//

		/**
		* Initialize engine. Setup core object and services
		* \param iArgs                                Number of arguments in command line argument array
		* \param ppszArgs                             Command line argument array
		* \return                                     Error code
		*/
		int                                           Initialize( int iArgs, char **ppszArgs );

		/**
		* Shutdown engine. Deallocates core object and services
		* \return                                     Error code
		*/
		int                                           Shutdown();


		//******** INPUT DEVICE METHODS ********//

		/**
		* Create new input device. You must use this method to create a new input device, 
		* it will automatically try to load the needed module if not already loaded and 
		* call the needed initialization methods.
		* Unless you do your own housekeeping with your own input managers
		* (i.e not the core objects) you should not pass any arguments for these but
		* let them remain as default values, null. This will cause the device to use
		* the core manager objects.
		* \param rstrName                             Device name
		* \param pkRenderDevice                       Render device from which the window will be used. If this parameter is null (default), the core render device will be used
		* \param pkInputManager                       Input manager to link to (render device is also an input device). If this parameter is null (default), the core input manager will be used
		* \return                                     Pointer to new input device, null if failed
		*/
		InputDevice                                  *CreateInputDevice( const std::string &rstrName, RenderDevice *pkRenderDevice = 0, InputManager *pkInputManager = 0 );

		/**
		* Delete input device object. You must use this methods to delete an input device,
		* since it calls the needed shutdown methods and correctly frees the loadable module
		* if it is no longer needed. Failure to do so will result in resource leaks and/or
		* strange crashes.
		* \param pkDevice                             Input device to delete
		*/
		void                                          DeleteInputDevice( InputDevice *pkDevice );


		//******** RENDER DEVICE METHODS ********//

		/**
		* Create new render device (will set render device pointer in core). You must use
		* this method to create a new render device, it will automatically try to load
		* the needed module if not already loaded and call the needed initialization methods.
		* Unless you do your own housekeeping with your own file and input managers
		* (i.e not the core objects) you should not pass any arguments for these but
		* let them remain as default values, null. This will cause the device to use
		* the core manager objects.
		* \param rstrName                             Device name
		* \param pkFileManager                        File manager used by device to locate textures and other resource files. If this parameter is null (default), the core file manager will be used
		* \param pkInputManager                       Input manager to link to (render device is also an input device). If this parameter is null (default), the core input manager will be used
		* \return                                     Pointer to new render device, null if failed
		*/
		RenderDevice                                 *CreateRenderDevice( const std::string &rstrName, FileManager *pkFileManager = 0, InputManager *pkInputManager = 0 );

		/**
		* Delete render device object. You must use this methods to delete a render device,
		* since it calls the needed shutdown methods and correctly frees the loadable module
		* if it is no longer needed. Failure to do so will result in resource leaks and/or
		* strange crashes.
		* \param pkDevice                             Render device to delete
		*/
		void                                          DeleteRenderDevice( RenderDevice *pkDevice );

		/**
		* Set the render device pointer in the core. Useful if you have a multi-device application
		* \param pkDevice                             New active core render device
		* \return                                     Old render device
		*/
		RenderDevice                                 *SetRenderDevice( RenderDevice *pkDevice );


		//******** AUDIO DEVICE METHODS ******//
		/**
		* Creates an audio device by name. supported names are "openal" and "dsound"
		* \param rstrName                             Name of the audio device to open
		* \param pkFileManager                        File manager used by device to locate sounds and other resource files. If this parameter is null (default), the core file manager will be used
		* \return                                     Pointer to the audio device
		*/
		AudioDevice                                  *CreateAudioDevice( const std::string &rstrName, FileManager *pkFileManager = 0 );

		/**
		* Deletes a previously created audio device
		* \param pkDevice                             Pointer to the audio device
		*/
		void                                          DeleteAudioDevice( AudioDevice *pkDevice );

		/**
		* Set the audio device pointer in the core. Useful if you have a multi-device application
		* \param pkDevice                             New active core audio device
		* \return                                     Old audio device
		*/
		AudioDevice                                  *SetAudioDevice( AudioDevice *pkDevice );




		//******** ACCESS METHODS ********//

		/**
		* \return                                     Module manager
		*/
		static ModuleManager                         *GetModuleManager();

		/**
		* \return                                     File manager
		*/
		inline FileManager                           *GetFileManager() { return m_pkFileManager; }

		/**
		* \return                                     Input manager
		*/
		inline InputManager                          *GetInputManager() { return m_pkInputManager; }

		/**
		* \return                                     Font manager
		*/
		inline FontManager                           *GetFontManager() { return m_pkFontManager; }

		/**
		* \return                                     Material manager
		*/
		inline MaterialTable                         *GetMaterialManager() { return m_pkMaterialManager; }

		/**
		* \return                                     Mesh blueprint manager
		*/
		inline MeshPool                              *GetMeshManager() { return m_pkMeshManager; }

		/**
		* \return                                     Room manager
		*/
		inline RoomManager                           *GetRoomManager() { return m_pkRoomManager; }

		/**
		* \param rstrName                             Terrain type
		*/
		void                                          InitializeTerrain( const std::string &rstrName );

		/**
		* \return                                     Terrain manager
		*/
		inline TerrainManager                        *GetTerrainManager() { return m_pkTerrainManager; }

		/**
		* \return                                     Profile manager
		*/
		inline ProfileManager                        *GetProfileManager() { return m_pkProfileManager; }

		/**
		* \return                                     Console
		*/
		inline Console                               *GetConsole() { return m_pkConsole; }

		/**
		* \return                                     Configuration repository
		*/
		inline Config                                *GetConfig() { return m_pkConfig; }

		/**
		* \return                                     Render device
		*/
		inline RenderDevice                          *GetRenderDevice() { return m_pkRenderDevice; }

		/**
		* \return                                     Current audio device
		*/
		inline AudioDevice                           *GetAudioDevice() { return m_pkAudioDevice; }

		/**
		* \return                                     stdout sink object
		*/
		inline LogSink                               *GetStdoutSink() { return m_pkStdoutSink; }



		//******** REPLACEMENT METHODS ********//

		/**
		* Set a new core console object. Old console object will be deleted
		* \param pkConsole                            New core console object
		*/
		void                                          SetConsole( Console *pkConsole );



		//******** SINGLETON ACCESS ********** //

		/**
		* Access the singleton core object
		* \return                                     Core object
		*/
		inline static Core                           *Get() { if( !s_pkSingleton ) s_pkSingleton = new Core; return s_pkSingleton; }
};


};


#endif

