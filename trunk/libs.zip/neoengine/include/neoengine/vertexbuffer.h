/***************************************************************************
            vertexbuffer.h  -  Vertex buffers with flexible format
                             -------------------
    begin                : Tue Oct 30 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, vertexbuffer.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEVERTEXBUFFER_H
#define __NEVERTEXBUFFER_H


/**
  * \file neoengine/vertexbuffer.h
  * Vertex buffers with flexible format
  */


#include "base.h"
#include "vertexdecl.h"
#include "buffer.h"
#include "util.h"


namespace NeoEngine
{


/**
  * \brief Vertex storage in buffer
  * Vertex buffer with flexible format, with possible agp/video ram storage managed by device
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API VertexBuffer : public Buffer
{
	friend class RenderDevice;

	protected:

		/*! Vertex format declaration */
		VertexDeclaration                            *m_pkVertexFormat;

		/*! Size of a vertex */
		unsigned int                                  m_uiVertexFormatSize;

		/*! Real buffer pointer */
		unsigned char                                *m_pucBuffer;

		/*! Read/write access buffer pointer */
		unsigned char                                *m_pucVertices;


		/**
		* Called by Lock. Lock type member m_uiLock has been set at this point
		* \return                                     true if lock successful, false if not
		*/
		virtual bool                                  AcquireLock() { m_pucVertices = m_pucBuffer; return true; }

		/**
		* Called by Unlock when a lock should be released. Lock type member m_uiLock is still holding lock type at this point.
		*/
		virtual void                                  ReleaseLock() { m_pucVertices = 0; }


		
				
	public:

		/**
		* \param uiType                               Buffer type
		* \param uiNumVertices                        Number of vertices to allocate memory for
		* \param pkFormat                             Vertex format declaration
		* \param pData                                Optional pointer to data to load buffer with
		*/
		                                              VertexBuffer( unsigned int uiType, unsigned int uiNumVertices, const VertexDeclaration *pkFormat, const void *pData = 0 );

		/**
		*/
		virtual                                      ~VertexBuffer();

		/**
		* Resize buffer. There must not be any active lock held on buffer when calling this method
		* \param uiNumVertices                        New vertex count
		* \param pkFormat                             Vertex format declaration
		* \param pData                                Optional pointer to data to copy
		*/
		virtual void                                  AllocateVertices( unsigned int uiNumVertices, const VertexDeclaration *pkFormat, const void *pData = 0 );

		/**
		* Load data into buffer. Data must have same internal layout and size as vertex buffer format.
		* An active WRITE lock must have been acquired on the buffer prior to calling this method.
		* \param pData                                Vertex data (will read m_uiNumVertices vertices)
		*/
		inline void                                   LoadVertexData( const void *pData ) { fmemcpy( m_pucVertices, pData, m_uiVertexFormatSize * m_uiNumCurrent ); }

		/**
		* Get ptr to element
		* \param uiElement                            Element to access
		*/
		inline void                                  *GetVertex( unsigned int uiElement = 0 ) { return( m_pucVertices + ( m_uiVertexFormatSize * uiElement ) ); }

		/**
		* \return                                     Vertex format declaration
		*/
		inline const VertexDeclaration               *GetVertexFormat() const { return m_pkVertexFormat; }

		/**
		* Get size of a single element in array
		* \return                                     Element size in bytes
		*/
		inline unsigned int                           GetVertexSize() const { return m_uiVertexFormatSize; }

		/**
		* Get pointer to render data. Used by derived buffer classes in device with AGP/video RAM storage to return
		* pointer to data used for rendering.
		* \return                                     Render data pointer 
		*/
		virtual const void                           *GetRenderData() { return m_pucBuffer; }
};


#ifndef __HAVE_SMARTPOINTER_NEVERTEXBUFFER
   //Define smart pointer
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif
   SmartPointer( VertexBuffer );
#  define __HAVE_SMARTPOINTER_NEVERTEXBUFFER
#endif


};


#endif
