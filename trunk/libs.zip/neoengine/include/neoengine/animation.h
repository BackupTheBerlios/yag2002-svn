/***************************************************************************
                   animation.h  -  Template base for animations
                             -------------------
    begin                : Fri Nov 23 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, animation.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEANIMATION_H
#define __NEANIMATION_H


#include "base.h"
#include "hashstring.h"
#include "updateentity.h"

#include <vector>

#include <assert.h>


/**
  * \file animation.h
  * Template base for animations
  */


namespace NeoEngine
{


/**
  * \brief An animation is a collection of ordered keyframes
  * \author Mattias Jansson (mattias@realityrift.com)
  */
template < class KeyframeType > class Animation : public virtual UpdateEntity
{
	public:

		typedef std::vector< KeyframeType* >          KeyframeVec;

		/*! Keyframes ordered by timestamp */
		KeyframeVec                                   m_vpkKeyframes;

		/*! Animation ID */
		unsigned int                                  m_uiID;

		/*! Animation name */
		HashString                                    m_strName;

		/*! Lenght of animation in seconds */
		float                                         m_fLength;

		/*! Current time in [0,1] interval */
		float                                         m_fCurTime;

		/*! Last keyframe */
		int                                           m_iLastKeyframe;

		/*! Next keyframe */
		int                                           m_iNextKeyframe;

		/*! Current time offset from last keyframe to next keyframe (in [0,1] range) */
		float                                         m_fOffset;


		/**
		* Set default values
		*/
		                                              Animation();

		/**
		* Copy data from reference animation object
		* \param rkAnimation                          Reference object
		*/
		                                              Animation( const Animation< KeyframeType > &rkAnimation );

		/**
		* Delete keyframes
		*/
		virtual                                      ~Animation();

		/**
		* Insert new keyframe
		* \param pkKeyframe                           New keyframe
		*/
		inline virtual void                           AddKeyframe( KeyframeType *pkKeyframe );

		/**
		* Update animation
		* \param fDeltaTime                           Deltatime passed since last update
		*/
		inline virtual void                           Update( float fDeltaTime );
};


#include "animation_inl.h"


};


#endif
