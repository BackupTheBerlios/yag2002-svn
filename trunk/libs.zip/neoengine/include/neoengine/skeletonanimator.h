/***************************************************************************
 skeletonanimator.h  -  Animator controller classes for skeletons and bones
                             -------------------
    begin                : Tue Mar 4 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, skeletonanimator.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NESKELETONANIMATOR_H
#define __NESKELETONANIMATOR_H


/**
  * \file skeletonanimator.h
  * Animator controller classes for skeletons and bones
  */


#include "base.h"
#include "animator.h"
#include "nodeanimator.h"

#include <vector>


namespace NeoEngine
{


// External classes
class Skeleton;


/**
  * \brief A skeleton animation consists of a node animation object for each channel (bone)
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SkeletonAnimation : public virtual Activator
{
	public:

		/*! Node animation objects */
		std::vector< NodeAnimation* >      m_vpkChannels;

		/*! Animation ID */
		unsigned int                       m_uiID;

		/*! Animation name */
		HashString                         m_strName;

		/*! Lenght of animation in seconds */
		float                              m_fLength;

		/*! Current time in [0,1] interval */
		float                              m_fCurTime;


		/**
		*/
		                                   SkeletonAnimation();

		/**
		* \param rkAnimation               Reference animation object
		*/
		                                   SkeletonAnimation( const SkeletonAnimation &rkAnimation );

		/**
		*/
		virtual                           ~SkeletonAnimation();

		/**
		* Update all channel animations
		* \param fDeltaTime                Delta time passed since last update
		*/
		virtual void                       Update( float fDeltaTime );
};


#ifdef WIN32

#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif

#  ifndef __HAVE_VECTOR_NESKELETONANIMATION
     UDTVectorEXPIMP( class SkeletonAnimation* );
#    define __HAVE_VECTOR_NESKELETONANIMATION
#  endif

#  ifdef _MSC_VER
#    ifndef __HAVE_NEANIMATIONBLENDSTAGE_NESKELETONANIMATION
       EXPIMP_TEMPLATE template class NEOENGINE_API AnimationBlendStage< SkeletonAnimation >;
#      define __HAVE_NEANIMATIONBLENDSTAGE_NESKELETONANIMATION
#    endif
#    ifndef __HAVE_VECTOR_NEANIMATIONBLENDSTAGE_NESKELETONANIMATION
       UDTVectorEXPIMP( AnimationBlendStage< SkeletonAnimation >* );
#      define __HAVE_VECTOR_NEANIMATIONBLENDSTAGE_NESKELETONANIMATION
#    endif
#    ifndef __HAVE_NEANIMATORCONTROLLER_NESKELETONANIMATION
       EXPIMP_TEMPLATE template class NEOENGINE_API AnimatorController< class SkeletonAnimation >;
#      define __HAVE_NEANIMATORCONTROLLER_NESKELETONANIMATION
#    endif
#  endif

#endif


/**
  * \brief Animator controller for skeletons
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API SkeletonAnimatorController : public AnimatorController< SkeletonAnimation >
{
	protected:

		/**
		* Blend in a new stage in final data
		* \param pkDstAnim                             Destination animation
		* \param fWeight                               Blend weight factor
		* \param pvbMask                               Mask array
		*/
		virtual void                                   BlendStage( SkeletonAnimation *pkDstAnim, float fWeight, std::vector< bool > *pvbMask );


	public:

		/*! The skeleton object we animate */
		Skeleton                                      *m_pkSkeleton;


		/**
		*/
		                                               SkeletonAnimatorController() : AnimatorController< SkeletonAnimation >() {}

		/**
		* \param rkController                          Reference controller object to copy
		*/
		                                               SkeletonAnimatorController( const SkeletonAnimatorController &rkController ) : AnimatorController< SkeletonAnimation >( rkController ) {}

		/**
		*/
		virtual                                       ~SkeletonAnimatorController() {}
};


};


#endif
