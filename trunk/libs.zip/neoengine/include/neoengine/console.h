/***************************************************************************
                console.h  -  Drop-down console with built-in font
                             -------------------
    begin                : Thu Feb 21 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, console.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NECONSOLE_H
#define __NECONSOLE_H


/**
  * \file console.h
  * Dropdown console for in-game debugging
  */


#ifndef __NEED_VECTOR_STRING
#  define __NEED_VECTOR_STRING
#endif

#include "base.h"
#include "renderentity.h"
#include "inputentity.h"
#include "callback.h"
#include "logstream.h"
#include "font.h"
#include "vertexbuffer.h"
#include "polygonbuffer.h"
#include "material.h"

#include <vector>


namespace NeoEngine
{


/**
  * \brief Data for a command
  * A console command is identified with a string (case sensetive)
  * and matched to a callback object, receiving the command and arguments
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API ConsoleCmd
{
	public:

		/*! Command */
		HashString                                    m_strCmd;

		/*! Callback object (not deleted) */
		ConsoleCmdCallback                           *m_pkCallback;

		/**
		* \param rstrCmd                              Command
		* \param pkCallback                           Callback
		*/
		                                              ConsoleCmd( const HashString &rstrCmd, ConsoleCmdCallback *pkCallback ) : m_strCmd( rstrCmd ), m_pkCallback( pkCallback ) {}
};



#ifdef WIN32
#  ifndef __HAVE_VECTOR_CONSOLECMD
     UDTVectorEXPIMP( ConsoleCmd* );
#    define __HAVE_VECTOR_CONSOLECMD
#  endif
#endif


/**
  * \brief Dropdown console for easy debugging
  * A console is a semi-transparent quad rendered in orthographic mode
  * displaying the debug output sent to it. A console also has a prompt
  * that supports registering commands (and default fallback).
  *
  * A console is also a log sink that you can attach to a log source
  * to get log messages printed in the console. Example:
  * <pre>
  * neolog.AttachSink( Core::Get()->GetConsole() );
  * </pre>
  * This will attach the core console object as a log sink to the global
  * neolog log source.
  *
  * For an example on how to use the command callbacks, look at the documentation
  * for the ConsoleCmdCallback class.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Console : public RenderEntity, public InputEntity, public LogSink
{
	friend class Core;

	public:

		/**
		* Console defines and default values
		*/
		enum CONSOLEDEFS
		{
		  /*! Default history length */
		  DEFAULTHISTORY                              = 200
		};


	protected:

		/*! Messages */
		std::vector< std::string >                    m_vstrHistory;

		/*! Font */
		FontPtr                                       m_pkFont;
		
		/*! Current command */
		std::string                                   m_strCmd;

		/*! Registered commands */
		std::vector< ConsoleCmd* >                    m_vpkCommands;

		/*! x coordinate */
		int                                           m_iX;

		/*! y coordinate */
		int                                           m_iY;

		/*! Width */
		int                                           m_iWidth;

		/*! Height */
		int                                           m_iHeight;

		/*! Default callback object */
		ConsoleCmdCallback                           *m_pkDefaultCallback;

		/*! Vertex buffer */
		VertexBufferPtr                               m_pkVertexBuffer;

		/*! Polygon buffer */
		PolygonBufferPtr                              m_pkPolygonBuffer;

		/*! Material */
		MaterialPtr                                   m_pkMaterial;

		/*! History length */
		unsigned int                                  m_uiHistory;


		/*! Default console font */
		static FontPtr                                s_pkDefaultFont;


		/**
		* Process command entered in console
		* \param rstrCmd                              Command string
		* \return                                     true if command was processed, false if not
		*/
		virtual bool                                  ProcessCmd( const std::string &rstrCmd );


	public:

		/**
		* \param uiHistory                            Number of lines in history
		*/
		                                              Console( unsigned int uiHistory = DEFAULTHISTORY );

		/**
		* Deallocate memory
		*/
		virtual                                      ~Console();

		/**
		* Render object
		* \param pkFrustum                            Current view frustum (if any), ignored
		* \param bForce                               Render even if rendered previously this frame (default false)
		* \return                                     true if we were rendered, false if not (already rendered, not forced)
		*/
		virtual bool                                  Render( Frustum *pkFrustum = 0, bool bForce = false );
		
		/**
		* Set font
		* \param pkFont                               Font
		*/
		void                                          SetFont( FontPtr pkFont );

		/**
		* \return                                     Current font
		*/
		const FontPtr                                &GetFont() const { return m_pkFont; }

		/**
		* Process input
		* \param pkEvent                              Event
		*/
		virtual void                                  Input( const InputEvent *pkEvent );
		
		/**
		* Write log sink data to console
		* \param rstrMsg                              Log message
		*/
		virtual void                                  Write( const std::string &rstrMsg );

		/**
		* Register new command
		* \param rstrCmd                              Command
		* \param pkCallback                           Callback object
		* \return                                     true if registered successfully, false if error (already registered)
		*/
		bool                                          RegisterCommand( const HashString &rstrCmd, ConsoleCmdCallback *pkCallback );

		/**
		* Register default callback (not deleted)
		* \param pkCallback                           Default callback object
		*/
		void                                          RegisterDefaultCallback( ConsoleCmdCallback *pkCallback );

		/**
		* Set position and dimensions of console "window". All arguments are in pixels
		* \param iX                                   x coordinate
		* \param iY                                   y coordinate
		* \param iWidth                               width (a value of -1 means to cover whole screen from x coordinate to right edge)
		* \param iHeight                              height (like width, a -1 value indicates whole screen from y coordinate)
		*/
		void                                          SetDimensions( int iX = 0, int iY = 0, int iWidth = -1, int iHeight = -1 );

		/**
		* Delete buffers. Only for internal use
		*/
		void                                          DeleteBuffers();

		/**
		* Clear the console history
		*/
		void                                          Clear();

		/**
		* Load default font
		*/
		static void                                   LoadDefaultFont();

		/**
		* Get default console font. Will load font if not previously loaded
		* \return                                     Default console font object
		*/
		static FontPtr                                GetDefaultFont();

		/**
		* Unload default font
		*/
		static void                                   UnloadDefaultFont();
};


}; // namespace NeoEngine


#endif
