/***************************************************************************
                  base.h  -  Base defines, macros and types
                             -------------------
    begin                : Tue Oct 30 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, base.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#if defined(WIN32) && defined(_MSC_VER)

/* disable warnings on 255 char debug symbols */
#  pragma warning( disable : 4786 )
  
/* disable warnings on extern before template instantiation */
#  pragma warning( disable : 4231 )

#endif


#ifndef __NEBASE_H
#define __NEBASE_H

/*#if defined(WIN32)
  #  include "buildconfig-win32.h"
  #endif*/

#if defined( NEOENGINE_INTERNALS ) && defined( HAVE_CONFIG_H )
#  include "buildconfig.h"
#endif

#if defined( WIN32 )
#  if !defined( NOGDI ) && !defined( NEEDGDI )
#    define NOGDI
#  endif
#  define NOMINMAX
#endif

/* Default to POSIX if undefined platform */
#if !defined( POSIX ) && !defined( WIN32 ) && !defined( __APPLE__ )
#  define POSIX
#endif

/**
  * \file neoengine/base.h
  * Base defines, macros and types for engine
  */


#define NEOENGINEVERSION_MAJOR             0
#define NEOENGINEVERSION_MINOR             8
#define NEOENGINEVERSION_REVISION          3

#define NEOENGINEVERSIONSTRING             "0.8.3"

#ifdef __APPLE__

   /* Only PPC architectures under Win32 */
#  ifndef ARCH_PPC
#    define ARCH_PPC
#  endif

#  ifdef ARCH_X86
#    undef  ARCH_X86
#  endif

#elif WIN32

   /* Only x86 architectures under Win32 */
#  ifndef ARCH_X86
#    define ARCH_X86
#  endif

#  ifdef ARCH_PPC
#    undef ARCH_PPC
#  endif

#  ifdef _MSC_VER

     /* MSVC++ */
#    define NEOENGINE_API
#    define EXPIMP_TEMPLATE

#    define NEOENGINE_ATTRIBUTE_PACKED
#    define NE_STATIC

#    ifdef __cplusplus
       /* disable warnings on non-standard extension bullshit */
#      pragma warning( disable : 4231 )

#      define UDTVectorEXPIMP(classname)
#    endif /* __cplusplus */

#    define snprintf _snprintf
#    define vsnprintf _vsnprintf

#  elif defined __MINGW32__

	/* Dev-C++ and Cygwin */
#    ifndef NOMINMAX
#      define NOMINMAX
#    endif
#    ifndef __need_size_t
#      define __need_size_t
#    endif

#    include <_mingw.h>

#    define NEOENGINE_ATTRIBUTE_PACKED

#    ifndef WIN32
#      define WIN32
#    endif

#    define NEOENGINE_API
#    define EXPIMP_TEMPLATE
#    define NEOENGINE_STATIC_API

#    define NE_STATIC NEOENGINE_API

#    define UDTVectorEXPIMP(classname)

#  else
#    error "Unsupported Win32 environment"
#  endif

#  define NE_CDECL __cdecl

#else

	/* Default to x86 architextures */
#  if !defined( ARCH_X86 ) && !defined( ARCH_PPC ) && !defined( ARCH_X86_64 )
#    define ARCH_X86
#  endif

	/* Default to Linux platform */
#  if !defined( LINUX ) && !defined( FREEBSD )
#    define LINUX
#    ifndef _GNU_SOURCE
#      define _GNU_SOURCE
#    endif
#  endif

#endif

#if defined( POSIX ) || defined( __APPLE__ )

#  define NEOENGINE_API
#  define NEOENGINE_ATTRIBUTE_PACKED __attribute__((packed))

#  define NE_STATIC
#  define NE_CDECL

#elif !defined( WIN32 )
#  error "Platform uninplemented"
#endif


#include "basetypes.h"

/*
#ifdef __APPLE__
#  define sqrtf(f)    sqrt(f)
#  define sinf(f)     sin(f)
#  define cosf(f)     cos(f)
#  define acosf(f)    acos(f)
#  define logf(f)     log(f)
#  define powf(x, y)  pow(x, y)
#endif
*/

#endif /* __NEBASE_H */
