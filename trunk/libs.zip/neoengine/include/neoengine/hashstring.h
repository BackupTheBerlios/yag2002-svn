/***************************************************************************
                 hashstring.h  -  Hashed version of std::string
                             -------------------
    begin                : Wed Oct 16 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, hashstring.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEHASHSTRING_H
#define __NEHASHSTRING_H


/**
  * \file neoengine/hashstring.h
  * Hashed version of std::string
  */


#include "base.h"
#include "hash.h"

#include <string>


namespace NeoEngine
{


/**
  * \brief Hashed version of std::string for faster comparision
  * The HashString stores a hash of the string for fast early-out comparision
  * with other hashed strings by comparing the hash, and only if equal compare
  * the actual string data. Overloads some useful operations of std::string
  * but not all, if you need to access the string data directly, remember to
  * call HashMe() if you modify it (not needed if you simply read from it, naturally)
  * \author Mattias Jansson (mattias@realityrift.com)
  * \author Robert A Balfe (rbalfe@attbi.com)
  */
class NEOENGINE_API HashString
{
	protected:

		/*! Hash value of string */
		unsigned int  	                              m_uiHash;


	public:

		/*! String data, if you modify this directly you must remember to call HashMe() to update the hash value */
		std::string                                   m_strData;


		/**
		* Empty string
		*/
		inline                                        HashString();

		/**
		* Copy string
		* \param rstrRef                              String to copy
		*/
		inline                                        HashString( const HashString &rstrRef );

		/**
		* Copy string
		* \param rstrRef                              String to copy
		*/
		inline                                        HashString( const std::string &rstrRef );

		/**
		* Construct from char array
		* \param pcRef                                String
		* \param iNum                                 Length
		*/
		inline                                        HashString( const char *pcRef, int iNum );

		/**
		* Construct from zero terminated string
		* \param pszRef                               String
		*/
		inline                                        HashString( const char *pszRef );

		/**
		* Fill string with data
		* \param iNum                                 Length
		* \param cData                                Character to fill string with
		*/
		inline                                        HashString( int iNum, const char cData );

		/**
		* Compare hashed strings
		* \param rstrRef                              String to compare with
		* \return                                     true if equal, false if not
		*/
		inline bool                                   Compare( const HashString &rstrRef ) const;

		/**
		* Compare hash values
		* \param uiHash                               Hash value
		* \return                                     true if our hash equals, false if not
		*/
		inline bool                                   Compare( unsigned int uiHash ) const;

		/**
		* \return                                     Hash value
		*/
		inline unsigned int                           GetHash() const;

		/**
		* Calculate hash value of string
		* \return                                     Hashed string object (this)
		*/
		inline HashString                            &HashMe();

		/**
		* \return                                     Length of string
		*/
		inline size_t                                 length() const;

		/**
		* \return                                     pointer to C-style string
		*/
		inline const char                            *c_str() const;

		/**
		* Compare hashed strings
		* \param rstrRef                              String to compare with
		* \return                                     true if equal, false if not
		*/
		inline bool                                   operator == ( const HashString &rstrRef ) const;

		/**
		* Compare hash values
		* \param uiHash                               Hash value
		* \return                                     true if our hash equals, false if not
		*/
		inline bool                                   operator == ( unsigned int uiHash ) const;

		/**
		* Compare with std::string
		* \param rstrRef                              String to compare with
		* \return                                     true if strings equals, false if not
		*/
		inline bool                                   operator == ( const std::string &rstrRef ) const;

		/**
		* Compare with char ptr
		* \param pszRef                               String to compare with
		* \return                                     true if strings equals, false if not
		*/
		inline bool                                   operator == ( const char *pszRef ) const;

		/**
		* Compare hashed strings
		* \param rstrRef                              String to compare with
		* \return                                     true if equal, false if not
		*/
		inline bool                                   operator != ( const HashString &rstrRef ) const;

		/**
		* Compare hash values
		* \param uiHash                               Hash value
		* \return                                     true if our hash equals, false if not
		*/
		inline bool                                   operator != ( unsigned int uiHash ) const;

		/**
		* Compare with std::string
		* \param rstrRef                              String to compare with
		* \return                                     true if strings equals, false if not
		*/
		inline bool                                   operator != ( const std::string &rstrRef ) const;

		/**
		* Compare with char ptr
		* \param pszRef                               String to compare with
		* \return                                     true if strings equals, false if not
		*/
		inline bool                                   operator != ( const char *pszRef ) const;

		/**
		* Assign from hashed string
		* \param rstrRef                              String
		* \return                                     this
		*/
		inline HashString                            &operator = ( const HashString &rstrRef );

		/**
		* Assign from std::string
		* \param rstrRef                              String
		* \return                                     this
		*/
		inline HashString                            &operator = ( const std::string &rstrRef );

		/**
		* Assign from null-terminated char array
		* \param pszRef                               String
		* \return                                     this
		*/
		inline HashString                            &operator = ( const char *pszRef );

		/**
		* Concatenate string
		* \param rstrRef                              String to add to end of this string
		* \return                                     this
		*/
		inline HashString                            &operator += ( const HashString &rstrRef );

		/**
		* Concatenate string
		* \param rstrRef                              String to add to end of this string
		* \return                                     this
		*/
		inline HashString                            &operator += ( const std::string &rstrRef );

		/**
		* Concatenate string
		* \param pszRef                               Null-terminated string to add to end of this string
		* \return                                     this
		*/
		inline HashString                            &operator += ( const char *pszRef );

		/**
		* Implicit conversion to std::string
		*/
		inline                                        operator std::string &();

		/**
		* Implicit conversion to std::string
		*/
		inline                                        operator const std::string &() const;

		/**
		* Comparison
		* \param rstrString                           Reference string to compare with
		* \return                                     true if this string is less than reference
		*/
		inline bool                                   operator < ( const HashString &rstrString ) const;
};


/**
  * Stream operator for output HashString to stream
  * \param rkStream                           Stream
  * \param rkString                           Hash string object
  * \return                                   Stream
  */
NEOENGINE_API std::ostream                   &operator << ( std::ostream &rkStream, const HashString &rkString );


/**
* Concatenate strings
* \param rstrOne                              First string
* \param rstrTwo                              Second string
* \return                                     Resulting string
*/
inline HashString                             operator + ( const HashString &rstrOne, const HashString &rstrTwo );


/**
* Concatenate strings
* \param rstrOne                              First string
* \param rstrTwo                              Second string
* \return                                     Resulting string
*/
inline HashString                             operator + ( const HashString &rstrOne, const std::string &rstrTwo );


/**
* Concatenate strings
* \param rstrOne                              First string
* \param pszTwo                               Second string
* \return                                     Resulting string
*/
inline HashString                             operator + ( const HashString &rstrOne, const char *pszTwo );


/**
* Concatenate strings
* \param rstrOne                              First string
* \param rstrTwo                              Second string
* \return                                     Resulting string
*/
inline HashString                             operator + ( const std::string &rstrOne, const HashString &rstrTwo );


/**
* Concatenate strings
* \param pszOne                               First string
* \param rstrTwo                              Second string
* \return                                     Resulting string
*/
inline HashString                             operator + ( const char *pszOne, const HashString &rstrTwo );


#include "hashstring_inl.h"


};


#endif
