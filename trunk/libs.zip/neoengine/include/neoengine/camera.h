/***************************************************************************
                        camera.h  -  Base camera class
                             -------------------
    begin                : Sat Nov 3 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, camera.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NECAMERA_H
#define __NECAMERA_H


/**
  * \file camera.h
  * Camera class. Used for positioning and rendering
  */


#include "base.h"
#include "scenenode.h"

#include <string>


namespace NeoEngine
{


// External classes
class Room;


/**
  * \brief Main camera abstraction class. Use for rendering
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Camera : public SceneNode
{

	public:

		DefineVisitable();

	protected:

		/*! Room we are in */
		Room                                         *m_pkRoom;

		/*! Current active camera */
		static Camera                               *s_pkActiveCamera;


	public:

		/**
		* Create camera
		* \param rstrName                            Name
		* \param pkParent                            Parent node
		*/
		                                             Camera( const std::string &rstrName, SceneNode *pkParent = 0 );

		/**
		* Render camera
		* \param pkFrustum                           Ignored, will continue rendering with own frustum
		* \param bForce                              Force rendering of nodes even if already rendered
		* \return                                    true if successful, false if error
		*/
		virtual bool                                 Render( Frustum *pkFrustum = 0, bool bForce = false );

		/**
		* Sets current orientation derived from at and up vector
		* \param rkAt                                Vector indicating viewing direction
		* \param rkUp                                Vector indicating up direction
		*/
		void                                         LookAt( const Vector3d &rkAt, const Vector3d &rkUp );

		/**
		* \return                                    View matrix
		*/
		inline const Matrix                          &GetViewMatrix() { return GetInverseWorldTransform(); }

		/**
		* \return                                    Inverse view matrix
		*/
		const Matrix                                &GetInverseViewMatrix() { return GetWorldTransform(); }

		/**
		* Set room
		* \param pkRoom                              New room
		*/
		void                                         SetRoom( Room *pkRoom );

		/**
		* \return                                    Current room
		*/
		Room                                        *GetRoom() { return m_pkRoom; }

		/**
		* Set as active camera
		*/
		void                                         SetActive() { s_pkActiveCamera = this; }

		/**
		* \return                                    Active camera
		*/
		static Camera                               *GetActive() { return s_pkActiveCamera; }
};


}


#endif
