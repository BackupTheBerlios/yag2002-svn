/***************************************************************************
               massparticle.h  -  Massive particle physics node
                             -------------------
    begin                : Sat Jan 3 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, massparticle.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEMASSPARTICLE_H
#define __NEMASSPARTICLE_H


/**
  * \file massparticle.h
  * Massive particle physics node
  */


#include "base.h"
#include "physicsnode.h"

#include <vector>


namespace NeoEngine
{


/**
  * \brief State data for a mass particle object
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API MassParticleState
{
	public:

		/*! Applied force */
		Vector3d                                      m_kForce;

		/*! Mass of particle */
		float                                         m_fMass;

		/*! Inverted mass, precalculated */
		float                                         m_fInvMass;


		/**
		*/
		                                              MassParticleState() {}

		/**
		* \param rkForce                              Applied force
		* \param fMass                                Mass
		* \param fInvMass                             Inverse mass
		*/
		                                              MassParticleState( const Vector3d &rkForce, float fMass, float fInvMass ) : m_kForce( rkForce ), m_fMass( fMass ), m_fInvMass( fInvMass ) {}

		/**
		* \param rkState                              Reference state object to copy
		*/
		                                              MassParticleState( const MassParticleState &rkState ) : m_kForce( rkState.m_kForce ), m_fMass( rkState.m_fMass ), m_fInvMass( rkState.m_fInvMass ) {}

		/**
		* Needed for STL exports of UDTs under Win32
		* \param rkState                              State data to compare with
		* \return                                     false
		*/
		bool                                          operator < ( const MassParticleState &rkState ) const { return( false ); }

		/**
		* Query if states are equal
		* \param rkState                              State data to compare with
		* \return                                     true if all elements are equal, false if not      
		*/
		bool                                          operator == ( const MassParticleState &rkState ) const { return( ( m_kForce == rkState.m_kForce ) && ( m_fMass == rkState.m_fMass ) && ( m_fInvMass == rkState.m_fInvMass ) ); }
};


#ifdef WIN32
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif
#  ifndef __HAVE_VECTOR_NEMASSPARTICLESTATEOBJ
     UDTVectorEXPIMP( MassParticleState );
#    define __HAVE_VECTOR_NEMASSPARTICLESTATEOBJ
#  endif
#endif


/**
  * \brief Mass particle abstraction
  * Simulate mass particle physics. A mass particle has a mass but no (infinetesimal) volume.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API MassParticle : public PhysicsNode
{
	private:

		/*! State stack */
		std::vector< MassParticleState >              m_vkStateStack;



	protected:

		/*! Applied force */
		Vector3d                                      m_kForce;

		/*! Mass of particle */
		float                                         m_fMass;

		/*! Inverted mass, precalculated */
		float                                         m_fInvMass;



	public:

		/**
		*/
		                                              MassParticle();

		/**
		*/
		virtual                                      ~MassParticle();

		/**
		* Duplicate node
		* \return                                     New node that is exact copy of this node
		*/
		virtual SceneNode                            *Duplicate();

		/**
		* Set mass of particle
		* \param fMass                                Mass
		*/
		void                                          SetMass( float fMass );

		/**
		* \return                                     Mass of particle
		*/
		inline float                                  GetMass() const { return m_fMass; }

		/**
		* \return                                     Inverse mass (1/mass) of particle
		*/
		inline float                                  GetInvMass() const { return m_fInvMass; }

		/**
		* Apply force to this particle
		* \param rkForce                              Force
		* \return                                     Resulting force acting on particle
		*/
		const Vector3d                               &ApplyForce( const Vector3d &rkForce );

		/**
		* Apply impulse to this particle
		* \param rkImpulse                            Impulse
		*/
		void                                          ApplyImpulse( const Vector3d &rkImpulse );

		/**
		* Reset force acting on particle
		*/
		void                                          ResetForce();

		/**
		* Get current force acting on object
		*/
		inline const Vector3d                        &GetForce() const { return m_kForce; }

		/**
		* Update by integrating the equations for laws of motion
		* \param fDeltaTime                           Delta time passed since last update
		*/
		virtual void                                  Update( float fDeltaTime );

		/**
		* Push current state to stack
		*/
		virtual void                                  PushState();

		/**
		* Restore state from stack
		* \param bSet                                 If true, restore node to state popped off stack, otherwise ignore popped state
		*/
		virtual void                                  PopState( bool bSet = true );

		/**
		* Clear state stack
		*/
		virtual void                                  ClearState();
};


};


#endif
