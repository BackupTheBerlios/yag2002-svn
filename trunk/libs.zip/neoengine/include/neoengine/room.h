/***************************************************************************
                   room.h  -  Space partitioning base classes
                             -------------------
    begin                : Tue Oct 30 2001
    copyright            : (C) 2001 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, room.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2001
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEROOM_H
#define __NEROOM_H


/**
  * \file neoengine/room.h
  * Scene management in rooms. Space partition base
  */


#include "base.h"
#include "scenenode.h"
#include "module.h"
#include "vertexbuffer.h"
#include "polygonbuffer.h"

#include <string>


namespace NeoEngine
{


// External classes
class Ray;


/**
  * \brief Scene management base class
  * A room is the top-level class for scene management, capable
  * of holding both static geometry and dynamic objects through
  * the scene graph capabilities in SceneNode.
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API Room : public SceneNode
{
	public:

		DefineVisitable();

	protected:

		/*! Global nodes */
		std::vector< SceneNode* >                     m_vpkGlobalNodes;


	public:


		/**
		* Create named room
		* \param rstrName                             Room name
		*/
		                                              Room( const HashString &rstrName = "" );

		/**
		*/
		virtual                                      ~Room();

		/**
		* Attach a global (always rendered) node
		* \param pkNode                               Scene node object
		* \return                                     room-specific value
		*/
		virtual int                                   AttachGlobalNode( SceneNode *pkNode );

		/**
		* Detach a global node
		* \param pkNode                               Scene node object
		* \return                                     room-specific value
		*/
		virtual int                                   DetachGlobalNode( SceneNode *pkNode );

		/**
		* Attach node. Set node room pointer
		* \param pkNode                               Node to attach
		* \param bKeepWorldSRT                        If true, recalculate node relative position to maintain world SRT
		* \return                                     undefined (reserved for future use or derived classes)
		*/
		virtual int                                   AttachNode( SceneNode *pkNode, bool bKeepWorldSRT = false );

		/**
		* Detach node. Reset node room pointer
		* \param pkNode                               Node to detach
		* \return                                     undefined (reserved for future use or derived classes)
		*/
		virtual int                                   DetachNode( SceneNode *pkNode );

		/**
		* Render room
		* \param pkFrustum                            Current view frustum (if any)
		* \param bForce                               Render even if rendered previously this frame or deactivated
		* \return                                     true if we were rendered, false if not (already rendered)
		*/
		virtual bool                                  Render( Frustum *pkFrustum = 0, bool bForce = false );

		/**
		* Update attached nodes (global and non-global)
		* \param fDeltaTime                           Time passed since last update
		*/
		virtual void                                  Update( float fDeltaTime );

		/**
		* Add and partition geometry. Some room implementation does not support this.
		* \param pkPolygonBuffer                      Polygon buffer
		* \param pkVertexBuffer                       Vertex buffer
		* \param pkMaterial                           Material
		*/
		virtual void                                  AddGeometry( const PolygonBufferPtr &pkPolygonBuffer, const VertexBufferPtr &pkVertexBuffer, const MaterialPtr &pkMaterial );

		/**
		* Slice geometry with triangle
		* \param rkV0                                 First vertex
		* \param rkV1                                 Second vertex
		* \param rkV2                                 Third vertex
		* \param pvkPoints                            Pointer to vector receiving line segments
		*/
		virtual void                                  SliceGeometry( const NeoEngine::Vector3d &rkV0, const NeoEngine::Vector3d &rkV1, const NeoEngine::Vector3d &rkV2, std::vector< NeoEngine::Vector3d > *pvkPoints );
};


/**
  * \brief Room manager
  * The room manager creates rooms and loads extension modules on demand
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API RoomManager
{
	protected:

		/*! Loaded room modules */
		std::vector< ModulePtr >                      m_vpkModules;


	public:


		/**
		*/
		                                              RoomManager();

		/**
		*/
		virtual                                      ~RoomManager();

		/**
		* Load room module
		* \param rstrName                             Module name
		* \return                                     true if module loaded successfully, false if not
		*/
		virtual ModulePtr                             LoadModule( const HashString &rstrName );

		/**
		* Create room of specified type (will try to load room module if no matching module found)
		* \param rstrType                             Room type
		* \return                                     New room object or null if error
		*/
		virtual Room                                 *CreateRoom( const HashString &rstrType );
};


};


#endif
