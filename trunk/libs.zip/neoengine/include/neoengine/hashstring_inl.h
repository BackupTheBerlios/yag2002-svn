/***************************************************************************
               hashstring_inl.h  -  Hashed Version of std::string
                             -------------------
    begin                : Thu Oct 23 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, hashstring_inl.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


inline HashString::HashString() :
	m_uiHash( 0 )
{
}


inline HashString::HashString( const HashString &rstrRef ) :
	m_uiHash( rstrRef.m_uiHash ),
	m_strData( rstrRef.m_strData )
{
}


inline HashString::HashString( const std::string &rstrRef ) :
	m_uiHash( 0 ),
	m_strData( rstrRef )
{
	HashMe();
}


inline HashString::HashString( const char *pcRef, int iNum ) :
	m_uiHash( 0 ),
	m_strData( pcRef, iNum )
{
	HashMe();
}


inline HashString::HashString( const char *pszRef ) :
	m_uiHash( 0 ),
	m_strData( pszRef )
{ 
	HashMe();
}


inline HashString::HashString( int iNum, const char cData ) :
	m_uiHash( 0 ),
	m_strData( iNum, cData )
{
	HashMe();
}


inline bool HashString::Compare( const HashString &rstrRef ) const
{
	return( ( rstrRef.GetHash() == this->GetHash() ) && ( rstrRef.m_strData == this->m_strData ) );
}


inline bool HashString::Compare( unsigned int uiHash ) const
{
	return( uiHash == this->GetHash() );
}


inline unsigned int HashString::GetHash() const
{
	return m_uiHash;
}


inline HashString &HashString::HashMe()
{
	m_uiHash = Hash( this->m_strData );
	return( *this );
};


inline size_t HashString::length() const
{
	return m_strData.length();
}


inline const char *HashString::c_str() const
{
	return m_strData.c_str();
}


inline bool HashString::operator == ( const HashString &rstrRef ) const
{
	return Compare( rstrRef );
}


inline bool HashString::operator == ( unsigned int uiHash ) const
{
	return Compare( uiHash );
}


inline bool HashString::operator == ( const std::string &rstrRef ) const
{
	return( m_strData == rstrRef ); 
}


inline bool HashString::operator == ( const char *pszRef ) const
{ 
	return( pszRef && ( m_strData == pszRef ) );
}


inline bool HashString::operator != ( const HashString &rstrRef ) const
{ 
	return !Compare( rstrRef ); 
}


inline bool HashString::operator != ( unsigned int uiHash ) const
{ 
	return !Compare( uiHash ); 
}


inline bool HashString::operator != ( const std::string &rstrRef ) const 
{ 
	return( m_strData != rstrRef );
}


inline bool HashString::operator != ( const char *pszRef ) const
{ 
	return( pszRef && ( m_strData != pszRef ) ); 
}


inline HashString &HashString::operator = ( const HashString &rstrRef )
{ 
	m_strData = rstrRef.m_strData; 
	m_uiHash = rstrRef.GetHash(); 
	return( *this );
}


inline HashString &HashString::operator = ( const std::string &rstrRef )
{ 
	m_strData = rstrRef;
	return HashMe(); 
}


inline HashString &HashString::operator = ( const char *pszRef )
{ 
	if( pszRef )
	{ 
		m_strData = pszRef; 
		return HashMe();
	} 
	else
	{ 
		m_strData = ""; 
		m_uiHash = 0; 
		return( *this );
	}
}


inline HashString &HashString::operator += ( const HashString &rstrRef )
{ 
	m_strData += rstrRef.m_strData;
	HashMe();
	return( *this );
}


inline HashString &HashString::operator += ( const std::string &rstrRef )
{ 
	m_strData += rstrRef;
	HashMe();
	return( *this );
}


inline HashString &HashString::operator += ( const char *pszRef )
{
	if( pszRef )
	{
		m_strData += pszRef;
		HashMe();
	}
	
	return( *this );
}


inline HashString::operator std::string &()
{
	return m_strData;
}


inline HashString::operator const std::string &() const
{
	return m_strData;
}


inline bool HashString::operator < ( const HashString &rstrString ) const
{
	return( m_strData < rstrString.m_strData );
}


inline HashString operator + ( const HashString &rstrOne, const HashString &rstrTwo )
{
	return HashString( rstrOne.m_strData + rstrTwo.m_strData );
}


inline HashString operator + ( const HashString &rstrOne, const std::string &rstrTwo )
{
	return HashString( rstrOne.m_strData + rstrTwo );
}


inline HashString operator + ( const HashString &rstrOne, const char *pszTwo )
{
	return HashString( pszTwo ? ( rstrOne.m_strData + pszTwo ) : rstrOne.m_strData );
}


inline HashString operator + ( const std::string &rstrOne, const HashString &rstrTwo )
{
	return HashString( rstrOne + rstrTwo.m_strData );
}


inline HashString operator + ( const char *pszOne, const HashString &rstrTwo )
{
	return HashString( pszOne ? ( pszOne + rstrTwo.m_strData ) : rstrTwo.m_strData );
}

