/***************************************************************************
                          tcp.h  -  TCP/IP sockets
                             -------------------
    begin                : Thu Oct 10 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, tcp.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/


#ifndef __NETCP_H
#define __NETCP_H



#include "base.h"
#include "socket.h"

#include <string>


/**
  * \file tcp.h
  * TCP/IP socket wrapper
  */


namespace NeoEngine
{


//External classes
class Thread;




/**
  * \class TCPSocket
  * \brief TCP/IP implementation of socket interface
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class NEOENGINE_API TCPSocket : public Socket
{
	public:

		/*! Socket descriptor */
		int                                    m_iSocket;

		/*! Accept thread */
		Thread                                *m_pkAcceptThread;



		/**
		* \param pkCallback                    Socket callback object receiving events
		*/
		                                       TCPSocket( SocketCallback *pkCallback = 0 );

		/**
		* \param iSocket                       Socket descriptor
		* \param pkCallback                    Socket callback object receiving events
		*/
		                                       TCPSocket( int iSocket, SocketCallback *pkCallback = 0 );

		/**
		*/
		virtual                               ~TCPSocket();

		/**
		* Listen for incoming connections
		* \param iPort                         Port to listen to
		* \param pkCallback                    Callback recieving connection events (will replace current callback object if not null)
		* \return                              true if socket successfuly setup and accepting connections, false otherwise
		*/
		virtual bool                           Listen( int iPort, SocketCallback *pkCallback );

		/**
		* Connect to other socket
		* \param rstrAddr                      Address
		* \param iPort                         Port
		* \return                              true if connection successful, false otherwise
		*/
		virtual bool                           Connect( const std::string &rstrAddr, int iPort );

		/**
		* Read data from socket
		* \param pDst                          Destination buffer
		* \param iBytes                        Bytes to read
		* \return                              Actual number of bytes read
		*/
		int                                    Read( void *pDst, int iBytes );

		/**
		* Write data to socket
		* \param pSrc                          Source buffer
		* \param iBytes                        Bytes to write
		* \return                              Actual number of bytes written
		*/
		int                                    Write( const void *pSrc, int iBytes );

		/**
		* \return                              Socket FD
		*/
		virtual int                            GetFD() { return m_iSocket; }

		/**
		* Set blocking/nonblocking mode
		* \param bBlock                        Blocking flag
		*/
		virtual void                           SetBlocking( bool bBlock = false );

		/**
		* Poll socket
		* \param iTimeout                      Timeout in milliseconds
		* \return                              Events bitfield
		*/
		virtual unsigned int                   Poll( int iTimeout );
};



}; // namespace NeoEngine



#endif
