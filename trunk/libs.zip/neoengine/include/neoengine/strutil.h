/***************************************************************************
                        strutil.h  -  String utilities
                             -------------------
    begin                : Mon Oct 21 2002
    copyright            : (C) 2002 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, strutil.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2002
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NESTRUTIL_H
#define __NESTRUTIL_H


#ifndef __NEED_VECTOR_STRING
#  define __NEED_VECTOR_STRING
#endif

#ifndef __NEED_VECTOR_CHARPTR
#  define __NEED_VECTOR_CHARPTR
#endif

#include "base.h"
#include "core.h"

#include <vector>
#include <string>



/**
  * \file strutil.h
  * String utility methods
  */



namespace NeoEngine
{



/**
* Tokenize a string
* \param rstrSeparators                       Token delimiters
* \param rstrString                           String to tokenize
* \param pvstrResult                          Vector receiving resulting tokens
* \return                                     Number of tokens
*/
int NEOENGINE_API                             Explode( const std::string &rstrSeparators, const std::string &rstrString, std::vector< std::string > *pvstrResult );

/**
* Tokenize a string (NOTE! Modifies pszString argument!)
* \param pszSeparators                        Token delimiters
* \param pszString                            String to tokenize
* \param pvpszResult                          Vector receiving resulting tokens
* \return                                     Number of tokens
*/
int NEOENGINE_API                             Explode( const char *pszSeparators, char *pszString, std::vector< char* > *pvpszResult );


/**
* Strip characters from start and end of string, deafult to whitespace stripping
* \param rstrString                           Input string
* \param rstrDelimiters                       Characters to strip from start and end of string, default to whitespace (space, tabs and newlines)
* \return                                     Stripped string
*/
std::string NEOENGINE_API                     Strip( const std::string &rstrString, const std::string &rstrDelimiters = " \t\n\r" );


};


#endif

