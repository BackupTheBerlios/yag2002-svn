/***************************************************************************
        scenenode.h  -  Base class for hierarchies in a scene graph
                             -------------------
    begin                : Sat Jan 25 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, scenenode.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

		
inline SceneNode *SceneNode::Get()
{
	return this;
}


inline void SceneNode::NotifyUpdate( bool bRecurse )
{
	HierarchyNode<SceneNode>::NotifyUpdate( bRecurse );
	NotifyVolumeUpdate( bRecurse ); 
	
	std::vector< SceneNodeCallback* >::iterator ppkEnd = m_vpkCallbacks.end();
	for( std::vector< SceneNodeCallback* >::iterator ppkCallback = m_vpkCallbacks.begin(); ppkCallback != ppkEnd; ++ppkCallback )
		(*ppkCallback)->NodeChanged( this );
}

		
inline void SceneNode::NotifyVolumeUpdate( bool bRecurse )
{
	m_bNeedVolumeUpdate = true;
	
	if( !bRecurse || !m_pkParent || m_bIgnoreVolumeUpdate )
		return;
		
	m_pkParent->NotifyVolumeUpdate( true );
}

		
inline BoundingVolume *SceneNode::GetBoundingVolume()
{
	if( m_bWorldUpdate )
		UpdateWorld();
	
	if( m_bNeedVolumeUpdate )
		UpdateVolume();
		
	return m_pkBoundingVolume;
}

		
inline SceneEntity *SceneNode::GetEntity()
{
	return m_pkEntity;
}

