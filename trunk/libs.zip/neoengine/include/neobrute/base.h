/***************************************************************************
                 base.h  -  Base defines for brute terrain
                             -------------------
    begin                : Mon Sep 8 2003
    copyright            : (C) 2003 by Cody Russell
    email                : cody `at' jhu.edu
 ***************************************************************************
 
 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoBrute, base.h

 The Initial Developer of the Original Code is Cody Russell.
 Portions created by Cody Russell are Copyright (C) 2003
 Cody Russell. All Rights Reserved.
 
 ***************************************************************************/
 
#ifndef __NEOBRUTE_BASE_H
#define __NEOBRUTE_BASE_H
 
#if defined(HAVE_CONFIG_H) && defined(NEOBRUTE_INTERNALS)
#  include "buildconfig.h"
#endif

#include <neoengine/base.h>
#include <neoengine/terrain.h>

#define NEOBRUTEVERSION_MAJOR             NEOENGINEVERSION_MAJOR
#define NEOBRUTEVERSION_MINOR             NEOENGINEVERSION_MINOR
#define NEOBRUTEVERSION_REVISION          NEOENGINEVERSION_REVISION

#define NEOBRUTEVERSIONSTRING             NEOENGINEVERSIONSTRING

                                                                                
#ifdef WIN32
                                                                                
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif

#  define NEOBRUTE_API
#  define NEOBRUTEEXPIMP_TEMPLATE
#  define BRUTEUDTVectorEXPIMP

#elif defined(POSIX) || defined(__APPLE__)
                                                                                
#  define NEOBRUTE_API
#  define NEOBRUTE_TEMPLATE
                                                                                
#  define BRUTEUDTVectorEXPIMP(classname)
                                                                                
#else
#  error "Platform uninplemented"
#endif

#endif // __NEOBRUTE_BASE_H
