/***************************************************************************
                terrain.h  -  Brute force terrain implementation
                             -------------------
    begin                : Mon Sep 8 2003
    copyright            : (C) 2003-2004 by Cody Russell
    email                : cody `at' jhu.edu
 ***************************************************************************
 
 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoBrute, terrain.h

 The Initial Developer of the Original Code is Cody Russell.
 Portions created by Cody Russell are Copyright (C) 2003-2004
 Cody Russell. All Rights Reserved.
 
 ***************************************************************************/
 
#ifndef __NEBRUTE_TERRAIN_H
#define __NEBRUTE_TERRAIN_H
 
#include "base.h"

#include <neoengine/render.h>
#include <neoengine/terrain.h>
 
/**
  * \file terrain.h
  * This is a simple, brute force terrain implementation.  It is
  * generally not useful in practice, but is useful for testing
  * purposes.  It makes no interesting optimizations; it simply
  * loads terrain data from a heightmap and generates a vertex
  * buffer, a polygon buffer, and an AABB bounding volume.
  */


namespace NeoBrute
{


class BruteTerrain;


class NEOBRUTE_API BruteTerrainBlock : public NeoEngine::TerrainBlock
{
	protected:

		BruteTerrain                                  *m_pkBrutePage;

		int                                            m_iOffset;

		NeoEngine::TerrainMaterialFactory             *m_pkMaterialFactory;

		NeoEngine::VertexBufferPtr                     m_pkVertices;

		NeoEngine::PolygonBufferPtr                    m_pkPolygons;

		virtual void                                   UpdateData();

	public:

		virtual NeoEngine::VertexBufferPtr            &GetVertexBuffer() { if( m_bNeedUpdate ) UpdateData(); return m_pkVertices; }

		virtual NeoEngine::PolygonBufferPtr           &GetPolygonBuffer() { if( m_bNeedUpdate ) UpdateData(); return m_pkPolygons; }

		virtual bool                                   Render( NeoEngine::Frustum *pkFrustum, bool bForce = false );

		virtual void                                   GenerateAABB();

		                                               BruteTerrainBlock( int iXOffset, int iYOffset, int iSize, int iIndex, NeoEngine::TerrainMaterialFactory *pkMaterialFactory, BruteTerrain *pkPage );

		virtual                                       ~BruteTerrainBlock() {}
};
 
class NEOBRUTE_API BruteTerrain : public NeoEngine::TerrainPage
{
	public:

		                                              BruteTerrain( NeoEngine::TerrainHeightmap *pkHeightmap, NeoEngine::TerrainMaterialFactory *pkMaterialFactory, int iDepth );

		virtual                                      ~BruteTerrain() {}

		virtual bool                                  Render( NeoEngine::Frustum *pkFrustum, bool bForce = false );
};


class NEOBRUTE_API BruteTerrainManager : public NeoEngine::TerrainManager
{
        public:

	                                            BruteTerrainManager() { }

	        virtual                            ~BruteTerrainManager() { }

	        virtual NeoEngine::TerrainPage*     CreateTerrain( NeoEngine::TerrainHeightmap *pkHeightmap, NeoEngine::TerrainMaterialFactory *pkMaterialFactory );
};


}; // namespace NeoBrute

#endif // __NEBRUTE_TERRAIN_H
