/***************************************************************************
                          neoicdds.h  -  description
                             -------------------
    begin                : Fre Apr 09 2004
    copyright            : (C) 2004 by Patrick Levin
    email                : p.levin@numlock.de
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoICDDS, neoicdds.h

 The Initial Developer of the Original Code is Patrick Levin
 Portions created by Patrick Levin are Copyright (C) 2004
 Numlock Software GmbH. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOICDDS_H
#define __NEOICDDS_H


#include <neoengine/base.h>
#include <neoengine/texture.h>


namespace NeoDDS
{

/**
  * \brief Image loader codec for dds files
  * \author Patrick Levin (p.levin@numlock.de)
  */
class ImageCodec : public NeoEngine::ImageCodec
{
	public:

		/**
		* Create new DDS loader codec object
		* \param rvstrExtensions        Extension string vector
		*/
		                                ImageCodec( const std::vector<std::string> &rvstrExtensions );

		/**
		* Check if file is a DDS file
		* \param pkFile                 File to check
		* \return                       true if DDS file, false if not recognized
		*/
		virtual bool                    IsType( NeoEngine::File *pkFile );

		/**
		* Loads data from file
		* \param pkFile                 File
		* \return                       Ptr to new ImageData object
		*/
		virtual NeoEngine::ImageData   *LoadImage( NeoEngine::File *pkFile );

		/**
		* Free image data
		* \param pkImageData            Image data
		*/
		virtual void                    FreeImage( NeoEngine::ImageData *pkImageData );

		virtual bool                    WriteImage( NeoEngine::ImageData *pkImageData, NeoEngine::File *pkFile );
};


}; // namespace NeoDDS


#endif
