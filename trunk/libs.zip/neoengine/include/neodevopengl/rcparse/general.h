/***************************************************************************
               general.h  -  nVidia register combiners parser
                             -------------------
    begin       : Wed Jan 7 2004
    copyright   : (C) 2004 by Reality Rift Studios
    email       : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, rcparse/general.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.
 ***************************************************************************/

#ifndef _NEOGL_RCPARSE_GENERAL_H
#define _NEOGL_RCPARSE_GENERAL_H


#include <neoengine/base.h>
#include <neoengine/logstream.h>

#include "register.h"


namespace NeoEngine
{

class ShaderParam;
class RenderPrimitive;

}


namespace NeoOGL
{


class Device;


enum NVRCPARSERGENERALDEFS
{
	RCP_MUL     = 0,
	RCP_DOT,
	RCP_MUX,
	RCP_SUM
};


class NVConstColor
{
	public:

		NVRegister reg;
		float      v[4];

		void Init( NVRegister _reg, float _v0, float _v1, float _v2, float _v3 )
		{
			reg  = _reg;
			v[0] = _v0;
			v[1] = _v1;
			v[2] = _v2;
			v[3] = _v3;
		}
};


class NVOp
{
	public:

		int              op;
		NVMappedRegister reg[3];

		void Init( int _op, NVRegister _reg0, NVMappedRegister _reg1, NVMappedRegister _reg2 )
		{ 
			op         = _op;
			reg[0].reg = _reg0;
			reg[1]     = _reg1;
			reg[2]     = _reg2;
		}
	
		void Init( int _op, NVRegister _reg0 )
		{
			op         = _op;
			reg[0].reg = _reg0;
		}
	
		bool Validate( int stage, int portion );
};


class NVGeneralFunction
{
	public:

		int  numOps;
		NVOp op[3];

		void Init( NVOp _op0, NVOp _op1, NVOp _op2)
		{ 
			op[0]  = _op0;
			op[1]  = _op1;
			op[2]  = _op2;
			numOps = 3;
		}
	
		void Init( NVOp _op0, NVOp _op1 )
		{ 
			op[0]  = _op0;
			op[1]  = _op1;
			numOps = 2;
		}
	
		void Init( NVOp _op0 )
		{
			op[0]  = _op0;
			numOps = 1;
		}

		bool Validate( int stage, int portion );
	
		void Invoke( int stage, int portion, NVBiasScale bs );
	
		void ZeroOut();
};


class NVGeneralPortion
{
	public:

		int               designator;
		NVGeneralFunction gf;
		NVBiasScale       bs;

		void Init( int _designator, NVGeneralFunction _gf, NVBiasScale _bs )
		{
			designator = _designator;
			gf         = _gf;
			bs         = _bs;
		}

		bool Validate( int stage );
	
		void Invoke( int stage );
	
		void ZeroOut();
};


class NVGeneralCombiner
{
	public:

		NVGeneralPortion portion[2];
		int              numPortions;
		NVConstColor     cc[2];
		int              numConsts;

		NeoEngine::ShaderParam *m_pkParams[2];

		void Init( NVGeneralPortion _portion0, NVGeneralPortion _portion1, NVConstColor _cc0, NVConstColor _cc1 )
		{
			portion[0]  = _portion0;
			portion[1]  = _portion1;
			numPortions = 2;
			cc[0]       = _cc0;
			cc[1]       = _cc1;
			numConsts   = 2;
		}
	
		void Init( NVGeneralPortion _portion0, NVGeneralPortion _portion1, NVConstColor _cc0 )
		{
			portion[0]  = _portion0;
			portion[1]  = _portion1;
			numPortions = 2;
			cc[0]       = _cc0;
			numConsts   = 1;
		}

		void Init( NVGeneralPortion _portion0, NVGeneralPortion _portion1 )
		{
			portion[0]  = _portion0;
			portion[1]  = _portion1;
			numPortions = 2;
			numConsts   = 0;
		}
	
		void Init( NVGeneralPortion _portion0, NVConstColor _cc0, NVConstColor _cc1 )
		{
			portion[0]  = _portion0;
			numPortions = 1;
			cc[0]       = _cc0;
			cc[1]       = _cc1;
			numConsts   = 2;
		}
	
		void Init( NVGeneralPortion _portion0, NVConstColor _cc0 )
		{
			portion[0]  = _portion0;
			numPortions = 1;
			cc[0]       = _cc0;
			numConsts   = 1;
		}

		void Init( NVGeneralPortion _portion0 )
		{
			portion[0]  = _portion0;
			numPortions = 1;
			numConsts   = 0;
		}

		bool Validate( int stage );

		void SetUnusedLocalConsts( int numGlobalConsts, NVConstColor *globalCCs );
	
		void Invoke( Device *pkDevice, int stage, NeoEngine::RenderPrimitive *pkPrimitive );

		void BindLightParams( Device *pkDevice, int stage, NeoEngine::RenderPrimitive *pkPrimitive );
	
		void ZeroOut();
};


class NVGeneralCombiners
{
	private:
	
		int               localConsts;


	public:

		NVGeneralCombiner general[ RCP_NUM_GENERAL_COMBINERS ];
		int               num;


		void Init()
		{
			num = 0;
		}
	
		void Init( NVGeneralCombiner _gc )
		{
			num = 1; general[0] = _gc;
		}
	
		NVGeneralCombiners &operator+=( NVGeneralCombiner &_gc )
		{
			if( num < RCP_NUM_GENERAL_COMBINERS )
				general[num++] = _gc;
			else
				NeoEngine::neolog << NeoEngine::LogLevel( NeoEngine::ERROR ) << "*** Invalid fragment shader: Too many general combiners" << std::endl;
			return *this;
		}
	
		bool Validate( int numConsts, NVConstColor *cc );
	
		void Invoke( Device *pkDevice, NeoEngine::RenderPrimitive *pkPrimitive );	

		void BindLightParams( Device *pkDevice, NeoEngine::RenderPrimitive *pkPrimitive );
};


};


#endif
