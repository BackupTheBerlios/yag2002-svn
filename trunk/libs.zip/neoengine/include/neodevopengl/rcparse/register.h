/***************************************************************************
               register.h  -  nVidia register combiners parser
                             -------------------
    begin       : Wed Jan 7 2004
    copyright   : (C) 2004 by Reality Rift Studios
    email       : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, rcparse/register.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.
 ***************************************************************************/

#ifndef _NEOGL_RCPARSE_REGISTER_H
#define _NEOGL_RCPARSE_REGISTER_H

#include <neoengine/base.h>

#include "../extensions.h"

#include <stdlib.h>


namespace NeoOGL
{


enum NVRCPARSERREGISTERDEFS
{
	RCP_NUM_GENERAL_COMBINERS        = 8,

	RCP_RGB                          = 0,
	RCP_ALPHA                        = 1,
	RCP_BLUE                         = 2,
	RCP_NONE                         = 3
};


union NVRegister
{
	struct
	{

#if defined( ARCH_X86 ) || defined( ARCH_X86_64 )

		unsigned int name          :16; // OpenGL enum for register
		unsigned int channel       : 2; // RCP_RGB, RCP_ALPHA, etc
		unsigned int readOnly      : 1; // true or false
		unsigned int finalOnly     : 1; // true or false
		unsigned int unused        :12;

#elif defined( ARCH_PPC )

		unsigned int unused        :12;
		unsigned int finalOnly     : 1; // true or false
		unsigned int readOnly      : 1; // true or false
		unsigned int channel       : 2; // RCP_RGB, RCP_ALPHA, RCP_BLUE, RCP_NONE
		unsigned int name          :16; // OpenGL enum for register

#else
#  error "Platform not supported yet"
#endif

	} bits;

	unsigned int word;
};

// No need for writeOnly flag, since DISCARD is the only register in that category


// WARNING:  Don't monkey with the above structure or this macro
// unless you're absolutely sure of what you're doing!
// This constant allocation makes validation *much* cleaner.
#define RCP_SET_REGISTER_ENUM(name, channel, readonly, finalonly) ((finalonly << 19) | (readonly << 18) | (channel << 16) | name)

#define RCP_FOG_RGB					RCP_SET_REGISTER_ENUM(GL_FOG, RCP_RGB,   1, 0)
#define RCP_FOG_ALPHA				RCP_SET_REGISTER_ENUM(GL_FOG, RCP_ALPHA, 1, 1)
#define RCP_FOG_BLUE				RCP_SET_REGISTER_ENUM(GL_FOG, RCP_BLUE,  1, 0)
#define RCP_FOG						RCP_SET_REGISTER_ENUM(GL_FOG, RCP_NONE,  1, 0)
#define RCP_PRIMARY_COLOR_RGB		RCP_SET_REGISTER_ENUM(GL_PRIMARY_COLOR_NV, RCP_RGB,   0, 0)
#define RCP_PRIMARY_COLOR_ALPHA		RCP_SET_REGISTER_ENUM(GL_PRIMARY_COLOR_NV, RCP_ALPHA, 0, 0)
#define RCP_PRIMARY_COLOR_BLUE		RCP_SET_REGISTER_ENUM(GL_PRIMARY_COLOR_NV, RCP_BLUE,  0, 0)
#define RCP_PRIMARY_COLOR			RCP_SET_REGISTER_ENUM(GL_PRIMARY_COLOR_NV, RCP_NONE,  0, 0)
#define RCP_SECONDARY_COLOR_RGB		RCP_SET_REGISTER_ENUM(GL_SECONDARY_COLOR_NV, RCP_RGB,   0, 0)
#define RCP_SECONDARY_COLOR_ALPHA	RCP_SET_REGISTER_ENUM(GL_SECONDARY_COLOR_NV, RCP_ALPHA, 0, 0)
#define RCP_SECONDARY_COLOR_BLUE	RCP_SET_REGISTER_ENUM(GL_SECONDARY_COLOR_NV, RCP_BLUE,  0, 0)
#define RCP_SECONDARY_COLOR			RCP_SET_REGISTER_ENUM(GL_SECONDARY_COLOR_NV, RCP_NONE,  0, 0)
#define RCP_SPARE0_RGB				RCP_SET_REGISTER_ENUM(GL_SPARE0_NV, RCP_RGB,   0, 0)
#define RCP_SPARE0_ALPHA			RCP_SET_REGISTER_ENUM(GL_SPARE0_NV, RCP_ALPHA, 0, 0)
#define RCP_SPARE0_BLUE				RCP_SET_REGISTER_ENUM(GL_SPARE0_NV, RCP_BLUE,  0, 0)
#define RCP_SPARE0					RCP_SET_REGISTER_ENUM(GL_SPARE0_NV, RCP_NONE,  0, 0)
#define RCP_SPARE1_RGB				RCP_SET_REGISTER_ENUM(GL_SPARE1_NV, RCP_RGB,   0, 0)
#define RCP_SPARE1_ALPHA			RCP_SET_REGISTER_ENUM(GL_SPARE1_NV, RCP_ALPHA, 0, 0)
#define RCP_SPARE1_BLUE				RCP_SET_REGISTER_ENUM(GL_SPARE1_NV, RCP_BLUE,  0, 0)
#define RCP_SPARE1					RCP_SET_REGISTER_ENUM(GL_SPARE1_NV, RCP_NONE,  0, 0)
#define RCP_TEXTURE0_RGB			RCP_SET_REGISTER_ENUM(GL_TEXTURE0_ARB, RCP_RGB,   0, 0)
#define RCP_TEXTURE0_ALPHA			RCP_SET_REGISTER_ENUM(GL_TEXTURE0_ARB, RCP_ALPHA, 0, 0)
#define RCP_TEXTURE0_BLUE			RCP_SET_REGISTER_ENUM(GL_TEXTURE0_ARB, RCP_BLUE,  0, 0)
#define RCP_TEXTURE0				RCP_SET_REGISTER_ENUM(GL_TEXTURE0_ARB, RCP_NONE,  0, 0)
#define RCP_TEXTURE1_RGB			RCP_SET_REGISTER_ENUM(GL_TEXTURE1_ARB, RCP_RGB,   0, 0)
#define RCP_TEXTURE1_ALPHA			RCP_SET_REGISTER_ENUM(GL_TEXTURE1_ARB, RCP_ALPHA, 0, 0)
#define RCP_TEXTURE1_BLUE			RCP_SET_REGISTER_ENUM(GL_TEXTURE1_ARB, RCP_BLUE,  0, 0)
#define RCP_TEXTURE1				RCP_SET_REGISTER_ENUM(GL_TEXTURE1_ARB, RCP_NONE,  0, 0)
#define RCP_TEXTURE2_RGB			RCP_SET_REGISTER_ENUM(GL_TEXTURE2_ARB, RCP_RGB,   0, 0)
#define RCP_TEXTURE2_ALPHA			RCP_SET_REGISTER_ENUM(GL_TEXTURE2_ARB, RCP_ALPHA, 0, 0)
#define RCP_TEXTURE2_BLUE			RCP_SET_REGISTER_ENUM(GL_TEXTURE2_ARB, RCP_BLUE,  0, 0)
#define RCP_TEXTURE2				RCP_SET_REGISTER_ENUM(GL_TEXTURE2_ARB, RCP_NONE,  0, 0)
#define RCP_TEXTURE3_RGB			RCP_SET_REGISTER_ENUM(GL_TEXTURE3_ARB, RCP_RGB,   0, 0)
#define RCP_TEXTURE3_ALPHA			RCP_SET_REGISTER_ENUM(GL_TEXTURE3_ARB, RCP_ALPHA, 0, 0)
#define RCP_TEXTURE3_BLUE			RCP_SET_REGISTER_ENUM(GL_TEXTURE3_ARB, RCP_BLUE,  0, 0)
#define RCP_TEXTURE3				RCP_SET_REGISTER_ENUM(GL_TEXTURE3_ARB, RCP_NONE,  0, 0)
#define RCP_CONST_COLOR0_RGB		RCP_SET_REGISTER_ENUM(GL_CONSTANT_COLOR0_NV, RCP_RGB,   1, 0)
#define RCP_CONST_COLOR0_ALPHA		RCP_SET_REGISTER_ENUM(GL_CONSTANT_COLOR0_NV, RCP_ALPHA, 1, 0)
#define RCP_CONST_COLOR0_BLUE		RCP_SET_REGISTER_ENUM(GL_CONSTANT_COLOR0_NV, RCP_BLUE,  1, 0)
#define RCP_CONST_COLOR0			RCP_SET_REGISTER_ENUM(GL_CONSTANT_COLOR0_NV, RCP_NONE,  1, 0)
#define RCP_CONST_COLOR1_RGB		RCP_SET_REGISTER_ENUM(GL_CONSTANT_COLOR1_NV, RCP_RGB,   1, 0)
#define RCP_CONST_COLOR1_ALPHA		RCP_SET_REGISTER_ENUM(GL_CONSTANT_COLOR1_NV, RCP_ALPHA, 1, 0)
#define RCP_CONST_COLOR1_BLUE		RCP_SET_REGISTER_ENUM(GL_CONSTANT_COLOR1_NV, RCP_BLUE,  1, 0)
#define RCP_CONST_COLOR1			RCP_SET_REGISTER_ENUM(GL_CONSTANT_COLOR1_NV, RCP_NONE,  1, 0)
#define RCP_ZERO_RGB				RCP_SET_REGISTER_ENUM(GL_ZERO, RCP_RGB,   1, 0)
#define RCP_ZERO_ALPHA				RCP_SET_REGISTER_ENUM(GL_ZERO, RCP_ALPHA, 1, 0)
#define RCP_ZERO_BLUE				RCP_SET_REGISTER_ENUM(GL_ZERO, RCP_BLUE,  1, 0)
#define RCP_ZERO					RCP_SET_REGISTER_ENUM(GL_ZERO, RCP_NONE,  1, 0)
#define RCP_ONE_RGB					RCP_SET_REGISTER_ENUM(GL_ONE, RCP_RGB,   1, 0)
#define RCP_ONE_ALPHA				RCP_SET_REGISTER_ENUM(GL_ONE, RCP_ALPHA, 1, 0)
#define RCP_ONE_BLUE				RCP_SET_REGISTER_ENUM(GL_ONE, RCP_BLUE,  1, 0)
#define RCP_ONE						RCP_SET_REGISTER_ENUM(GL_ONE, RCP_NONE,  1, 0)
#define RCP_DISCARD					RCP_SET_REGISTER_ENUM(GL_DISCARD_NV, RCP_NONE, 0, 0)
#define RCP_FINAL_PRODUCT			RCP_SET_REGISTER_ENUM(GL_E_TIMES_F_NV, RCP_NONE, 1, 1)
#define RCP_COLOR_SUM				RCP_SET_REGISTER_ENUM(GL_SPARE0_PLUS_SECONDARY_COLOR_NV, RCP_NONE, 1, 1)

#define MAP_CHANNEL(channel) ((RCP_RGB == (channel)) ? GL_RGB : (RCP_ALPHA == (channel) ? GL_ALPHA : GL_BLUE))

union NVBiasScale
{
	struct
	{

#if defined( ARCH_X86 ) || defined( ARCH_X86_64 )

		unsigned int bias          :16; // OpenGL enum for bias
		unsigned int scale         :16; // OpenGL enum for scale

#elif defined( ARCH_PPC )

		unsigned int scale         :16; // OpenGL enum for scale
		unsigned int bias          :16; // OpenGL enum for bias

#else
#  error "Platform not supported yet"
#endif

	} bits;

	unsigned int word;
};


// WARNING:  Don't monkey with the above structure or this macro
// unless you're absolutely sure of what you're doing!
// This constant allocation makes validation *much* cleaner.
#define RCP_SET_BIAS_SCALE_ENUM(bias, scale) ((scale << 16) | bias)

#define RCP_BIAS_BY_NEGATIVE_ONE_HALF_SCALE_BY_TWO	RCP_SET_BIAS_SCALE_ENUM(GL_BIAS_BY_NEGATIVE_ONE_HALF_NV, GL_SCALE_BY_TWO_NV)
#define RCP_BIAS_BY_NEGATIVE_ONE_HALF				RCP_SET_BIAS_SCALE_ENUM(GL_BIAS_BY_NEGATIVE_ONE_HALF_NV, GL_NONE)
#define RCP_SCALE_BY_ONE_HALF						RCP_SET_BIAS_SCALE_ENUM(GL_NONE, GL_SCALE_BY_ONE_HALF_NV)
#define RCP_SCALE_BY_ONE							RCP_SET_BIAS_SCALE_ENUM(GL_NONE, GL_NONE)
#define RCP_SCALE_BY_TWO							RCP_SET_BIAS_SCALE_ENUM(GL_NONE, GL_SCALE_BY_TWO_NV)
#define RCP_SCALE_BY_FOUR							RCP_SET_BIAS_SCALE_ENUM(GL_NONE, GL_SCALE_BY_FOUR_NV)


class NVMappedRegister
{
	public:

		int	       map;
		NVRegister reg;

		void Init( NVRegister _reg, int _map = GL_UNSIGNED_IDENTITY_NV )
		{
			if( GL_ONE == _reg.bits.name )
			{
				_reg.bits.name = GL_ZERO;
			
				switch( _map )
				{
					case GL_UNSIGNED_IDENTITY_NV:
						_map = GL_UNSIGNED_INVERT_NV;
						break;

					case GL_UNSIGNED_INVERT_NV:
						_map = GL_UNSIGNED_IDENTITY_NV;
						break;

					case GL_EXPAND_NORMAL_NV:
						_map = GL_UNSIGNED_INVERT_NV;
						break;

					case GL_EXPAND_NEGATE_NV:
						_map = GL_EXPAND_NORMAL_NV;
						break;

					case GL_HALF_BIAS_NORMAL_NV:
						_map = GL_HALF_BIAS_NEGATE_NV;
						break;
			
					case GL_HALF_BIAS_NEGATE_NV:
						_map = GL_HALF_BIAS_NORMAL_NV;
						break;
			
					case GL_SIGNED_IDENTITY_NV:
						_map = GL_UNSIGNED_INVERT_NV;
						break;
			
					case GL_SIGNED_NEGATE_NV:
						_map = GL_EXPAND_NORMAL_NV;
						break;
				}
			}

			map = _map;
			reg = _reg;
		}
};


#ifdef NVRCPARSER_TEST_BIT_FIELDS

class NVRegisterBitTest
{
	public:

		NVRegisterBitTest()
		{
			NVRegister reg;
	
			bool error = false;

			if( sizeof( reg.bits ) != sizeof( reg.word ) )
				error = true;

			reg.word      = 0;
			reg.bits.name = 0xFFFF;
	
			if( RCP_SET_REGISTER_ENUM( 0xFFFF, 0, 0, 0 ) != reg.word )
				error = true;

			reg.word         = 0;
			reg.bits.channel = 3;
	
			if( RCP_SET_REGISTER_ENUM( 0, 3, 0, 0 ) != reg.word )
				error = true;

			reg.word          = 0;
			reg.bits.readOnly = true;
	
			if( RCP_SET_REGISTER_ENUM( 0, 0, 1, 0 ) != reg.word )
				error = true;

			reg.word           = 0;
			reg.bits.finalOnly = true;
	
			if( RCP_SET_REGISTER_ENUM( 0, 0, 0, 1 ) != reg.word )
				error = true;

			if( error )
			{
				fprintf( stderr, "ERROR: Bit Fields were not compiled correctly in " __FILE__ "!\n" );
				exit(1);
			}
		}
};


static NVRegisterBitTest _doNVRegisterBitTest;


#endif


};


#endif
