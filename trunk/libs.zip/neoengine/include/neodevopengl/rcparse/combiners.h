/***************************************************************************
                 combiners.h  -  nVidia register combiners parser
                             -------------------
    begin       : Wed Jan 7 2004
    copyright   : (C) 2004 by Reality Rift Studios
    email       : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, rcparse/combiners.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.
 ***************************************************************************/

#ifndef _NEOGL_RCPARSE_COMBINERS_H
#define _NEOGL_RCPARSE_COMBINERS_H


#include <neoengine/base.h>

#include "general.h"
#include "final.h"


namespace NeoEngine
{

class ShaderParam;

};


namespace NeoOGL
{


class Device;


class NVRegisterCombiners
{
	public:

		NVGeneralCombiners                            m_kGenerals;

		NVFinalCombiner                               m_kFinal;

		NVConstColor                                  m_kConstColor[2];

		unsigned int                                  m_uiNumConst;

		NeoEngine::ShaderParam                       *m_pkParams[2];


		void                                          Init( NVGeneralCombiners kGCs, NVFinalCombiner kFC, NVConstColor kC0, NVConstColor kC1 ) { m_kGenerals = kGCs; m_kFinal = kFC; m_uiNumConst = 2 ; m_kConstColor[0] = kC0; m_kConstColor[1] = kC1; }

		void                                          Init( NVGeneralCombiners kGCs, NVFinalCombiner kFC, NVConstColor kC0 ) { m_kGenerals = kGCs; m_kFinal = kFC; m_uiNumConst = 1; m_kConstColor[0] = kC0; }

		void                                          Init( NVGeneralCombiners kGCs, NVFinalCombiner kFC ) { m_kGenerals = kGCs; m_kFinal = kFC; m_uiNumConst = 0; }

		bool                                          Validate();

		void                                          Invoke( Device *pkDevice, NeoEngine::RenderPrimitive *pkPrimitive );

		bool                                          Compile( const char *pszSource );

		void                                          BindLightParams( Device *pkDevice, NeoEngine::RenderPrimitive *pkPrimitive );

		static void                                   BindParam( Device *pkDevice, int iStage, unsigned int uiName, NeoEngine::ShaderParam *pkParam, NeoEngine::RenderPrimitive *pkPrimitive );
};


};


#endif
