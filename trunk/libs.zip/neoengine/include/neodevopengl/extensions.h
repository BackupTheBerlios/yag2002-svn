/***************************************************************************
                  extensions.h  -  Supported OpenGL extensions
                             -------------------
    begin                : Sun Mar 30 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, extensions.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 Contributors: Cody Russell (cody [at] jhu.edu)

 ***************************************************************************/

#ifndef __NEOGLEXTENSIONS_H
#define __NEOGLEXTENSIONS_H


/**
  * \file extensions.h
  * Supported OpenGL extensions
  */


#include <neoengine/base.h>


#define GL_GLEXT_PROTOTYPES

#ifdef WIN32
   //Exclude rarely-used stuff from Windows headers
#  ifndef WIN32_LEAN_AND_MEAN
#    define WIN32_LEAN_AND_MEAN
#  endif
#  include <windows.h>
#  include <windowsx.h>
#  include <GL/gl.h>
#  include "glext.h"
#  include "wglext.h"
#  undef ERROR
#elif defined(__APPLE__)
#  include <Carbon/Carbon.h>
#  include <AGL/agl.h>
#elif defined(POSIX)
#  include <X11/Xlib.h>
#  include <X11/extensions/xf86vmode.h>
#endif

#ifdef __APPLE__
#  include <OpenGL/OpenGL.h>
#  include <OpenGL/gl.h>
#  undef GL_ARB_vertex_buffer_object
#  undef GL_ARB_multitexture
#  include "glext.h"
#endif

#ifdef POSIX
// Force usage of our provided headers
#  define __glext_h_
#  define __glxext_h_
#  include <GL/gl.h>
#  include <GL/glx.h>
#  undef __glext_h_
#  include "glext.h"
#  undef __glxext_h_
#  include "glxext.h"
#  if ( GL_GLEXT_VERSION < 18 )
#    error "Your system has an old incompatible glext.h"
#  endif
#  if ( GLX_GLXEXT_VERSION < 5 )
#    error "Your system has an old incompatible glxext.h"
#  endif
#endif

#ifdef WIN32
#  define NEOGLAPIENTRY __stdcall
#else
#  define NEOGLAPIENTRY
#endif


#include <string.h>

#include <string>


namespace NeoOGL
{


/**
  * \brief Management of supported extensions
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class Extensions
{
	public:

		/**
		* \brief Extension identifiers
		*/
		enum OPENGLEXTENSION
		{
		  /*! Transpose matrix */
		  ARB_TRANSPOSE_MATRIX                        = 0x00000001,

		  /*! WGL extensions string */
		  WGL_EXTENSIONS_STRING                       = 0x00000002,


		  /*! ADD texenv */
		  ARB_TEXENV_ADD                              = 0x01000001,

		  /*! COMBINE texenv */
		  ARB_TEXENV_COMBINE                          = 0x01000002,


		  /*! WGL Pixel Format */
		  WGL_PIXEL_FORMAT_ARB                        = 0x02000001,

		  /*! WGL PBUFFER */
		  WGL_PBUFFER_ARB                             = 0x02000002,

		  /*! WGL render_texture */
		  WGL_RENDER_TEXTURE_ARB                      = 0x02000004,


		  /*! nVidia vertex arrays */
		  NV_VERTEX_ARRAY_RANGE                       = 0x03000001,

		  /*! nVidia fences */
		  NV_FENCE                                    = 0x03000002,

		  /*! ATI vertex array object */
		  ATI_VERTEX_ARRAY_OBJECT                     = 0x03000004,

		  /*! ATI element array */
		  ATI_ELEMENT_ARRAY                           = 0x03000008,

  		  /*! ARB vertex buffer object */
		  ARB_VERTEX_BUFFER_OBJECT                    = 0x03000010,


		  /*! NV20 vertex program */
		  NV_VERTEX_PROGRAM                           = 0x04000001,

		  /*! NV30 vertex program */
		  NV_VERTEX_PROGRAM2                          = 0x04000002,

		  /*! ARB vertex program */
		  ARB_VERTEX_PROGRAM                          = 0x04000004,

		  /*! ARB vertex shader */
		  ARB_VERTEX_SHADER                           = 0x04000008,

		  /*! ARB shader objects - FIXME: Does this belong here? */
		  ARB_SHADER_OBJECTS                          = 0x04000010,

		  /*! ARB shading language 100 - FIXME: Does this belong here? */
		  ARB_SHADING_LANGUAGE_100                    = 0x04000020,


		  /*! ARB fragment program */
		  ARB_FRAGMENT_PROGRAM                        = 0x04000100,

		  /*! ATI fragment shader */
		  ATI_FRAGMENT_SHADER                         = 0x04000200,

		  /*! NV register combiners */
		  NV_REGISTER_COMBINERS                       = 0x04000400,

		  /*! NV register combiners 2 */
		  NV_REGISTER_COMBINERS2                      = 0x04000800,

		  /*! ARB fragment shader */
		  ARB_FRAGMENT_SHADER                         = 0x04001000,


		  /*! Automatic mipmap generation */
		  SGIS_GENERATE_MIPMAP                        = 0x05000001,

		  /*! Texture cubemaps */
		  ARB_TEXTURE_CUBE_MAP                        = 0x05000002,

		  /*! Anisotropic filtering */
		  EXT_TEXTURE_FILTER_ANISOTROPIC              = 0x05000004,

		  /*! Per-vertex fog coordinate */
		  EXT_FOG_COORD                               = 0x05000008,

		  /*! Point parameters */
		  ARB_POINT_PARAMETERS                        = 0x05000010,

		  /*! Point sprites */
		  ARB_POINT_SPRITE                            = 0x05000020
		};


	protected:

		/*! Supported extensions */
		unsigned int                                  m_auiExtensions[256];


	public:

		/**
		*/
		                                              Extensions() { memset( m_auiExtensions, 0, sizeof( unsigned int ) * 256 ); }

		/**
		*/
		                                             ~Extensions() {}

		/**
		* Query if extension is supported (don't combine extensions from different groups)
		* \param uiExtension                          Extension ID to query for
		* \return                                     true if extension is supported, false if not
		*/
		inline bool                                   IsSupported( unsigned int uiExtension ) const { return( ( m_auiExtensions[ ( uiExtension >> 24 ) & 0xFF ] & ( uiExtension & 0x00FFFFFF ) ) != 0 ); }

		/**
		* Set extension (don't combine extensions from different groups)
		* \param uiExtensions                         Extension ID bits to set
		*/
		void                                          Set( unsigned int uiExtensions ) { m_auiExtensions[ ( uiExtensions >> 24 ) & 0xFF ] |= ( uiExtensions & 0x00FFFFFF ); }

		/**
		* Reset extension (don't combine extensions from different groups)
		* \param uiExtensions                         Extension ID bits to reset
		*/
		void                                          Reset( unsigned int uiExtensions ) { m_auiExtensions[ ( uiExtensions >> 24 ) & 0xFF ] &= ( ~( uiExtensions & 0x00FFFFFF ) & 0xFF000000 ); }

		/**
		* Reset all caps
		*/
		void                                          ResetAll() { memset( m_auiExtensions, 0, sizeof( unsigned int ) * 256 ); }
};


}; // namespace NeoOGL


//EXTENSION FUNCTIONS

bool                                                     neoglCheckError( const std::string &rstrPrefix = "*** OpenGL ERROR: " );

#ifdef __APPLE__

#  define neoglActiveTextureARB(x)                       glActiveTextureARB((x))
#  define neoglClientActiveTextureARB(x)                 glClientActiveTextureARB((x))

#else

typedef void (NEOGLAPIENTRY *                            fpglActiveTextureARBProc)( GLenum );
typedef void (NEOGLAPIENTRY *                            fpglClientActiveTextureARBProc)( GLenum );

extern fpglActiveTextureARBProc                          fpneoglActiveTextureARB;
extern fpglClientActiveTextureARBProc                    fpneoglClientActiveTextureARB;

#  define neoglActiveTextureARB(x)                      (fpneoglActiveTextureARB((x)))
#  define neoglClientActiveTextureARB(x)                (fpneoglClientActiveTextureARB((x)))

#endif

#ifdef POSIX

#  define neoglXGetProcAddressARB( address )            (glXGetProcAddressARB((address)))

#endif

#ifdef WIN32

/* WGL_EXT_extensions_string */
typedef const char* ( NEOGLAPIENTRY *                    fpwglGetExtensionsStringEXTProc)( void );

extern fpwglGetExtensionsStringEXTProc                   fpneowglGetExtensionsStringEXT;

#  define neowglGetExtensionsStringEXT()                (fpneowglGetExtensionsStringEXT())

/* WGL_ARB_pixel_format */

typedef BOOL (NEOGLAPIENTRY *                            fpwglGetPixelFormatAttribivARBProc)(HDC hdc, int iPixelFormat, int iLayerPlane, UINT nAttributes, const int *piAttributes, int *piValues);
typedef BOOL (NEOGLAPIENTRY *                            fpwglGetPixelFormatAttribfvARBProc)(HDC hdc, int iPixelFormat, int iLayerPlane, UINT nAttributes, const int *piAttributes, FLOAT *pfValues);
typedef BOOL (NEOGLAPIENTRY *                            fpwglChoosePixelFormatARBProc)(HDC hdc, const int *piAttribIList, const float *pfAttribFList, unsigned int nMaxFormats, int *piFormats, unsigned int *nNumFormats);

extern fpwglGetPixelFormatAttribivARBProc                fpneowglGetPixelFormatAttribivARB;
extern fpwglGetPixelFormatAttribfvARBProc                fpneowglGetPixelFormatAttribfvARB;
extern fpwglChoosePixelFormatARBProc                     fpneowglChoosePixelFormatARB;

#  define neowglGetPixelFormatAttribfvARB(a,b,c,d,e,f)  (fpneowglGetPixelFormatAttribfvARB((a),(b),(c),(d),(e),(f)))
#  define neowglGetPixelFormatAttribivARB(a,b,c,d,e,f)  (fpneowglGetPixelFormatAttribivARB((a),(b),(c),(d),(e),(f)))
#  define neowglChoosePixelFormatARB(a,b,c,d,e,f)       (fpneowglChoosePixelFormatARB((a),(b),(c),(d),(e),(f)))

/* WGL_ARB_pbuffer */

typedef HDC         (NEOGLAPIENTRY *                     fpwglGetPbufferDCARBProc)(HPBUFFERARB hPbuffer);
typedef HPBUFFERARB (NEOGLAPIENTRY *                     fpwglCreatePbufferARBProc)(HDC hDC, int iPixelFormat, int iWidth, int iHeight, const int *piAttribList);
typedef int         (NEOGLAPIENTRY *                     fpwglReleasePbufferDCARBProc)(HPBUFFERARB hPbuffer, HDC hDC);
typedef BOOL        (NEOGLAPIENTRY *                     fpwglDestroyPbufferARBProc)(HPBUFFERARB hPbuffer);
typedef BOOL        (NEOGLAPIENTRY *                     fpwglQueryPbufferARBProc)(HPBUFFERARB hPbuffer, int iAttribute, int *piValue);

extern fpwglCreatePbufferARBProc                         fpneowglCreatePbufferARB;
extern fpwglGetPbufferDCARBProc                          fpneowglGetPbufferDCARB;
extern fpwglReleasePbufferDCARBProc                      fpneowglReleasePbufferDCARB;
extern fpwglDestroyPbufferARBProc                        fpneowglDestroyPbufferARB;
extern fpwglQueryPbufferARBProc                          fpneowglQueryPbufferARB;

#  define neowglCreatePbufferARB(a,b,c,d,e)             (fpneowglCreatePbufferARB((a),(b),(c),(d),(e)))
#  define neowglGetPbufferDCARB(a)                      (fpneowglGetPbufferDCARB((a)))
#  define neowglReleasePbufferDCARB(a,b)                (fpneowglReleasePbufferDCARB((a),(b)))
#  define neowglDestroyPbufferARB(a)                    (fpneowglDestroyPbufferARB((a)))
#  define neowglQueryPbufferARB(a,b,c)                  (fpneowglQueryPbufferARB((a),(b),(c)))


/* WGL_ARB_render_texture */

typedef BOOL (NEOGLAPIENTRY *                            fpwglBindTexImageARBProc)(HPBUFFERARB hPbuffer, int iBuffer);
typedef BOOL (NEOGLAPIENTRY *                            fpwglReleaseTexImageARBProc)(HPBUFFERARB hPbuffer, int iBuffer);
typedef BOOL (NEOGLAPIENTRY *                            fpwglSetPbufferAttribARBProc)(HPBUFFERARB hPbuffer, const int *piAttribList);

extern fpwglBindTexImageARBProc                          fpneowglBindTexImageARB;
extern fpwglReleaseTexImageARBProc                       fpneowglReleaseTexImageARB;
extern fpwglSetPbufferAttribARBProc                      fpneowglSetPbufferAttribARB;

#  define neowglBindTexImageARB(a,b)                    (fpneowglBindTexImageARB((a),(b)))
#  define neowglReleaseTexImageARB(a,b)                 (fpneowglReleaseTexImageARB((a),(b)))
#  define neowglSetPbufferAttribARB(a,b)                (fpneowglSetPbufferAttribARB((a),(b)))


#endif // WIN32

/*! ARB_transpose_matrix */

typedef void      (NEOGLAPIENTRY *                          fpglLoadMatrixfARBProc)( GLfloat* );
typedef void      (NEOGLAPIENTRY *                          fpglMultMatrixfARBProc)( GLfloat* );

extern fpglLoadMatrixfARBProc                               fpneoglLoadMatrixfARB;
extern fpglMultMatrixfARBProc                               fpneoglMultMatrixfARB;

#define neoglLoadMatrixf(x)                                (fpneoglLoadMatrixfARB((x)))
#define neoglMultMatrixf(x)                                (fpneoglMultMatrixfARB((x)))


/*! EXT_fog_coord */
typedef void      (NEOGLAPIENTRY *                          fpglFogCoordfEXTProc)( GLfloat );
typedef void      (NEOGLAPIENTRY *                          fpglFogCoorddEXTProc)( GLdouble );
typedef void      (NEOGLAPIENTRY *                          fpglFogCoordfvEXTProc)( GLfloat );
typedef void      (NEOGLAPIENTRY *                          fpglFogCoorddvEXTProc)( GLdouble );
typedef void      (NEOGLAPIENTRY *                          fpglFogCoordPointerEXTProc)( GLenum, GLsizei, const GLvoid * );

extern fpglFogCoordfEXTProc                                 fpneoglFogCoordfEXT;
extern fpglFogCoorddEXTProc                                 fpneoglFogCoorddEXT;
extern fpglFogCoordfvEXTProc                                fpneoglFogCoordfvEXT;
extern fpglFogCoorddvEXTProc                                fpneoglFogCoorddvEXT;
extern fpglFogCoordPointerEXTProc                           fpneoglFogCoordPointerEXT;

#define neoglFogCoordfEXT(x)                               (fpneoglFogCoordfEXT((x)))
#define neoglFogCoorddEXT(x)                               (fpneoglFogCoorddEXT((x)))
#define neoglFogCoordfvEXT(x)                              (fpneoglFogCoordfvEXT((x)))
#define neoglFogCoorddvEXT(x)                              (fpneoglFogCoorddvEXT((x)))
#define neoglFogCoordPointerEXT(a,b,c)                     (fpneoglFogCoordPointerEXT((a),(b),(c)))


/*! ARB_point_parameters */
typedef void       (NEOGLAPIENTRY *                         fpglPointParameterfARB)( GLenum, GLfloat );
typedef void       (NEOGLAPIENTRY *                         fpglPointParameterfvARB)( GLenum, GLfloat* );

extern fpglPointParameterfARB                               fpneoglPointParameterfARB;
extern fpglPointParameterfvARB                              fpneoglPointParameterfvARB;

#define neoglPointParameterfARB( pname, param )            (fpneoglPointParameterfARB( ( pname ), ( param ) ) )
#define neoglPointParameterfvARB( pname, param )           (fpneoglPointParameterfvARB( ( pname ), ( param ) ) )


/*! ATI_vertex_array_object */

typedef GLuint    (NEOGLAPIENTRY *                          fpglNewObjectBufferATI)( GLsizei, const GLvoid *, GLenum );
typedef GLboolean (NEOGLAPIENTRY *                          fpglIsObjectBufferATI)( GLuint );
typedef void      (NEOGLAPIENTRY *                          fpglUpdateObjectBufferATI)( GLuint, GLuint, GLsizei, const GLvoid *, GLenum );
typedef void      (NEOGLAPIENTRY *                          fpglGetObjectBuffervATI)( GLuint, GLenum, GLfloat * );
typedef void      (NEOGLAPIENTRY *                          fpglGetObjectBufferATI)( GLuint );
typedef void      (NEOGLAPIENTRY *                          fpglFreeObjectBufferATI)( GLuint );
typedef void      (NEOGLAPIENTRY *                          fpglArrayObjectATI)( GLenum, GLint, GLenum, GLsizei, GLuint, GLuint );

extern fpglNewObjectBufferATI                               fpneoglNewObjectBufferATI;
extern fpglUpdateObjectBufferATI                            fpneoglUpdateObjectBufferATI;
extern fpglFreeObjectBufferATI                              fpneoglFreeObjectBufferATI;
extern fpglArrayObjectATI                                   fpneoglArrayObjectATI;

#define neoglNewObjectBufferATI(a,b,c)                      (fpneoglNewObjectBufferATI((a),(b),(c)))
#define neoglUpdateObjectBufferATI(a,b,c,d,e)               (fpneoglUpdateObjectBufferATI((a),(b),(c),(d),(e)))
#define neoglFreeObjectBufferATI(a)                         (fpneoglFreeObjectBufferATI((a)))
#define neoglArrayObjectATI(a,b,c,d,e,f)                    (fpneoglArrayObjectATI((a),(b),(c),(d),(e),(f)))


/*! ATI_vertex_attrib_array_object */

typedef void       (NEOGLAPIENTRY *                         fpglVertexAttribArrayObjectATI)( GLuint, GLint, GLenum, GLboolean, GLsizei, GLuint, GLuint );

extern fpglVertexAttribArrayObjectATI                       fpneoglVertexAttribArrayObjectATI;

#define neoglVertexAttribArrayObjectATI( uiIndex, iSize, eType, bNormalized, iStride, uiBuffer, uiOffset ) (fpneoglVertexAttribArrayObjectATI( uiIndex, iSize, eType, bNormalized, iStride, uiBuffer, uiOffset ))


/*! ARB_vertex_buffer_object */

typedef void      (NEOGLAPIENTRY *                          fpglBindBufferARB)( GLenum, GLuint );
typedef void      (NEOGLAPIENTRY *                          fpglDeleteBuffersARB)( GLsizei, const GLuint * );
typedef void      (NEOGLAPIENTRY *                          fpglGenBuffersARB)( GLsizei, GLuint* );
typedef void      (NEOGLAPIENTRY *                          fpglIsBufferARB)( GLuint );
typedef void      (NEOGLAPIENTRY *                          fpglBufferDataARB)( GLenum, GLsizeiptrARB, const GLvoid *, GLenum );
typedef void      (NEOGLAPIENTRY *                          fpglBufferSubDataARB)( GLenum, GLintptrARB, GLsizeiptrARB, const GLvoid* );
typedef void      (NEOGLAPIENTRY *                          fpglGetBufferSubDataARB)( GLenum, GLintptrARB, GLsizeiptrARB, GLvoid* );
typedef void *    (NEOGLAPIENTRY *                          fpglMapBufferARB)( GLenum, GLenum );
typedef GLboolean (NEOGLAPIENTRY *                          fpglUnmapBufferARB)( GLenum );
typedef void      (NEOGLAPIENTRY *                          fpglGetBufferParameterivARB)( GLenum, GLenum, GLint * );
typedef void      (NEOGLAPIENTRY *                          fpglGetBufferPointervARB)( GLenum, GLenum, GLvoid ** );

extern fpglBindBufferARB                                    fpneoglBindBufferARB;
extern fpglDeleteBuffersARB                                 fpneoglDeleteBuffersARB;
extern fpglGenBuffersARB                                    fpneoglGenBuffersARB;
extern fpglIsBufferARB                                      fpneoglIsBufferARB;
extern fpglBufferDataARB                                    fpneoglBufferDataARB;
extern fpglBufferSubDataARB                                 fpneoglBufferSubDataARB;
extern fpglGetBufferSubDataARB                              fpneoglGetBufferSubDataARB;
extern fpglMapBufferARB                                     fpneoglMapBufferARB;
extern fpglUnmapBufferARB                                   fpneoglUnmapBufferARB;
extern fpglGetBufferParameterivARB                          fpneoglGetBufferParameterivARB;
extern fpglGetBufferPointervARB                             fpneoglGetBufferPointervARB;

#define neoglBindBufferARB(a,b)                             (fpneoglBindBufferARB((a),(b)))
#define neoglDeleteBuffersARB(a,b)                          (fpneoglDeleteBuffersARB((a),(b)))
#define neoglGenBuffersARB(a,b)                             (fpneoglGenBuffersARB((a),(b)))
#define neoglIsBufferARB(a)                                 (fpneoglIsBufferARB((a)))
#define neoglBufferDataARB(a,b,c,d)                         (fpneoglBufferDataARB((a),(b),(c),(d)))
#define neoglBufferSubDataARB(a,b,c,d)                      (fpneoglBufferSubDataARB((a),(b),(c),(d)))
#define neoglGetBufferSubDataARB(a,b,c,d)                   (fpneoglGetBufferSubDataARB((a),(b),(c),(d)))
#define neoglMapBufferARB(a,b)                              (fpneoglMapBufferARB((a),(b)))
#define neoglUnmapBufferARB(a)                              (fpneoglUnmapBufferARB((a)))
#define neoglGetBufferParameterivARB(a,b,c)                 (fpneoglGetBufferParameterivARB((a),(b),(c)))
#define neoglGetBufferPointervARB(a,b,c)                    (fpneoglGetBufferPointervARB((a),(b),(c)))


/*! ARB_vertex_program */

typedef void      (NEOGLAPIENTRY *                           fpglVertexAttribPointerARB)( GLuint, GLint, GLenum, GLboolean, GLsizei, const GLvoid * );
typedef void      (NEOGLAPIENTRY *                           fpglEnableVertexAttribArrayARB)( GLuint );
typedef void      (NEOGLAPIENTRY *                           fpglDisableVertexAttribArrayARB)( GLuint );
typedef void      (NEOGLAPIENTRY *                           fpglProgramStringARB)( GLenum, GLenum, GLsizei, const GLvoid * );
typedef void      (NEOGLAPIENTRY *                           fpglBindProgramARB)( GLenum, GLuint );
typedef void      (NEOGLAPIENTRY *                           fpglDeleteProgramsARB)( GLsizei, const GLuint * );
typedef void      (NEOGLAPIENTRY *                           fpglGenProgramsARB)( GLsizei, GLuint * );
typedef void      (NEOGLAPIENTRY *                           fpglProgramEnvParameter4fARB)( GLenum, GLuint, GLfloat, GLfloat, GLfloat, GLfloat );
typedef void      (NEOGLAPIENTRY *                           fpglProgramEnvParameter4fvARB)( GLenum, GLuint, const GLfloat * );
typedef void      (NEOGLAPIENTRY *                           fpglProgramLocalParameter4fARB)( GLenum, GLuint, GLfloat, GLfloat, GLfloat, GLfloat );
typedef void      (NEOGLAPIENTRY *                           fpglProgramLocalParameter4fvARB)( GLenum, GLuint, const GLfloat * );
typedef void      (NEOGLAPIENTRY *                           fpglGetProgramivARB)( GLenum, GLenum, GLint * );

extern fpglVertexAttribPointerARB                            fpneoglVertexAttribPointerARB;
extern fpglEnableVertexAttribArrayARB                        fpneoglEnableVertexAttribArrayARB;
extern fpglDisableVertexAttribArrayARB                       fpneoglDisableVertexAttribArrayARB;
extern fpglProgramStringARB                                  fpneoglProgramStringARB;
extern fpglBindProgramARB                                    fpneoglBindProgramARB;
extern fpglDeleteProgramsARB                                 fpneoglDeleteProgramsARB;
extern fpglGenProgramsARB                                    fpneoglGenProgramsARB;
extern fpglProgramEnvParameter4fARB                          fpneoglProgramEnvParameter4fARB;
extern fpglProgramEnvParameter4fvARB                         fpneoglProgramEnvParameter4fvARB;
extern fpglProgramLocalParameter4fARB                        fpneoglProgramLocalParameter4fARB;
extern fpglProgramLocalParameter4fvARB                       fpneoglProgramLocalParameter4fvARB;
extern fpglGetProgramivARB                                   fpneoglGetProgramivARB;

#define neoglVertexAttribPointerARB(a, b, c, d, e, f )      (fpneoglVertexAttribPointerARB((a),(b),(c),(d),(e),(f)))
#define neoglEnableVertexAttribArrayARB(a)                  (fpneoglEnableVertexAttribArrayARB((a)))
#define neoglDisableVertexAttribArrayARB(a)                 (fpneoglDisableVertexAttribArrayARB((a)))
#define neoglProgramStringARB(a, b, c, d)                   (fpneoglProgramStringARB((a),(b),(c),(d)))
#define neoglBindProgramARB(a, b)                           (fpneoglBindProgramARB((a),(b)))
#define neoglDeleteProgramsARB( a, b )                      (fpneoglDeleteProgramsARB((a),(b)))
#define neoglGenProgramsARB(a, b)                           (fpneoglGenProgramsARB((a),(b)))
#define neoglProgramEnvParameter4fARB(a, b, c, d, e, f )    (fpneoglProgramEnvParameter4fARB((a),(b),(c),(d),(e),(f)))
#define neoglProgramEnvParameter4fvARB(a, b, c)             (fpneoglProgramEnvParameter4fvARB((a),(b),(c)))
#define neoglProgramLocalParameter4fARB(a, b, c, d, e, f )  (fpneoglProgramLocalParameter4fARB((a),(b),(c),(d),(e),(f)))
#define neoglProgramLocalParameter4fvARB(a, b, c)           (fpneoglProgramLocalParameter4fvARB((a),(b),(c)))
#define neoglGetProgramivARB(a, b, c)                       (fpneoglGetProgramivARB((a),(b),(c)))


/*! ATI_fragment_shader */

typedef GLuint     (NEOGLAPIENTRY *                          fpglGenFragmentShadersATI)( GLuint );
typedef void       (NEOGLAPIENTRY *                          fpglBindFragmentShaderATI)( GLuint );
typedef void       (NEOGLAPIENTRY *                          fpglDeleteFragmentShaderATI)( GLuint );
typedef void       (NEOGLAPIENTRY *                          fpglBeginFragmentShaderATI)( GLvoid );
typedef void       (NEOGLAPIENTRY *                          fpglEndFragmentShaderATI)( GLvoid );
typedef void       (NEOGLAPIENTRY *                          fpglPassTexCoordATI)( GLuint, GLuint, GLenum );
typedef void       (NEOGLAPIENTRY *                          fpglSampleMapATI)( GLuint, GLuint, GLenum );
typedef void       (NEOGLAPIENTRY *                          fpglColorFragmentOp1ATI)( GLenum, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint );
typedef void       (NEOGLAPIENTRY *                          fpglColorFragmentOp2ATI)( GLenum, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint );
typedef void       (NEOGLAPIENTRY *                          fpglColorFragmentOp3ATI)( GLenum, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint );
typedef void       (NEOGLAPIENTRY *                          fpglAlphaFragmentOp1ATI)( GLenum, GLuint, GLuint, GLuint, GLuint, GLuint );
typedef void       (NEOGLAPIENTRY *                          fpglAlphaFragmentOp2ATI)( GLenum, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint );
typedef void       (NEOGLAPIENTRY *                          fpglAlphaFragmentOp3ATI)( GLenum, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint, GLuint );
typedef void       (NEOGLAPIENTRY *                          fpglSetFragmentShaderConstantATI)( GLuint, const GLfloat * );


extern fpglGenFragmentShadersATI                             fpneoglGenFragmentShadersATI;
extern fpglBindFragmentShaderATI                             fpneoglBindFragmentShaderATI;
extern fpglDeleteFragmentShaderATI                           fpneoglDeleteFragmentShaderATI;
extern fpglBeginFragmentShaderATI                            fpneoglBeginFragmentShaderATI;
extern fpglEndFragmentShaderATI                              fpneoglEndFragmentShaderATI;
extern fpglPassTexCoordATI                                   fpneoglPassTexCoordATI;
extern fpglSampleMapATI                                      fpneoglSampleMapATI;
extern fpglColorFragmentOp1ATI                               fpneoglColorFragmentOp1ATI;
extern fpglColorFragmentOp2ATI                               fpneoglColorFragmentOp2ATI;
extern fpglColorFragmentOp3ATI                               fpneoglColorFragmentOp3ATI;
extern fpglAlphaFragmentOp1ATI                               fpneoglAlphaFragmentOp1ATI;
extern fpglAlphaFragmentOp2ATI                               fpneoglAlphaFragmentOp2ATI;
extern fpglAlphaFragmentOp3ATI                               fpneoglAlphaFragmentOp3ATI;
extern fpglSetFragmentShaderConstantATI                      fpneoglSetFragmentShaderConstantATI;

#define neoglGenFragmentShadersATI( uiRange )               (fpneoglGenFragmentShadersATI( uiRange ))
#define neoglBindFragmentShaderATI( uiShader )              (fpneoglBindFragmentShaderATI( uiShader ))
#define neoglDeleteFragmentShaderATI( uiShader )            (fpneoglDeleteFragmentShaderATI( uiShader ))
#define neoglBeginFragmentShaderATI()                       (fpneoglBeginFragmentShaderATI())
#define neoglEndFragmentShaderATI()                         (fpneoglEndFragmentShaderATI())
#define neoglPassTexCoordATI( uiDst, uiSrc, eSwizzle )      (fpneoglPassTexCoordATI( uiDst, uiSrc, eSwizzle ) )
#define neoglSampleMapATI( uiDst, uiSrc, eSwizzle )         (fpneoglSampleMapATI( uiDst, uiSrc, eSwizzle ) )
#define neoglColorFragmentOp1ATI( eOp, uiDst, uiDstMask, uiDstMod, uiArg1, uiArg1Rep, uiArg1Mod )                                                             (fpneoglColorFragmentOp1ATI( eOp, uiDst, uiDstMask, uiDstMod, uiArg1, uiArg1Rep, uiArg1Mod ) )
#define neoglColorFragmentOp2ATI( eOp, uiDst, uiDstMask, uiDstMod, uiArg1, uiArg1Rep, uiArg1Mod, uiArg2, uiArg2Rep, uiArg2Mod )                               (fpneoglColorFragmentOp2ATI( eOp, uiDst, uiDstMask, uiDstMod, uiArg1, uiArg1Rep, uiArg1Mod, uiArg2, uiArg2Rep, uiArg2Mod ) )
#define neoglColorFragmentOp3ATI( eOp, uiDst, uiDstMask, uiDstMod, uiArg1, uiArg1Rep, uiArg1Mod, uiArg2, uiArg2Rep, uiArg2Mod, uiArg3, uiArg3Rep, uiArg3Mod ) (fpneoglColorFragmentOp3ATI( eOp, uiDst, uiDstMask, uiDstMod, uiArg1, uiArg1Rep, uiArg1Mod, uiArg2, uiArg2Rep, uiArg2Mod, uiArg3, uiArg3Rep, uiArg3Mod ) )
#define neoglAlphaFragmentOp1ATI( eOp, uiDst, uiDstMod, uiArg1, uiArg1Rep, uiArg1Mod )                                                                        (fpneoglAlphaFragmentOp1ATI( eOp, uiDst, uiDstMod, uiArg1, uiArg1Rep, uiArg1Mod ) )
#define neoglAlphaFragmentOp2ATI( eOp, uiDst, uiDstMod, uiArg1, uiArg1Rep, uiArg1Mod, uiArg2, uiArg2Rep, uiArg2Mod )                                          (fpneoglAlphaFragmentOp2ATI( eOp, uiDst, uiDstMod, uiArg1, uiArg1Rep, uiArg1Mod, uiArg2, uiArg2Rep, uiArg2Mod ) )
#define neoglAlphaFragmentOp3ATI( eOp, uiDst, uiDstMod, uiArg1, uiArg1Rep, uiArg1Mod, uiArg2, uiArg2Rep, uiArg2Mod, uiArg3, uiArg3Rep, uiArg3Mod )            (fpneoglAlphaFragmentOp3ATI( eOp, uiDst, uiDstMod, uiArg1, uiArg1Rep, uiArg1Mod, uiArg2, uiArg2Rep, uiArg2Mod, uiArg3, uiArg3Rep, uiArg3Mod ) )
#define neoglSetFragmentShaderConstantATI( uiNum, pfVal )   (fpneoglSetFragmentShaderConstantATI( uiNum, pfVal ) )


/*! NV_register_combiners */

typedef void          (NEOGLAPIENTRY *                       fpglCombinerParameterfvNV)( GLenum, const GLfloat * );
typedef void          (NEOGLAPIENTRY *                       fpglCombinerParameterfNV)( GLenum, const GLfloat );
typedef void          (NEOGLAPIENTRY *                       fpglCombinerParameterivNV)( GLenum, const GLint * );
typedef void          (NEOGLAPIENTRY *                       fpglCombinerParameteriNV)( GLenum, const GLint );
typedef void          (NEOGLAPIENTRY *                       fpglCombinerInputNV)( GLenum, GLenum, GLenum, GLenum, GLenum, GLenum );
typedef void          (NEOGLAPIENTRY *                       fpglCombinerOutputNV)( GLenum, GLenum, GLenum, GLenum, GLenum, GLenum, GLenum, GLboolean, GLboolean, GLboolean );
typedef void          (NEOGLAPIENTRY *                       fpglFinalCombinerInputNV) ( GLenum, GLenum, GLenum, GLenum );

extern fpglCombinerParameterfvNV                             fpneoglCombinerParameterfvNV;
extern fpglCombinerParameterfNV                              fpneoglCombinerParameterfNV;
extern fpglCombinerParameterivNV                             fpneoglCombinerParameterivNV;
extern fpglCombinerParameteriNV                              fpneoglCombinerParameteriNV;
extern fpglCombinerInputNV                                   fpneoglCombinerInputNV;
extern fpglCombinerOutputNV                                  fpneoglCombinerOutputNV;
extern fpglFinalCombinerInputNV                              fpneoglFinalCombinerInputNV;

#define neoglCombinerParameterfvNV( eName, pfParams )       (fpneoglCombinerParameterfvNV( eName, pfParams ))
#define neoglCombinerParameterfNV( eName, fParam )          (fpneoglCombinerParameterfNV( eName, fParam ))
#define neoglCombinerParameterivNV( eName, piParams )       (fpneoglCombinerParameterivNV( eName, piParams ))
#define neoglCombinerParameteriNV( eName, iParam )          (fpneoglCombinerParameteriNV( eName, iParam ))
#define neoglCombinerInputNV( eStage, ePortion, eVar, eInput, eMapping, eUsage ) (fpneoglCombinerInputNV( eStage, ePortion, eVar, eInput, eMapping, eUsage ))
#define neoglCombinerOutputNV( eStage, ePortion, eABOut, eCDOut, eSumOut, eScale, eBias, bABDotProd, bCDDotProd, bMuxSum ) (fpneoglCombinerOutputNV( eStage, ePortion, eABOut, eCDOut, eSumOut, eScale, eBias, bABDotProd, bCDDotProd, bMuxSum ))
#define neoglFinalCombinerInputNV( eVar, eInput, eMapping, eUsage ) (fpneoglFinalCombinerInputNV( eVar, eInput, eMapping, eUsage ))


/*! NV_register_combiners2 */

typedef void           (NEOGLAPIENTRY *                      fpglCombinerStageParameterfvNV)( GLenum, GLenum, const GLfloat * );

extern fpglCombinerStageParameterfvNV                        fpneoglCombinerStageParameterfvNV;

#define neoglCombinerStageParameterfvNV( eStage, ePName, pfParams ) (fpneoglCombinerStageParameterfvNV( eStage, ePName, pfParams ))



/*! NV_vertex_program */
typedef void      (NEOGLAPIENTRY *                           fpglVertexAttribPointerNV)( GLuint, GLint, GLenum, GLsizei, const GLvoid* );

extern fpglVertexAttribPointerNV                             fpneoglVertexAttribPointerNV;

#define neoglVertexAttribPointerNV( index, size, type, stride, pointer ) (fpneoglVertexAttribPointerNV( (index), (size), (type), (stride), (pointer) ) )


/*! ARB_shader_objects */
typedef void        (NEOGLAPIENTRY *                         fpglDeleteObjectARB)( GLenum );
typedef GLhandleARB (NEOGLAPIENTRY *                         fpglGetHandleARB)( GLenum );
typedef void        (NEOGLAPIENTRY *                         fpglDetachObjectARB)( GLhandleARB, GLhandleARB );
typedef GLhandleARB (NEOGLAPIENTRY *                         fpglCreateShaderObjectARB)( GLenum );
typedef void        (NEOGLAPIENTRY *                         fpglShaderSourceARB)( GLhandleARB, GLsizei, const GLcharARB **, const GLint * );
typedef void        (NEOGLAPIENTRY *                         fpglCompileShaderARB)( GLhandleARB );
typedef GLhandleARB (NEOGLAPIENTRY *                         fpglCreateProgramObjectARB)( void );
typedef void        (NEOGLAPIENTRY *                         fpglAttachObjectARB)( GLhandleARB, GLhandleARB);
typedef void        (NEOGLAPIENTRY *                         fpglLinkProgramARB)( GLhandleARB );
typedef void        (NEOGLAPIENTRY *                         fpglUseProgramObjectARB)( GLhandleARB );
typedef void        (NEOGLAPIENTRY *                         fpglValidateProgramARB)( GLhandleARB );
typedef void        (NEOGLAPIENTRY *                         fpglUniform1fARB)( GLint, GLfloat );
typedef void        (NEOGLAPIENTRY *                         fpglUniform2fARB)( GLint, GLfloat, GLfloat );
typedef void        (NEOGLAPIENTRY *                         fpglUniform3fARB)( GLint, GLfloat, GLfloat, GLfloat );
typedef void        (NEOGLAPIENTRY *                         fpglUniform4fARB)( GLint, GLfloat, GLfloat, GLfloat, GLfloat );
typedef void        (NEOGLAPIENTRY *                         fpglUniform1iARB)( GLint, GLint );
typedef void        (NEOGLAPIENTRY *                         fpglUniform2iARB)( GLint, GLint, GLint );
typedef void        (NEOGLAPIENTRY *                         fpglUniform3iARB)( GLint, GLint, GLint, GLint );
typedef void        (NEOGLAPIENTRY *                         fpglUniform4iARB)( GLint, GLint, GLint, GLint, GLint );
typedef void        (NEOGLAPIENTRY *                         fpglUniform1fvARB)( GLint, GLsizei, GLfloat * );
typedef void        (NEOGLAPIENTRY *                         fpglUniform2fvARB)( GLint, GLsizei, GLfloat * );
typedef void        (NEOGLAPIENTRY *                         fpglUniform3fvARB)( GLint, GLsizei, GLfloat * );
typedef void        (NEOGLAPIENTRY *                         fpglUniform4fvARB)( GLint, GLsizei, GLfloat * );
typedef void        (NEOGLAPIENTRY *                         fpglUniform1ivARB)( GLint, GLsizei, GLint * );
typedef void        (NEOGLAPIENTRY *                         fpglUniform2ivARB)( GLint, GLsizei, GLint * );
typedef void        (NEOGLAPIENTRY *                         fpglUniform3ivARB)( GLint, GLsizei, GLint * );
typedef void        (NEOGLAPIENTRY *                         fpglUniform4ivARB)( GLint, GLsizei, GLint * );
typedef void        (NEOGLAPIENTRY *                         fpglUniformMatrix2fvARB)( GLint, GLsizei, GLboolean, GLfloat * );
typedef void        (NEOGLAPIENTRY *                         fpglUniformMatrix3fvARB)( GLint, GLsizei, GLboolean, GLfloat * );
typedef void        (NEOGLAPIENTRY *                         fpglUniformMatrix4fvARB)( GLint, GLsizei, GLboolean, GLfloat * );
typedef void        (NEOGLAPIENTRY *                         fpglGetObjectParameterfvARB)( GLhandleARB, GLenum, GLfloat *);
typedef void        (NEOGLAPIENTRY *                         fpglGetObjectParameterivARB)( GLhandleARB, GLenum, GLint *);
typedef void        (NEOGLAPIENTRY *                         fpglGetInfoLogARB)( GLhandleARB, GLsizei, GLsizei *, GLcharARB * );
typedef void        (NEOGLAPIENTRY *                         fpglGetAttachedObjectsARB)( GLhandleARB containerObj, GLsizei, GLsizei *, GLhandleARB * );
typedef GLint       (NEOGLAPIENTRY *                         fpglGetUniformLocationARB)( GLhandleARB programObj, const GLcharARB * );
typedef void        (NEOGLAPIENTRY *                         fpglGetActiveUniformARB)( GLhandleARB, GLuint, GLsizei, GLsizei *, GLint *, GLenum *, GLcharARB * );
typedef void        (NEOGLAPIENTRY *                         fpglGetUniformfvARB)( GLhandleARB, GLint, GLfloat * );
typedef void        (NEOGLAPIENTRY *                         fpglGetUniformivARB)( GLhandleARB, GLint, GLint * );
typedef void        (NEOGLAPIENTRY *                         fpglGetShaderSourceARB)( GLhandleARB, GLsizei, GLsizei *, GLcharARB * );


extern fpglDeleteObjectARB                                   fpneoglDeleteObjectARB;
extern fpglGetHandleARB                                      fpneoglGetHandleARB;
extern fpglDetachObjectARB                                   fpneoglDetachObjectARB;
extern fpglCreateShaderObjectARB                             fpneoglCreateShaderObjectARB;
extern fpglShaderSourceARB                                   fpneoglShaderSourceARB;
extern fpglCompileShaderARB                                  fpneoglCompileShaderARB;
extern fpglCreateProgramObjectARB                            fpneoglCreateProgramObjectARB;
extern fpglAttachObjectARB                                   fpneoglAttachObjectARB;
extern fpglLinkProgramARB                                    fpneoglLinkProgramARB;
extern fpglUseProgramObjectARB                               fpneoglUseProgramObjectARB;
extern fpglValidateProgramARB                                fpneoglValidateProgramARB;
extern fpglUniform1fARB                                      fpneoglUniform1fARB;
extern fpglUniform2fARB                                      fpneoglUniform2fARB;
extern fpglUniform3fARB                                      fpneoglUniform3fARB;
extern fpglUniform4fARB                                      fpneoglUniform4fARB;
extern fpglUniform1iARB                                      fpneoglUniform5fARB;
extern fpglUniform2iARB                                      fpneoglUniform6fARB;
extern fpglUniform3iARB                                      fpneoglUniform7fARB;
extern fpglUniform4iARB                                      fpneoglUniform8fARB;
extern fpglUniform1fvARB                                     fpneoglUniform1fvARB;
extern fpglUniform2fvARB                                     fpneoglUniform2fvARB;
extern fpglUniform3fvARB                                     fpneoglUniform3fvARB;
extern fpglUniform4fvARB                                     fpneoglUniform4fvARB;
extern fpglUniform1ivARB                                     fpneoglUniform1ivARB;
extern fpglUniform2ivARB                                     fpneoglUniform2ivARB;
extern fpglUniform3ivARB                                     fpneoglUniform3ivARB;
extern fpglUniform4ivARB                                     fpneoglUniform4ivARB;
extern fpglUniformMatrix2fvARB                               fpneoglUniformMatrix2fvARB;
extern fpglUniformMatrix3fvARB                               fpneoglUniformMatrix3fvARB;
extern fpglUniformMatrix4fvARB                               fpneoglUniformMatrix4fvARB;
extern fpglGetObjectParameterfvARB                           fpneoglGetObjectParameterfvARB;
extern fpglGetObjectParameterivARB                           fpneoglGetObjectParameterivARB;
extern fpglGetInfoLogARB                                     fpneoglGetInfoLogARB;
extern fpglGetAttachedObjectsARB                             fpneoglGetAttachedObjectsARB;
extern fpglGetUniformLocationARB                             fpneoglGetUniformLocationARB;
extern fpglGetActiveUniformARB                               fpneoglGetActiveUniformARB;
extern fpglGetUniformfvARB                                   fpneoglGetUniformfvARB;
extern fpglGetUniformivARB                                   fpneoglGetUniformivARB;
extern fpglGetShaderSourceARB                                fpneoglGetShaderSourceARB;


#define neoglDeleteObjectARB(a)                              (fpneoglDeleteObjectARB((a)))
#define neoglGetHandleARB(a)                                 (fpneoglGetHandleARB((a)))
#define neoglDetachObjectARB(a,b)                            (fpneoglDetachObjectARB((a),(b)))
#define neoglCreateShaderObjectARB(a)                        (fpneoglCreateShaderObjectARB((a)))
#define neoglShaderSourceARB(a,b,c,d)                        (fpneoglShaderSourceARB((a),(b),(c),(d)))
#define neoglCompileShaderARB(a)                             (fpneoglCompileShaderARB((a)))
#define neoglCreateProgramObjectARB(a)                       (fpneoglCreateProgramObjectARB((a))
#define neoglAttachObjectARB(a,b)                            (fpneoglAttachObjectARB((a),(b)))
#define neoglLinkProgramARB(a)                               (fpneoglLinkProgramARB((a)))
#define neoglUseProgramObjectARB(a)                          (fpneoglUseProgramObjectARB((a)))
#define neoglValidateProgramARB(a)                           (fpneoglValidateProgramARB((a)))
#define neoglUniform1fARB(a,b)                               (fpneoglUniform1fARB((a),(b)))
#define neoglUniform2fARB(a,b,c)                             (fpneoglUniform2fARB((a),(b),(c)))
#define neoglUniform3fARB(a,b,c,d)                           (fpneoglUniform3fARB((a),(b),(c),(d)))
#define neoglUniform4fARB(a,b,c,d,e)                         (fpneoglUniform4fARB((a),(b),(c),(d),(e)))
#define neoglUniform1iARB(a,b)                               (fpneoglUniform1iARB((a),(b)))
#define neoglUniform2iARB(a,b,c)                             (fpneoglUniform2iARB((a),(b),(c)))
#define neoglUniform3iARB(a,b,c,d)                           (fpneoglUniform3iARB((a),(b),(c),(d)))
#define neoglUniform4iARB(a,b,c,d,e)                         (fpneoglUniform4iARB((a),(b),(c),(d),(e)))
#define neoglUniform1fvARB(a,b,c)                            (fpneoglUniform1fvARB((a),(b),(c)))
#define neoglUniform2fvARB(a,b,c)                            (fpneoglUniform2fvARB((a),(b),(c)))
#define neoglUniform3fvARB(a,b,c)                            (fpneoglUniform3fvARB((a),(b),(c)))
#define neoglUniform4fvARB(a,b,c)                            (fpneoglUniform4fvARB((a),(b),(c)))
#define neoglUniform1ivARB(a,b,c)                            (fpneoglUniform1ivARB((a),(b),(c)))
#define neoglUniform2ivARB(a,b,c)                            (fpneoglUniform2ivARB((a),(b),(c)))
#define neoglUniform3ivARB(a,b,c)                            (fpneoglUniform3ivARB((a),(b),(c)))
#define neoglUniform4ivARB(a,b,c)                            (fpneoglUniform4ivARB((a),(b),(c)))
#define neoglUniformMatrix2fvARB(a,b,c,d)                    (fpneoglUniformMatrix2fvARB((a),(b),(c),(d)))
#define neoglUniformMatrix3fvARB(a,b,c,d)                    (fpneoglUniformMatrix3fvARB((a),(b),(c),(d)))
#define neoglUniformMatrix4fvARB(a,b,c,d)                    (fpneoglUniformMatrix4fvARB((a),(b),(c),(d)))
#define neoglGetObjectParameterfvARB(a,b,c)                  (fpneoglGetObjectParameterfvARB((a),(b),(c)))
#define neoglGetObjectParameterivARB(a,b,c)                  (fpneoglGetObjectParameterivARB((a),(b),(c)))
#define neoglGetInfoLogARB(a,b,c,d)                          (fpneoglGetInfoLogARB((a),(b),(c),(d)))
#define neoglGetAttachedObjectsARB(a,b,c,d)                  (fpneoglGetAttachedObjectsARB((a),(b),(c),(d)))
#define neoglGetUniformLocationARB(a,b)                      (fpneoglGetUniformLocationARB((a),(b)))
#define neoglGetActiveUniformARB(a,b,c,d,e,f,g)              (fpneoglGetActiveUniformARB((a),(b),(c),(d),(e),(f),(g)))
#define neoglGetUniformfvARB(a,b,c)                          (fpneoglGetUniformfvARB((a),(b),(c)))
#define neoglGetUniformivARB(a,b,c)                          (fpneoglGetUniformfiARB((a),(b),(c)))
#define neoglGetShaderSourceARB(a,b,c,d)                     (fpneoglGetShaderSourceARB((a),(b),(c),(d)))



/*! ARB_vertex_shader */
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib1fARB)( GLuint, GLfloat );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib1sARB)( GLuint, GLshort );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib1dARB)( GLuint, GLdouble );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib2fARB)( GLuint, GLfloat, GLfloat );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib2sARB)( GLuint, GLshort, GLshort );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib2dARB)( GLuint, GLdouble, GLdouble );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib3fARB)( GLuint, GLfloat, GLfloat v1, GLfloat );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib3sARB)( GLuint, GLshort, GLshort v1, GLshort );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib3dARB)( GLuint, GLdouble, GLdouble, GLdouble );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4fARB)( GLuint, GLfloat, GLfloat, GLfloat, GLfloat );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4sARB)( GLuint, GLshort, GLshort, GLshort, GLshort );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4dARB)( GLuint, GLdouble, GLdouble, GLdouble, GLdouble );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4NubARB)( GLuint, GLubyte, GLubyte, GLubyte, GLubyte );

typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib1fvARB)( GLuint, const GLfloat * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib1svARB)( GLuint, const GLshort * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib1dvARB)( GLuint, const GLdouble * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib2fvARB)( GLuint, const GLfloat * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib2svARB)( GLuint, const GLshort * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib2dvARB)( GLuint, const GLdouble * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib3fvARB)( GLuint, const GLfloat * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib3svARB)( GLuint, const GLshort * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib3dvARB)( GLuint, const GLdouble * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4fvARB)( GLuint, const GLfloat * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4svARB)( GLuint, const GLshort * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4dvARB)( GLuint, const GLdouble * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4ivARB)( GLuint, const GLint * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4bvARB)( GLuint, const GLbyte * );

typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4ubvARB)( GLuint, const GLubyte * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4usvARB)( GLuint, const GLushort * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4uivARB)( GLuint, const GLuint * );

typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4NbvARB)( GLuint, const GLbyte * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4NsvARB)( GLuint, const GLshort * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4NivARB)( GLuint, const GLint * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4NubvARB)( GLuint, const GLubyte * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4NusvARB)( GLuint, const GLushort * );
typedef void        (NEOGLAPIENTRY *                         fpglVertexAttrib4NuivARB)( GLuint, const GLuint * );

//typedef void        (NEOGLAPIENTRY *                         fpglVertexAttribPointerARB)( GLuint, GLint, GLenum, GLboolean, GLsizei, const GLvoid * );

//typedef void        (NEOGLAPIENTRY *                         fpglEnableVertexAttribArrayARB)( GLuint );
//typedef void        (NEOGLAPIENTRY *                         fpglDisableVertexAttribArrayARB)( GLuint );

typedef void        (NEOGLAPIENTRY *                         fpglBindAttribLocationARB)( GLhandleARB, GLuint, const GLcharARB * );

typedef void        (NEOGLAPIENTRY *                         fpglGetActiveAttribARB)( GLhandleARB, GLuint, GLsizei, GLsizei *, GLint *, GLenum *, GLcharARB * );

typedef GLint       (NEOGLAPIENTRY *                         fpglGetAttribLocationARB)( GLhandleARB, const GLcharARB * );

typedef void        (NEOGLAPIENTRY *                         fpglGetVertexAttribdvARB)( GLuint, GLenum, GLdouble * );
typedef void        (NEOGLAPIENTRY *                         fpglGetVertexAttribfvARB)( GLuint, GLenum, GLfloat * );
typedef void        (NEOGLAPIENTRY *                         fpglGetVertexAttribivARB)( GLuint, GLenum, GLint * );
typedef void        (NEOGLAPIENTRY *                         fpglGetVertexAttribPointervARB)( GLuint, GLenum, GLvoid ** );


extern fpglVertexAttrib1fARB                                 fpneoglVertexAttrib1fARB;
extern fpglVertexAttrib1sARB                                 fpneoglVertexAttrib1sARB;
extern fpglVertexAttrib1dARB                                 fpneoglVertexAttrib1dARB;
extern fpglVertexAttrib2fARB                                 fpneoglVertexAttrib2fARB;
extern fpglVertexAttrib2sARB                                 fpneoglVertexAttrib2sARB;
extern fpglVertexAttrib2dARB                                 fpneoglVertexAttrib2dARB;
extern fpglVertexAttrib3fARB                                 fpneoglVertexAttrib3fARB;
extern fpglVertexAttrib3sARB                                 fpneoglVertexAttrib3sARB;
extern fpglVertexAttrib3dARB                                 fpneoglVertexAttrib3dARB;
extern fpglVertexAttrib4fARB                                 fpneoglVertexAttrib4fARB;
extern fpglVertexAttrib4sARB                                 fpneoglVertexAttrib4sARB;
extern fpglVertexAttrib4dARB                                 fpneoglVertexAttrib4dARB;
extern fpglVertexAttrib4NubARB                               fpneoglVertexAttrib4NubARB;

extern fpglVertexAttrib1fvARB                                fpneoglVertexAttrib1fvARB;
extern fpglVertexAttrib1svARB                                fpneoglVertexAttrib1svARB;
extern fpglVertexAttrib1dvARB                                fpneoglVertexAttrib1dvARB;
extern fpglVertexAttrib2fvARB                                fpneoglVertexAttrib2fvARB;
extern fpglVertexAttrib2svARB                                fpneoglVertexAttrib2svARB;
extern fpglVertexAttrib2dvARB                                fpneoglVertexAttrib2dvARB;
extern fpglVertexAttrib3fvARB                                fpneoglVertexAttrib3fvARB;
extern fpglVertexAttrib3svARB                                fpneoglVertexAttrib3svARB;
extern fpglVertexAttrib3dvARB                                fpneoglVertexAttrib3dvARB;
extern fpglVertexAttrib4fvARB                                fpneoglVertexAttrib4fvARB;
extern fpglVertexAttrib4svARB                                fpneoglVertexAttrib4svARB;
extern fpglVertexAttrib4dvARB                                fpneoglVertexAttrib4dvARB;
extern fpglVertexAttrib4ivARB                                fpneoglVertexAttrib4ivARB;
extern fpglVertexAttrib4bvARB                                fpneoglVertexAttrib4bvARB;

extern fpglVertexAttrib4ubvARB                               fpneoglVertexAttrib4ubvARB;
extern fpglVertexAttrib4usvARB                               fpneoglVertexAttrib4usvARB;
extern fpglVertexAttrib4uivARB                               fpneoglVertexAttrib4uivARB;

extern fpglVertexAttrib4NbvARB                               fpneoglVertexAttrib4NbvARB;
extern fpglVertexAttrib4NsvARB                               fpneoglVertexAttrib4NsvARB;
extern fpglVertexAttrib4NivARB                               fpneoglVertexAttrib4NivARB;
extern fpglVertexAttrib4NubvARB                              fpneoglVertexAttrib4NubvARB;
extern fpglVertexAttrib4NusvARB                              fpneoglVertexAttrib4NusvARB;
extern fpglVertexAttrib4NuivARB                              fpneoglVertexAttrib4NuivARB;

//extern fpglVertexAttribPointerARB                            fpneoglVertexAttribPointerARB;

//extern fpglEnableVertexAttribArrayARB                        fpneoglEnableVertexAttribArrayARB;
//extern fpglDisableVertexAttribArrayARB                       fpneoglDisableVertexAttribArrayARB;

extern fpglBindAttribLocationARB                             fpneoglBindAttribLocationARB;

extern fpglGetActiveAttribARB                                fpneoglGetActiveAttribARB;

extern fpglGetAttribLocationARB                              fpneoglGetAttribLocationARB;

extern fpglGetVertexAttribdvARB                              fpneoglGetVertexAttribdvARB;
extern fpglGetVertexAttribfvARB                              fpneoglGetVertexAttribfvARB;
extern fpglGetVertexAttribivARB                              fpneoglGetVertexAttribivARB;
extern fpglGetVertexAttribPointervARB                        fpneoglGetVertexAttribPointervARB;


#define neoglVertexAttrib1fARB(a,b)                          (fpneoglVertexAttrib1fARB((a),(b)))
#define neoglVertexAttrib1sARB(a,b)                          (fpneoglVertexAttrib1sARB((a),(b)))
#define neoglVertexAttrib1dARB(a,b)                          (fpneoglVertexAttrib1dARB((a),(b)))
#define neoglVertexAttrib2fARB(a,b,c)                        (fpneoglVertexAttrib2fARB((a),(b)))
#define neoglVertexAttrib2sARB(a,b,c)                        (fpneoglVertexAttrib2sARB((a),(b)))
#define neoglVertexAttrib2dARB(a,b,c)                        (fpneoglVertexAttrib2dARB((a),(b)))
#define neoglVertexAttrib3fARB(a,b,c,d)                      (fpneoglVertexAttrib3fARB((a),(b),(c),(d)))
#define neoglVertexAttrib3sARB(a,b,c,d)                      (fpneoglVertexAttrib3sARB((a),(b),(c),(d)))
#define neoglVertexAttrib3dARB(a,b,c,d)                      (fpneoglVertexAttrib3dARB((a),(b),(c),(d)))
#define neoglVertexAttrib4fARB(a,b,c,d,e)                    (fpneoglVertexAttrib4fARB((a),(b),(c),(d),(e)))
#define neoglVertexAttrib4sARB(a,b,c,d,e)                    (fpneoglVertexAttrib4sARB((a),(b),(c),(d),(e)))
#define neoglVertexAttrib4dARB(a,b,c,d,e)                    (fpneoglVertexAttrib4dARB((a),(b),(c),(d),(e)))
#define neoglVertexAttrib4NubARB(a,b,c,d,e)                  (fpneoglVertexAttrib4NubARB((a),(b),(c),(d),(e)))
#define neoglVertexAttrib1fvARB(a,b)                         (fpneoglVertexAttrib1fvARB((a),(b)))
#define neoglVertexAttrib1svARB(a,b)                         (fpneoglVertexAttrib1svARB((a),(b)))
#define neoglVertexAttrib1dvARB(a,b)                         (fpneoglVertexAttrib1dvARB((a),(b)))
#define neoglVertexAttrib2fvARB(a,b)                         (fpneoglVertexAttrib2fvARB((a),(b)))
#define neoglVertexAttrib2svARB(a,b)                         (fpneoglVertexAttrib2svARB((a),(b)))
#define neoglVertexAttrib2dvARB(a,b)                         (fpneoglVertexAttrib2dvARB((a),(b)))
#define neoglVertexAttrib3fvARB(a,b)                         (fpneoglVertexAttrib3fvARB((a),(b)))
#define neoglVertexAttrib3svARB(a,b)                         (fpneoglVertexAttrib3svARB((a),(b)))
#define neoglVertexAttrib3dvARB(a,b)                         (fpneoglVertexAttrib3dvARB((a),(b)))
#define neoglVertexAttrib4fvARB(a,b)                         (fpneoglVertexAttrib4fvARB((a),(b)))
#define neoglVertexAttrib4svARB(a,b)                         (fpneoglVertexAttrib4svARB((a),(b)))
#define neoglVertexAttrib4dvARB(a,b)                         (fpneoglVertexAttrib4dvARB((a),(b)))
#define neoglVertexAttrib4ivARB(a,b)                         (fpneoglVertexAttrib4ivARB((a),(b)))
#define neoglVertexAttrib4bvARB(a,b)                         (fpneoglVertexAttrib4bvARB((a),(b)))

#define neoglVertexAttrib4ubvARB(a,b)                        (fpneoglVertexAttrib4ubvARB((a),(b)))
#define neoglVertexAttrib4usvARB(a,b)                        (fpneoglVertexAttrib4usvARB((a),(b)))
#define neoglVertexAttrib4uivARB(a,b)                        (fpneoglVertexAttrib4uivARB((a),(b)))

#define neoglVertexAttrib4NbvARB(a,b)                        (fpneoglVertexAttrib4NbvARB((a),(b)))
#define neoglVertexAttrib4NsvARB(a,b)                        (fpneoglVertexAttrib4NsvARB((a),(b)))
#define neoglVertexAttrib4NivARB(a,b)                        (fpneoglVertexAttrib4NivARB((a),(b)))
#define neoglVertexAttrib4NubvARB(a,b)                       (fpneoglVertexAttrib4NubvARB((a),(b)))
#define neoglVertexAttrib4NusvARB(a,b)                       (fpneoglVertexAttrib4NusvARB((a),(b)))
#define neoglVertexAttrib4NuivARB(a,b)                       (fpneoglVertexAttrib4NuivARB((a),(b)))

//#define neoglVertexAttribPointerARB(a,b,c,d,e,f)             (fpneoglVertexAttribPointerARB((a),(b),(c),(d),(e),(f)))

//#define neoglEnableVertexAttribArrayARB(a)                   (fpneoglEnableVertexAttribArrayARB((a)))
//#define neoglDisableVertexAttribArrayARB(a)                  (fpneoglDisableVertexAttribArrayARB((a)))

#define neoglBindAttribLocationARB(a,b,c)                    (fpneoglBindAttribLocationARB((a),(b),(c)))

#define neoglGetActiveAttribARB(a,b,c,d,e,f,g)               (fpneoglGetActiveAttribARB((a),(b),(c),(d),(e),(f),(g)))

#define neoglGetAttribLocationARB(a,b)                       (fpneoglGetAttribLocationARB((a),(b)))

#define neoglGetVertexAttribdvARB(a,b,c)                     (fpneoglGetVertexAttribdvARB((a),(b),(c)))
#define neoglGetVertexAttribfvARB(a,b,c)                     (fpneoglGetVertexAttribfvARB((a),(b),(c)))
#define neoglGetVertexAttribivARB(a,b,c)                     (fpneoglGetVertexAttribivARB((a),(b),(c)))
#define neoglGetVertexAttribPointervARB(a,b,c)               (fpneoglGetVertexAttribPointervARB((a),(b),(c)))

#endif

