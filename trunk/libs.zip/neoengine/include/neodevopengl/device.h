/***************************************************************************
                     device.h  -  OpenGL render device
                             -------------------
    begin                : Thu Mar 27 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, device.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOPENGLDEVICE_H
#define __NEOPENGLDEVICE_H


/**
  * \file device.h
  * OpenGL render device
  */


#include <neoengine/render.h>

#include "extensions.h"
#include "zbufferstate.h"


namespace NeoOGL
{


// External classes
class TextureUnit;
class Shader;
class PixelBuffer;
class RenderTarget;
class FrameBufferRenderTarget;
class PixelBufferRenderTarget;
class VertexBufferManager;
class FrameStatistics;
class Texture;




#ifndef NEOGL_ENABLE_STATISTICS
//Uncomment to get statistic gathering
//#  define NEOGL_ENABLE_STATISTICS
#endif




/**
  * \brief OpenGL implementation of render device
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class Device : public NeoEngine::RenderDevice
{
	friend class FrameBufferRenderTarget;
	friend class Texture;
	friend class PixelBuffer;

	public:

#ifdef WIN32

		/*! Flag indicating we have registered window class */
		static bool                                   s_bWindowClassRegistered;

		/*! Ignore sending kill event when window closed */
		bool                                          m_bIgnoreKill;

#elif __APPLE__

		/*! Last event point */
		Point                                         m_ptLastWhere;

		/*! Last event modifiers */
		EventModifiers                                m_emLastModifiers;

		/*! Last keymap */
		KeyMap                                        m_kmLastKeys;

		/*! Key translation table */
		int                                           m_aiKeyMap[256];

#elif POSIX

		/*! Fullscreen window */
		Window                                        m_FSWindow;

		/*! Pre-Fullscreen mode */
		XF86VidModeModeInfo                           m_OldMode;

		/*! Window delete atom */
		Atom                                          m_WMDeleteWindow;

#endif

		/*! Vertex buffer manager */
		VertexBufferManager                          *m_pkVertexBufferManager;

		/*! Requested vertex storage size */
		unsigned int                                  m_uiVertexStorageSize;

		/*! Frame buffer render target */
		FrameBufferRenderTarget                      *m_pkFrameBufferTarget;

		/*! Pixel buffer render target */
		PixelBufferRenderTarget                      *m_pkPixelBufferTarget;

		/*! Pixel buffers */
		std::vector< PixelBuffer* >                   m_vpkPixelBuffers;

		/*! Current active render target */
		RenderTarget                                 *m_pkCurTarget;

		/*! Texture units */
		TextureUnit                                 **m_ppkTMU;

		/*! Number of texture units */
		unsigned int                                  m_uiNumTMUs;

		/*! Maximum texture size */
		unsigned int                                  m_uiMaxTextureSize;

		/*! Default material */
		NeoEngine::MaterialPtr                        m_pkDefaultMaterial;

		/*! Z buffer state manager */
		ZBufferState                                  m_kZBufferState;

		/*! Supported extensions manager */
		Extensions                                    m_kExtensions;

		/*! Pending events */
		std::vector< NeoEngine::InputEvent* >         m_vpkEvents;

		/*! Frame callbacks */
		std::vector< NeoEngine::FrameCallback* >      m_avpkFrameCallbacks[ NeoEngine::FrameCallback::NUMCALLBACKS ];

		/*! Frame statistics */
		FrameStatistics                              *m_pkStats;

		/*! Flag to reset statistics on begin call */
		bool                                          m_bResetStats;

		/*! Flag to draw outlines */
		bool                                          m_bDrawOutlines;

		/*! Flag to force use of default material */
		bool                                          m_bForceDefaultMaterial;

		/*! Flag to draw polygons */
		bool                                          m_bDrawPolygons;

		/*! Flag to draw normals */
		bool                                          m_bDrawNormals;

		/*! Flag to draw outlines */
		bool                                          m_bDrawTangents;

		/*! Flag set if we are rendering to texture */
		bool                                          m_bIsRenderingTexture;

		/*! Current fragment shader */
		Shader                                      *m_pkVertexShader;

		/*! Current fragment shader */
		Shader                                      *m_pkFragmentShader;

		/*! Active lights */
		NeoEngine::Light                            **m_ppkLights;

		/*! Allocated number of light pointers */
		unsigned int                                  m_uiAllocatedLights;

		/*! Maximum number of lights in vertex lighting path */
		unsigned int                                  m_uiMaxLights;

		/*! Number of active lights */
		unsigned int                                  m_uiNumLights;

		/*! Current light offset */
		unsigned int                                  m_uiCurLight;

		/*! Total sum of ambient lights */
		NeoEngine::Color                              m_kAmbientLight;

		/*! Total sum of ambient light from all lights, including directional and point lights */
		NeoEngine::Color                              m_kTotalAmbientLight;

		/*! Fog mode currently being used */
		NeoEngine::FogMode                            m_kCurrentFogMode;


	public:

		/**
		* Initialize data
		* \param pkFileManager                        File manager used to locate texture files
		* \param pkInputManager                       Input manager to attach to for reporting events
		*/
		                                              Device( NeoEngine::FileManager *pkFileManager, NeoEngine::InputManager *pkInputManager );

		/**
		* Cleanup
		*/
		virtual                                      ~Device();
		/**
		* Open device in an already existing window
		* \param rkWndData                            Window specification and OS specific window data
		* \return                                     true if successful, false if not
		*/
		virtual bool                                  Open( const NeoEngine::RenderWindow &rkWndData );

		/**
		* Close device, restore settings
		*/
		virtual void                                  Close();

		/**
		* Initialize OpenGL
		* \param pkCaps                               Render caps (requested - will be filled with acquired values after open). If null, default values will be used
		* \return                                     true if successful, false if not
		*/
		bool                                          Initialize( const NeoEngine::RenderCaps *pkCaps );

		/**
		* Wrapper for obtaining function addresses
		* \param pszName                              Function name
		* \return                                     Address, or null if not found
		*/
		void                                         *GetProcAddress( const char *pszName );

		/**
		* Terminate OpenGL
		*/
		void                                          Shutdown();

		/**
		* Begin new frame. Call this before any calls to Render
		* \param rkViewMatrix                         View matrix for this batch of render operations
		*/
		virtual void                                  Begin( const NeoEngine::Matrix &rkViewMatrix, unsigned int uiFlags );

		/**
		* End frame
		*/
		virtual void                                  End();

		/**
		* Render primitive batch
		* \param rkData                               Render batch data
		* \param iFlags                               Batch flags
		*/
		virtual void                                  Render( const NeoEngine::RenderPrimitive &rkData, unsigned int uiFlags );

		/**
		* Set current render target
		* \param uiTarget                             Render target identifier
		* \return                                     Previous render target identifier (you should restore this if other than INVALIDBUFFER)
		*/
		virtual unsigned int                          SetRenderTarget( unsigned int uiTarget );

		/**
		* Set culling mode. Must be called outside Begin()-End() block
		* \param eCullMode                            Culling mode identifier
		* \return                                     Last culling mode
		*/
		virtual CULLMODE                              SetCullMode( CULLMODE eCullMode );

		/**
		* Set stencil operations
		* \param eStencilFail                         Operation when stencil buffer test fails
		* \param eZFail                               Operation when stencil buffer test passes and z buffer test fails
		* \param eZPass                               Operation when stencil buffer test passes and z buffer test passes
		*/
		virtual void                                  SetStencilOp( STENCILOP eStencilFail, STENCILOP eZFail, STENCILOP eZPass );

		/**
		* Set stencil function, reference value and test mask
		* \param eFunc                                Stencil test func
		* \param uiRefValue                           Reference value
		* \param uiTestMask                           A mask that is ANDed with both the reference value and the stored stencil value when the test is done
		*/
		virtual void                                  SetStencilFunc( STENCILFUNC eFunc, unsigned int uiRefValue, unsigned int uiTestMask );

		/**
		* Set stencil write mask
		* \param uiMask                               Write mask
		*/
		virtual void                                  SetStencilMask( unsigned int uiWriteMask );

		/**
		* Set render target write mask
		* \param bWrite                               Write flag, if false will disable writing to render target buffer, if true enable writing to render target buffer
		*/
		virtual void                                  SetTargetMask( bool bWrite );

		/**
		* Set buffer backing storage size. You must call this method prior to an Open() call, or
		* default sizes will be used.
		* \param uiVertexStorageSize                  Size in bytes of vertex buffer storage (default 3Mb)
		* \param uiPolygonStorageSize                 Size in bytes of polygon buffer storage (default 1Mb)
		* \return                                     true if successful, false if error (called after Open(), unable to allocate memory)
		*/
		virtual bool                                  SetStorageSize( unsigned int uiVertexStorageSize, unsigned int uiPolygonStorageSize );

		/**
		* Set projection matrix
		* \param rkMatrix                             Projection matrix
		*/
		virtual void                                  SetProjection( const NeoEngine::Matrix &rkMatrix );

		/**
		* Set rendering viewport (must be outside Begin()-End() block)
		* \param iX                                   Starting x coordinate
		* \param iY                                   Starting y coordinate
		* \param iWidth                               Width
		* \param iHeight                              Height
		*/
		virtual void                                  SetViewport( int iX, int iY, int iWidth, int iHeight );

		/**
		* Clear the current viewport (must be outside Begin()-End() block) for framebuffer, 
		* or for other clear targets clear the whole buffer
		* \param uiTargets                            Target bitfield (combination of CLEAR_xxx enums )
		* \param rkColor                              Color to clear color buffer with
		* \param fZValue                              Value to clear z buffer with
		* \param uiStencilValue                       Value to clear stencil buffer with
		*/
		virtual void                                  Clear( unsigned int uiTargets, const NeoEngine::Color &rkColor, float fZValue, unsigned int uiStencilValue );

		/**
		* Flip buffers, flush pipeline (must be outside Begin()-End() block)
		*/
		virtual void                                  Flip();

		/**
		* Add light to rendering pipeline for this Begin()-End() block. This is implementation/hardware specific and is not guaranteed to work in the fixed-function pipeline (max number of lights)
		* \param pkLight                              Light to add
		* \return                                     < 0 if failed
		*/
		virtual int                                   AddLight( NeoEngine::Light *pkLight );

		/**
		* Load a texture file. Implement in derived class
		* \param rstrFilename                         File name
		* \param eTextureType                         Texture type (2D, cubemap, ...)
		* \param eTextureFormat                       Requested texture format (Texture::DEFAULT if not needed)
		* \param uiFlags                              Load flags (default Texture::NONE)
		* \param uiFiltering                          Texture filtering modes (0 as default, using default set device filtering mode)
		* \param uiMaxAnisotropy                      Max anisotropy
		* \return                                     Ptr to texture
		*/
		virtual NeoEngine::TexturePtr                 LoadTexture( const std::string &rstrFilename, NeoEngine::Texture::TEXTURETYPE eTextureType, NeoEngine::Texture::TEXTUREFORMAT eTextureFormat, unsigned int uiFlags, unsigned int uiFiltering, unsigned int uiMaxAnisotropy );

		/**
		* Create new texture object
		* \param rstrName                             Texture name
		* \param eTextureType                         Texture type (2D, cubemap, ...)
		* \param eTextureFormat                       Requested texture format (Texture::DEFAULT if not needed)
		* \return                                     Ptr to texture
		*/
		virtual NeoEngine::TexturePtr                 CreateTexture( const std::string &rstrName, NeoEngine::Texture::TEXTURETYPE eTextureType, NeoEngine::Texture::TEXTUREFORMAT eTextureFormat );

		/**
		* Find texture by name
		* \param rstrName                             Texture name
		* \return                                     Ptr to texture
		*/
		virtual NeoEngine::TexturePtr                 GetTexture( const std::string &rstrName );

		/**
		* Read pixels from the currently bound buffer (framebuffer, pixelbuffer, stencilbuffer)
		* \return                                     Image data containinig pixels
		*/
		virtual NeoEngine::ImageData                 *ReadPixels();

		/**
		* Allocate a vertex buffer
		* \param uiType                               Buffer type
		* \param uiNumVertices                        Number of vertices
		* \param pkFormat                             Flexible vertex format declaration
		* \param pData                                Optional pointer to data to load buffer with
		* \return                                     Ptr to new vertex buffer
		*/
		virtual NeoEngine::VertexBufferPtr            CreateVertexBuffer( unsigned int uiType, unsigned int uiNumVertices, const NeoEngine::VertexDeclaration *pkFormat, const void *pData );

		/**
		* Allocate a polygon buffer
		* \param uiType                               Buffer type
		* \param uiNumPolygons                        Number of polygons
		* \param pkData                               Optional pointer to data to load buffer with
		* \param bStripify                            Stripify buffer if true
		* \return                                     Ptr to new polygon buffer
		*/
		virtual NeoEngine::PolygonBufferPtr           CreatePolygonBuffer( unsigned int uiType, unsigned int uiNumPolygons, const NeoEngine::Polygon *pkData, bool bStripify );

		/**
		* Allocate a polygon strip buffer
		* \param uiType                               Buffer type
		* \param uiNumPolygons                        Number of polygons
		* \param pusData                              Optional pointer to data to load buffer with
		* \return                                     Ptr to new polygon strip buffer
		*/
		virtual NeoEngine::PolygonStripBufferPtr      CreatePolygonStripBuffer( unsigned int uiType, unsigned int uiNumPolygons, const unsigned short *pusData );

		/**
		* Create a pixel buffer for offscreen rendering
		* \param uiWidth                              Width of buffer
		* \param uiHeight                             Height of buffer
		* \param uiBPP                                Suggested bit depth (might be ignored if not found or incompatible in windowed mode)
		* \param eTextureType                         Target texture type (2D, cubemap, ... )
		* \return                                     New pixel buffer object, or null if error/unsupported
		*/
		virtual NeoEngine::PixelBuffer               *CreatePixelBuffer( unsigned int uiWidth, unsigned int uiHeight, unsigned int uiBPP, NeoEngine::Texture::TEXTURETYPE eTextureType );

		/**
		* Create a new shader object, which can then be loaded and compiled
		* \param eType                                Shader type (vertex or fragment)
		* \return                                     Pointer to the new shader object
		*/
		virtual NeoEngine::ShaderPtr                  CreateShader( NeoEngine::Shader::SHADERTYPE eType );

		/**
		* Find shader by name and type
		* \param eType                                Shader type
		* \param rstrName                             Shader name
		* \return                                     Ptr to shader
		*/
		virtual NeoEngine::ShaderPtr                  GetShader( NeoEngine::Shader::SHADERTYPE eType, const std::string &rstrName );

		/**
		* \return                                     String with statistics for last frame
		*/
		virtual std::string                           GetStatistics();

		/**
		* Set mouse position relative window client area top-left corner.
		* \param iX                                   X coordinate in pixels
		* \param iX                                   Y coordinate in pixels
		*/
		virtual void                                  SetMousePos( int iX, int iY );

		/**
		* Capture or release mouse from window
		* \param bCapture                             If true, capture mouse in window. If false, release mouse
		*/
		virtual void                                  CaptureMouse( bool bCapture );

		/**
		* Show or hide mouse cursor
		* \param bShow                                If true, show cursor. If false, hide cursor
		*/
		virtual void                                  ShowCursor( bool bShow );

		/**
		* Configuration change callback
		* \param rstrKey                              Key that has changed
		*/
		void                                          ConfigValueChange( const NeoEngine::HashString &rstrKey );

		/**
		* Collect input events
		* \param pkEvent                              Event object to fill with data
		* \return                                     true if events was collected, false if not
		*/
		virtual bool                                  Collect( NeoEngine::InputEvent *pkEvent );

		/**
		* Register/deregister frame callback
		* \param eType                                Callback type
		* \param pkCallback                           Callback object
		* \param bRegister                            If true, register new callback. If false, deregister callback
		*/
		virtual void                                  RegisterFrameCallback( NeoEngine::FrameCallback::FRAMECALLBACKTYPE eType, NeoEngine::FrameCallback *pkCallback, bool bRegister );

		/**
		* Query device for available adapters
		* \param pvkAdapters                          Pointer to vector receiving available adapters
		*/
		virtual void                                  QueryAdapters( std::vector< NeoEngine::RenderAdapter > *pvkAdapters );

		/**
		* Query device for available fullscreen resolutions, sorted by total area, bits per pixel, refresh rate
		* \param pvkResolutions                       Pointer to vector receiving available resolutions
		* \param uiAdapter                            Adapter identifier, 0 for default (primary) adapter
		*/
		virtual void                                  QueryResolutions( std::vector< NeoEngine::RenderResolution > *pvkResolutions, unsigned int uiAdapter );
};


#ifdef __APPLE__

// mac key scancodes -- from inside macintosh
#define MK_ESCAPE          0x35
#define MK_F1              0x7A
#define MK_F2              0x78
#define MK_F3              0x63
#define MK_F4              0x76
#define MK_F5              0x60
#define MK_F6              0x61
#define MK_F7              0x62
#define MK_F8              0x64
#define MK_F9              0x65
#define MK_F10             0x6D
#define MK_F11             0x67
#define MK_F12             0x6F
#define MK_PRINT           0x69
#define MK_SCROLLOCK       0x6B
#define MK_PAUSE           0x71
#define MK_POWER           0x7F
#define MK_BACKQUOTE       0x32
#define MK_1               0x12
#define MK_2               0x13
#define MK_3               0x14
#define MK_4               0x15
#define MK_5               0x17
#define MK_6               0x16
#define MK_7               0x1A
#define MK_8               0x1C
#define MK_9               0x19
#define MK_0               0x1D
#define MK_MINUS           0x1B
#define MK_EQUALS          0x18
#define MK_BACKSPACE       0x33
#define MK_INSERT          0x72
#define MK_HOME            0x73
#define MK_PAGEUP          0x74
#define MK_NUMLOCK         0x47
#define MK_KP_EQUALS       0x51
#define MK_KP_DIVIDE       0x4B
#define MK_KP_MULTIPLY     0x43
#define MK_TAB             0x30
#define MK_q               0x0C
#define MK_w               0x0D
#define MK_e               0x0E
#define MK_r               0x0F
#define MK_t               0x11
#define MK_y               0x10
#define MK_u               0x20
#define MK_i               0x22
#define MK_o               0x1F
#define MK_p               0x23
#define MK_LEFTBRACKET     0x21
#define MK_RIGHTBRACKET    0x1E
#define MK_BACKSLASH       0x2A
#define MK_DELETE          0x75
#define MK_END             0x77
#define MK_PAGEDOWN        0x79
#define MK_KP7             0x59
#define MK_KP8             0x5B
#define MK_KP9             0x5C
#define MK_KP_MINUS        0x4E
#define MK_CAPSLOCK        0x39
#define MK_a               0x00
#define MK_s               0x01
#define MK_d               0x02
#define MK_f               0x03
#define MK_g               0x05
#define MK_h               0x04
#define MK_j               0x26
#define MK_k               0x28
#define MK_l               0x25
#define MK_SEMICOLON       0x29
#define MK_QUOTE           0x27
#define MK_RETURN          0x24
#define MK_KP4             0x56
#define MK_KP5             0x57
#define MK_KP6             0x58
#define MK_KP_PLUS         0x45
#define MK_LSHIFT          0x38
#define MK_z               0x06
#define MK_x               0x07
#define MK_c               0x08
#define MK_v               0x09
#define MK_b               0x0B
#define MK_n               0x2D
#define MK_m               0x2E
#define MK_COMMA           0x2B
#define MK_PERIOD          0x2F
#define MK_SLASH           0x2C
#define MK_RSHIFT          0x38
#define MK_UP              0x7E
#define MK_KP1             0x53
#define MK_KP2             0x54
#define MK_KP3             0x55
#define MK_KP_ENTER        0x4C
#define MK_LCTRL           0x3B
#define MK_LALT            0x3A
#define MK_LMETA           0x37
#define MK_SPACE           0x31
#define MK_RMETA           0x37
#define MK_RALT            0x3A
#define MK_RCTRL           0x3B
#define MK_LEFT            0x7B
#define MK_DOWN            0x7D
#define MK_RIGHT           0x7C
#define MK_KP0             0x52
#define MK_KP_PERIOD       0x41

#endif /*! __APPLE__ */

// X mouse events
#define MB_X_LEFT	1
#define MB_X_MIDDLE	2
#define MB_X_RIGHT	3

}; // namespace NeoOGL


#endif
