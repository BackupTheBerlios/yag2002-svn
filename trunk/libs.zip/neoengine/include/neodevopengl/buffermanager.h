/***************************************************************************
                 buffermanager.h  -  Buffer allocation manager
                             -------------------
    begin                : Thu Apr 24 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, buffermanager.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOGLBUFFERMANAGER_H
#define __NEOGLBUFFERMANAGER_H


/**
  * \file buffermanager.h
  * Buffer allocation manager
  */


#include <vector>


namespace NeoOGL
{


//External classes
class BufferRegion;


/**
  * \brief Manages buffer allocations from backing store
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class BufferManager
{
	protected:

		/*! Buffer pointer */
		unsigned char                                      *m_pucBuffer;

		/*! Size of allocated memory */
		unsigned int                                        m_uiSize;

		/*! Offset to current free block */
		unsigned int                                        m_uiOffset;

		/*! Allocated regions */
		std::vector< BufferRegion* >                        m_vpkAllocatedRegions;

		/*! Holes */
		std::vector< BufferRegion* >                        m_vpkHoles;

		/*! Last allocated region */
		BufferRegion                                       *m_pkTailRegion;



	public:

		/**
		*/
		                                                    BufferManager();

		/**
		* Free memory
		*/
		virtual                                            ~BufferManager();

		/**
		* Get pointer to free region of memory
		* \param uiSize                                     Requested size
		* \param bBackingStore                              Flag indicating buffer has backing store and can be invalidated safely
		* \param uiRequiredAlign                            Alignment of start of region, 0 if not required
		* \return                                           Pointer to buffer region object or null if failed
		*/
		virtual BufferRegion                               *Alloc( unsigned int uiSize, bool bBackingStore, unsigned int uiRequiredAlign = 0 );

		/**
		* Free region of memory
		* \param pkRegion                                   Buffer region to free
		*/
		virtual void                                        Free( BufferRegion *pkRegion );

		/**
		* \return                                           Buffer pointer
		*/
		inline unsigned char                               *GetBuffer() { return m_pucBuffer; }

		/**
		* Verify buffer region integrity
		*/
		void                                                CheckMemoryIntegrity();

		/**
		* Dump data about allocations to debug output
		*/
		void                                                DumpAllocationData();
};


}; // namespace NeoOGL


#endif
