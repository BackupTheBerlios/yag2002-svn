/***************************************************************************
                  texture.h  -  OpenGL texture implementation
                             -------------------
    begin                : Sun Mar 30 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, texture.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOGLTEXTURE_H
#define __NEOGLTEXTURE_H



/**
  * \file texture.h
  * OpenGL texture implementation
  */

#include "extensions.h"

#include <neoengine/material.h>
#include <neoengine/texture.h>
#include <neoengine/loadableentity.h>
#include <neoengine/logstream.h>


namespace NeoOGL
{


// External classes
class Device;


/**
  * \brief OpenGL texture implementation
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class Texture : public NeoEngine::Texture, public NeoEngine::LoadableEntity
{
	protected:

		/*! Device */
		Device                                       *m_pkDevice;

		/**
		* Load texture file
		* \param uiFlags                              Load flags
		* \return                                     true if successful, false if not
		*/
		bool                                          LoadNode( unsigned int uiFlags );

                
	public:

		/*! Current UV addressing mode */
		unsigned int                                  m_uiUVAddress;

		/*! Texture target index */
		unsigned int                                  m_uiTargetIndex;

		/*! Cubemap face mapping array */
		static const GLenum                           s_aeOGLCubeFaces[6];


		/**
		* Create an empty texture object
		* \param pkDevice                             Device
		* \param rstrName                             Texture name
		* \param eTextureType                         Texture type (2D, cubemap, ...)
		* \param eTextureFormat                       Texture format
		* \param uiFiltering                          Filtering modes
		* \param uiMaxAnisotropy                      Max anisotropy
		* \param pkTexturePool                        Parent texture pool object
		* \param pkFileManager                        File manager object
		*/
		                                              Texture( Device *pkDevice, const std::string &rstrName, TEXTURETYPE eTextureType, TEXTUREFORMAT eTextureFormat, unsigned int uiFiltering, unsigned int uiMaxAnisotropy, NeoEngine::TexturePool *pkTexturePool, NeoEngine::FileManager *pkFileManager, int iWidth = 0, int iHeight = 0 );

		/**
		* Delete texture object, deallocate associated memory
		*/
		virtual                                      ~Texture();

		/**
		* Upload image data
		* \param pkImageData                          Image data
		* \param eType                                Texture type (2D, cubemap, ...)
		* \param eFormat                              Requested format
		* \param uiFlags                              Texture load flags
		* \param uiFiltering                          Filtering modes, 0 for default
		* \param uiMaxAnisotropy                      Max anisotropy
		* \return                                     true if successful, false otherwise
		*/
		virtual bool                                  UploadImage( NeoEngine::ImageData *pkImageData, TEXTURETYPE iTextureType, TEXTUREFORMAT eTextureFormat, unsigned int uiFlags, unsigned int uiFiltering, unsigned int uiMaxAnisotropy );

		/**
		* Set addressing mode
		* \param uiAddressMode                        New addressing mode
		*/
		inline void                                   SetAddressMode( unsigned int uiAddressMode )
		{
			if( m_uiUVAddress != uiAddressMode )
			{
				glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, ( ( uiAddressMode & 0x000F ) == NeoEngine::TextureLayer::CLAMP_U ) ? GL_CLAMP_TO_EDGE : GL_REPEAT );
				glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, ( ( uiAddressMode & 0x00F0 ) == NeoEngine::TextureLayer::CLAMP_V ) ? GL_CLAMP_TO_EDGE : GL_REPEAT );
				glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_R, ( ( uiAddressMode & 0x0F00 ) == NeoEngine::TextureLayer::CLAMP_W ) ? GL_CLAMP_TO_EDGE : GL_REPEAT );

				m_uiUVAddress = uiAddressMode;
			}
		}
};


}; // namespace NeoOGL


#endif
