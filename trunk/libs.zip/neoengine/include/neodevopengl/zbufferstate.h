/***************************************************************************
                   zbufferstate.h  -  Z buffer state management
                             -------------------
    begin                : Sat Mar 29 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, zbufferstate.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOGLZBUFFERSTATE_H
#define __NEOGLZBUFFERSTATE_H



/**
  * \file zbufferstate.h
  * Z buffer state management
  */

#include <neoengine/material.h>

#include "extensions.h"


namespace NeoOGL
{


/**
  * \brief Z buffer state management
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class ZBufferState
{
	public:

		/*! Current test mode */
		unsigned int                                  m_uiTestMode;

		/*! Write mode */
		unsigned int                                  m_uiWriteMode;

		/*! Translate table between engine mode enums and GL enums */
		static GLenum                                 s_aeTestModeTranslator[];


	public:

		/**
		*/
		                                              ZBufferState();

		/**
		*/
		virtual                                      ~ZBufferState();

		/**
		* Set z buffer state
		* \param uiTest                               Test mode
		* \param uiWrite                              Write mode
		*/
		inline void                                   SetMode( unsigned int uiTest, unsigned int uiWrite )
		{
			if( m_uiTestMode != uiTest )
				glDepthFunc( s_aeTestModeTranslator[ ( m_uiTestMode = uiTest ) ] );

			if( m_uiWriteMode != uiWrite )
				glDepthMask( ( ( m_uiWriteMode = uiWrite ) == NeoEngine::ZBufferMode::ENABLED ) ? GL_TRUE : GL_FALSE );
		}
};


}; // namespace NeoOGL


#endif
