/***************************************************************************
     vertexbuffermanager-ati.h  -  ATI vertex buffer allocation manager
                             -------------------
    begin                : Sat May 10 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, vertexbuffermanager-ati.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOGLVERTEXBUFFERMANAGER_ATI_H
#define __NEOGLVERTEXBUFFERMANAGER_ATI_H



/**
  * \file vertexbuffermanager-ati.h
  * ATI vertex buffer allocation manager
  */


#include "vertexbuffermanager.h"


namespace NeoOGL
{


/**
  * Manages vertex buffer allocations from backing store
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class VertexBufferManagerATI : public VertexBufferManager
{
	protected:




	public:

		/**
		* \param pkDevice                                   Device object
		*/
		                                                    VertexBufferManagerATI( Device *pkDevice );

		/**
		* Free memory
		*/
		virtual                                            ~VertexBufferManagerATI();

		/**
		* Create a new vertex buffer object
		* \param uiType                                     Buffer type
		* \param uiNumVertices                              Number of vertices
		* \param pkFormat                                   Flexible vertex format declaration
		* \param pData                                      Optional pointer to data to load buffer with
		* \return                                           Ptr to new vertex buffer
		*/
		virtual NeoEngine::VertexBufferPtr                  CreateVertexBuffer( unsigned int uiType, unsigned int uiNumVertices, const NeoEngine::VertexDeclaration *pkFormat, const void *pData );

		/**
		* Set base pointers for rendering
		* \param pkVertexBuffer                             Vertex buffer object
		* \param uiUVLayer                                  UV layer
		*/
		virtual void                                        SetBasePointers( VertexBufferGL *pkVertexBuffer, unsigned int uiUVLayer );

		/**
		* Set pointer for texture layer for rendering
		* \param pkVertexBuffer                             Vertex buffer object
		* \param uiTexUnit                                  Active texture unit
		* \param uiUVLayer                                  UV layer
		* \param bDisable                                   Force disable
		*/
		virtual void                                        SetTexLayerPointer( VertexBufferGL *pkVertexBuffer, unsigned int uiTexUnit, unsigned int uiUVLayer, bool bDisable = false );
};


}; // namespace NeoOGL


#endif
