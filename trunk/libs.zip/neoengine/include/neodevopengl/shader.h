/***************************************************************************
                       shader.h  -  Pipeline shaders
                             -------------------
    begin       : Mon May 05 2003
    copyright   : (C) 2003 by Reality Rift Studios
    email       : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, shader.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 contributors: Cody Russell (cody@jhu.edu)

 ***************************************************************************/

#ifndef __NEOGLSHADER_H
#define __NEOGLSHADER_H


#include "device.h"

#include <neoengine/shader.h>
#include <neoengine/hashtable.h>


namespace NeoOGL
{


typedef NeoEngine::HashTable< class Shader > ShaderTable;


/**
  * \brief OpenGL implementation of pipeline shaders
  * \author Matt Holmes (kerion@houston.rr.com)
  * \author Cody Russell (cody@jhu.edu)
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class Shader : public NeoEngine::Shader
{
	friend class Device;
	friend class VertexBufferManager;
	friend class VertexBufferManagerARB;
	friend class VertexBufferManagerATI;

	protected:

		/*! Vertex shader table */
		static ShaderTable                           s_kVSTable;

		/*! Fragment shader table */
		static ShaderTable                           s_kFSTable;


		/*! Render device */
		Device                                       *m_pkDevice;

		/*! Flag indicating we have been compiled */
		bool                                          m_bIsCompiled;


	public:

		/**
		* \param pkDevice                             Render device
		* \param eType                                Shader type
		* \param pkFileManager                        Filemananger, null if default
		*/
		                                              Shader( Device *pkDevice, SHADERTYPE eType, NeoEngine::FileManager *pkFileManager = 0 );

		/**
		*/
		virtual                                      ~Shader();

		/**
		* Set name of shader
		* \param rstrName                             New name
		*/
		virtual void                                  SetName( const NeoEngine::HashString &rstrName );

		/**
		* Bind this pipeline shader and parameters, performing OpenGL specific operations
		* \param pkPrimitive                          Primitive currently processing
		* \return                                     True if bound, or false if error
		*/
		virtual bool                                  Bind( NeoEngine::RenderPrimitive *pkPrimitive ) = 0;

		/**
		* Bind light parameters
		* \param pkPrimitive                          Primitive currently processing
		* \return                                     True if bound, or false if error
		*/
		virtual bool                                  BindLightParams( NeoEngine::RenderPrimitive *pkPrimitive ) = 0;

		/**
		* Disable shader
		* \return                                     True if successful, false if error
		*/
		virtual bool                                  Unbind() = 0;
};


};


#endif
