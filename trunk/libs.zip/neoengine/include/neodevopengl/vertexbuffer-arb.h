/***************************************************************************
              vertexbuffer-arb.h  -  ARB vertex buffer abstraction
                             -------------------
    begin                : Fri Aug 15 2003
    copyright            : (C) 2003 by Cody Russell
    email                : cody `at' jhu.edu
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, vertexbuffer-arb.h

 The Initial Developer of the Original Code is Cody Russell.
 Portions created by Cody Russell are Copyright (C) 2003
 Cody Russell. All Rights Reserved.

 Contributors: Mattias Jansson (mattias@realityrift.com)

 ***************************************************************************/

#ifndef __NEOGLVERTEXBUFFER_ARB_H
#define __NEOGLVERTEXBUFFER_ARB_H


#include "vertexbuffer.h"


namespace NeoOGL
{


// External classes
class Device;
class VertexBufferManagerARB;


/**
  * \brief Vertex buffer for ARB extension
  * \author Cody Russell (cody `at' jhu.edu)
  */
class VertexBufferARB : public VertexBufferGL
{
	friend class VertexBufferManagerARB;

	private:

		/**
		* Release and free the buffer
		*/
		void                                          Release();

	public:

		/*! Buffer manager */
		VertexBufferManagerARB                       *m_pkBufferManager;

		/*! ARB buffer object */
		unsigned int                                  m_uiObject;


		/**
		* \param pkDevice                             Device object
		* \param pkBufferManager                      Buffer manager
		* \param uiType                               Buffer type
		* \param uiNumVertices                        New vertex count
		* \param uiVertexFormat                       Vertex format
		* \param pData                                Optional pointer to data to copy
		*/
		                                              VertexBufferARB( Device *pkDevice, VertexBufferManagerARB *pkBufferManager, unsigned int uiType, unsigned int uiNumVertices, const NeoEngine::VertexDeclaration *pkFormat, const void *pData );

		/**
		*/
		virtual                                      ~VertexBufferARB();

		/**
		* Resize buffer. There must not be any active lock held on buffer when calling this method
		* \param uiNumVertices                        New vertex count
		* \param uiVertexFormat                       Vertex format
		* \param pData                                Optional pointer to data to copy
		*/
		virtual void                                  AllocateVertices( unsigned int uiNumVertices, const NeoEngine::VertexDeclaration *pkFormat, const void *pData = 0 );

		/**
		* Upload data to buffer object
		*/
		virtual void                                  Upload();
};


}; // namespace NeoOGL


#endif // __NEOGLVERTEXBUFFER_ARB_H
