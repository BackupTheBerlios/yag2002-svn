/***************************************************************************
           vertexbuffer.h  -  Base OpenGL vertex buffer abstraction
                             -------------------
    begin                : Fri Aug 1 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, vertexbuffer.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOGLVERTEXBUFFER_H
#define __NEOGLVERTEXBUFFER_H


#include <neoengine/vertexbuffer.h>


namespace NeoOGL
{


//External classes
class Device;


/**
  * \brief Vertex buffer base class for OpenGL device
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class VertexBufferGL : public NeoEngine::VertexBuffer
{
	public:

		/*! Device object */
		Device                                       *m_pkDevice;

		/*! Position element */
		NeoEngine::VertexElement                     *m_pkPositionElement;

		/*! Normal element */
		NeoEngine::VertexElement                     *m_pkNormalElement;

		/*! Diffuse element */
		NeoEngine::VertexElement                     *m_pkDiffuseElement;

		/*! Texcoord elements */
		NeoEngine::VertexElement                     *m_pkTexCoordElement[8];

		/*! Tangent element */
		NeoEngine::VertexElement                     *m_pkTangentElement;

		/*! Binormal element */
		NeoEngine::VertexElement                     *m_pkBinormalElement;

		/*! Fog element */
		NeoEngine::VertexElement                     *m_pkFogElement;


		/**
		* \param pkDevice                             Device object
		* \param uiType                               Buffer type
		* \param uiNumVertices                        New vertex count
		* \param pkFormat                             Vertex format declaration
		* \param pData                                Optional pointer to data to copy
		*/
		                                              VertexBufferGL( Device *pkDevice, unsigned int uiType, unsigned int uiNumVertices, const NeoEngine::VertexDeclaration *pkFormat, const void *pData = 0 );

		/**
		*/
		virtual                                      ~VertexBufferGL();

		/**
		* Resize buffer. There must not be any active lock held on buffer when calling this method
		* \param uiNumVertices                        New vertex count
		* \param pkFormat                             Vertex format declaration
		* \param pData                                Optional pointer to data to copy
		*/
		virtual void                                  AllocateVertices( unsigned int uiNumVertices, const NeoEngine::VertexDeclaration *pkFormat, const void *pData = 0 );

		/**
		* Parse vertex format declaration
		*/
		virtual void                                  ParseDeclaration();
};


}; // namespace NeoOGL


#endif
