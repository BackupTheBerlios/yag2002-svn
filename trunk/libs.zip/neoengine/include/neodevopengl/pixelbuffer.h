/***************************************************************************
            pixelbuffer.h  -  OpenGL pixel buffer implementation
                             -------------------
    begin                : Thu Apr 17 2003
    copyright            : (C) 2003 by Cody Russell
    email                : cody [at] jhu.edu
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, pixelbuffer.h

 The Initial Developer of the Original Code is Cody Russell.
 Portions created by Cody Russell are Copyright (C) 2003
 Cody Russell. All Rights Reserved.

 Contributors: Mattias Jansson (mattias@realityrift.com)

 ***************************************************************************/

#ifndef __NEOGLPIXELBUFFER_H
#define __NEOGLPIXELBUFFER_H


#include "extensions.h"
#include "texture.h"

#include <neoengine/activator.h>
#include <neoengine/pixelbuffer.h>



/**
  * \file pixelbuffer.h
  * Classes for OpenGL pixel buffers
  */


namespace NeoOGL
{


// External classes
class Device;


/**
  * \brief OpenGL pixel buffer implementation
  * \author Cody Russell (cody [at] jhu.edu)
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class PixelBuffer : public NeoEngine::PixelBuffer, virtual public NeoEngine::Activator
{
	protected:

		/*! Device */
		Device                                       *m_pkDevice;

		/*! Flag indicating if buffer is currently bound */
		bool                                          m_bIsBound;

		/*! Texture */
		NeoEngine::TexturePtr                         m_pkTexture;

		/*! Stored viewport */
		NeoEngine::Viewport                           m_kViewport;

		/*! Current cubemap face */
		Texture::TEXTURECUBEMAPFACE                   m_eCurCubemapFace;
/*
#if defined(WIN32)

		void                                          ModeSwitch();

		HDC                                           m_hDC;
		HGLRC                                         m_hGLRC;
		HPBUFFERARB                                   m_hPbuffer;

#elif defined(POSIX)

		bool                                          m_bShareObjects;

		Display                                      *m_pDisplay;
		GLXPbuffer                                    m_glxPbuffer;
		GLXContext                                    m_glxContext;

#elif defined(__APPLE__)

		AGLContext                                    m_aglContext;
		WindowPtr                                     m_pWindow;

#endif
*/

		/**
		* Grab texture data
		*/
		void                                          GrabTexture();


	public:

		/**
		* \param pkDevice                             Render device
		*/
		                                              PixelBuffer( Device *pkDevice );

		/**
		*/
		virtual                                      ~PixelBuffer();

		/**
		* Open pixel buffer with specified dimensions and attributes
		* \param uiWidth                              Width
		* \param uiHeight                             Height
		* \param uiBPP                                Bits per pixel
		* \param eTextureType                         Target texture type (2D, cubemap, ... )
		* \return                                     true if successful, false if error
		*/
		bool                                          Open( unsigned int uiWidth, unsigned int uiHeight, unsigned int uiBPP, Texture::TEXTURETYPE eTextureType );

		/**
		* Close pixelbuffer and deallocate resources
		*/
		void                                          Close();

		/**
		* Activate this pixelbuffer
		*/
		virtual void                                  Activate();

		/**
		* Deactivate this pixelbuffer
		*/
		virtual void                                  Deactivate();

		/**
		* Bind buffer
		*/
		int                                           Bind();

		/**
		* Relese buffer
		*/
		int                                           Release();

		/**
		* Set active target cubemap face. Ignored for non-cubemap target texture types
		* \param eCubeMapFace                         Which cubemap face to render to
		*/
		virtual void                                  SetCubeMapFace( Texture::TEXTURECUBEMAPFACE eCubeMapFace );

		/**
		* Get texture object from this pixel buffer
		* \return                                     Texture
		*/
		virtual const NeoEngine::TexturePtr          &GetTexture() { return m_pkTexture; }
};


};


#endif


