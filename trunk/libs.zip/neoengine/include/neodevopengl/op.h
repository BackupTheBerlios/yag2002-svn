/***************************************************************************
                         op.h  -  Render operation data
                             -------------------
    begin                : Sun Mar 30 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, op.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOGLOP_H
#define __NEOGLOP_H


#include <neoengine/renderprimitive.h>


namespace NeoOGL
{


/**
  * \brief An array of render primitives
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class OpArray
{
	public:

		/**
		* \brief Defines for op array
		*/
		enum OPARRAYDEFS
		{
		  /*! Size of array. must be a power of two */
		  ARRAYSIZE                                   = 128,

		  /*! Shift bits for getting array index from op number */
		  ARRAYSHIFT                                  = 7,

		  /*! Bitmask for getting op index in array from op number */
		  ARRAYMASK                                   = 0x0000007F
		};



		/*! The ops */
		NeoEngine::RenderPrimitive                    m_akOps[ ARRAYSIZE ];
};


}; // namespace NeoOGL


#endif
