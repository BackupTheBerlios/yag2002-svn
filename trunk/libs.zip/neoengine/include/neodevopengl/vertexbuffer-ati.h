/***************************************************************************
              vertexbuffer-ati.h  -  ATI vertex buffer abstraction
                             -------------------
    begin                : Sat May 10 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, vertexbuffer-ati.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOGLVERTEXBUFFER_ATI_H
#define __NEOGLVERTEXBUFFER_ATI_H

#include "vertexbuffermanager-ati.h"


namespace NeoOGL
{


//External classes
class Device;


/**
  * \brief Vertex buffer for ATI extension
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class VertexBufferATI : public VertexBufferGL
{
	public:

		/*! Buffer manager */
		VertexBufferManagerATI                       *m_pkBufferManager;

		/*! ATI buffer object */
		unsigned int                                  m_uiObject;


		/**
		* \param pkDevice                             Device object
		* \param pkBufferManager                      Buffer manager
		* \param uiType                               Buffer type
		* \param uiNumVertices                        New vertex count
		* \param pkFormat                             Vertex format declaration
		* \param pData                                Optional pointer to data to copy
		*/
		                                              VertexBufferATI( Device *pkDevice, VertexBufferManagerATI *pkBufferManager, unsigned int uiType, unsigned int uiNumVertices, const NeoEngine::VertexDeclaration *pkFormat, const void *pData = 0 );

		/**
		*/
		virtual                                      ~VertexBufferATI();

		/**
		* Resize buffer. There must not be any active lock held on buffer when calling this method
		* \param uiNumVertices                        New vertex count
		* \param pkFormat                             Vertex format declaration
		* \param pData                                Optional pointer to data to copy
		*/
		virtual void                                  AllocateVertices( unsigned int uiNumVertices, const NeoEngine::VertexDeclaration *pkFormat, const void *pData = 0 );

		/**
		* Upload data to buffer object
		*/
		virtual void                                  Upload();
};


}; // namespace NeoOGL


#endif
