/***************************************************************************
              shader-arb.h  -  ARB vertex/fragment programs
                             -------------------
    begin       : Mon Jan 5 2004
    copyright   : (C) 2004 by Reality Rift Studios
    email       : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, shader-arb.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.
 ***************************************************************************/

#ifndef __NEOGLSHADER_ARB_H
#define __NEOGLSHADER_ARB_H


#include "device.h"
#include "shader.h"


namespace NeoOGL
{


/**
  * \brief OpenGL implementation of pipeline shaders
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class ShaderARB : public Shader
{
	protected:

		/*! Native shader object */
		unsigned int                                  m_uiShader;

		/*! Shader type enum (vertexshader or fragmentshader) */
		GLenum                                        m_eType;


	public:

		/**
		* \param pkDevice                             Render device
		* \param eType                                Shader type
		* \param pkFileManager                        Filemananger, null if default
		*/
		                                              ShaderARB( Device *pkDevice, SHADERTYPE eType, NeoEngine::FileManager *pkFileManager = 0 );

		/**
		* Destruct this instance of the OpenGL vertex shader instance
		*/
		virtual                                      ~ShaderARB();

		/**
		* Compile the pipeline shader, performing OpenGL and target specific operations
		* \param pstrSource                           Source string, null if use already loaded source
		* \return                                     True if compiled, or false
		*/
		virtual bool                                  Compile( const std::string *pstrSource = 0 );

		/**
		* Bind this pipeline shader and parameters, performing OpenGL and target specific operations
		* \param pkPrimitive                          Primitive currently processing
		* \return                                     True if bound, or false if error
		*/
		virtual bool                                  Bind( NeoEngine::RenderPrimitive *pkPrimitive );

		/**
		* Disable shader
		* \return                                     True if successful, false if error
		*/
		virtual bool                                  Unbind();

		/**
		* Bind light parameters
		* \param pkPrimitive                          Primitive currently processing
		* \return                                     True if bound, or false if error
		*/
		virtual bool                                  BindLightParams( NeoEngine::RenderPrimitive *pkPrimitive );
};


};


#endif
