/***************************************************************************
                      statistics.h  -  Frame statistics
                             -------------------
    begin                : Wed Apr 2 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, statistics.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOGLSTATISTICS_H
#define __NEOGLSTATISTICS_H


/**
  * \file statistics.h
  * Frame statistics
  */

#include "device.h"

#include <string.h>

#include <vector>
#include <string>


namespace NeoOGL
{


/**
  * \brief Frame statistics
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class FrameStatistics
{
	public:

		/*! Device */
		Device                                        *m_pkDevice;

		/*! Total number of unique render ops processed */
		unsigned int                                  m_uiTotalOps;

		/*! Total number of unique polygons processed */
		unsigned int                                  m_uiUniquePolygons;

		/*! Total number of polygons processed */
		unsigned int                                  m_uiTotalPolygons;

		/*! Total number of texture changes for each texture unit */
		unsigned int                                  m_auiTextureChanges[16];

		/*! Number of unique textures set for each texture unit */
		unsigned int                                  m_auiUniqueTextures[16];

		/*! Used texture IDs for each texture unit */
		std::vector< unsigned int >                   m_vuiUniqueTextureIDs[16];


		/**
		* \param pkDevice                             Parent device object
		*/
		                                              FrameStatistics( Device *pkDevice ) : m_pkDevice( pkDevice ) { Reset(); }

		/**
		* Reset statistics
		*/
		void                                          Reset() { m_uiTotalOps = m_uiUniquePolygons = m_uiTotalPolygons = 0; memset( m_auiTextureChanges, 0, sizeof( unsigned int ) * 16 ); memset( m_auiUniqueTextures, 0, sizeof( unsigned int ) * 16 ); for( unsigned int uiUnit = 0; uiUnit < 16; ++uiUnit ) m_vuiUniqueTextureIDs[ uiUnit ].clear(); }

		/**
		* Generate statistics string
		* \return                                     Statistics string
		*/
		std::string                                   GenerateString();
};


}; // namespace NeoOGL


#endif
