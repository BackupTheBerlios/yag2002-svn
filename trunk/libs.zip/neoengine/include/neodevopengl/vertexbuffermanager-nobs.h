/***************************************************************************
     vertexbuffermanager-nobs.h  -  Vertex buffer allocation manager
	               without backing storage capabilities
                             -------------------
    begin                : Sat May 10 2003
    copyright            : (C) 2003 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevOpenGL, vertexbuffermanager-nobs.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOGLVERTEXBUFFERMANAGER_NOBS_H
#define __NEOGLVERTEXBUFFERMANAGER_NOBS_H



/**
  * \file vertexbuffermanager-nobs.h
  * Vertex buffer allocation manager without backing storage
  */


#include "vertexbuffermanager.h"


namespace NeoOGL
{


/**
  * Manages vertex buffer allocations from backing store
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class VertexBufferManagerNOBS : public VertexBufferManager
{
	protected:




	public:

		/**
		* \param pkDevice                                   Device object
		*/
		                                                    VertexBufferManagerNOBS( Device *pkDevice );

		/**
		* Free memory
		*/
		virtual                                            ~VertexBufferManagerNOBS();

		/**
		* Create a new vertex buffer object
		* \param uiType                                     Buffer type
		* \param uiNumVertices                              Number of vertices
		* \param pkFormat                                   Flexible vertex format declaration
		* \param pData                                      Optional pointer to data to load buffer with
		* \return                                           Ptr to new vertex buffer
		*/
		virtual NeoEngine::VertexBufferPtr                  CreateVertexBuffer( unsigned int uiType, unsigned int uiNumVertices, const NeoEngine::VertexDeclaration *pkFormat, const void *pData );
};


}; // namespace NeoOGL


#endif
