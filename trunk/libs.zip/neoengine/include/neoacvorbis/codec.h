/***************************************************************************
                          codec.h  -  Ogg Vorbis codec
                             -------------------
    begin                : Wed Mar 17 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoACVorbis, codec.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOACVORBIS_CODEC_H
#define __NEOACVORBIS_CODEC_H

#include <neoengine/base.h>
#include <neoengine/sound.h>
#include <neoengine/file.h>

namespace NeoACVorbis
{


/**
  * \brief Ogg Vorbis sound codec
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class Codec : public NeoEngine::SoundCodec
{
	public:

		/**
		* \param rstrFiletypeName                          File type name
		* \param rvstrExtensions                           File type extensions
		*/
		                                                   Codec( const std::string &rstrFiletypeName, const std::vector< std::string > &rvstrExtensions );

		/**
		*/
		virtual                                           ~Codec();

		/**
		* Check if file is type (must NOT change file offset!)
		* \param pkFile                                    File
		* \return                                          true if type, false if not
		*/
		virtual bool                                       IsType( NeoEngine::File *pkFile );

		/**
		* Create a sound stream
		* \param pkFile                                    File
		* \return                                          Ptr to new SoundStream object
		*/
		virtual NeoEngine::SoundStream                    *GetStream( NeoEngine::File *pkFile );
};


};


#endif
