/***************************************************************************
                        stream.h  -  Ogg Vorbis stream
                             -------------------
    begin                : Wed Mar 17 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoACVorbis, stream.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEOACVORBIS_STREAM_H
#define __NEOACVORBIS_STREAM_H

#include "codec.h"

#include "ogg/ogg.h"
#include "vorbis/vorbisfile.h"

#include <neoengine/sound.h>
#include <neoengine/file.h>


namespace NeoACVorbis
{


/**
  * \brief WAV sound stream
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class Stream : public NeoEngine::SoundStream
{
	protected:

		/*! The vorbis stream */
		OggVorbis_File                                     m_kVorbis;

	public:


		/**
		* \param pkFile                                    Sound file
		* \param pkCodec                                   Sound codec
		*/
		                                                   Stream( NeoEngine::File *pkFile );

		/**
		*/
		virtual                                           ~Stream();

		/**
		* Reset the stream to start
		*/
		virtual void                                       Reset();

		/**
		* Decode a chunk of data
		* \param pucBuffer                                 Target buffer
		* \param uiBytes                                   Maximum number of bytes to decode (maximum size of buffer)
		* \return                                          Number of bytes decoded
		*/
		virtual unsigned int                               Decode( unsigned char *pucBuffer, unsigned int uiBytes );
};


size_t read_stream( void*, size_t, size_t, void* );
int    seek_stream( void*, ogg_int64_t, int );
int    close_stream( void* );
long   tell_stream( void* );


};


#endif
