/***************************************************************************
                    device.h  -  DirectSound sound device
                             -------------------
    begin                : Wed Mar 17 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevDSound, device.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2003
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEDSOUND_DEVICE_H
#define __NEDSOUND_DEVICE_H

#include <windows.h>

#include <neoengine/base.h>
#include <neoengine/audio.h>

#include <dsound.h>


namespace NeoDSound
{


/**
  * \brief DirectSound device implementation
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class AudioDevice : public NeoEngine::AudioDevice
{
	friend class Sound;

	protected:

		/*! DirectSound object */
		IDirectSound8                                     *m_pkDS;
	
		/*! Primary buffer */
		IDirectSoundBuffer8                               *m_pkPrimaryBuffer;


	public:

		/**
		* \param pkFileManager                             File manager, will use core global object if null (default)
		*/
		                                                   AudioDevice( NeoEngine::FileManager *pkFileManager = 0 );

		/**
		*/
		virtual                                           ~AudioDevice();

		/**
		* Open the audio device
		* \param rkWindow                                  Window to initialize sound device in
		*/
		virtual bool                                       Open( const NeoEngine::RenderWindow &rkWindow );

		/**
		* Close the audio device
		*/
		virtual void                                       Close();

		/**
		* Load a sound file. Implement in derived class
		* \param rstrFilename                              File name
		* \return                                          Ptr to sound
		*/
		virtual NeoEngine::Sound                          *LoadSound( const std::string &rstrFilename );
};


};

#endif
