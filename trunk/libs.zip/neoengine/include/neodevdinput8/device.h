/***************************************************************************
                    device.h  -  Export symbols for engine
                             -------------------
    begin                : Wed Sep 24 2003
    copyright            : (C) 2003 by emedia-solutions wolf
    email                : markus@emedia-solutions-wolf.de
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevDInput8, device.h

 The Initial Developer of the Original Code is Markus Wolf.
 Portions created by Markus Wold are Copyright (C) 2003
 emedia-solutions wolf. All Rights Reserved.

 ***************************************************************************/
#ifndef __NEDIDEVICE_H
#define __NEDIDEVICE_H

#ifndef WIN32_LEAN_AND_MEAN
#  define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>

#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>

#include <neoengine/input.h>
#include <neoengine/logstream.h>

namespace NeoDI
{

class Device : public NeoEngine::InputDevice  
{
protected:
	enum MOUSECOLLECTSTATE
	{
		COLLECT        = 1,
		CHECKAXIS,
		CHECKBUTTON1,
		CHECKBUTTON2,
		CHECKBUTTON3,
		CHECKBUTTON4,
		CHECKBUTTON5,
		CHECKBUTTON6,
		CHECKBUTTON7,
		CHECKBUTTON8
	};

	LPDIRECTINPUT8                  m_pkDI;
	LPDIRECTINPUTDEVICE8            m_pkKeyboard;
	LPDIRECTINPUTDEVICE8            m_pkMouse;
	HWND                            m_hWnd;
	DIMOUSESTATE2                   m_kMouseData;
	int                             m_iKeyIndex;
	char                            m_aKeyData[256];
	int								m_eMouseCollectState;

	bool                            m_bKeyboardInitialized;
	bool                            m_bKeyboardBuffered;
	bool                            m_bMouseInitialized;
	bool                            m_bMouseBuffered;

	int                             m_iZeroX;
	int                             m_iZeroY;
	int                             m_iZeroZ;
	int                             m_iX;
	int                             m_iY;
	int                             m_iZ;
	int                             m_iButtonState;

public:
	static HINSTANCE                s_hInstance;

public:
	                                Device( HWND hWnd, NeoEngine::InputManager *pkInputManager );
	virtual                         ~Device();

	/**
	* Collect input events
	* \param pkEvent                Event object to fill with data
	* \return                       true if events was collected, false if not
	*/
	virtual bool                    Collect( NeoEngine::InputEvent *pkEvent );
	virtual void                    SetMouseRange( int left, int right, int top, int bottom );
	virtual void                    ToggleKeyboardInputMethod();
	virtual void                    ToggleMouseInputMethod();


protected:
	virtual void                    InitializeMouse();
	virtual void                    InitializeKeyboard();
	virtual void                    ReleaseMouse();
	virtual void                    ReleaseKeyboard();
	virtual bool                    CollectMouse( NeoEngine::InputEvent *pkEvent );
	virtual bool                    CollectBufferedMouse( NeoEngine::InputEvent *pkEvent );
	virtual bool                    CollectKeyboard( NeoEngine::InputEvent *pkEvent );
	virtual bool                    CollectBufferedKeyboard( NeoEngine::InputEvent *pkEvent );
	virtual bool                    SetBufferSize( IDirectInputDevice8 *pkDevice, int iSize );
	virtual NeoEngine::InputEvent*  CreateEventByKeyCode( int iCode, int iType );
};

}; /* namespace */

#endif /* __NEDIDEVICE_H */
