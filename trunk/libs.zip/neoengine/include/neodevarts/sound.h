/***************************************************************************
                     sound.h  -  Sound classes and codecs
                             -------------------
    begin                : Wed Mar 17 2004
    copyright            : (C) 2004 by Reality Rift Studios
    email                : mattias@realityrift.com
 ***************************************************************************

 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoDevALSA, sound.h

 The Initial Developer of the Original Code is Mattias Jansson.
 Portions created by Mattias Jansson are Copyright (C) 2004
 Reality Rift Studios. All Rights Reserved.

 ***************************************************************************/

#ifndef __NEARTS_SOUND_H
#define __NEARTS_SOUND_H

#include "device.h"

#include <neoengine/sound.h>
#include <neoengine/thread.h>

#include <string>
#include <vector>


namespace NeoArts
{


/**
  * \brief Sound (2D stereo sound)
  * \author Mattias Jansson (mattias@realityrift.com)
  */
class Sound : public NeoEngine::Sound, public NeoEngine::ThreadMethod
{
	protected:

		/*! Device */
		AudioDevice                                       *m_pkDevice;

		/*! Thread */
		NeoEngine::Thread                                 *m_pkThread;
	
		/*! Paused state */
		bool                                               m_bPaused;
		
	public:

		/**
		* \param pkDevice                                  Device
		* \param rstrName                                  Name
		* \param pkStream                                  Sound stream
		*/
		                                                   Sound( AudioDevice *pkDevice, const std::string &rstrName, NeoEngine::SoundStream *pkStream );

		/**
		*/
		virtual                                           ~Sound();

		/**
		* Play the sound
		* \param bLoop                                     Loop
		*/
		virtual void                                       Play( bool bLoop = false );

		/**
		* Pause the sound. Next Play call will resume sound from paused position
		*/
		virtual void                                       Pause();

		/**
		* Stop playing the sound
		*/
		virtual void                                       Stop();

		/**
		* Thread execution entry point
		* \param pkThread                                  Thread object
		* \param pData                                     Pointer to thread-specific data
		*/
		virtual void                                      *ThreadEntry( NeoEngine::Thread *pkThread, void *pData );
};


};


#endif

