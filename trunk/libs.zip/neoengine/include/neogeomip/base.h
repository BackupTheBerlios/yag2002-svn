/***************************************************************************
                 base.h  -  Base defines for mip terrain
                             -------------------
    begin                : Thu Mar 18 2004
    copyright            : (C) 2004 by Cody Russell
    email                : cody `at' jhu.edu
 ***************************************************************************
 
 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoGeoMip, base.h

 The Initial Developer of the Original Code is Cody Russell.
 Portions created by Cody Russell are Copyright (C) 2004
 Cody Russell. All Rights Reserved.
 
 ***************************************************************************/
 
#ifndef __NEOGEOMIP_BASE_H
#define __NEOGEOMIP_BASE_H
 
#if defined(HAVE_CONFIG_H) && defined(NEOENGINE_INTERNALS)
#  include "buildconfig.h"
#endif

#include <neoengine/base.h>
#include <neoengine/terrain.h>

#define NEOGEOMIPVERSION_MAJOR             NEOENGINEVERSION_MAJOR
#define NEOGEOMIPVERSION_MINOR             NEOENGINEVERSION_MINOR
#define NEOGEOMIPVERSION_REVISION          NEOENGINEVERSION_REVISION

#define NEOGEOMIPVERSIONSTRING             NEOENGINEVERSIONSTRING

                                                                                
#ifdef WIN32
                                                                                
#  ifdef _MSC_VER
#    pragma warning( disable : 4231 )
#  endif

#  define NEOGEOMIP_API
#  define NEOGEOMIPEXPIMP_TEMPLATE
#  define GEOMIPUDTVectorEXPIMP(classname)

#elif defined(POSIX) || defined(__APPLE__)
                                                                                
#  define NEOGEOMIP_API
#  define NEOGEOMIP_TEMPLATE
                                                                                
#  define GEOMIPUDTVectorEXPIMP(classname)
                                                                                
#else
#  error "Platform uninplemented"
#endif

#endif // __NEOGEOMIP_BASE_H
