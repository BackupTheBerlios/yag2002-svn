/***************************************************************************
                terrain.h  -  GeoMipMap terrain implementation
                             -------------------
    begin                : Thu Feb 26 2004
    copyright            : (C) 2004 by Cody Russell
    email                : cody `at' jhu.edu
 ***************************************************************************
 
 The contents of this file are subject to the Mozilla Public License Version
 1.1 (the "License"); you may not use this file except in compliance with
 the License. You may obtain a copy of the License at 
 http://www.mozilla.org/MPL/

 Software distributed under the License is distributed on an "AS IS" basis,
 WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 for the specific language governing rights and limitations under the
 License.

 The Original Code is the NeoEngine, NeoGeoMip, terrain.h

 The Initial Developer of the Original Code is Cody Russell.
 Portions created by Cody Russell are Copyright (C) 2004
 Cody Russell. All Rights Reserved.
 
 ***************************************************************************/
 
#ifndef __NEGEOMIP_TERRAIN_H
#define __NEGEOMIP_TERRAIN_H
 
#include "base.h"

#include <neoengine/render.h>
#include <neoengine/terrain.h>
 
/**
  * \file terrain.h
  * \author Cody Russell <cody jhu edu>
  * This is a terrain method for NeoEngine based upon the geomipmap algorithm.
  * It decreases the number of triangles rendered at runtime by checking the
  * camera distance and automatically adjusting the resolution of the terrain
  * blocks.  Terrain blocks that are nearer to the camera will be rendered in
  * higher detail than those farther from the camera.
  */


namespace NeoGeoMip
{


class MipTerrain;
class MipTerrainBlock;


/**
  * \brief Internal data for MipTerrainBlock
  * This is internal data used by MipTerrainBlock.
  * \author Cody Russell <cody jhu edu>
  */
class NEOGEOMIP_API MipData
{
	public:

		/*! Our polygon buffer */
		NeoEngine::PolygonBufferPtr                    m_pkPolygons;

		/*! Used for internal vertex counting */
		int                                            m_iIncrement;

		                                               MipData( MipTerrainBlock *pkBlock, int i, int iIncrement, int iSize );
};


#ifdef WIN32
 
#ifndef __HAVE_VECTOR_MIPDATA
     GEOMIPUDTVectorEXPIMP( MipData* );
#    define __HAVE_VECTOR_MIPDATA
#  endif
 
#endif // WIN32



/**
  * \brief GeoMipMap terrain block
  * This object derived from NeoEngine::TerrainBlock and implements the majority
  * of the functionality used in this mip terrain engine.  It doesn't contain a
  * polygon buffer, but instead contains a vector of mipmap data objects, each of
  * which hold their own polygon buffer.  Those all refer to a single vertex
  * buffer.
  * \author Cody Russell <cody jhu edu>
  */
class NEOGEOMIP_API MipTerrainBlock : public NeoEngine::TerrainBlock
{
	friend class MipData;

	protected:

		MipTerrain                                    *m_pkMipPage;

		int                                            m_iOffset;

		NeoEngine::Matrix                              m_kLastTransform;

		/*! The current level of detail.  This is updated automatically. */
		int                                            m_iCurrentLOD;

		/*! Pre-computed table of squared distance values. */
		float                                         *m_pfDistanceTable;

		/*! The center of the block */
		NeoEngine::Vector3d                            m_kCenter;

		/*! Our material generator */
		NeoEngine::TerrainMaterialFactory             *m_pkMaterialFactory;

		/*! Our vertex buffer */
		NeoEngine::VertexBufferPtr                     m_pkVertices;

		/*! Our vector of mip data, including polygon buffers. */
		std::vector< MipData* >                        m_vpkData;

		/**
		* Calculate the current level of detail.  This is called automatically.
		*/
		void                                           CalculateLOD();

		/**
		* Calculate distance data for mip changes
		*/
		void                                           PrecomputeDistances();

	public:

		virtual NeoEngine::VertexBufferPtr            &GetVertexBuffer();

		virtual NeoEngine::PolygonBufferPtr           &GetPolygonBuffer();

		virtual bool                                   Render( NeoEngine::Frustum *pkFrustum, bool bForce = false );

		virtual void                                   GenerateAABB();

		                                               MipTerrainBlock( int iXOffset, int iYOffset, int iSize, int iIndex, NeoEngine::TerrainMaterialFactory *pkMaterialFactory, MipTerrain *pkPage );

		virtual                                       ~MipTerrainBlock();

        protected:

		virtual void                                   UpdateData();
};


/**
  * The mip terrain system
  * \author Cody Russell <cody jhu edu>
  */
class NEOGEOMIP_API MipTerrain : public NeoEngine::TerrainPage
{
        protected:

                float                                         m_fMaxError;

		bool                                          m_bCallbackInstalled;

	public:

		                                              MipTerrain( NeoEngine::TerrainHeightmap *pkHeightmap, NeoEngine::TerrainMaterialFactory *pkMaterialFactory, int iDepth );

		virtual                                      ~MipTerrain() {}

		virtual bool                                  Render( NeoEngine::Frustum *pkFrustum, bool bForce = false ) { return false; }

		void                                          SetMaxError( float fError ) { m_fMaxError = fError; }
};


/**
  * The mip terrain manager object
  * \author Cody Russell <cody jhu edu>
  */
class NEOGEOMIP_API MipTerrainManager : public NeoEngine::TerrainManager
{
	protected:

		int                                 m_iDetailLevels;

        public:

	                                            MipTerrainManager() { m_iDetailLevels = 4; }

	        virtual                            ~MipTerrainManager() { }

		void                                SetMaxDetailLevels( int iLevels ) { m_iDetailLevels = iLevels; }

		int                                 GetMaxDetailLevels() { return m_iDetailLevels; }

	        virtual NeoEngine::TerrainPage*     CreateTerrain( NeoEngine::TerrainHeightmap *pkHeightmap, NeoEngine::TerrainMaterialFactory *pkMaterialFactory );
};


}; // namespace NeoGeoMip

#endif // __NEBRUTE_TERRAIN_H
