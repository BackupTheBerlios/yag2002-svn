//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by OSGExp.rc
//
#define IDS_LIBDESCRIPTION              1
#define IDS_CATEGORY                    2
#define IDS_CLASS_NAME                  3
#define IDS_PARAMS                      4
#define IDS_SHORTDESC                   5
#define IDS_LONGDESC                    6
#define IDS_EXTENSION                   7
#define IDS_COPYRIGHT                   8
#define IDS_PROGRESS_MSG                9
#define IDS_VERSIONSTRING               10
#define IDS_AUTHORNAME                  11
#define IDD_PANEL                       101
#define IDD_EXPORTBOX                   101
#define IDD_ABOUTBOX                    102
#define IDC_CLOSEBUTTON                 1000
#define IDC_DOSTUFF                     1000
#define IDC_MATERIALS                   1006
#define IDC_TEXTURES                    1007
#define IDC_HIDDENNODES                 1008
#define IDC_BACKFACECULLING             1009
#define IDC_LIGHTS                      1009
#define IDC_FLIPNORMALS                 1010
#define IDC_GEOMETRY                    1010
#define IDC_NORMALIZE                   1011
#define IDC_TEXTURECOORDS               1012
#define IDC_VERTEXNORMALS               1013
#define IDC_TEXFORMAT                   1014
#define IDC_VERTEXCOLORS                1015
#define IDC_CAMERAS                     1016
#define IDC_ANIMATIONS                  1017
#define IDC_WHITENTEXMAT                1018
#define IDC_TEXCOMPRESSION              1019
#define IDC_HELPERS                     1020
#define IDC_TRISTRIP                    1021
#define IDC_WHITENSELFILLUM             1021
#define IDC_WRITETEXTURE                1022
#define IDC_SAVEFILE                    1023
#define IDC_QUICKVIEW                   1024
#define IDC_PARTICLES                   1025
#define IDC_USEINDICES                  1026
#define IDC_INCLUDEIMAGEDATA            1027
#define IDC_ABOUT                       1028
#define IDC_SHOWERRMSG                  1028
#define IDC_USENODEMASK                 1029
#define IDC_NODEMASKVALUE               1032
#define IDC_IPADDRESS2                  1033
#define IDC_EXPORT_OM_ALPHABLENDED      1034
#define IDC_EXPORT_OM_TEXENVCOMBINE     1035
#define IDC_SPATIALIZEGROUPS            1036
#define IDC_TRISTRIPGEOMETRY            1037
#define IDC_MERGEGEOMETRY               1038
#define IDC_FLATTENSTATICTRANSFORM      1039
#define IDC_SHAREDUPLICATESTATES        1040
#define IDC_EXPORTGLSL                  1041
#define IDC_EXPORT_GLSL                 1041
#define IDC_COLOR                       1456
#define IDC_EDIT                        1490
#define IDC_SPIN                        1496

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
